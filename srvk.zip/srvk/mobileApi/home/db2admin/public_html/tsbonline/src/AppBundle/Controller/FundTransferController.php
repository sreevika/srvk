<?php

/*
 * Class For Transfering Money to Benificiary
 * Start Date           :11-04-2016
 * Last Updated         :03-07-2017
 * Author               :NIC
 */

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\ProfilePassword\ProfilePasswordType;
use AppBundle\Form\OTP\OtpType;
use AppBundle\Form\Funds\ScheduleNextDayType;
use AppBundle\Form\Funds\FundsTransferCancelType;
use AppBundle\Form\Funds\FundsTransferType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use JMS\Serializer\SerializationContext;
use AppBundle\Interfaces\AuditableControllerInterface;
use Symfony\Component\Form\FormError;
use AppBundle\Form\Funds\ScheduleConfirmType;
use Symfony\Component\HttpFoundation\Response;
class FundTransferController extends Controller implements AuditableControllerInterface {
    /*
     * Transfering of Money from Customer Account to Benfficiary Takes place here
     * @var request
     * Getting Beneficiary Details and Amount to which the Fund Transfer is performed
     */

    public function ShowFundsTabAction(Request $request) {

        return $this->render('AppBundle:Funds:manageFundsTab.html.twig', array('menu' => 'funds'));
    }

    public function viewTransactionAction(Request $request) {
        $userName = $this->getUser()->getUserName();
        $accList = $this->get('customer_account_list');
        $accno = $accList->UserDetails($userName);

        return $this->render('AppBundle:Funds:viewTrans.html.twig', array('accno' => $accno));
    }

    public function listScheduleAction(Request $request) {
        $dbConnection = $this->get('database_connection');
        $accno = $request->request->get('accno');
        $option = $request->request->get('optionTypemode');
        $paymntStatus = $request->request->get('paymntStatus');
        $fromDate = $request->request->get('fromDate');
        $toDate = $request->request->get('toDate');
        $paymntStatuswherecondtn = '';
        $dateQuery = '';
        if ($option != 4) {
            if ($option == 2) {
                $iniStatus = "AND INITIATE_STATUS='PN'";
            } else if ($option == 3) {
                $iniStatus = "AND INITIATE_STATUS='SL'";
            } else
                $iniStatus = "";


            if ($paymntStatus == 1) {
                $paymntStatuswherecondtn = " AND PROCESS_STATUS='S'";
            } else if ($paymntStatus == 2) {
                $paymntStatuswherecondtn = " AND (PROCESS_STATUS IS NULL)";
            } else if ($paymntStatus == 3) {
                $paymntStatuswherecondtn = " AND (PROCESS_STATUS='C')";
            } else if ($paymntStatus == 4) {
              //  $paymntStatuswherecondtn = " AND (PROCESS_STATUS='F' $customerID)";
                $paymntStatuswherecondtn = " AND (PROCESS_STATUS='F' )";
            }
            if ($fromDate != '' && $toDate != '') {
                list($date, $month, $year) = explode('/', $fromDate);

                $fromDate = $year . "-" . $month . "-" . $date;

                list($dateto, $monthto, $yearto) = explode('/', $toDate);

                $toDate = $yearto . "-" . $monthto . "-" . $dateto;
                $dateQuery = " AND DATE(DATE) BETWEEN '" . $fromDate . "' AND  '" . $toDate . "'";
            }
            $selectSI = "SELECT A.*,B.ACCTYPE_DES,C.BENEFICIARY_NAME FROM TSBONLINE_SCHEDULE A LEFT JOIN SB_ACCTYPE B ON A.ACC_TYPE=B.ACCTYPE LEFT JOIN TSBONLINE_BENEFICIARYMASTER C ON A.BENEF_ID=C.BENEFICIARY_ID   WHERE A.ACC_NO=?  " . $iniStatus . $paymntStatuswherecondtn . $dateQuery;
            $statement = $dbConnection->prepare($selectSI);
            $statement->bindValue(1, $accno, \PDO::PARAM_INT);
            $statement->execute();
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $this->render('AppBundle:Funds:listSchedule.html.twig', array('results' => $result));
        } else {
            $selectSI = "SELECT A.*,B.ACCTYPE_DES,C.BENEFICIARY_NAME,D.DECSRIPTION AS DESCRIPTION,E.DECSRIPTION,F.SI_ID AS SID FROM TSBONLINE_STANDNG_INSTRUCTON A LEFT JOIN SB_ACCTYPE B ON A.ACC_TYPE=B.ACCTYPE LEFT JOIN TSBONLINE_BENEFICIARYMASTER C ON A.BENEF_ID=C.BENEFICIARY_ID AND A.ACC_NO=C.PARENT_ACCNO AND A.ACC_TYPE=C.PARENT_ACCTYPE   LEFT JOIN TSBONLINE_TIME_PERIOD D ON A.TIME_PERIOD=D.PERIOD_CODE LEFT JOIN TSBONLINE_TIME_UNIT E ON A.TIME_UNIT=E.UNIT_CODE and  A.TIME_PERIOD=E.PERIOD_CODE LEFT JOIN TSBONLINE_SCHEDULE F ON A.SI_ID=F.SI_ID WHERE A.ACC_NO=?";
            $statement = $dbConnection->prepare($selectSI);
            $statement->bindValue(1, $accno, \PDO::PARAM_INT);
            $statement->execute();
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $this->render('AppBundle:Funds:listSIview.html.twig', array('results' => $result));
        }
    }

    public function transferMoneyAction(Request $request) {
        $user = $this->getUser();
        if (!$user) {
            return $this->render('AppBundle:Default:publicpage.html.twig');
        } else {
            $userName = $user->getUsername();
            $accList = $this->get('customer_account_list');
            $accountDetails = $accList->UserDetails($userName);
            $form = $this->createForm(new FundsTransferType($accountDetails), null, array('action' => $this->generateUrl('manage_fund_transfer')));

            $form->handleRequest($request);
            $accnum = $form->get('accountDetails')->getData();

            if ($form->isValid()) {


                $today = new \DateTime("now");
                $today = $today->format('Y-m-d H:i:s');

                $benficiaryId = $form->get('benifficiaryid')->getData();
                $benifficiaryDetails = $this->get('transaction_limit')->getBeneficiary($accnum, $benficiaryId);
                $trans_type = $benifficiaryDetails[0]['TRANS_TYPE'];


                $timeConstraint = "19:00:00";

                $transLimit = $this->get('transaction_limit');

                if ($trans_type == 'O') {
                    if (strtotime("now") <= strtotime($timeConstraint) && ($trans_type == 'O')) {

                        $transLimit = $this->get('transaction_limit');
                        $transferLimit = $transLimit->transferLimit($accnum, $benficiaryId);
                        $amountPayable = $form->get('Amount')->getData();
                        $remarks = $form->get('remarks')->getData();
                        $payOption = $form->get('payOptions')->getData();
                        $scheduleDate = $form->get('date')->getData();
                        if ($transferLimit > $amountPayable || $transferLimit == 0) {
                            $this->get('session')->set('userAccno', array('accounts' => $accnum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $scheduleDate));
                            return $this->redirect($this->generateUrl('fundtransfer_autentication'));
                        } else {

                            $messag = 'Transaction Limit exceeded cant Proceed';
                            return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail'));
                        }
                    } else {


                        $transLimit = $this->get('transaction_limit');
                        $transferLimit = $transLimit->transferLimit($accnum, $benficiaryId);


                        $amountPayable = $form->get('Amount')->getData();

                        $remarks = $form->get('remarks')->getData();
                        $payOption = $form->get('payOptions')->getData();
                        $scheduleDate = $form->get('date')->getData();
                        if ($transferLimit > $amountPayable || $transferLimit == 0) {
                            $this->get('session')->set('userAccno', array('accounts' => $accnum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $scheduleDate));
                            return $this->redirect($this->generateUrl('confirm_fund_shedule'));
                        } else {

                            $messag = 'Transaction Limit exceeded Cant Proceed';
                            return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail'));
                        }
                    }
                } else {

                    $transLimit = $this->get('transaction_limit');
                    $transferLimit = $transLimit->transferLimit($accnum, $benficiaryId);
                    $amountPayable = $form->get('Amount')->getData();
                    $remarks = $form->get('remarks')->getData();
                    $payOption = $form->get('payOptions')->getData();
                    $scheduleDate = $form->get('date')->getData();
                    if ($transferLimit > $amountPayable || $transferLimit == 0) {
                        $this->get('session')->set('userAccno', array('accounts' => $accnum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $scheduleDate));
                        return $this->redirect($this->generateUrl('fundtransfer_autentication'));
                    } else {

                        $messag = 'Transaction Limit exceeded cant Proceed';
                        return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail'));
                    }
                }
            }
            return $this->render('AppBundle:Funds:funds.html.twig', array('fundtransfer' => $form->createView()));
        }
    }

    /*
     * Load Beneficiaries available for a particular Account No. to the select box
     */

    public function loadBeneficiaryNameAction(Request $request, $benftype) {

        $dbConnection = $this->get('database_connection');
        $accno = $request->request->get('accno');
        $serializer = $this->get('jms_serializer');

        $selectBeneficiary = "SELECT BENEFICIARY_ID,BENEFICIARY_NAME FROM TSBONLINE_BENEFICIARYMASTER WHERE PARENT_ACCNO=? AND TRANS_TYPE=?";
        $statement = $dbConnection->prepare($selectBeneficiary);

        $statement->bindValue(1, $accno, \PDO::PARAM_INT);
        $statement->bindValue(2, $benftype);
        $statement->execute();
        $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $beneficiaryList = null;

        foreach ($result as $item) {
            $beneficiaryList[$item['BENEFICIARY_ID']] = $item['BENEFICIARY_NAME'];
        }
        $sboxResult = $serializer->serialize($beneficiaryList, 'json', SerializationContext::create()->setGroups(array('sbox_en')));




        return new JsonResponse($sboxResult);
    }

    /*
     * Fetch the details of the selected Beneficiary form select box
     */

    public function fetchBeneficiaryDetailsAction(Request $request) {
        $result=null;$bankName=null;$branchName=null;
        $dbConnection = $this->get('database_connection');
        $user = $this->getUser();
        $customerID = $user->getID();
        $transType = $request->request->get('benftype');
        $parentAccno = $request->request->get('parentAccno');
        if (strcmp($transType, "O") == 0) {
            $selectBeneficiary = "SELECT * FROM TSBONLINE_BENEFICIARYMASTER  a join tsbonline_bank_maste b on a.BANK_ID=b.BANK_CODE   AND PARENT_CUSTOMER_ID=? AND TRANS_TYPE=? AND ACTIVATED = 'Y'";
        } else {
            $selectBeneficiary = "SELECT * FROM TSBONLINE_BENEFICIARYMASTER  WHERE PARENT_CUSTOMER_ID=? AND TRANS_TYPE=?  AND ACTIVATED = 'Y' ";
        }
        //return new Response($customerID." ".$transType." ".$parentAccno);
        //exit;
        $stateMent = $dbConnection->prepare($selectBeneficiary);
        $stateMent->bindValue(1, $customerID, \PDO::PARAM_INT);
        $stateMent->bindValue(2, $transType);
        //$stateMent->bindValue(3, $parentAccno);
        $stateMent->execute();
        $result = $stateMent->fetchAll(\PDO::FETCH_ASSOC);
        if($result)
        {
        $bankCode = $result[0]['BANK_ID'];
        $ifsCode = $result[0]['IFS_CODE'];
        if ($bankCode !== '' && $ifsCode !== '') {
            $ifscDetails = $this->get('get_branch_from_ifsc');
            $ifscArray = $ifscDetails->getifscDetailsFromCoretis($bankCode, $ifsCode);
            $ifscArray = json_decode($ifscArray, true);
            $bankName = $ifscArray['BANK_NAME'];
            $branchName = $ifscArray['BRANCH_NAME'];
        }
        }

        return $this->render('AppBundle:Funds:listAmtTransferBeneficiary.html.twig', array('results' => $result, 'from' => 'fundTransfer', 'transType' => $transType, 'bankName' => $bankName, 'branchName' => $branchName));
    }

    /*
     * Secondary password checking for authentication
     */

    public function checkSecondaryPasswordAction(Request $request) {
        $user = $this->getUser();
        $salt = $user->getKeySalt();
        $pwd = new ProfilePasswordType($salt);
        $form = $this->createForm($pwd, null, array('action' => $this->generateUrl('fundtransfer_autentication',array('menu' => 'funds'))));
        $messag = '';
        $status = 'success';
        $form->handleRequest($request);
        $profPwd = $form['profilePassword']->getData();
        if ($form->isValid() && $profPwd != '') {
            $user = $this->container->get('security.token_storage')->getToken()->getUser()->getUsername();
            $transKey = $this->get('transaction_key');
            $secondaryPassword = $transKey->checkTransPassForCurrentUser($profPwd);
            if ($secondaryPassword) {
                $fundDet = $this->get('session')->get('userAccno');
                $option = ($fundDet['option']);
                if ($option == 1) {
                    return $this->redirect($this->generateUrl('fundtransfer_otp',array('menu' => 'funds')));
                } else {
                    return $this->redirect($this->generateUrl('fundtransfer_otp',array('menu' => 'funds')));
                    //return $this->redirect($this->generateUrl('schedule_later',array('menu' => 'funds')));
                }
            } else {
                return $this->render('AppBundle:Message:message.html.twig', array('message' => 'Your Transaction Password seems to be Wrong. Please try again. Thank You.', 'status' => 'fail','menu' => 'funds'));
            }
        }
        $session_helper = $this->get("session_helper");
        $salt = $session_helper->setSessionSalt();
        return $this->render('AppBundle:SecondaryPassword:transactionPassword.html.twig', array(
                    'form' => $form->createView(),
                    'status' => 'success',
                    'result' => '',
                    'salt' => $salt,
                    'message' => $messag,'menu' => 'funds'));
    }

    /*
     * OTP generation and checking
     */

    public function otpCheckAction(Request $request) {
        $dbConnection = $this->get('database_connection');
        $accNumber = $this->get('session')->get('userAccno');
        $accnum = ($accNumber['accounts']);
        $user = $this->getUser();

        $userName = $user->getUsername();


        $customerID = "SELECT CUSTOMER_ID FROM TSB_CUSTOMER_ACCOUNT A,TSB_ACCMAST B WHERE A.ACCNO=B.ACCNO AND A.ACCNO=?";
        $statement1 = $dbConnection->prepare($customerID);
        $statement1->bindValue(1, $accnum, \PDO::PARAM_INT);
        $statement1->execute();
        $reslt1 = $statement1->fetchAll(\PDO::FETCH_ASSOC);
        if ($reslt1) {
            $customerID = $reslt1[0]['CUSTOMER_ID'];
            $smsMessage = null;
            $otp = null;
            $dbConnection = $this->get('database_connection');
            $accnoQuery = 'SELECT MOBILE FROM TSBONLINE_PORTAL_USERS WHERE CUSTOMERID=?';
            $statement2 = $dbConnection->prepare($accnoQuery);
            $statement2->bindValue(1, $customerID, \PDO::PARAM_INT);
            $statement2->execute();
            $result2 = $statement2->fetchAll(\PDO::FETCH_ASSOC);
            if ($result2) {
                $mobileNumber = $result2[0]['MOBILE'];


                $otp = mt_rand(100000, 1000000);

                $otpTime = date('Y-m-d H:i:s');
                $smsMessage .= $otp . '. Do not share it with any one.';

                $sendotp = $this->get('app_sms_send_service');

                $otpString = $sendotp->sendSMS($mobileNumber, $smsMessage, $userName);
                $selectOtpQuery = "SELECT COUNT(*) AS CNT FROM tsbonline_funds_otp WHERE CUSTOMER_ID=?";
                $sTamentSelect = $dbConnection->prepare($selectOtpQuery);
                $sTamentSelect->bindValue(1, $customerID);
                $sTamentSelect->execute();
                $resultSelectcnt = $sTamentSelect->fetchAll(\PDO::FETCH_ASSOC);
                if ($resultSelectcnt) {
                    $otpCnt = $resultSelectcnt[0]['CNT'];
                }

                if ($otpCnt == 0) {



                    $otpUser = 'INSERT INTO tsbonline_funds_otp(CUSTOMER_ID,OTP,OTP_SENT_TIME,OTP_ATTEMPTED_COUNT) VALUES(?,?,?,?)';
                    $stmtOtp = $dbConnection->prepare($otpUser);
                    $stmtOtp->bindValue(1, $customerID);
                    $stmtOtp->bindValue(2, $otp);
                    $stmtOtp->bindValue(3, $otpTime);
                    $stmtOtp->bindValue(4, 0);
                    $stmtOtp->execute();
                } else {

                    $otpUser = 'UPDATE  tsbonline_funds_otp SET OTP =? ,OTP_SENT_TIME =? ,OTP_ATTEMPTED_COUNT= ? WHERE CUSTOMER_ID=? ';
                    $stmtOtp = $dbConnection->prepare($otpUser);

                    $stmtOtp->bindValue(1, $otp);
                    $stmtOtp->bindValue(2, $otpTime);
                    $stmtOtp->bindValue(3, 0);
                    $stmtOtp->bindValue(4, $customerID);
                    $stmtOtp->execute();
                }










                $status = 'success';
                $messag = '';
                $otpForm = new OtpType($accnum);
                $form = $this->createForm($otpForm, null, array('action' => $this->generateUrl('fundtransfer_otp_verify',array('menu' => 'funds'))));

                $mobilenumberpad = substr_replace($mobileNumber, "*****", 0, 7);
                $messag = null;
                return $this->render('AppBundle:OTP:otpMobile.html.twig', array(
                            'form' => $form->createView(),
                            'accno' => $accnum, 'mobilenumber' => $mobilenumberpad, 'message' => $messag, 'status' => 'sucess','menu' => 'funds'));
            } else {
                $messag = 'Mobile Number Not Registred';
                return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail','menu' => 'funds'));
            }
        } else {
            $messag = 'Account  Details not found';
            return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail','menu' => 'funds'));
        }
    }

    public function fundotpCheckverifyAction(Request $request) {
        $dbConnection = $this->get('database_connection');
        $fundTransferOtp = $request->request->get('acccountotp');
        $otp = $fundTransferOtp['otp'];
        $smsMessage = null;
        $user = $this->getUser();
        $customerID = $user->getID();
        $accnum = null;
        if ($otp != null) {

            $otpQuery = 'SELECT * FROM tsbonline_funds_otp WHERE CUSTOMER_ID=? AND OTP=?';
            $statement3 = $dbConnection->prepare($otpQuery);
            $statement3->bindValue(1, $customerID, \PDO::PARAM_INT);
            $statement3->bindValue(2, $otp, \PDO::PARAM_INT);
            $statement3->execute();
            $result3 = $statement3->fetchAll(\PDO::FETCH_ASSOC);
            if ($result3) {
                $details = $this->get('session')->get('userAccno');
                return $this->redirect($this->generateUrl('schedule_later'));
            } else {
                $mobilenumberpad = null;
                $otpForm = new OtpType($accnum);
                $form = $this->createForm($otpForm, null, array('action' => $this->generateUrl('fundtransfer_otp_verify')));
                $messag = 'The OTP you have entered is Wrong. Please try again. Thank You.';
                return $this->render('AppBundle:OTP:otpMobile.html.twig', array(
                            'form' => $form->createView(),
                            'accno' => $accnum, 'mobilenumber' => $mobilenumberpad, 'message' => $messag, 'status' => 'fail','menu'=>'funds'));
            }
        } else {
            $otpForm = new OtpType($accnum);
            $form = $this->createForm($otpForm, null, array('action' => $this->generateUrl('fundtransfer_otp_verify')));
            $messag = 'The OTP you have entered is Wrong. Please try again. Thank You.';
            return $this->render('AppBundle:OTP:otpMobile.html.twig', array(
                        'form' => $form->createView(),
                        'accno' => $accnum, 'mobilenumber' => $mobilenumberpad, 'message' => $messag, 'status' => 'fail','menu'=>'funds'));
        }
    }

    public function scheduleLaterAction(Request $request) {

        $dbConnection = $this->get('database_connection');
        $details = $this->get('session')->get('userAccno');


        $accNum = ($details['accounts']);
        $benefId = ($details['benificiary']);
        $amount = ($details['amount']);
        $option = ($details['option']);
        $remark = ($details['remarks']);
        $today = new \DateTime("now");
        $todayNow = $today->format('Y-m-d H:i:s');
        $dateToday = $today->format('Y-m-d H:i:s');


        if ($option == 2) {
            $date = ($details['date']);
            //$dateToday = $date->format('Y-m-d H:i:s');

            $dateToday = implode('-', array_reverse(explode('/', $date)));


            $dateToday = date('Y-m-d H:i:s', strtotime($dateToday));
        } else if ($option == 3) {
            $date = ($details['date']);
            $date = implode('-', array_reverse(explode('/', $date)));
        }

        $user = $this->container->get('security.token_storage')->getToken()->getUser()->getUsername();
        $ledgerBal = 'SELECT LEDGER_BAL FROM TSB_ACCMAST WHERE ACCNO=?';
        $statement = $dbConnection->prepare($ledgerBal);
        $statement->bindValue(1, $accNum, \PDO::PARAM_INT);
        $statement->execute();
        $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $ledBal = $result[0]['LEDGER_BAL'];
        $newLedBal = $ledBal - $amount;
        $todayMin = $today->format('Y-m-d');
        $accTypeQuery = 'SELECT ACCTYPE FROM TSB_ACCMAST WHERE ACCNO=?';
        $statement2 = $dbConnection->prepare($accTypeQuery);
        $statement2->bindValue(1, $accNum, \PDO::PARAM_INT);
        $statement2->execute();
        $result2 = $statement2->fetchAll(\PDO::FETCH_ASSOC);
        $accType = $result2[0]['ACCTYPE'];
        $minBalQuery = "SELECT MINBAL FROM SB_FACILITY WHERE ACCTYPE=? AND ? BETWEEN MINBAL_EFF_FROM AND CASE WHEN MINBAL_EFF_TO IS NULL THEN CURRENT_DATE ELSE MINBAL_EFF_TO END";
        $statement3 = $dbConnection->prepare($minBalQuery);
        $statement3->bindValue(1, $accType, \PDO::PARAM_INT);
        $statement3->bindValue(2, $todayMin);
        $statement3->execute();
        $result3 = $statement2->fetchAll(\PDO::FETCH_ASSOC);
//        $minBal = $result3[0]['MINBAL'];
//        if ($minBal < $newLedBal) {
        $seqnogenration = $this->get('seq_no_gen');
        $seqno = $seqnogenration->seqnoGenerate($todayMin);
        if ($seqno > 0) {
            if ($option == 1) {
                $iniStatus = 'PN';
            } else {
                $iniStatus = 'SL';
            }
//            $selectSchedule = 'SELECT MAX(SCHEDULE_ID) FROM TSBONLINE_SCHEDULE';
//            $statement4 = $dbConnection->prepare($selectSchedule);
//            $statement4->execute();
//            $result4 = $statement4->fetchAll(\PDO::FETCH_ASSOC);
//            $scheduleId = $result4[0][1] + 1;

            $maximumScheduleid = $this->get('maximumid_listner');

            $scheduleId = $maximumScheduleid->getMaximumscheduleId();

            $transactionIDgenration = $this->get('transactionID_gen');
            $tsb_transaction_id = $transactionIDgenration->transactionID($seqno);
            $insertSchedule = 'INSERT INTO TSBONLINE_SCHEDULE (ACC_NO,ACC_TYPE,BENEF_ID,DATE,AMOUNT,ENTERED_BY,ENTERED_TIME,INITIATE_STATUS,PROCESS_STATUS,SCHEDULE_ID,REMARKS,TRANSACTION_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)';
            $statement1 = $dbConnection->prepare($insertSchedule);
            $statement1->bindValue(1, $accNum, \PDO::PARAM_INT);
            $statement1->bindValue(2, $accType, \PDO::PARAM_INT);
            $statement1->bindValue(3, $benefId, \PDO::PARAM_INT);
            $statement1->bindValue(4, $dateToday);
            $statement1->bindValue(5, $amount, \PDO::PARAM_INT);
            $statement1->bindValue(6, $user);
            $statement1->bindValue(7, $todayNow);
            $statement1->bindValue(8, $iniStatus);
            $statement1->bindValue(9, null);
            $statement1->bindValue(10, $scheduleId, \PDO::PARAM_INT);
            $statement1->bindValue(11, $remark);
            $statement1->bindValue(12, $tsb_transaction_id);
            $statement1->execute();
            if ($option == 1) {
                return $this->redirect($this->generateUrl('transfer_money_payment', array('sid' => $scheduleId)));
            } else {
                return $this->render('AppBundle:Message:message.html.twig', array(
                            'message' => 'Transaction scheduled',
                            'status' => 'success', 'menu' => 'funds'));
            }
        }
//        } else {
//            return $this->render('AppBundle:Message:message.html.twig', array(
//                        'message' => 'Transaction cannot be scheduled. No sufficient minimum balance.',
//                        'status' => 'fail'));
//        }
    }

    public function Confirm_fund_scheduleAction(Request $request) {
        $form = $this->createForm(new ScheduleConfirmType(), null, array('action' => $this->generateUrl('confirm_fund_shedule')));
        $messag = "Today's Transaction time for RBI is over, Payment will be scheduled  to Next working hour";
        $details = $this->get('session')->get('userAccno');


        $accNum = ($details['accounts']);
        $benficiaryId = ($details['benificiary']);
        $amount = ($details['amount']);
        $option = ($details['option']);
        $remarks = ($details['remarks']);
        $tomorrow = new \DateTime("tomorrow");
        $tomorrowDate = $tomorrow->format('Y-m-d H:i:s');

        $payOption = 3;
        $amountPayable = ($details['amount']);



        $this->get('session')->set('userAccno', array('accounts' => $accNum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $tomorrowDate));


        $form->handleRequest($request);
        if ($form->isValid()) {
            return $this->redirect($this->generateUrl('schedule_later'));

            //return $this->redirect($this->generateUrl('confirm_fund_shedule'));
        }

        return $this->render('AppBundle:Funds:scheduleFundtoComfirm.html.twig', array('results' => $messag, 'form' => $form->createView()));
    }

    public function editScheduleLaterAction(Request $request, $schedulid) {


        $dbConnection = $this->get('database_connection');
        $user = $this->getUser();
        $userName = $user->getUsername();
        $accList = $this->get('customer_account_list');
        $accountDetails = $accList->UserDetails($userName);

        $scheduleDetailsQuery = 'SELECT BENEF_ID, AMOUNT,REMARKS,ACC_NO,date(DATE) as DATE FROM TSBONLINE_SCHEDULE WHERE SCHEDULE_ID=?';

        $statement = $dbConnection->prepare($scheduleDetailsQuery);
        $statement->bindValue(1, $schedulid, \PDO::PARAM_INT);
        $statement->execute();
        $resultschedue = $statement->fetchAll(\PDO::FETCH_ASSOC);
        foreach ($resultschedue as $item) {
            $benfAccno = $item['ACC_NO'];
            $benifficiaryDetails = $this->get('transaction_limit')->getBeneficiary($benfAccno, $item['BENEF_ID']);


            $benifficiaryid = $item['BENEF_ID'];
            $transferAmt = $item['AMOUNT'];
            $remarks = $item['REMARKS'];
            $selectedAccount = $item['ACC_NO'];
            $dateofSchedule = $item['DATE'];
        }


        $customerID = $user->getID();
        $selectBeneficiary = "SELECT BENEFICIARY_ID,BENEFICIARY_NAME FROM TSBONLINE_BENEFICIARYMASTER WHERE PARENT_CUSTOMER_ID=?";
        $statement = $dbConnection->prepare($selectBeneficiary);
        $statement->bindValue(1, $customerID, \PDO::PARAM_INT);
        $statement->execute();
        $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $beneficiaryList = null;
        foreach ($result as $item) {
            $beneficiaryList[$item['BENEFICIARY_ID']] = $item['BENEFICIARY_NAME'];
        }


        $form = $this->createForm(new FundsTransferCancelType($accountDetails, $selectedAccount, $benifficiaryid, $beneficiaryList, $transferAmt, $remarks, $dateofSchedule, $schedulid), null, array('action' => $this->generateUrl('schedule_later_edit', array('schedulid' => $schedulid))));
        $form->handleRequest($request);
        if ($form->isSubmitted()) {

            // dump($form);
            // die;
            $form['scheduleid']->getData();
            $accno = $form['accountDetails']->getData();
            ;
            $benifficiaryid = $form['benifficiaryid']->getData();

            $Benfamt = $form['Amount']->getData();
            $remarks = $form['remarks']->getData();
            $date_ofschedule = $form['date_ofschedule']->getData();
            $date_ofschedule = $date_ofschedule->format('Y-m-d H:i:s');


            $scheduleid = $form['scheduleid']->getData();

            $updateSI = 'UPDATE TSBONLINE_SCHEDULE SET AMOUNT=?,  REMARKS=?, DATE=?,BENEF_ID=?  WHERE SCHEDULE_ID=?';

            $statement3 = $dbConnection->prepare($updateSI);
            $statement3->bindValue(1, $Benfamt, \PDO::PARAM_INT);


            $statement3->bindValue(2, $remarks);
            $statement3->bindValue(3, $date_ofschedule);
            $statement3->bindValue(4, $benifficiaryid);
            $statement3->bindValue(5, $scheduleid);

            $statement3->execute();


            return $this->redirect($this->generateUrl('show_fund_transfer'));
        }
        return $this->render('AppBundle:Funds:fundsEdit.html.twig', array('fundtransfer' => $form->createView()));
    }

    public function cancelScheduleLaterAction(Request $request, $schedulid) {




        $dbConnection = $this->get('database_connection');
        $user = $this->getUser();
        $userName = $user->getUsername();
        $accList = $this->get('customer_account_list');
        $accountDetails = $accList->UserDetails($userName);

        $scheduleDetailsQuery = 'SELECT BENEF_ID, AMOUNT,REMARKS,ACC_NO,date(DATE) as DATE FROM TSBONLINE_SCHEDULE WHERE SCHEDULE_ID=?';

        $statement = $dbConnection->prepare($scheduleDetailsQuery);
        $statement->bindValue(1, $schedulid, \PDO::PARAM_INT);
        $statement->execute();
        $resultschedue = $statement->fetchAll(\PDO::FETCH_ASSOC);
        foreach ($resultschedue as $item) {
            $benfAccno = $item['ACC_NO'];
            $benifficiaryDetails = $this->get('transaction_limit')->getBeneficiary($benfAccno, $item['BENEF_ID']);


            $benifficiaryid = $item['BENEF_ID'];
            $transferAmt = $item['AMOUNT'];
            $remarks = $item['REMARKS'];
            $selectedAccount = $item['ACC_NO'];
            $dateofSchedule = $item['DATE'];
        }

        $customerID = $user->getID();
        $selectBeneficiary = "SELECT BENEFICIARY_ID,BENEFICIARY_NAME FROM TSBONLINE_BENEFICIARYMASTER WHERE PARENT_CUSTOMER_ID=?";
        $statement = $dbConnection->prepare($selectBeneficiary);
        $statement->bindValue(1, $customerID, \PDO::PARAM_INT);
        $statement->execute();
        $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        $beneficiaryList = null;
        foreach ($result as $item) {
            $beneficiaryList[$item['BENEFICIARY_ID']] = $item['BENEFICIARY_NAME'];
        }

        $form = $this->createForm(new FundsTransferCancelType($accountDetails, $selectedAccount, $benifficiaryid, $beneficiaryList, $transferAmt, $remarks, $dateofSchedule, $schedulid), null, array('action' => $this->generateUrl('schedule_later_edit', array('schedulid' => $schedulid))));
        $form->handleRequest($request);
        //  dump($form->getErrorsAsString());die;
        if ($form->isValid()) {



            $form['scheduleid']->getData();
            $accno = $form['accountDetails']->getData();
            ;
            $benifficiaryid = $form['benifficiaryid']->getData();

            $Benfamt = $form['Amount']->getData();
            $remarks = $form['remarks']->getData();
            $date_ofschedule = $form['date_ofschedule']->getData();
            $date_ofschedule = $date_ofschedule->format('Y-m-d H:i:s');


            $scheduleid = $form['scheduleid']->getData();

            $updateSI = "UPDATE TSBONLINE_SCHEDULE SET PROCESS_STATUS='C'  WHERE SCHEDULE_ID=?";

            $statement3 = $dbConnection->prepare($updateSI);

            $statement3->bindValue(1, $scheduleid);

            $statement3->execute();


            return $this->redirect($this->generateUrl('show_fund_transfer'));
        }
        return $this->render('AppBundle:Funds:fundsEdit.html.twig', array('fundtransfer' => $form->createView()));
    }

    public function accountBalanceAction(Request $request) {
        $dbConnection = $this->get('database_connection');



        $accNumber = $request->request->get('accno');

        $ledgerSelectQuery = 'SELECT LEDGER_BAL FROM TSB_ACCMAST WHERE ACCNO=? ';
        $statement1 = $dbConnection->prepare($ledgerSelectQuery);
        $statement1->bindValue(1, $accNumber, \PDO::PARAM_INT);
        $statement1->execute();
        $result1 = $statement1->fetchAll(\PDO::FETCH_ASSOC);
        if ($result1) {
            $ledgerBalance = $result1[0]['LEDGER_BAL'];

            return new JsonResponse($ledgerBalance);
        }
    }

    public function activeAccountsAction(Request $request) {
        $dbConnection = $this->get('database_connection');
        $user = $this->getUser();

        if (!$user) {
            return $this->redirect($this->generateUrl('login'));
        } else {
            $userId = $user->getID();



            $customerAcc = "SELECT a.ACCNO,a.ACCTYPE,c.ACCTYPE_ABBR,SCRT_BAL FROM TSB_CUSTOMER_ACCOUNT a,tsb_accmast b,SB_ACCTYPE c  WHERE a.acctype=b.acctype and a.accno=b.accno and b.confirmed='Y' and b.sb_close='N' and  a.acctype=c.acctype and c.ONLINE_FACILTY='Y' and a.acctype<>5 and CUSTOMER_ID=? ORDER BY a.acctype";

            $statement2 = $dbConnection->prepare($customerAcc);
            $statement2->bindValue(1, $userId, \PDO::PARAM_INT);

            $statement2->execute();
            $result2 = $statement2->fetchAll(\PDO::FETCH_ASSOC);


            $fiyrQuery = "SELECT FINYR_CD,LEFT(FINYR_DESC,4) AS FINYR_DESC FROM finyr ";
            $stamentFinyr = $dbConnection->prepare($fiyrQuery);
            $stamentFinyr->execute();
            $finyr = $stamentFinyr->fetchAll(\PDO::FETCH_ASSOC);

            return $this->render('AppBundle:Funds:activeAccounts.html.twig', array('result' => $result2, 'finyr' => $finyr));
        }
    }

    public function fundTransferSaveAction(Request $request) {
        $user = $this->getUser();
        if (!$user) {
            return $this->render('AppBundle:Default:publicpage.html.twig');
        } else {

            $transLimit = null;
             $customerID = $user->getID();
            $userName = $user->getUsername();
            $accnum = $request->request->get('form-field-radio-accno');
            $amountPayable = $request->request->get('fundtransfer-amt');
            $remarks = $request->request->get('fundtransfer-remarks');

            $transtype = $request->request->get('transtype');
            $benficiaryId = $request->request->get('form-field-radio-benfaccno');
            $payOptionfundTransfer = $request->request->get('fundtransfer');

            $payOption = $payOptionfundTransfer['payOptions'];
            $scheduleDate = $payOptionfundTransfer['date'];



            $today = new \DateTime("now");
            $today = $today->format('Y-m-d H:i:s');




            $timeConstraint = "19:00:00";
            if (strtotime("now") <= strtotime($timeConstraint) && (strcmp($transtype, "O") == 0)) {



                $transLimit = $this->get('transaction_limit');
                $benfTransferLimit = $transLimit->transferLimitbenfCustomer($customerID, $benficiaryId);

                if ($benfTransferLimit >= $amountPayable || $benfTransferLimit == 0) {

                    $this->get('session')->set('userAccno', array('accounts' => $accnum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $scheduleDate));
                    return $this->redirect($this->generateUrl('fundtransfer_autentication'));
                } else {

                    $messag = 'Transaction Limit exceeded cant Proceed';
                    return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail'));
                }
            } else {
                $transLimit = $this->get('transaction_limit');
                $benfTransferLimit = $transLimit->transferLimitbenfCustomer($customerID, $benficiaryId);


                if ( $amountPayable <=  $benfTransferLimit || $benfTransferLimit == 0) {
                    $this->get('session')->set('userAccno', array('accounts' => $accnum, 'amount' => $amountPayable, 'remarks' => $remarks, 'benificiary' => $benficiaryId, 'option' => $payOption, 'date' => $scheduleDate));
                    return $this->redirect($this->generateUrl('fundtransfer_autentication'));
                    //  return $this->redirect($this->generateUrl('confirm_fund_shedule'));
                } else {

                    $messag = 'Transaction Limit exceeded Cant Proceed';
                    return $this->render('AppBundle:Message:message.html.twig', array('message' => $messag, 'status' => 'fail', "menu" => "funds"));
                }
            }
        }
    }

    public function scrtBlanceAction(Request $request) {



        $accNumber = $request->request->get('accno');
        $amt = $request->request->get('amt');

        $scrutinyBalService = $this->get('scrt_balance_account');


        $scrtBalanceArray = $scrutinyBalService->scrutinyBalanceCheck($accNumber);
        $scrtBalance = $scrtBalanceArray['SCRT_BAL'];
        $ledgerBalance = $scrtBalanceArray['LEDGER_BAL'];
        $sbClose = $scrtBalanceArray['SB_CLOSE'];
        $sbAcctype = $scrtBalanceArray['ACCTYPE'];
        $sbFacility = $scrtBalanceArray['FACILITY'];
        $currentDate = date('m/d/Y');

        if ($amt == "0") {
            $scrtBalanceMsg = "Withdrawal amount can't be Zero";

            return new JsonResponse($scrtBalance);
        }
        if ($amt == '') {
            $scrtBalanceMsg = "Please Enter Withdrawal Amount";
            return new JsonResponse($scrtBalanceMsg);
        }

        if ($scrtBalance) {
            if ($amt > $scrtBalance) {
                $scrtBalanceMsg = "Insufficient Account Balance";
                return new JsonResponse($scrtBalanceMsg);
            }
            if (($sbClose == "Y") && $ledgerBalance != $amt) {
                $scrtBalanceMsg = "Closed account. Withdrawal Amount should be equal Balance Amount";
                return new JsonResponse($scrtBalanceMsg);
            }
            $dbConnection = $this->get('database_connection');
             $sqlMinBalance = "select MINBAL from sb_facility where ACCTYPE=? and  FACILITY=? and  ? between MINBAL_EFF_FROM and   case when MINBAL_EFF_TO is null  then current_date else MINBAL_EFF_TO end ";
            $statement2 = $dbConnection->prepare($sqlMinBalance);
            $statement2->bindValue(1, $sbAcctype, \PDO::PARAM_INT);
            $statement2->bindValue(2, $sbFacility, \PDO::PARAM_INT);
            $statement2->bindValue(3, $currentDate, \PDO::PARAM_INT);
            $statement2->execute();
            $result2 = $statement2->fetchAll(\PDO::FETCH_ASSOC);
            if ($result2) {
                $accountMinBalance = $result2[0]['MINBAL'];

                $netBal = ($scrtBalance - $amt);
                if (($netBal < $accountMinBalance) && ($sbClose != "Y")) {
                    $scrtBalanceMsg = "Minimum Balance of " . $accountMinBalance . " should be maintained.";
                     return new JsonResponse($scrtBalanceMsg);
                } else {
                    $scrtBalanceMsg= "1";
                     return new JsonResponse($scrtBalanceMsg);
                }
            }
        }

        return new JsonResponse($scrtBalance);
    }

}

<?php
require 'vendor/autoload.php';

  require_once("config/init.php");

  $dbObj = new \Database\DbObject("tsb");







?>

<?php
	

	/**
	 * TSB SERVICES ARE REGISTERED HERE
	 * 
	 */
	$app->group("/tsb", function() use($app) {
		  if(match_uri($app, '/tsb')){
		  	$app->response->headers->set('content-type', 'application/json');
		  	$app->container->set('TsbdbObj', function() { return new Database\DbObject("tsb"); } );
		  	require_once 'app/routes/tsb/v1.0/index.php';
		  }
	});


	/**
	 * PIMS SERVICES ARE REGISTERED HERE
	 *
	 */
	$app->group("/pims", function() use($app) {
		if(match_uri($app, '/pims')){
			$app->response->headers->set('Content-Type', 'application/json');
			$app->container->set('CoretisdbObj', function() { return new Database\DbObject("coretis"); });
			require_once 'app/routes/pims/v1.0/index.php' ;
		}
	});


?>
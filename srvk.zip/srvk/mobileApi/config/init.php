<?php
  error_reporting(-1);
  require_once("config/config.php");
  require_once("functions/function.php");


  !defined("DS")? define("DS", DIRECTORY_SEPARATOR) : null;
  !defined("ROOT_DIR")? define("ROOT_DIR",  realpath(dirname(__FILE__).DS."..").DS) : null;
?>

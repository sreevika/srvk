<?php
  $CONFIG = [];
  $CONFIG["base_url"] = "http://103.251.43.79/mobileApi/";
  $CONFIG["db"] = [];

  // TSB DATABASE CONFIGURATION

  $CONFIG["db"]["tsb"] = [
    "db_dsn" => "ibm:tsb",
    "db_name" => "tsb",
    "db_user" => "db2admin",
    "db_password" => "db2admin"
  ];


  // CORETIS DATABASE CONFIGURATION

  $CONFIG["db"]["coretis"] = [
    "db_dsn" => "ibm:coretest",
    "db_name" => "coretest",
    "db_user" => "db2admin",
    "db_password" => "stagedb2@123"
  ];


  // SLIM SYSTEM CONFIGURATION

  $CONFIG["system"] = [
    "debug" => true
  ];

  // Service Config
  $CONFIG["services"] = array();

  $CONFIG["services"]["pims"]["mod"] = array();
  $CONFIG["services"]["pims"]["mod"]["check_mobno"]["sms"] = true;


  $CONFIG["services"]["tsb"]["mod"] = array();
  $CONFIG["services"]["tsb"]["mod"]["check_mobno"]["sms"] = true;



?>

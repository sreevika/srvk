<?php



if(!function_exists('mach_uri')){
  function match_uri($app, $uri = ""){
    $uri_len = strlen($uri);
    $req_uri = $app->request->getResourceUri();
    if($uri_len > 0 && strlen($req_uri) > $uri_len ){
      $req_url_sub = substr($req_uri, 0, $uri_len);
      return ($req_url_sub === $uri)? true : false;
    }
    return false;
  }
}


if(!function_exists('switch_date_format')){

  function switch_date_format($date, $from, $to){
    $date = DateTime::createFromFormat($from, $date);
    if($date){
      return $date->format($to);
    }
    return null;
  }
}


if(!function_exists("db2_timestamp_to_unix")){
    function db2_timestamp_to_unix($timestamp){
      $date = \DateTime::createFromFormat('Y-m-d H:i:s.u', $timestamp);
      if($date){
          return $date->getTimestamp();
      }
      return false;
    }
}

if(!function_exists("create_db2_timestamp")){
  function create_db2_timestamp($timestamp = null){
    $timestamp = ($timestamp)? $timestamp : time();
    $time = new DateTime();
    $time->setTimestamp($timestamp);
    return $time->format('Y-m-d H:i:s.u');
  }
}

if(!function_exists("create_iv")){
  function create_iv($data = null){
      $data = ($data)? md5($data) : md5(mt_rand());
      return substr($data, 0, 16);
  }
}
if(!function_exists("remove_null")){
  function remove_null($data = null){
    return (empty($data))? "" : $data;
  }
}

?>

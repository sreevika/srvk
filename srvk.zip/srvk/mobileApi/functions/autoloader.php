<?php

  spl_autoload_register(function($classname){
    $classname = str_replace('\\', '/', $classname);
    $fullclassname = ROOT_DIR.'classes'.DS.$classname.".php";
    if(file_exists($fullclassname)){
      require_once($fullclassname);
    }
  });

?>

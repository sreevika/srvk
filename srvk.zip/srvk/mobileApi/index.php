<?php
  /*
   * Mobile Rest service
   * This is a common REST service provider for all mobile application in treasury
   * This app is build on the top of slim microframework version 2.0
   * SLIM V2 DOCS : https://docs.slimframework.com/
  */

  /* Class autoloader
   * Autoloader for composer packages and other packages inside class directory
  */
  require 'vendor/autoload.php';

  /* Configuraion
   * Configuraion of the applicaion
  */
  require_once 'config/init.php';
  $app = new \Slim\Slim($CONFIG["system"]);

  // Adding routes from the routes register inside the config directory
  require_once 'config/routes.php';






  // For testing purpose of AES ecrytption

  // ********************************** //

  $app->get("/aes", function() use($app){
      $key = $app->request->get("key");
      $input = $app->request->get("input");
      $iv = $app->request->get("iv");
      $out  = [];
      if($key){
        $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
        $cipher->setKey($key);
        $cipher->setIv($iv);
        $encinput = $cipher->encrypt($input);
        //echo $cipher->decrypt($encinput);
        $out["enc_data"] = $encinput;
      }
        $app->render("aes.php", $out);
  });


  // \\********************************** //


  $app->run();
?>

<?php
  namespace Database;
  class DbConnection{

    //db name
    public $conn;
    // Connecton Storage
    public static $conn_bag = array();
    public function __construct($db){
      $this->createConnection($db);
    }

    /**
     * getDbConnection
     * public accessable method for getting database connection
     * @param String connection configuration naem
     * @return Object PDO
     */
    public static function getDbConnection($db = ""){
      // check db config is available in config
      global $CONFIG;
      if(!isset($CONFIG["db"][$db])){
          return false;
      }
      // If db is already connected
      if(in_array($db, self::$conn_bag)){
         return $conn_bag[$db];
      }

      // new connection
      $conn = new self($db);
      self::$conn_bag[$db] = $conn;
      return static::$conn_bag[$db];
    }



    private function createConnection($db){
      global $CONFIG;
      $dsn = $CONFIG["db"][$db]["db_dsn"];
      $user = $CONFIG["db"][$db]["db_user"];
      $password = $CONFIG["db"][$db]["db_password"];
      try{
        $this->conn = new \PDO($dsn, $user, $password);
      }catch(Exception $e){
        echo " database connection failed ".$e->getMessage();
        exit;
      }
    }
  }
?>

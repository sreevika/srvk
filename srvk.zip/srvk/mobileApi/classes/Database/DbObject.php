<?php
  namespace Database;

  class DbObject {
      public $conn;
      /**
       * @param String db config name
       */
      public function __construct($db){
        $this->conn = DbConnection::getDbConnection($db)->conn;
      }

      public function getConnection(){
          return $this->conn;
      }

      public function execute_query($sql, $params= array()){

        $pdoStatementObj = $this->conn->prepare($sql);
        if($pdoStatementObj){
        // If PdoStatementObj is not false
        if(count($params) > 0){
        $param_index = 1;
        foreach($params as &$value){
          $pdoStatementObj->bindParam($param_index, $value);
          $param_index ++;
        }
        }
        return ($pdoStatementObj->execute()) ? $pdoStatementObj : false;
        }
        return false;
      }


  }
?>

<?php
	namespace MobileRest\Init;

	interface InitRepositoryInterface{

      public function getEntity();

      public function setEntity(InitInterface $entity);

		  public function create();

      public function update();

      public function delete();

      public function findById($id);

      public function findByDevice($device_id, $device_os);

      public function findByInitKey();

	}


?>

<?php
namespace MobileRest\Init;
  /**
   * Init object Interface
   */
  interface InitInterface
  {
    public function setId($id);

    public function getId();

    public function getInitHash();

    public function setInithash($hash);

    public function getInitIv();

    public function setInitIv($iv);

    public function setInitKey($key);

    public function getInitKey();

    public function setInitTime($time);

    public function getInitTime();

    public function setDeviceId($device_id);

    public function getDeviceId();
    
  }


?>

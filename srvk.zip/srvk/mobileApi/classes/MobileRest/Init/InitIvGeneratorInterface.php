<?php
  namespace MobileRest\Init;

  /**
   * Init key generator
   */
  interface GeneratorTypeInterface{
      /**
       * generateInitkey
       * GenerateInit key for the device
       * Init key must be universally unique
       * @param $device_id
       * @return string Init hash
       */
      public function generateInitIv($device_id);
  }


?>

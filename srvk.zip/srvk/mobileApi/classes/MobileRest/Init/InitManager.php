<?php
	namespace MobileRest\Init;

	/* Init Manager
	 * Do all intilization job
	 *
	*/

	class InitManager {


		protected $_repo;
		protected $_init_entity;

    private  $_init_hash_generator = null;
    private  $_init_key_generator = null;
    private  $_init_iv_generator = null;
		private  $_init_time_generator = null;





	  public function setEntity(InitInterface $init){
			$this->_init_entity = $init;
		}
		/**
		 * Constructor
		 * @param String $device_id  InitRepositoryInterface $repo
		 */
		public function __construct(InitRepositoryInterface $repo){
			$this->_repo = $repo;
			$this->_init_entity = $repo->getEntity();
		}

    public function setInitHashGenerator(generatorType $generator){
      $this->_init_hash_generator = $generator;
    }

		public function setInitKeyGenerator(generatorType $generator){
			$this->_init_key_generator = $generator;
		}


		public function setInitIvGenerator(generatorType $generator){
      $this->_init_iv_generator = $generator;
    }



    private function getInitHashGenerator(){
      if(isset($this->_init_hash_generator)){
          return $this->_init_hash_generator;
      }
      return new Extensions\InitHashGenerator();
    }


		private function getInitKeyGenerator(){
			if(isset($this->_init_key_generator)){
					return $this->_init_key_generator;
			}
			return new Extensions\InitKeyGenerator();
		}


		private function getInitIvGenerator(){
      if(isset($this->_init_iv_generator)){
          return $this->_init_iv_generator;
      }
      return new Extensions\InitIvGenerator();
    }

		private function getInitTimeGenerator(){
			if(isset($this->_init_time_generator)){
				return $this->_init_time_generator;
			}
			return new Extensions\InitTimeGenerator();
		}



    public function updateInitHash(){
        // create new init key hash generate
        $this->_init_entity->setInitHash($this->getInitHashGenerator()->generate($this->_init_entity->getId()));
    }

		public function updateInitKey(){
				// create new init key hash generate
				$this->_init_entity->setInitKey($this->getInitKeyGenerator()->generate($this->_init_entity->getDeviceId()));
		}

		public function updateInitIv(){
        // create new init key hash generate
        $this->_init_entity->setInitIv($this->getInitIvGenerator()->generate($this->_init_entity->getDeviceId()));
    }

		public function updateIntiTime(){
			$time = time();
			$this->_init_entity->setInitTime($this->getInitTimeGenerator()->generate($time));
		}



    /**
     * @return Init
     */
    public function initializeDevice(){
				$this->updateInitHash();
				$this->updateInitKey();
				$this->updateInitIv();
				$status = $this->save();
				if($status == false){
					throw new \Exception("Initialization failed");
				}
        return $this->_init_entity;
		}


		public function save(){
				$init =  $this->_repo->save($this->_init_entity);
				return $init;
		}








	}


?>

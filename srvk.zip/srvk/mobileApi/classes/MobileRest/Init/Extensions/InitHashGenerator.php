<?php
namespace MobileRest\Init\Extensions;
  /**
   * Simple Init keygenerator
   */
  class InitHashGenerator implements \MobileRest\Init\GeneratorTypeInterface{

      public function generate($id){
        return md5($id.time());
      }

  }

?>

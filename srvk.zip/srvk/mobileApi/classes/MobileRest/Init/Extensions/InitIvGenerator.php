<?php
namespace MobileRest\Init\Extensions;
  /**
   * Simple Init keygenerator
   */
  class InitIvGenerator implements \MobileRest\Init\GeneratorTypeInterface{

      public function generate($id){
        return substr(md5(md5($id.time())), 0, 16);
      }

  }

?>

<?php
  namespace \MobileRest\Init\Extensions;
    class InitTimeGenerator implements generatorType{
        public function generate($time){
          return date('Y-m-d H:i:s', $time);
        }
    }
?>

<?php
namespace MobileRest\Init\Extensions;
  /**
   * Simple Init keygenerator
   */
  class InitKeyGenerator implements \MobileRest\Init\GeneratorTypeInterface{

      public function generate($id){
        return md5($id.time());
      }

  }

?>

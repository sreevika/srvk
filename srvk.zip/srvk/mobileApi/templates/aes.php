<html>
  <head>

  </head>
  <body>
    <div>

      <form>
        <lable>Key</label>
        <input type="text" name="key">
        <br>
        <lable>Input</label>
        <input type="text" name="input">
        <br>
        <lable>Input</label>
        <input style="width:300px;" type="text" name="iv" value="<?php echo md5("12345"); ?>">
        <br>
        <input type="submit">
      </form>
      <?php
      if(isset($enc_data)){
      ?>
      <div>
        <h3>AES CBC</h3>
        <p><?php echo $enc_data; ?></p>
        <h3>AES CBC base64 encoded</h3>
        <p style="padding:10px; border:1px solid #ddd;"><?php echo base64_encode($enc_data); ?></p>
      </div>
      <?php
      }
      ?>
    </div>
  </body>
</html>

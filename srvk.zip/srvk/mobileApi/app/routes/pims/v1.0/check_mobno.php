<?php
  /*
  *----------------------------------------------------------
  * Project 	: Mobile API for Pension App
  * Module  	: Checking the Registered Mobile No
  * Author  	: Maneksh MS
  * Created On	: Aug 20 2017
  * Modified By	: Hari Krishnan 
  * Modified On	: March 07 2018
  -------------------------------------------------------
   * ERROR CODE AND REASON
   * ERR_000 = "Invalid init hash"
   * ERR_001 = "Invalid mob No"
   * ERR_002 = "Invalid Device Id"
   * ERR_003 = "failed to execure init hash check query"
   * ERR_004 = "Init hash not found in db return no recoard for that init hash "
   * ERR_005 = " Faild to decrypt mobile no"
   * ERR_006 = " Faild to decrypt device id"
   * ERR_007 = " Faild to execute check mobile number user query"
   * ERR_008 = " User not found for the mobile no"
   * ERR_009 = " Insert user login table query failed"
   * ERR_010 = " update user hash query failed"
   * ERR_011 = " Otp sent failed"
   */
  $app->post("/v1.0/check_mobno", function() use($app){
    /*
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey("18f55d0d63204f4a6546e3faa83ec88e");
    $cipher->setIv("6c8249f6e4e9a315");
    $enc = $cipher->encrypt("8089275598");
    $d =  base64_encode($enc);

    echo $d;
    echo "  ||  ";
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey("18f55d0d63204f4a6546e3faa83ec88e");
    $cipher->setIv("6c8249f6e4e9a315");
    $user_ee = $cipher->encrypt('11111');
    echo base64_encode($user_ee);
    exit;
    */
      global $CONFIG;
      $dbObj = $app->container["CoretisdbObj"];
      $api_output = array();

      $api_output["response"] = array();

      //api headers

      // api information
      $api_info = array();
      $api_info["versionNo"] = 1.0;
      $api_info["versionName"] = "Rest mobile api for treasury";
      $api_info["releseDate"] = "17/10/2017";
      $api_info["description"] = "Rest api for treasury";


      // Android platform header
      $android_platform = array();
      $android_platform["verisonNo"] = 1.0;
      $android_platform["verisonName"] = "Rest for treasury";
      $android_platform["forceUpdate"] = "yes";
      $android_platform["description"] = "Rest api for treasury";


      // ios platform header
      $ios_platform = array();
      $ios_platform["verisonNo"] = 1.0;
      $ios_platform["verisonName"] = "Rest for treasury";
      $ios_platform["forceUpdate"] = "yes";
      $ios_platform["description"] = "Rest api for treasury";


      $initHash = $app->request->post("initHash");
      $encMobNo = $app->request->post("mobNum");
      $encDeviceId = $app->request->post("deviceID");

      // Post data are valid

      // Check init hash

      if($initHash === null){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_000",
          "message" => "Invalid Data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      // Check Mobile No
      if($encMobNo === null){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_001",
          "message" => "Invalid Data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Check device Id
      if($encDeviceId === null){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_002",
          "message" => "Invalid Data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      // Check valid init hash
      $sql = "  SELECT  * FROM PIMS_MOB_APP WHERE INIT_HASH = ? ";
      $params = array($initHash);
      $result = $dbObj->execute_query($sql, $params);

      // query execution failed
      if(!$result){
        $api_output["response"]["operation"]['status'] = "error";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_003",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $init_data = $result->fetchAll();

      // If init hash not found
      if(empty($init_data)){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_004",
          "message" => "Invalid Request"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Decrypt mobile No
      $init_aes_key = $init_data[0]["INIT_KEY"];
      $init_aes_iv = $init_data[0]["INIT_IV"];

      $init_aes_cipher =  new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $init_aes_cipher ->setKey($init_aes_key);
      $init_aes_cipher ->setIv($init_aes_iv);
      $decrypted_mobile_no = $init_aes_cipher->decrypt(base64_decode($encMobNo));

      // if decrypted_mobile_no failed then invalid request
      if(!$decrypted_mobile_no){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_005",
          "message" => "Invalid Request"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Decrypt device Id

      $init_aes_cipher =  new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $init_aes_cipher->setKey($init_aes_key);
      $init_aes_cipher->setIv($init_aes_iv);
      $decrypted_device_id = $init_aes_cipher->decrypt(base64_decode($encDeviceId));


      // If device id decrytion failed
      if(!$decrypted_device_id){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_006",
          "message" => "Invalid Request"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      // Check mobile is registered
      //$sql = " SELECT * FROM PIMS_PUB_REGN WHERE MOBILE_NO = ? ";
	  
	  $sql = " SELECT distinct MOBILE as USER_ID FROM PENMAST WHERE MOBILE = ? AND CONFIRMED='Y' AND PEN_STOP='N'";
	  	  	  
	  
      $params = array($decrypted_mobile_no);

      $result = $dbObj->execute_query($sql, $params);

      // if query execution failed
      if(!$result){
        $api_output["response"]["operation"]['status'] = "error";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_007",
          "message" => "System Request"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      $user_info = $result->fetchAll();

      if(empty($user_info)){
        $api_output["response"]["operation"]['status'] = "fail";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_008",
          "message" => "Invalid mobile number"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      if($CONFIG["services"]["pims"]["mod"]["check_mobno"]["sms"] === true){
        $otp = mt_rand(100000, 999999);
        $sms_uname = "treasury";
        $sms_pwd = "esmsalerts";
        $message = 'Your OTP for Pensioners portal mobile app is '.$otp;
        $dis = $message;

        $mob = $decrypted_mobile_no;

        $dis=urlencode($dis);

        $url = "http://api.esms.kerala.gov.in/fastclient/SMSclient.php?username=".$sms_uname."&password=".$sms_pwd."&message=".$dis."&numbers=".$mob;

        $curl_handle=curl_init();
        curl_setopt($curl_handle, CURLOPT_URL,$url);
        curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
        curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_handle, CURLOPT_USERAGENT, 'PIMS');
        $query = curl_exec($curl_handle);
        curl_close($curl_handle);
        //$sent_sms_cnt.=$result.'|';
      }else{
        $otp = "12345";
      }


      $user_id = $user_info[0]["USER_ID"];
      $init_id = $init_data[0]["ID"];
      $otp_time = create_db2_timestamp();
      $created_time = create_db2_timestamp();
      $is_valid = 'N';

      // Insert into user login table
      $sql = " INSERT INTO PIMS_MOB_APP_USER_LOGIN ( INIT_ID, USER_ID, OTP, OTP_TIME, IS_VALID, CREATED_TIME ) ";
      $sql .= " VALUES( ?, ?, ?, ?, ?, ? )";
      $params = [];
      $params[] = $init_id;
      $params[] = $user_id;
      $params[] = $otp;
      $params[] = $otp_time;
      $params[] = $is_valid;
      $params[] = $created_time;


      $result = $dbObj->execute_query($sql, $params);

      // If query failed

      if(!$result){
        $api_output["response"]["operation"]['status'] = "error";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_009",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $user_login_id = $dbObj->conn->lastInsertId();

      // create user hash
      $user_hash = md5($user_login_id);

      // update user hash

      $sql = " UPDATE PIMS_MOB_APP_USER_LOGIN SET USER_HASH = ? WHERE ID = ? ";
      $params = [];
      $params[] = $user_hash;
      $params[] = $user_login_id;

      $result = $dbObj->execute_query($sql, $params);
      if(!$result || ( $result && $result->rowCount() == 0 )  ){
        $api_output["response"]["operation"]['status'] = "error";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_010",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // sent otp function goes here if failed add error
      /*
      if(otpsent failed ){
        $api_output["response"]["operation"]['status'] = "error";
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_011",
          "message" => "System error"
        ];
        $app->response->setBody($api_output);
        return;
      }


      */
      $api_output["response"]["operation"]['status'] = "success";
      $data = [];
      $data["userHash"] = $user_hash;
      $data["url"] = $CONFIG["base_url"]."pims/v1.0/verify_otp";
      $api_output["response"]["data"] = $data;
      $app->response->setBody(json_encode($api_output));
      return;



  });
?>

<?php
  $checkProxyHeaders = true; // Note: Never trust the IP address for security processes!
  $trustedProxies = ['10.0.0.1', '10.0.0.2']; // Note: Never trust the IP address for security processes!
  $app->post('/v1.0/init/', function() use ($app){
      global $CONFIG;
    $dbObj = $app->container["CoretisdbObj"];
    $api_output = array();

    $api_output["response"] = array();

    //api headers

    // api information
    $api_info = array();
    $api_info["versionNo"] = 2.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // Android platform header
    $android_platform = array();
    $android_platform["versionNo"] = 2.0;
    $android_platform["verisonName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";


    // ios platform header
    $ios_platform = array();
    $ios_platform["versionNo"] = 2.0;
    $ios_platform["versionName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";


    $error_status =false;
    $fatal_error_status =false;
    $error = array();

    //POST params
    $deviceId = (isset($_POST["deviceID"]))? trim($_POST["deviceID"]) : "";
    $lang = (isset($_POST["lang"]))? trim($_POST["lang"]) : "";
    $ip = $app->request->getIp();
    $locationX = (isset($_POST["locationX"]))? trim($_POST["locationX"]) : "";
    $locationY = (isset($_POST["locationY"]))? trim($_POST["locationY"]) : "";
    $deviceOs = (isset($_POST["deviceOs"]))? trim($_POST["deviceOs"]) : "";



    //validation

    //validating device id
    if($deviceId === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validation lang
    if($lang === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating ip
     if($ip === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating location x
    if($locationX === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating location y
    if($locationY === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating deviceOs
    if($deviceOs === "" && !in_array($deviceOs, array("android" , "ios"))){
    	$error_status =true;
    	$fatal_error_status =true;
    }


    if($fatal_error_status){
    	  	$api_output["response"]["operation"]["status"] = "fail";
    	  	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_000",
    	  		"message" => "Invalid data"
    	  	];
          echo json_encode($api_output);
          exit;
    }

    // Check deviceId is already registered

    $sql = " SELECT * FROM PIMS_MOB_APP WHERE DEVICE_ID = ? ";
    $params = array($deviceId);
    $result = $dbObj->execute_query($sql, $params);

    if(!$result){
    	$error_status = true;
    	$api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
    }

    $data_set = $result->fetchAll();
    if(is_array($data_set)  && !empty($data_set) ){

    $init_key_new = md5(mt_rand(10000, 999999));
  	// Get init key
  	$init_key_sql = " UPDATE  PIMS_MOB_APP SET INIT_KEY = ?, INIT_TIME = CURRENT_TIMESTAMP  WHERE DEVICE_ID =  ? ";
  	$params = array($init_key_new, $deviceId);
  	$result = $dbObj->execute_query($init_key_sql, $params);

  	if(!$result && $result->rowCount() <= 0){
  		$error_status = true;
      $api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
  	}

      $api_output["response"]["api"] = $api_info;
    	if($deviceOs == "android"){
    		$api_output["response"]["platform"] = $android_platform;
    	}else if($deviceOs == "ios"){
    		$api_output["response"]["platform"] = $ios_platform;
    	}

    	$api_output["response"]["operation"]["status"] = "success";
    	$api_output["response"]["data"] = array();
    	$api_output["response"]["data"]["initKey"] = $init_key_new;
      $api_output["response"]["data"]["initHash"] = $data_set[0]["INIT_HASH"];
      $api_output["response"]["data"]["initIv"] = $data_set[0]["INIT_IV"];
      $api_output["response"]["data"]["url"] = $CONFIG["base_url"]."pims/v1.0/check_mobno";

    	echo json_encode($api_output);
    	exit();


    }


    //If first time regester then insert new row

    $init_key = md5(mt_rand(10000, 999999));
    $init_iv = create_iv(mt_rand(10000, 999999));
    $insert_sql = " INSERT INTO PIMS_MOB_APP ( DEVICE_ID , DEVICE_OS, LOCATION_X, LOCATION_Y, INIT_KEY, IP_ADDR , INIT_IV ) ";
    $insert_sql .= " VALUES ( ?, ?, ?, ?, ?, ? , ?) ";
    $params = array();
    $params[] = $deviceId;
    $params[] = $deviceOs;
    $params[] = $locationX;
    $params[] = $locationY;
    $params[] = $init_key;
    $params[] = $ip;
    $params[] = $init_iv;


    $result = $dbObj->execute_query($insert_sql, $params);
    //var_dump($dbObj->_conn->errorInfo());

    if(!$result || $result->rowCount() <= 0){
    	$error_status = true;
    	$error_status = true;
    	$api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
    }


    if(!$error_status && !$fatal_error_status){
      $last_insert_id = $dbObj->conn->lastInsertId();
      $init_hash = md5($last_insert_id);
      //update init key
      $sql = " UPDATE PIMS_MOB_APP SET INIT_HASH =  ? WHERE ID = ? ";
      $params = array();
      $params[] = $init_hash;
      $params[] = $last_insert_id;
      if($dbObj->execute_query($sql, $params)){
        $api_output["response"]["api"] = $api_info;

      	if($deviceOs == "android"){
      		$api_output["response"]["platform"] = $android_platform;
      	}else if($deviceOs == "ios"){
      		$api_output["response"]["platform"] = $ios_platform;
      	}

      	$api_output["response"]["operation"]["status"] = "success";
      	$api_output["response"]["data"] = array();
      	$api_output["response"]["data"]["initKey"] = $init_key;
      	$api_output["response"]["data"]["initHash"] = $init_hash;
      	$api_output["response"]["data"]["initIv"] = $init_iv;
      	$api_output["response"]["data"]["url"] = $CONFIG["base_url"]."pims/v1.0/check_mobno";
      	echo json_encode($api_output);
        }
    }else{
      $error_status = true;
    	$error_status = true;
    	$api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	return;
    }


  });
?>

<?php

  /* Error code details
   * ERR_003 = " userhash is empty"
   * ERR_004 = " check user hash query failed"
   * ERR_005 = " User hash not found in the database"
   * ERR_006 = " Trcode decryption failed"
   * ERR_007 = " Pentype decryption failed"
   * ERR_008 = " Pencode decryption failed"
   * ERR_009 = " Check user in penmast query failed"
   * ERR_010 = " User mobile number is empty"
   * ERR_011 = " User mobile number is empty"
   * ERR_012 = " Mobile number decryption failed "
   * ERR_013 = " Device Id decryption failed "
   * ERR_014 = " Sql quey failed on passbook details"
   *
  */

/*
  $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
  $cipher->setKey("1096f19e844904907639f2d7119fe0b9");
  $cipher->setIv("f68861860f548c6c");
  $enc = $cipher->encrypt("9447429271");
  $d =  $enc;

  echo base64_encode($d);
  echo "  ||  ";
  $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
  $cipher->setKey("1096f19e844904907639f2d7119fe0b9");
  $cipher->setIv("f68861860f548c6c");
  $user_ee = $cipher->encrypt('11111');
  echo base64_encode($user_ee);


  exit;
 */
  $app->post("/v1.0/get_dataset", function() use($app){

    $dbObj = $app->container["CoretisdbObj"];
    // api information
    $api_info = array();
    $api_info["versionNo"] = 2.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // Android platform header
    $android_platform = array();
    $android_platform["versionNo"] = 2.0;
    $android_platform["versionName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";


    // ios platform header
    $ios_platform = array();
    $ios_platform["versionNo"] = 2.0;
    $ios_platform["versionName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";



    // request data
    $user_hash = $app->request->post("userHash");
    $user_mobnum = $app->request->post("mobNum");
    $user_device_id = $app->request->post("deviceID");


    // Validation


    //check user hash
    if(empty($user_hash)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_003",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    //check mobile number
    if(empty($user_mobnum)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_010",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }


    //check device id
    if(empty($user_device_id)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_011",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }


    // Check user hash is valid
    $sql = " SELECT P_LOGIN.ID, P_LOGIN.INIT_ID, P_LOGIN.USER_ID, P_LOGIN.OTP, P_LOGIN.OTP_TIME, P_LOGIN.USER_HASH, ";
	$sql .= " P_LOGIN.IS_VALID, P_LOGIN.VALID_TIME, P_LOGIN.CREATED_TIME, P_LOGIN.SESSION_KEY, P_LOGIN.SESSION_IV, P_MOB.DEVICE_OS  ";
	$sql .= " FROM PIMS_MOB_APP_USER_LOGIN AS P_LOGIN JOIN PIMS_MOB_APP AS P_MOB ON ( P_LOGIN.INIT_ID = P_MOB.ID ) ";
	$sql .= " WHERE USER_HASH = ? AND IS_VALID = 'Y' ";
    $params = array($user_hash);

    $result = $dbObj->execute_query($sql, $params);
    // check query executed sucessfully
    if(!$result){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_004",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }
    // user details
    $user_info = $result->fetchAll();

    // Check user data exists
    if( !is_array($user_info) || ( is_array($user_info) && count($user_info) == 0 )){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_005",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $session_key = $user_info[0]["SESSION_KEY"];
    $session_iv = $user_info[0]["SESSION_IV"];


    // Decrypt data

    // Decrypt mobile number
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($session_key);
    $cipher->setIv($session_iv);

    $decrypted_mobile_no = $cipher->decrypt(base64_decode($user_mobnum));
    if($decrypted_mobile_no === false){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_012",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Decrypted device id
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($session_key);
    $cipher->setIv($session_iv);
    $decrypted_device_id = $cipher->decrypt(base64_decode($user_device_id));

    if($decrypted_device_id === false){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_013",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }





    // Check user data is exists in penmast table

    $sql = " SELECT A.TRCODE, A.PENTYPE, A.PENCODE, P.PENDESC AS PENSION_TYPE,
            P.FMLY_SERV_OTH_PEN, A.PPONO, A.PENNAME, A.PERM_ADD1,
            A.PERM_ADD2, A.PERM_ADD3, A.PERM_PINCODE, A.PRES_ADD1,
            A.PRES_ADD2, A.PRES_ADD3, A.PRES_PINCODE, A.MOBILE,to_char(A.DATE_BIRTH, 'dd-mm-yyyy') DATE_BIRTH ,
            (CASE WHEN P.FMLY_SERV_OTH_PEN = 'F' THEN A.FMLY_PEN_HIGHER ELSE A.BASIC_PENSION END) AS BASIC_PENSION,
            (CASE WHEN P.FMLY_SERV_OTH_PEN = 'F' THEN A.FMLY_PEN_LOWER ELSE A.CURR_REDUCED_PEN END) AS CURRENT_REDUCED_PENSION,
            B.REVISION_NO, to_char(A.RETIREMENT_DATE, 'dd-mm-yyyy') RETIREMENT_DATE,
            (CASE WHEN P.FMLY_SERV_OTH_PEN = 'F' THEN   to_char(A.FPEN_COMMENCEDT, 'dd-mm-yyyy')  ELSE to_char(A.SPEN_COMMENCEDT, 'dd-mm-yyyy') END) AS COMMENCEDT ,
             COALESCE(H.DEPTNAME,'-') as DEPTNAME,COALESCE(I.DESIGDESC,'-') as DESIGDESC  ,COALESCE(A.LAST_OFFNAME,'-') as LAST_OFFNAME ,to_char(A.PPODATE, 'dd-mm-yyyy') PPODATE, CASE WHEN  A.DISBURSE_MODE =4 THEN 'Bank' WHEN A.DISBURSE_MODE =2 THEN 'Treasury (PTSB)' WHEN A.DISBURSE_MODE =3 THEN 'Money Order' end as DISBURSE_MODE,A.DISBURSE_MODE as DISB_MODE,A.IFSC_CODE,
			  CASE WHEN  A.DISBURSE_MODE =4 THEN VARCHAR(A.BANK_ACCNO)
             WHEN A.DISBURSE_MODE =2 THEN VARCHAR(A.PTSB_ACCNO) WHEN A.DISBURSE_MODE =3 THEN '-'
            end as ACCOUNT_NO,COALESCE(M.BANK_NAME,'-') AS BANK_NAME,COALESCE(C.RANCH_NAME,'-')AS RANCH_NAME,COALESCE(C.BRANCH_ADDRESS,'-')AS BRANCH_ADDRESS,A.PTSB_ACCNO
            FROM PENMAST AS A
            LEFT JOIN PENMAST_ADDL AS B ON A.TRCODE = B.TRCODE AND A.PENTYPE = B.PENTYPE AND A.PENCODE = B.PENCODE
            LEFT JOIN PENTYPE P ON P.PENTYPE=A.PENTYPE
            LEFT JOIN DEPT AS H ON B.DEPTCODE = H.DEPTCODE
            LEFT JOIN BANK_TYPE M ON M.BANK_CODE=A.BANK_TYPE
            LEFT join BANK_DETAILS as C on C.ifsc_code=A.ifsc_code
            LEFT JOIN SPARK_DESIG AS I ON B.DESIGCODE = I.DESIGCODE AND I.DEPTCODE = H.DEPTCODE
            WHERE A.MOBILE = ? AND CONFIRMED='Y' AND PEN_STOP='N' ";
    $params = array($decrypted_mobile_no);

    $result = $dbObj->execute_query($sql, $params);
    if(!$result){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_009",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $user_pen_info = $result->fetchAll();

    if( !is_array($user_pen_info) || ( is_array($user_pen_info) && count($user_pen_info) === 0 ) ){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_010",
        "message" => "User details not found"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $data = array();
    $data["dataSet"] = array();
    foreach( $user_pen_info as $user_det){
      $user_data = array();
      // user details
      $det = array();
      $det["Pensioner Name"] = $user_det["PENNAME"];
      $det["Pension Type"] = $user_det["PENSION_TYPE"];
      $det["PPO Number"] ="PPONO : ". $user_det["PPONO"];
      $det["Mobile No"] = $user_det["MOBILE"];
      $det["Date of Birth"] = $user_det["DATE_BIRTH"];
      $det["Address"] = $user_det["PERM_ADD1"]." ".$user_det["PERM_ADD2"]." ".$user_det["PERM_ADD3"]." ".$user_det["PERM_PINCODE"];

      $user_data["userInfo"] = $det;


	  //============
	   // user Key details
      $user_key = array();
     // $pension_details["pentypeCat"] = $user_det["FMLY_SERV_OTH_PEN"];
      $user_key["TRCODE"] = $user_det["TRCODE"];
      $user_key["PENTYPE"] = $user_det["PENTYPE"];
      $user_key["PENCODE"] = $user_det["PENCODE"];

      $user_data["user_key"] =  $user_key;
	  //==========


      // user pension details
      $pension_details = array();
     // $pension_details["pentypeCat"] = $user_det["FMLY_SERV_OTH_PEN"];
      $pension_details["Basic Pension"] = $user_det["BASIC_PENSION"]." (₹)";
	  
	  
	  if($user_det["CURRENT_REDUCED_PENSION"] == '0')
		{		
		 $pension_details["Reduced Pension"] = '-';
		}
		else
		{
		$pension_details["Reduced Pension"] =$user_det["CURRENT_REDUCED_PENSION"]." (₹)";
		}     
		
		$pension_details["Revision No"] = $user_det["REVISION_NO"];    
	  	  
	   if($user_det["RETIREMENT_DATE"] == '')
		{	
		$pension_details["Retirement Date"] = '-';
		}
		else
		{
			  $pension_details["Retirement Date"] = $user_det["RETIREMENT_DATE"];
		}
		 
	   if($user_det["PPODATE"] == '')
		{		
			$pension_details["Pension Sanction Date"] = '-';
		}
		else
		{
			$pension_details["Pension Sanction Date"] = $user_det["PPODATE"];
		}
		
		
	  $pension_details["Pension Commence Date"] = $user_det["COMMENCEDT"];
      $pension_details["Last Department"] = $user_det["DEPTNAME"];
 
	   	  
		if($user_det["LAST_OFFNAME"] == '')
		{		
			$pension_details["Last Office"] = '-';
		}
		else
		{
			$pension_details["Last Office"] = $user_det["LAST_OFFNAME"];
		}
	 
      $pension_details["Last Designation"] = $user_det["DESIGDESC"];


      $user_data["pensionDetails"] =  $pension_details;



      // Disbursment
      $disb_details = array();

      $disb_details["Disbursement Mode"] = $user_det["DISBURSE_MODE"];
	  
	  
	  
	  if(($user_det["DISB_MODE"] == '2') || ($user_det["DISB_MODE"] == '4'))
		{
		$disb_details["Bank Name"] = $user_det["BANK_NAME"];
		$disb_details["Account Number"] = $user_det["ACCOUNT_NO"];
		$disb_details["Branch Name"] = $user_det["RANCH_NAME"];
		$disb_details["Branch Address"] = $user_det["BRANCH_ADDRESS"];
		}  
     
      $user_data["disbDetails"] = $disb_details;
      // Passbook details
      $passbook_details = array();


      $sql_passbook = "SELECT MONTH, YEAR, GROSS_AMT,FUTURE_DATE,
      (CASE
      WHEN TRANSACTION_TYPE = 'A' THEN 'Arrear'
      WHEN TRANSACTION_TYPE = 'P' THEN 'Pension'
      WHEN TRANSACTION_TYPE = 'C' THEN 'Commutation'
      WHEN TRANSACTION_TYPE = 'G' THEN 'Gratuity'
      END) AS TYPE  ,DISBURSE_MODE,CREDIT_DATE,to_char(CREDIT_DATE, 'dd-mm-yyyy')CREDITDATE
      FROM PENBLK_MON_MAST
      WHERE TRCODE =? AND PENTYPE = ? AND PENCODE = ? AND CONFIRMED = 'Y' AND RECORD_PROCESSED = 'Y'
      AND (RN_STATUS IS NULL OR RN_STATUS = '') ORDER BY  CREDIT_DATE DESC";

      $params = array();
      $params[] = $user_det["TRCODE"];
      $params[] = $user_det["PENTYPE"];
      $params[] = $user_det["PENCODE"];
      $passbookResult = $dbObj->execute_query($sql_passbook, $params);

      if(!$passbookResult){
        $api_output["response"]["operation"]['error'] = [
          "code" => "ERR_014",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }
      $result = $passbookResult->fetchAll();
      if(is_array($result) && count($result) > 0){
        foreach($result as $passbook_det){
         $row = array();
         //$row["creditDate"] = $passbook_det["CREDITDATE"];
		 
		 if($passbook_det["CREDITDATE"] == '')
		{		
			$row["creditDate"] = '-';
		}
		else
		{
			$row["creditDate"] = $passbook_det["CREDITDATE"];
		}
		 
		 
         $row["details"] = $passbook_det["TYPE"]." - ".$passbook_det["MONTH"]."/".$passbook_det["YEAR"];
         $row["amount"] = '₹ '.$passbook_det["GROSS_AMT"];
         $passbook_details[] =$row;
        }
      }
      $user_data["passbookDetails"] = $passbook_details;

      $data["dataSet"][] = $user_data;
    }

    $sql = " select '('||trcode||')'||trname  AS TRNAME, ADDRESS1|| ADDRESS2 AS TRADDR from trmast order by trcode ";
    $pdostmt = $dbObj->execute_query($sql);
    if(!$pdostmt){
      // error
    }
    $result_set = $pdostmt->fetchAll();
    if(!is_array($result_set)){
      // error
    }
    $contact_collection = array();
    foreach($result_set as $result){
      $contact = array();
      $contact[] = remove_null($result["TRNAME"]);
      $contact[] = remove_null($result["TRADDR"]);
      $contact_collection[] = $contact;
    }
    $data["contactDetails"] = $contact_collection;
    // encrypt data and base 64 encode
    /*
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($session_key);
    $cipher->setIv($session_iv);
    $encrypted_json_data = $cipher->encrypt(json_encode($data));
    $base_64_encrypted_data = base64_encode($encrypted_json_data);
    */
	if($user_info[0]['DEVICE_OS'] == 'ios'){
		$api_output["response"]['platform'] = $ios_platform;
	}else{
		$api_output["response"]['platform'] = $android_platform;
	}
	
    $api_output["response"]["operation"]['status'] = "success";
    $api_output["response"]["data"] = $data;
    $app->response->setBody(json_encode($api_output));
    return;

  });
?>

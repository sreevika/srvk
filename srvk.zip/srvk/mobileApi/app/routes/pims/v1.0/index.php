<?php
	require_once ROOT_DIR.'app/routes/pims/v1.0/init.php';
	require_once ROOT_DIR.'app/routes/pims/v1.0/check_mobno.php';
	require_once ROOT_DIR.'app/routes/pims/v1.0/verify_otp.php';
	require_once ROOT_DIR.'app/routes/pims/v1.0/get_dataset.php';
	require_once ROOT_DIR.'app/routes/pims/v1.0/logout.php';
?>

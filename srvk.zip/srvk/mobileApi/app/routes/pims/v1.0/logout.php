<?php

/**
 * ERROR CODE
 * ERR_000 = " Empty user hash "
 * ERR_001 = " Empty mobile number"
 * ERR_002 = " Empty device ID"
 * ERR_003 = " Select user hash query failed "
 * ERR_004 = " Fetch user data failed"
 */


$app->post("/v1.0/logout", function() use($app){

    $dbObj = $app->container["CoretisdbObj"];
    // Data
    $user_hash = $app->request->post("userHash");
    $mob_num = $app->request->post("mobNum");
    $device_id = $app->request->post("deviceID");

    // data validation

    // Check user hash is empty or not

    if(empty($user_hash) || ( $user_hash && strlen($user_hash) > 100)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_000",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }
    // Check mobile number is empty or not
    if(empty($mob_num) || ( $mob_num && strlen($mob_num) > 100)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_001",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }
    // Check device id is empty or not
    if(empty($device_id) || ( $device_id && strlen($device_id) > 100)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_002",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }
    // Check user hash exists in database
    $sql = " SELECT * FROM PIMS_MOB_APP_USER_LOGIN WHERE USER_HASH = ? ";
    $params = array($user_hash);

    $stmt = $dbObj->execute_query($sql, $params);

    if(!$stmt){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_003",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $user_login_data = $stmt->fetchAll();

    if(!is_array($user_login_data)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_004",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    if(count($user_login_data) == 0){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_005",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // set Is valid to N
    $sql = " UPDATE PIMS_MOB_APP_USER_LOGIN SET IS_VALID = 'N' WHERE ID = ? ";
    $params = array($user_login_data[0]["ID"]);

    $stmt = $dbObj->execute_query($sql, $params);

    if(!$stmt || $stmt->rowCount() == 0){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_006",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $api_output["response"]["operation"]['status'] = "success";
    $app->response->setBody(json_encode($api_output));
    return;

});
?>

<?php
  /**
   * ERROR CODE
   * ERR_000 " Empty user hash or user hash length greater than 150 "
   * ERR_001 " Empty Device Id or device id  length greater than 150 "
   * ERR_002 " Empty Mobile number or mobile number length greater than 150 "
   * ERR_003 " Select login user hash query failed "
   * ERR_004 " No result user hash not fount "
   * ERR_005 " Session is not valid "
   * ERR_006 " Mobile number decryption failed "
   * ERR_007 " Select user data from TSBONLINE_PORTAL_USERS query failed "
   * ERR_008 " User mobile not found on the database"
   * ERR_009 " Profile details query failed "
   * ERR_010 " No result found"
   * ERR_011 " Account deteails query failed "
   * ERR_012 " Account details is empty"
   */
  $app->post("/v1.0/dashboard", function() use($app){


      /*
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("502ea6fb921bdf218e7ccead40357d14");
      $cipher->setIv("fc00e692f9b144c6");
      $enc = $cipher->encrypt("8089275598");
      $d =  base64_encode($enc);

      echo $d;
      echo "  ||  ";
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("502ea6fb921bdf218e7ccead40357d14");
      $cipher->setIv("fc00e692f9b144c6");
      $user_ee = $cipher->encrypt('11111');
      echo base64_encode($user_ee);
      exit;
      */


      $dbObj = $app->container["TsbdbObj"];
      $api_output = array();
      $api_output["response"] = array();


      //api headers

      // api information
      $api_info = array();
      $api_info["versionNo"] = 1.0;
      $api_info["versionName"] = "Rest mobile api for treasury";
      $api_info["releseDate"] = "17/10/2017";
      $api_info["description"] = "Rest api for treasury";


      // Android platform header
      $android_platform = array();
      $android_platform["verisonNo"] = 1.0;
      $android_platform["verisonName"] = "Rest for treasury";
      $android_platform["forceUpdate"] = "yes";
      $android_platform["description"] = "Rest api for treasury";


      // ios platform header
      $ios_platform = array();
      $ios_platform["verisonNo"] = 1.0;
      $ios_platform["verisonName"] = "Rest for treasury";
      $ios_platform["forceUpdate"] = "yes";
      $ios_platform["description"] = "Rest api for treasury";




      $user_hash = $app->request->post("userHash");
      $device_id = $app->request->post("deviceID");
      $mob_num = $app->request->post("mobNum");

      // Check user hash
      if(empty($user_hash) || (!empty($user_hash) && strlen($user_hash) > 150 ) ){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_000",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // check device Id
      if(empty($device_id) || (!empty($device_id) && strlen($user_hash) > 150 )){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // check mob num
      if(empty($mob_num) || (!empty($mob_num) && strlen($mob_num) > 150 )){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_002",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Check user hash is in and is valid
      $sql = " SELECT * FROM TSBONLINE_MOB_APP_USER_LOGIN JOIN TSBONLINE_MOB_APP ON (TSBONLINE_MOB_APP_USER_LOGIN.INIT_ID = TSBONLINE_MOB_APP.ID)  WHERE TSBONLINE_MOB_APP_USER_LOGIN.USER_HASH = ? ";
      $params = array();
      $params[] = $user_hash;

      $stmt = $dbObj->execute_query($sql, $params);

      if(!$stmt){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_003",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $user_login_result = $stmt->fetchAll();

      if(!is_array($user_login_result) || ( is_array($user_login_result) && count($user_login_result) == 0 )  ){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_004",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Check is logged in
      if($user_login_result[0]["IS_VALID"] != 'Y'){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_005",
          "message" => "Session timeout"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }
      $aes_key = $user_login_result[0]["SESSION_KEY"];
      $aes_iv = $user_login_result[0]["SESSION_IV"];
      // Decrypt mobile number
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey($aes_key);
      $cipher->setIv($aes_iv);
      $decrypted_mob = $cipher->decrypt(base64_decode($mob_num));

      if(!$decrypted_mob){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_006",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      // Check mobile number exists
      $sql = " SELECT * FROM TSBONLINE_PORTAL_USERS WHERE MOBILE = ? ORDER BY CUSTOMERID";
      $params = array($decrypted_mob);

      $stmt = $dbObj->execute_query($sql, $params);

      if(!$stmt){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_007",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      $user_data = $stmt->fetchAll();
      if(!is_array($user_data) || ( is_array($user_data) && count($user_data) == 0 ) ){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_008",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }





      // Select dashboard details
      $sql = " select NAME, a.customerid as CUSTOMER_ID, PRES_ADD1, PRES_ADD2, PRES_ADD3,  a.mobile,BIRTH_DATE ";
      $sql .= " from TSBONLINE_PORTAL_USERS a ,tsb_customer_mast b ";
      $sql .= " where a.customerid=b.customer_id and a.MOBILE = ? ";
      $params = array();
      $params[] = $decrypted_mob;

      $stmt = $dbObj->execute_query($sql, $params);
      if(!$stmt){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_009",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $profile_details = $stmt->fetchAll();

      if(!is_array($profile_details) || ( is_array($profile_details) && count($profile_details) == 0 ) ){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_010",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }


      $sql = "select a.customerid AS CUSTOMERID, b.accno ,d.acctype_abbr, d.ACCTYPE_DES ,c.scrt_bal as BALANCE  , c.opening_bal ";
      $sql .= " from tsbonline_portal_users a ,tsb_customer_account b ,tsb_accmast c , sb_acctype d ";
      $sql .= " where d.acctype=b.acctype and  c.accno=b.accno and a.customerid=b.customer_id and a.mobile = ?  order by a.CUSTOMERID ";

      $params = array($decrypted_mob);

      $stmt = $dbObj->execute_query($sql, $params);

      if(!$stmt){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_011",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $account_details = $stmt->fetchAll();

      if(!is_array($account_details) || ( is_array($account_details) && count($account_details) == 0  )  ){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_012",
          "message" => " Invalid Data "
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $account_data = array();
      foreach($account_details as $account){
        $list = array();
        $list["accNo"] = $account["ACCNO"];
        $list["accType"] = $account["ACCTYPE_ABBR"];
        $list["accTypeDesc"] = $account["ACCTYPE_DES"];
        $list["crntBal"] = $account["BALANCE"];
        $list["openBal"] = $account["OPENING_BAL"];
        $account_data[]  = $list;
      }

      $api_output["response"]["operation"]['status'] = "success";
      $data = array();
      $profile_data = array();
      $profile_data["name"] = $profile_details[0]["NAME"];
      $profile_data["address"] = $profile_details[0]["PRES_ADD1"]."\n ".$profile_details[0]["PRES_ADD2"]."\n ".$profile_details[0]["PRES_ADD3"];
      $profile_data["mobNum"] = $decrypted_mob;
      $profile_data["custID"] = "ID- ".$profile_details[0]["CUSTOMER_ID"];
      $profile_details["dob"] = $profile_details[0]["BIRTH_DATE"];
      $data["profileDetails"] = $profile_data;
      $data["accntDetails"] = $account_data;
      $data["timestamp"] = date_format(new DateTime("now"), "d/M/Y g-i-s A");
      $api_output["response"]["data"] = $data;
      if($user_login_result[0]['DEVICE_OS'] == 'android'){
	$api_output['response']['platform'] = $android_platform;
      }else if($user_login_result[0]['DEVICE_OS'] == 'ios' ){
	$api_output['response']['platform'] = $ios_platform;
      }
      
      $app->response->setBody(json_encode($api_output));
  });
?>

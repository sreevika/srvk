<?php
  $checkProxyHeaders = true; // Note: Never trust the IP address for security processes!
  $trustedProxies = ['10.0.0.1', '10.0.0.2']; // Note: Never trust the IP address for security processes!
  $app->post('/v1.0/init/', function() use ($app){

    $dbObj = $app->container["TsbdbObj"];
    $api_output = array();

    $api_output["response"] = array();

    //api headers

    // api information
    $api_info = array();
    $api_info["versionNo"] = 1.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // Android platform header
    $android_platform = array();
    $android_platform["verisonNo"] = 1.0;
    $android_platform["verisonName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";


    // ios platform header
    $ios_platform = array();
    $ios_platform["verisonNo"] = 1.0;
    $ios_platform["verisonName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";


    $error_status =false;
    $fatal_error_status =false;
    $error = array();

    //POST params
    $deviceId = (isset($_POST["deviceID"]))? trim($_POST["deviceID"]) : "";
    $lang = (isset($_POST["lang"]))? trim($_POST["lang"]) : "";
    $ip = $app->request->getIp();
    $locationX = (isset($_POST["locationX"]))? trim($_POST["locationX"]) : "";
    $locationY = (isset($_POST["locationY"]))? trim($_POST["locationY"]) : "";
    $deviceOs = (isset($_POST["deviceOs"]))? trim($_POST["deviceOs"]) : "";



    //validation

    //validating device id
    if($deviceId === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validation lang
    if($lang === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating ip
     if($ip === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating location x
    if($locationX === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating location y
    if($locationY === ""){
    	$error_status =true;
    	$fatal_error_status =true;
    }

    //validating deviceOs
    if($deviceOs === "" && !in_array($deviceOs, array("android" , "ios"))){
    	$error_status =true;
    	$fatal_error_status =true;
    }


    if($fatal_error_status){
    	  	$api_output["response"]["operation"]["status"] = "fail";
    	  	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_000",
    	  		"message" => "Invalid data"
    	  	];
          echo json_encode($api_output);
          exit;
    }

    // Check deviceId is already registered

    $sql = " SELECT COUNT(*) FROM TSBONLINE_MOB_APP WHERE DEVICE_ID = ? ";
    $params = array($deviceId);
    $result = $dbObj->execute_query($sql, $params);

    if(!$result){
    	$error_status = true;
    	$api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
    }

    $count = $result->fetchColumn();

    if($count > 0){

    $init_key_new = md5(mt_rand(10000, 999999));
  	// Get init key
  	$init_key_sql = " UPDATE  TSBONLINE_MOB_APP SET INIT_KEY = ?, INIT_TIME = CURRENT_TIMESTAMP  WHERE DEVICE_ID =  ? ";
  	$params = array($init_key_new, $deviceId);
  	$result = $dbObj->execute_query($init_key_sql, $params);

  	if(!$result && $result->rowCount() <= 0){
  		$error_status = true;
      $api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
  	}

      $api_output["response"]["api"] = $api_info;
    	if($deviceOs == "android"){
    		$api_output["response"]["platform"] = $android_platform;
    	}else if($deviceOs == "ios"){
    		$api_output["response"]["platform"] = $ios_platform;
    	}

    	$api_output["response"]["operation"]["status"] = "success";
    	$api_output["response"]["data"] = array();
    	$api_output["response"]["data"]["init_key"] = $init_key_new;
    	echo json_encode($api_output);
    	exit();


    }


    //If first time regester then insert new row

    $init_key = md5(mt_rand(10000, 999999));
    $insert_sql = " INSERT INTO TSBONLINE_MOB_APP ( DEVICE_ID , DEVICE_OS, LOCATION_X, LOCATION_Y, INIT_KEY, IP_ADDR ) ";
    $insert_sql .= " VALUES ( ?, ?, ?, ?, ?, ? ) ";
    $params = array();
    $params[] = $deviceId;
    $params[] = $deviceOs;
    $params[] = $locationX;
    $params[] = $locationY;
    $params[] = $init_key;
    $params[] = $ip;


    $result = $dbObj->execute_query($insert_sql, $params);
    //var_dump($dbObj->_conn->errorInfo());

    if(!$result || $result->rowCount() <= 0){
    	$error_status = true;
    	$error_status = true;
    	$api_output["response"]["operation"]["status"] = "error";
    	$api_output["response"]["operation"]["error"] = [
    	  		"code" => "ERR_001",
    	  		"message" => "System error"
    	  	];
    	$api_output["response"]["api"] = $api_info;
    	echo json_encode($api_output);
    	exit;
    }


    if(!$error_status && !$fatal_error_status){



    	$api_output["response"]["api"] = $api_info;

    	if($deviceOs == "android"){
    		$api_output["response"]["platform"] = $android_platform;
    	}else if($deviceOs == "ios"){
    		$api_output["response"]["platform"] = $ios_platform;
    	}

    	$api_output["response"]["operation"] = "success";
    	$api_output["response"]["data"] = array();
    	$api_output["response"]["data"]["init_key"] = $init_key;
    	echo json_encode($api_output);

    }


  });

  $app->get("/test", function(){
    $entity = new Acme\Tsb\Entity\InitEntity();
    $repo = new Acme\Tsb\Repo\InitRepo($entity);
    var_dump($repo);
  });
?>

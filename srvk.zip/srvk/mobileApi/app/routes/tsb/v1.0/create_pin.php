<?php
/**
 * ERROR CODE
 *
 * ERR_000 = ' User hash is invalid empty or length greater than 100'
 * ERR_001 = ' Device Id is invalid empty or length greater than 100'
 * ERR_002 = ' Mobile number is invalid empty or length greater than 100'
 * ERR_003 = ' pin is invalid empty or length greater than 100'
 * ERR_004 = ' Check user hash query failed '
 * ERR_005 = ' User hash doesn't exists '
 * ERR_006 = ' pin failed to decrypt or otp length is greater than 6 '
 * ERR_007 = ' UPDATE PIN query Failed '
 */
  $app->post("/v1.0/create_pin", function() use($app){
    /*
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey("05bfb7e8abcdb3a9d3db01be0553d091");
    $cipher->setIv("f96f18683dff9622");
    $enc = $cipher->encrypt("8089275598");
    $d =  base64_encode($enc);

    echo $d;
    echo "  ||  ";
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey("05bfb7e8abcdb3a9d3db01be0553d091");
    $cipher->setIv("f96f18683dff9622");
    $user_ee = $cipher->encrypt('11111');
    echo base64_encode($user_ee);

    echo "  ||  ";
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey("05bfb7e8abcdb3a9d3db01be0553d091");
    $cipher->setIv("f96f18683dff9622");
    $user_ee = $cipher->encrypt('12345');
    echo base64_encode($user_ee);

    exit;
    */


    global $CONFIG;
    $dbObj = $app->container["TsbdbObj"];
    $api_output["response"] = array();

    //api headers

    // api information
    $api_info = array();
    $api_info["versionNo"] = 1.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // Android platform header
    $android_platform = array();
    $android_platform["verisonNo"] = 1.0;
    $android_platform["verisonName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";


    // ios platform header
    $ios_platform = array();
    $ios_platform["verisonNo"] = 1.0;
    $ios_platform["verisonName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";

    // Post data

    $user_hash = $app->request->post("userHash");
    $device_id = $app->request->post("deviceID");
    $mob_num = $app->request->post("mobNum");
    $pin = $app->request->post("pin");


    // Validate data

    // Validate user Hash
    if(empty($user_hash) || strlen($user_hash) > 100){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_000",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Validate deviceID
    if(empty($device_id) || strlen($device_id) > 100){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_001",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Validate mobile number
    if(empty($mob_num) || strlen($mob_num) > 100){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_002",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Validate pin
    if(empty($pin) || strlen($pin) > 100){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_003",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    //Check user hash exists
    $sql = "  SELECT APP_LOGIN.ID AS ID, APP_LOGIN.INIT_ID AS INIT_ID, APP_LOGIN.USER_HASH AS USER_HASH, APP_LOGIN.OTP AS OTP, APP_LOGIN.OTP_TIME AS OTP_TIME, APP_LOGIN.USER_KEY AS USER_KEY, APP_LOGIN.IS_VALID AS IS_VALID, APP_LOGIN.VALID_TIME AS VALID_TIME, APP_LOGIN.USER_ID AS USER_ID, APP_LOGIN.CREATED_TIME AS CREATED_TIME, APP_LOGIN.SESSION_KEY AS SESSION_KEY, APP_LOGIN.SESSION_IV AS SESSION_IV, APP_LOGIN.LOGIN_PIN AS LOGIN_PIN, MOB_APP.DEVICE_OS AS DEVICE_OS  FROM TSBONLINE_MOB_APP_USER_LOGIN AS APP_LOGIN JOIN TSBONLINE_MOB_APP MOB_APP ON (TSBONLINE_MOB_APP_USER_LOGIN.INIT_ID = TSBONLINE_MOB_APP.ID) WHERE USER_HASH = ? ";
    $params = array($user_hash);

    $stmt = $dbObj->execute_query($sql, $params);

    if(!$stmt){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_004",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $user_login_info = $stmt->fetchAll();

    if(!is_array($user_login_info) || (is_array($user_login_info) && count($user_login_info) == 0) ){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_005",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Decrypt pin
    $aes_key = $user_login_info[0]["SESSION_KEY"];
    $aes_iv = $user_login_info[0]["SESSION_IV"];
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($aes_key);
    $cipher->setIv($aes_iv);

    $decrypted_pin = $cipher->decrypt(base64_decode($pin));
    if($decrypted_pin == false ||  ( $decrypted_pin != false && count($decrypted_pin) > 6)  ){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_006",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $new_session_key = md5($aes_key.time());
    $new_session_iv = create_iv($new_session_key);
    // save otp add valify user
    $sql = " UPDATE TSBONLINE_MOB_APP_USER_LOGIN SET LOGIN_PIN = ?, SESSION_KEY = ?, SESSION_IV = ?  , IS_VALID = 'Y'  WHERE ID = ? ";

    $params = array();
    $params[] = $decrypted_pin;
    $params[] = $new_session_key;
    $params[] = $new_session_iv;
    $params[] = $user_login_info[0]["ID"];

    $stmt = $dbObj->execute_query($sql, $params);
    //var_dump($dbObj->getConnection()->errorInfo()); exit;
    if(!$stmt || ($stmt && $stmt->rowCount() == 0) ){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_007",
        "message" => " System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // If sucess
    $api_output["response"]["operation"]['status'] = "success";
    if($user_login_info[0]['DEVICE_OS'] == 'android'){
      $api_output['response']['platform'] = $android_platform;
    }else if($user_login_info[0]['DEVICE_OS'] == 'ios' ){
      $api_output['response']['platform'] = $ios_platform;
    }
    $data = [];
    $data["sessionKey"] = $new_session_key;
    $data["sessionIv"] = $new_session_iv;
    $urls = [];
    $data["url"] = $CONFIG["base_url"]."tsb/v1.0/profile_details";
    $api_output["response"]["data"] = $data;
    $app->response->setBody(json_encode($api_output));
    return;









  });
?>

<?php
$app->response->headers->set('Content-Type', 'application/json');
require_once ROOT_DIR.'app/routes/tsb/v1.0/init.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/check_mobno.php';
//require_once ROOT_DIR.'app/routes/tsb/v1.0/sent_otp.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/verify_otp.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/create_pin.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/verify_pin.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/change_pin.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/dashboard.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/passbook.php';
require_once ROOT_DIR.'app/routes/tsb/v1.0/logout.php';
?>

<?php
  /**
   * Error codes
   * ERR_000 = " Device Id is empty or length is too large "
   * ERR_001 = " Device os is empty or length is too large "
   * ERR_002 = " Location X data length is too large "
   * ERR_003 = " Location Y data length is too large "
   */
  $checkProxyHeaders = true; // Note: Never trust the IP address for security processes!
  $trustedProxies = ['10.0.0.1', '10.0.0.2']; // Note: Never trust the IP address for security processes!
  $app->post('/v1.0/init/', function() use ($app){
    global $CONFIG;
    // Api output
    $output = array();

    // output response
    $output["response"] = array();

    // api information
    $api_info = array();
    $api_info["versionNo"] = 2.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // api platform information information

    // for android
    $android_platform = array();
    $android_platform["versionNo"] = 2.0;
    $android_platform["verisonName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";

    // for ios

    $ios_platform = array();
    $ios_platform["versionNo"] = 2.0;
    $ios_platform["verisonName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";




    $dbObj = $app->container["TsbdbObj"];
    // Post data
    $device_id = $app->request->post("deviceID");
    $device_os = $app->request->post("deviceOs");
    $location_x = $app->request->post("locationX");
    $location_y = $app->request->post("locationY");

    // Validating post data

    // check device id

    if(empty($device_id) || strlen($device_id) > 150){
      $output["response"]["operation"]["status"] = "failed";
      $output["response"]["error"] = [
        "code" => "ERR_000",
        "message" => "Invalid Data"
      ];
      echo json_encode($output);
      return;
    }

    // check device os

    if(empty($device_os) || strlen($device_os) > 150){
      $output["response"]["operation"]["status"] = "failed";
      $output["response"]["error"] = [
        "code" => "ERR_001",
        "message" => "Invalid Data"
      ];
      echo json_encode($output);
      return;
    }

    // check location x

    if(!empty($location_x) && strlen($location_x) > 100){
      $output["response"]["operation"]["status"] = "failed";
      $output["response"]["error"] = [
        "code" => "ERR_002",
        "message" => "Invalid Data"
      ];
      echo json_encode($output);
      return;
    }

    // check location y

    if(!empty($location_y) && strlen($location_y) > 100){
      $output["response"]["operation"]["status"] = "failed";
      $output["response"]["error"] = [
        "code" => "ERR_003",
        "message" => "Invalid Data"
      ];
      echo json_encode($output);
      return;
    }


    // Check device id is already registered
    $entity_generator = new Acme\Tsb\Auth\Init\InitEntityGenerator();
    $repo = new Acme\Tsb\Repo\InitRepo($entity_generator, $dbObj);
    $entity = $repo->findByDevice($device_id, $device_os);
    if(!$entity){
      $entity = $repo->getEntity();
    }

    $entity->setDeviceId($device_id);
    $entity->setDeviceOs($device_os);
    $entity->setLocationX($location_x);
    $entity->setLocationY($location_y);
    $tsbInitManager = new Acme\Tsb\Auth\Init\TsbInitManager($repo);
    $status = $tsbInitManager->initializeDevice();

    if($status){
          $output["api"] = $api_info;
          $output["response"]["operation"]["status"] = "success";
          if($device_os == "android"){
              $output['response']["platform"] = $android_platform;
          }else if($device_os == "ios"){
              $output['response']["platform"] = $ios_platform;
          }
          $data = array();
          $data["initHash"] = $entity->getInitHash();
          $data["initKey"] = $entity->getInitKey();
          $data["initIv"] = $entity->getInitIv();
          $data["url"] = $CONFIG["base_url"]."tsb/v1.0/check_mobno";
          $output["response"]["data"] = $data;
          echo json_encode($output);
          return;
    }



    // error case

  });

  $app->get("/test", function() use($app){
    $entity = new Acme\Tsb\Entity\InitEntity();
    $dbObj = $app->container["TsbdbObj"];
    $entity->setInitHash("hai there");
    $entity->setDeviceId("0101010");
    $repo = new Acme\Tsb\Repo\InitRepo($entity, $dbObj);
  });
?>

<?php
/*
 * ERR_000 = " Invalid user hash user hash is empty"
 * ERR_001 = " Invalid mobile number mobile number is empty"
 * ERR_002 = " Invalid device id device id is empty"
 * ERR_003 = " Invalid otp , otp is empty"
 * ERR_004 = " Select user by hash query failed "
 * ERR_005 = " user not found fot the purticular user hash"
 * ERR_006 = " Mobile number decrytion failed "
 * ERR_007 = " Device Id cant decrypte "
 * ERR_008 = " Otp cant decrypte "
 * ERR_009 = " Invalid otp "
 * ERR_010 = " Otp Expired "
 * ERR_011 = " System error failed to execute update session query, validate user "
 * ERR_012 = " System error failed select query check device id on PIMS_MOB_APP "
 * ERR_013 = " No data found for the given init id "
 * ERR_014 = " Invalid device "
 *
 *
 *
 *
 */
$app->post("/v1.0/verify_otp", function() use($app){

/*
  $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
  $cipher->setKey(md5("12345"));
  $cipher->setIv(create_iv(md5("12345")));
  $enc = $cipher->encrypt("8089275598");
  $d =  base64_encode($enc);

  echo $d;
  echo "  ||  ";
  $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
  $cipher->setKey(md5("12345"));
  $cipher->setIv(create_iv(md5("12345")));
  $user_ee = $cipher->encrypt('11111');
  echo base64_encode($user_ee);

  echo "  ||  ";
  $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
  $cipher->setKey(md5("12345"));
  $cipher->setIv(create_iv(md5("12345")));
  $user_ee = $cipher->encrypt('12345');
  echo base64_encode($user_ee);

  exit;
*/


    global $CONFIG;



    $dbObj = $app->container["TsbdbObj"];
    $api_output["response"] = array();

    //api headers

    // api information
    $api_info = array();
    $api_info["versionNo"] = 1.0;
    $api_info["versionName"] = "Rest mobile api for treasury";
    $api_info["releseDate"] = "17/10/2017";
    $api_info["description"] = "Rest api for treasury";


    // Android platform header
    $android_platform = array();
    $android_platform["verisonNo"] = 1.0;
    $android_platform["verisonName"] = "Rest for treasury";
    $android_platform["forceUpdate"] = "yes";
    $android_platform["description"] = "Rest api for treasury";


    // ios platform header
    $ios_platform = array();
    $ios_platform["verisonNo"] = 1.0;
    $ios_platform["verisonName"] = "Rest for treasury";
    $ios_platform["forceUpdate"] = "yes";
    $ios_platform["description"] = "Rest api for treasury";

    $user_hash = $app->request->post("userHash");
    $user_mobnum = $app->request->post("mobNum");
    $user_deviceid = $app->request->post("deviceID");
    $user_otp = $app->request->post("otp");

    // validation

    // Check user hash
    if(empty($user_hash)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_000",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check mobile number
    if(empty($user_mobnum)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_001",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check device id
    if(empty($user_deviceid)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_002",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check user otp
    if(empty($user_otp)){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_003",
        "message" => "Invalid Data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check user hash is exists
    $sql = " SELECT * FROM TSBONLINE_MOB_APP_USER_LOGIN  WHERE USER_HASH = ? ";
    $params = array($user_hash);

    $result = $dbObj->execute_query($sql, $params);

    // Check query executed sucessfully
    if(!$result){
      $api_output["response"]["operation"]['status'] = "error";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_004",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $user_info = $result->fetchAll();

    // Check user exists
    if(is_array($user_info) && count($user_info) == 0){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_005",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $aes_key = md5($user_info[0]["OTP"]);
    $aes_iv = create_iv($aes_key);
    // Decrypt Mobile number
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($aes_key);
    $cipher->setIv($aes_iv);

    $decrypted_mob = $cipher->decrypt(base64_decode($user_mobnum));
    // If failed to decrypt mobile number
    if($decrypted_mob === false){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_006",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }


    // Decrypt device id

    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($aes_key);
    $cipher->setIv($aes_iv);

    $decrypted_device_id = $cipher->decrypt(base64_decode($user_deviceid));

    // If device id cant decrypte then
    if($decrypted_device_id === false){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_007",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check device id is valid
    $sql =  " SELECT * FROM TSBONLINE_MOB_APP WHERE ID = ? ";
    $params = array($user_info[0]["INIT_ID"]);
    $result = $dbObj->execute_query($sql, $params);

    if(!$result){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_012",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    $init_info = $result->fetchAll();

    if(is_array($init_info) && count($init_info) === 0){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_013",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check device id is correct

    if($init_info[0]["DEVICE_ID"] !== $decrypted_device_id){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_014",
        "message" => "Invalid Device"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }



    // Decrypt Device Otp

    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
    $cipher->setKey($aes_key);
    $cipher->setIv($aes_iv);

    $decrypted_otp = $cipher->decrypt(base64_decode($user_otp));
    // If otp decryption failed
    if($decrypted_otp === false){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_008",
        "message" => "Invalid data"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }


    // Check otp is correct
    if($user_info[0]["OTP"] !== $decrypted_otp){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_009",
        "message" => "Invalid otp"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // Check otp time expire
    $curent_timestamp = time();
    $otp_sent_time = db2_timestamp_to_unix($user_info[0]["OTP_TIME"]);
    $expire_time = $otp_sent_time + ( 60 * 50);
    if($curent_timestamp > $expire_time){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_010",
        "message" => "Otp expired"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }

    // create session iv and session key
    $session_key = md5($user_info[0]["ID"].$user_info[0]["USER_HASH"]);
    $session_iv = create_iv(md5($session_key));

    // Save session_key, session_iv , vefify user and update virify time
    $sql = " UPDATE TSBONLINE_MOB_APP_USER_LOGIN SET SESSION_KEY = ?, SESSION_IV = ?,  VALID_TIME = ? WHERE ID = ? ";
    $params = array();
    $params[] = $session_key;
    $params[] = $session_iv;
    $params[] = create_db2_timestamp();
    $params[] = $user_info[0]["ID"];

    // Execure query
    $result = $dbObj->execute_query($sql, $params);

    if(!$result){
      $api_output["response"]["operation"]['status'] = "fail";
      $api_output["response"]["operation"]['error'] = [
        "code" => "ERR_011",
        "message" => "System error"
      ];
      $app->response->setBody(json_encode($api_output));
      return;
    }


    // If sucess
    $api_output["response"]["operation"]['status'] = "success";
    $data = [];
    $data["sessionKey"] = $session_key;
    $data["sessionIv"] = $session_iv;
    $urls = [];
    $urls["change_pin"] = $CONFIG["base_url"]."tsb/v1.0/change_pin";
    $urls["verify_pin"] = $CONFIG["base_url"]."tsb/v1.0/verify_pin";
    $urls["dashboard"] = $CONFIG["base_url"]."tsb/v1.0/dashboard";
    $urls["create_pin"] = $CONFIG["base_url"]."tsb/v1.0/create_pin";
    $urls["passbook"] = $CONFIG["base_url"]."tsb/v1.0/passbook";
    $urls["logout"] = $CONFIG["base_url"]."tsb/v1.0/logout";
    $data["urls"] = $urls;
    $api_output["response"]["data"] = $data;
    $app->response->setBody(json_encode($api_output));
    return;












});

?>

<?php

  /**
   * ERROR CODE
   *
   * ERR_000 " User hash is empty or invalid ( length is greater than 100 )"
   * ERR_001 " Device id is empty or invalid ( length is greater than 100 )"
   * ERR_002 " mobile number is empty or invalid (length is greater than 100 )"
   * ERR_003 " account number is empty or invalid ( length is greater than 100)"
   * ERR_004 " check hash exists query failed "
   * ERR_005 " user hash not found on the database"
   * ERR_006 " user hash not found on the database"
   * ERR_007 " Fetch account type query failed "
   * ERR_008 " No data found for the account number"
   * ERR_009 " Check fd accunt info query failed"
   * ERR_010 " fetch data query failed for fd accunt info "
   *
   */
  $app->post("/v1.0/passbook", function() use($app) {
    /*
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("502ea6fb921bdf218e7ccead40357d14");
      $cipher->setIv("fc00e692f9b144c6");
      $enc = $cipher->encrypt("799010500127608");
      $d =  base64_encode($enc);

      echo $d;
      echo "  ||  ";
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("d0bec9c7ccb345646594049b35c0212c");
      $cipher->setIv("8fd4520d665bbeab");
      $user_ee = $cipher->encrypt('11111');
      echo base64_encode($user_ee);
      echo "  ||  ";
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("d0bec9c7ccb345646594049b35c0212c");
      $cipher->setIv("8fd4520d665bbeab");
      $user_ee = $cipher->encrypt('8089275598');
      echo base64_encode($user_ee);
      exit;
*/


          $dbObj = $app->container["TsbdbObj"];
          $api_output = array();
          $api_output["response"] = array();


          //api headers

          // api information
          $api_info = array();
          $api_info["versionNo"] = 1.0;
          $api_info["versionName"] = "Rest mobile api for treasury";
          $api_info["releseDate"] = "17/10/2017";
          $api_info["description"] = "Rest api for treasury";


          // Android platform header
          $android_platform = array();
          $android_platform["verisonNo"] = 1.0;
          $android_platform["verisonName"] = "Rest for treasury";
          $android_platform["forceUpdate"] = "yes";
          $android_platform["description"] = "Rest api for treasury";


          // ios platform header
          $ios_platform = array();
          $ios_platform["verisonNo"] = 1.0;
          $ios_platform["verisonName"] = "Rest for treasury";
          $ios_platform["forceUpdate"] = "yes";
          $ios_platform["description"] = "Rest api for treasury";




          $user_hash = $app->request->post("userHash");
          $device_id = $app->request->post("deviceID");
          $mob_num = $app->request->post("mobNum");
          $acc_num = $app->request->post("accNum");

          // validation
          if(empty($user_hash) || ($user_hash && strlen($user_hash) > 100 ) ){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_000",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          // Check Device id is empty
          if(empty($device_id) || ($device_id && strlen($device_id) > 100 )){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_001",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }


          // Check mobile num is empty
          if(empty($mob_num) || ($mob_num && strlen($mob_num) > 100 )){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_002",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          // Check account number is empty
          if(empty($acc_num) || ($acc_num && strlen($acc_num) > 100  ) ){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_003",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }


          // Check user hash is in and is valid
          $sql = " SELECT * FROM TSBONLINE_MOB_APP_USER_LOGIN WHERE USER_HASH = ? ";
          $params = array();
          $params[] = $user_hash;

          $stmt = $dbObj->execute_query($sql, $params);

          // Check query failed
          if(!$stmt){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_004",
              "message" => "System error"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $user_login_result = $stmt->fetchAll();

          if(!is_array($user_login_result) || ( is_array($user_login_result) && count($user_login_result) == 0 )  ){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_005",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $aes_key = $user_login_result[0]['SESSION_KEY'];
          $aes_iv = $user_login_result[0]['SESSION_IV'];

          // Decrypt user account no

          $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
          $cipher->setKey($aes_key);
          $cipher->setIv($aes_iv);
          $decrypted_acc_num = $cipher->decrypt(base64_decode($acc_num));

          if(!$decrypted_acc_num){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_006",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }


          // Check account type

          $sql = " SELECT ACCTYPE FROM TSB_ACCMAST WHERE ACCNO = ? ";
          $params = array($decrypted_acc_num);

          $stmt = $dbObj->execute_query($sql, $params);

          if(!$stmt){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_007",
              "message" => " System error "
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $acc_type = $stmt->fetchColumn();

          if(!$acc_type){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_008",
              "message" => "No data found"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }



          // IF 5 OR 16 THEN FD
          $fd_type = array(5, 16);

          // IF FD
          if(in_array($acc_type, $fd_type)){
            $sql = " SELECT INT_FROM, INT_TO, INT_DUE_DATE, INT_AMT, ";
            $sql .= " INT_AMT_DRAWN, REF_COUNTER_DATE, REF_DAILY_SEQNO, ";
            $sql .= " (CASE WHEN REF_COUNTER_DATE IS NULL AND REF_DAILY_SEQNO IS NULL THEN 'Not paid' ELSE 'Paid' END) AS PAYMT_STATUS ";
            $sql .= " FROM FDAUTOINT_DET WHERE FD_ACCTYPE = ? AND FD_ACCNO = ? ORDER BY INT_FROM ASC ";
            $params = array($acc_type, $decrypted_acc_num);
          }else{
            $sql = " SELECT V_SBPASSBOOK_ONLINE.COUNTER_DATE,  V_SBPASSBOOK_ONLINE.PAY_RECPT  AS TRANS_PROCESS, ";
            $sql .= "(case when V_SBPASSBOOK_ONLINE.PAY_RECPT='P' then V_SBPASSBOOK_ONLINE.PAYMT_AMT else 0 end )  as debit , ";
            $sql .= " (case when V_SBPASSBOOK_ONLINE.PAY_RECPT='R' then V_SBPASSBOOK_ONLINE.RECPT_AMT else 0 end ) as credit , ";
            $sql .= " V_SBPASSBOOK_ONLINE.ACC_BALANCE ,V_SBPASSBOOK_ONLINE.REMARKS AS REMARKS FROM SB_TRANSTYPE, V_SBPASSBOOK_ONLINE";
            $sql .= " WHERE ( V_SBPASSBOOK_ONLINE.SB_TRANSTYPE = SB_TRANSTYPE.SB_TRANSTYPE ) ";
            $sql .=  " and accno= ? order by dt_acc_date desc , BPO_INIT_SYSDATE desc,daily_seqno desc";
            $sql .= " FETCH FIRST 5 ROWS ONLY";
            $params = array($decrypted_acc_num);
          }
          $stmt = $dbObj->execute_query($sql, $params);
          if(!$stmt){
          //  var_dump($dbObj->getConnection()->errorInfo()); exit;
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_009",
              "message" => "System error"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $account_details = $stmt->fetchAll();

          if(!is_array($account_details)){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_008",
              "message" => "Invaled data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }


          $passbook = array();

          // For FD
          if(in_array($acc_type, $fd_type)){
            foreach($account_details as $account ){
              $list = array();
              $list["from"] = switch_date_format($account["INT_FROM"], 'Y-m-d', 'd/m/Y');
              $list["to"] = switch_date_format($account["INT_TO"], 'Y-m-d', 'd/m/Y');
              $list["dueDate"] = switch_date_format($account["INT_DUE_DATE"], 'Y-m-d', 'd/m/Y');
              $list["interestAmt"] = remove_null($account["INT_AMT"]);
              $list["amtDrawn"] = remove_null($account["INT_AMT_DRAWN"]);
              $list["paymentStatus"] = remove_null($account["PAYMT_STATUS"]);
              $list["refID"] = $account["REF_COUNTER_DATE"]." - ".$account["REF_DAILY_SEQNO"];
              $passbook[] = $list;
            }
          }else{
              foreach($account_details as $account){
                $list = array();
                $list["transType"] = ($account["TRANS_PROCESS"] == 'R')? "C" : 'D';
                $list["date"] = switch_date_format($account["COUNTER_DATE"], 'Y-m-d', 'd/m/Y');
                $list["debit"] = remove_null($account["DEBIT"]);
                $list["credit"] = remove_null($account["CREDIT"]);
                $list["remarks"] = remove_null($account["REMARKS"]);
                $list["amt"] = (!empty($list["debit"]) && $list["debit"] != "0.00")? $list["debit"] : $list["credit"];
                $list["accBal"] = remove_null($account["ACC_BALANCE"]);
                $passbook[] = $list;
              }
          }

          // IF FD THEN SHOW ACCOUNT INFO
          if(in_array($acc_type, $fd_type)){
            $sql = "select a.trcode, b.TRNAME ,FDOPEN_AMOUNT, FD_BALANCE,FDOPEN_DATE, ";
            $sql .= " FDMATUR_DATE, FDINT_PCTG, CLOSED_PARTIAL_PAY, FDINTCR_ACCTYPE, c.ACCTYPE_DES as ACCTYPE_DES, ";
            $sql .= " FDINTCR_ACCNO from tsb_fd_accmast a , trmast b, sb_acctype c";
            $sql .= " where  a.trcode=b.trcode and a.FDINTCR_ACCTYPE=c.acctype  and fd_acctype= ? and fd_accno= ? ";
            $params = array($acc_type, $decrypted_acc_num);
            $stmt = $dbObj->execute_query($sql, $params);
            if(!$stmt){
              $api_output["response"]["operation"]["status"] = "fail";
              $api_output["response"]["operation"]["error"] = [
                "code" => "ERR_009",
                "message" => "Invalid data"
              ];
              $app->response->setBody(json_encode($api_output));
              return;
            }
            $fd_info = $stmt->fetchAll();

            if(!is_array($fd_info) || ( is_array($fd_info) && count($fd_info) == 0 ) ){
              $api_output["response"]["operation"]["status"] = "fail";
              $api_output["response"]["operation"]["error"] = [
                "code" => "ERR_010",
                "message" => "System error"
              ];
              $app->response->setBody(json_encode($api_output));
              return;
            }
            //NJp3/AQSYdTkzGMWJ8eQ== = array();
            $passbookInfo["trCode"] = remove_null($fd_info[0]["TRCODE"]);
            $passbookInfo["trCode"] = remove_null($fd_info[0]["TRNAME"]);
            $passbookInfo["fdOpenAmt"] = remove_null($fd_info[0]["FDOPEN_AMOUNT"]);
            $passbookInfo["fdOpenDate"] = switch_date_format($fd_info[0]["FDOPEN_DATE"], 'Y-m-d', 'd/m/Y');
            $passbookInfo["fdBal"] = remove_null($fd_info[0]["FD_BALANCE"]);
            $passbookInfo["maturityDate"] = switch_date_format($fd_info[0]["FDMATUR_DATE"], 'Y-m-d', 'd/m/Y');
            $passbookInfo["fdInterestRate"] = remove_null($fd_info[0]["FDINT_PCTG"]);
            $passbookInfo["withdrawalStatus"] = (empty($fd_info[0]["CLOSED_PARTIAL_PAY"]))? "Amount not Drawn" :
             ( ( $fd_info[0]["CLOSED_PARTIAL_PAY"] == "C" )? "Closed" :
                ( ($fd_info[0]["CLOSED_PARTIAL_PAY"] == "P" )?  "Partial" :
                  (( $fd_info[0]["CLOSED_PARTIAL_PAY"] == "R" )? "Renewed" :
                    ( ( $fd_info[0]["CLOSED_PARTIAL_PAY"] == "W" )? "Withdrawed" : "" )
                  )
                )
             ) ;
            $passbookInfo["interestCredtAccType"] = remove_null($fd_info[0]["FDINTCR_ACCTYPE"]);
            $passbookInfo["interestCredtAccTypeName"] = remove_null($fd_info[0]["ACCTYPE_DES"]);
            $passbookInfo["interestCredtAccNum"] = remove_null($fd_info[0]["FDINTCR_ACCNO"]);
          }

          $api_output["response"]["operation"]['status'] = "success";
          $data = array();
          $data["timestamp"] = date_format(new DateTime("now"), "d/M/Y g-i-s A");
          if(in_array($acc_type, $fd_type)){
            $data["passBookInfo"] = $passbookInfo;
          }
          $data["passBook"] = $passbook;
          $api_output["response"]["data"] = $data;
          $app->response->setBody(json_encode($api_output));

  });
?>

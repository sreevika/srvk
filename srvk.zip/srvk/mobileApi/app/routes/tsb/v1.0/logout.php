<?php
  /**
   * ERROR CODE
   * ERR_000 = " Invalid user user hash empty user hash ";
   * ERR_001 = " Invalid device id  empty user hash ";
   * ERR_002 = " Invalid mobile hash empty user hash ";
   * ERR_003 = " Sql query failed on select user hash ";
   * ERR_004 = " User hash not found";
   * ERR_005 = " Update is_valid query failed";
   *
   */
  $app->post('/v1.0/logout', function() use($app) {


          $dbObj = $app->container["TsbdbObj"];
          $api_output = array();
          $api_output["response"] = array();


          //api headers

          // api information
          $api_info = array();
          $api_info["versionNo"] = 1.0;
          $api_info["versionName"] = "Rest mobile api for treasury";
          $api_info["releseDate"] = "17/10/2017";
          $api_info["description"] = "Rest api for treasury";


          // Android platform header
          $android_platform = array();
          $android_platform["verisonNo"] = 1.0;
          $android_platform["verisonName"] = "Rest for treasury";
          $android_platform["forceUpdate"] = "yes";
          $android_platform["description"] = "Rest api for treasury";


          // ios platform header
          $ios_platform = array();
          $ios_platform["verisonNo"] = 1.0;
          $ios_platform["verisonName"] = "Rest for treasury";
          $ios_platform["forceUpdate"] = "yes";
          $ios_platform["description"] = "Rest api for treasury";




          $user_hash = $app->request->post("userHash");
          $device_id = $app->request->post("deviceID");
          $mob_num = $app->request->post("mobNum");


          // Validation

          // check User hash is empty
          if(empty($user_hash)){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_000",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }



          // check device id empty
          if(empty($device_id)){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_001",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          // check mobile number is empty
          if(empty($mob_num)){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_002",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }




          // check userHash
          $sql = " SELECT * FROM TSBONLINE_MOB_APP_USER_LOGIN WHERE USER_HASH = ? ";
          $params = array($user_hash);
          $stmt = $dbObj->execute_query($sql, $params);

          if(!$stmt){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_003",
              "message" => "System errro"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $user_data = $stmt->fetchAll();

          if(!is_array($user_data) || ( is_array($user_data) && count($user_data) == 0 ) ){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_004",
              "message" => "Invalid data"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          // invalidate user
          $sql = " UPDATE TSBONLINE_MOB_APP_USER_LOGIN SET IS_VALID = 'N' WHERE ID = ? ";
          $params = array($user_data[0]['ID']);

          $stmt = $dbObj->execute_query($sql, $params);

          if(!$stmt || ( $stmt && $stmt->rowCount() == 0) ){
            $api_output["response"]["operation"]["status"] = "fail";
            $api_output["response"]["operation"]["error"] = [
              "code" => "ERR_005",
              "message" => "System error"
            ];
            $app->response->setBody(json_encode($api_output));
            return;
          }

          $api_output["response"]["operation"]['status'] = "success";
          $app->response->setBody(json_encode($api_output));
          return;

  });
?>

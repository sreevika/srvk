<?php
    $app->post("/v1.0/change_pin", function() use($app){
/*
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("b7ef429c1c938d63e52e56982b69e86a");
      $cipher->setIv("16c3174c70faa6a6");
      $enc = $cipher->encrypt("8089275598");
      $d =  base64_encode($enc);

      echo $d;
      echo "  ||  ";
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("b7ef429c1c938d63e52e56982b69e86a");
      $cipher->setIv("16c3174c70faa6a6");
      $user_ee = $cipher->encrypt('11111');
      echo base64_encode($user_ee);

      echo "  ||  ";
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
      $cipher->setKey("b7ef429c1c938d63e52e56982b69e86a");
      $cipher->setIv("16c3174c70faa6a6");

      $user_ee = $cipher->encrypt('12345');
      echo base64_encode($user_ee);

      exit;
*/






      /**
       * ERROR CODE
       * ERR_000 : ' USER_HASH is empty'
       * ERR_001 : ' Device ID is empty'
       * ERR_002 : ' Mobile number is empty'
       * ERR_002 : ' Mobile number is empty'
       * ERR_003 : ' Pin is empty'
       * ERR_004 : ' check user hash query failed'
       * ERR_005 : ' user hash not found on the database'
       * ERR_006 : ' pen Decryption failed'
       * ERR_007 : ' update new session key and session iv query failed'
       * ERR_008 : ' New pin is empty'
       * ERR_009 : ' Invalid new pin ( string length  > 6  or decryption failed ) '
       */

      global $CONFIG;
      $dbObj = $app->container["TsbdbObj"];
      $api_output["response"] = array();

      //api headers

      // api information
      $api_info = array();
      $api_info["versionNo"] = 1.0;
      $api_info["versionName"] = "Rest mobile api for treasury";
      $api_info["releseDate"] = "17/10/2017";
      $api_info["description"] = "Rest api for treasury";


      // Android platform header
      $android_platform = array();
      $android_platform["verisonNo"] = 1.0;
      $android_platform["verisonName"] = "Rest for treasury";
      $android_platform["forceUpdate"] = "yes";
      $android_platform["description"] = "Rest api for treasury";


      // ios platform header
      $ios_platform = array();
      $ios_platform["verisonNo"] = 1.0;
      $ios_platform["verisonName"] = "Rest for treasury";
      $ios_platform["forceUpdate"] = "yes";
      $ios_platform["description"] = "Rest api for treasury";


        // post params
        $old_pin = $app->request->post("oldPin");
        $new_pin = $app->request->post("newPin");
        $user_hash = $app->request->post("userHash");
        $device_id = $app->request->post("deviceID");
        $mob_num = $app->request->post('mobNum');

        // validate post data

        // check empty user hash
        if(empty($user_hash)){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_000",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // check empty device id
        if(empty($device_id)){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_001",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // check empty mobile number
        if(empty($mob_num)){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_002",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // check old pin is empty
        if(empty($old_pin)){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_003",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // check new pin is empty
        if(empty($new_pin)){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_008",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // check user hash exists
        $sql = " SELECT APP_LOGIN.ID AS ID, APP_LOGIN.INIT_ID AS INIT_ID, APP_LOGIN.USER_HASH AS USER_HASH, APP_LOGIN.OTP AS OTP, APP_LOGIN.OTP_TIME AS OTP_TIME, APP_LOGIN.USER_KEY AS USER_KEY, APP_LOGIN.IS_VALID AS IS_VALID, APP_LOGIN.VALID_TIME AS VALID_TIME, APP_LOGIN.USER_ID AS USER_ID, APP_LOGIN.CREATED_TIME AS CREATED_TIME, APP_LOGIN.SESSION_KEY AS SESSION_KEY, APP_LOGIN.SESSION_IV AS SESSION_IV, APP_LOGIN.LOGIN_PIN AS LOGIN_PIN, MOB_APP.DEVICE_OS AS DEVICE_OS  FROM TSBONLINE_MOB_APP_USER_LOGIN AS APP_LOGIN JOIN TSBONLINE_MOB_APP MOB_APP ON (TSBONLINE_MOB_APP_USER_LOGIN.INIT_ID = TSBONLINE_MOB_APP.ID) WHERE USER_HASH = ? ";
        $params = array($user_hash);

        $stmt = $dbObj->execute_query($sql, $params);

        if(!$stmt){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_004",
            "message" => "System error"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        $user_login_info = $stmt->fetchAll();

        if(!is_array($user_login_info) || (is_array($user_login_info) && count($user_login_info) == 0 ) ){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_005",
            "message" => "Invalid Data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }


        // decrypt pin
        $aes_key = $user_login_info[0]["SESSION_KEY"];
        $aes_iv = $user_login_info[0]["SESSION_IV"];

        $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_CBC);
        $cipher->setKey($aes_key);
        $cipher->setIv($aes_iv);

        $decrypted_old_pin = $cipher->decrypt(base64_decode($old_pin));
        if(!$decrypted_old_pin || ( $decrypted_old_pin && $decrypted_old_pin != $user_login_info[0]["LOGIN_PIN"] ) ){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_006",
            "message" => "Invalid Pin"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }
        // Decrypted new pin

        $decrypted_new_pin = $cipher->decrypt(base64_decode($new_pin));
        if(!$decrypted_new_pin || ( $decrypted_new_pin && strlen($decrypted_new_pin) > 6  ) ){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_009",
            "message" => "Invalid Pin"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // update session key and iv
        $new_session_key = md5($aes_key.time());
        $new_session_iv = create_iv($new_session_key);

        $sql = " UPDATE TSBONLINE_MOB_APP_USER_LOGIN SET SESSION_KEY = ?, SESSION_IV = ?,  LOGIN_PIN = ?  WHERE ID = ? ";
        $params = array();
        $params[] = $new_session_key;
        $params[] = $new_session_iv;
        $params[] = $decrypted_new_pin;
        $params[] = $user_login_info[0]["ID"];

        $stmt = $dbObj->execute_query($sql, $params);
        if(!$stmt || ( $stmt && $stmt->rowCount() == 0 ) ){
          $api_output["response"]["operation"]['status'] = "fail";
          $api_output["response"]["operation"]['error'] = [
            "code" => "ERR_007",
            "message" => " System error"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
        }

        // If sucess
        $api_output["response"]["operation"]['status'] = "success";
	if($user_login_info[0]['DEVICE_OS'] == 'android'){
	  $api_output['response']['platform'] = $android_platform;
	}else if($user_login_info[0]['DEVICE_OS'] == 'ios' ){
	  $api_output['response']['platform'] = $ios_platform;
	}
        $data = [];
        $data["sessionKey"] = $new_session_key;
        $data["sessionIv"] = $new_session_iv;
        $urls = [];
        $api_output["response"]["data"] = $data;
        $app->response->setBody(json_encode($api_output));
        return;




    });
?>

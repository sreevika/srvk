<?php
  $app->post("/v1.0/check_mobno", function() use($app){
    $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_ECB);
    $cipher->setKey("0fccc67daa174a1c86c5a58fe484a529");
    $encmobile = $cipher->encrypt('8089275598');
  //  echo base64_encode($encmobile);
      $dbObj = $app->container["TsbdbObj"];
      $api_output = array();

      $api_output["response"] = array();

      //api headers

      // api information
      $api_info = array();
      $api_info["versionNo"] = 1.0;
      $api_info["versionName"] = "Rest mobile api for treasury";
      $api_info["releseDate"] = "17/10/2017";
      $api_info["description"] = "Rest api for treasury";


      // Android platform header
      $android_platform = array();
      $android_platform["verisonNo"] = 1.0;
      $android_platform["verisonName"] = "Rest for treasury";
      $android_platform["forceUpdate"] = "yes";
      $android_platform["description"] = "Rest api for treasury";


      // ios platform header
      $ios_platform = array();
      $ios_platform["verisonNo"] = 1.0;
      $ios_platform["verisonName"] = "Rest for treasury";
      $ios_platform["forceUpdate"] = "yes";
      $ios_platform["description"] = "Rest api for treasury";


      $mobNo = $app->request->post("mobNo");
      $deviceId = $app->request->post("deviceID");

      // Validating data
      if(!$mobNo){
          // "No mobile number";
          $api_output["response"]["operation"]["status"] = "fail";
          $api_output["response"]["operation"]["error"] = [
            "code" => "ERR_000",
            "message" => "Invalid data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
      }

      if(!$deviceId){
          // "No deviceID";
          $api_output["response"]["operation"]["status"] = "fail";
          $api_output["response"]["operation"]["error"] = [
            "code" => "ERR_000",
            "message" => "Invalid data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
      }

       // Decrypt mobile number via init_key

      // Get init key for the deviceID
      $sql_device_info_sql = " SELECT * FROM TSBONLINE_MOB_APP WHERE DEVICE_ID = ? ";
      $sql_device_info_sql_params = [$deviceId];
      $result = $dbObj->execute_query($sql_device_info_sql, $sql_device_info_sql_params);
      if(!$result){
        // "System error";

        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $result_init_data = $result->fetchAll();
      if(!is_array($result_init_data )){
        // System error
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      if(count($result_init_data ) < 0){
          $api_output["response"]["operation"]["status"] = "fail";
          $api_output["response"]["operation"]["error"] = [
            "code" => "ERR_000",
            "message" => "Invalid data"
          ];
          $app->response->setBody(json_encode($api_output));
          return;
      }
      // Check time expire or not
      $init_time = db2_timestamp_to_unix($result_init_data[0]["INIT_TIME"]);

      //Expire time
      $expire_time = $init_time + ( 30 * 60);

      $current_time = time();

      /*
      if($current_time > $expire_time){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_000",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }
      */

      //decrypt mob number via aes algo
      $aes_key =  $result_init_data[0]["INIT_KEY"];
      $cipher = new phpseclib\Crypt\AES(phpseclib\Crypt\AES::MODE_ECB);
      $cipher->setKey($aes_key);
      //$decrypted_mobile = $cipher->decrypt(base64_decode($mobNo));
      $decrypted_mobile = $cipher->decrypt(base64_decode($mobNo));
      if(!$decrypted_mobile){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_000",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // check mobile number in Database
      $check_mobno_sql = " SELECT  * FROM  TSBONLINE_PORTAL_USERS WHERE MOBILE = ? ";
      $check_mobno_param = array($decrypted_mobile);
      $result = $dbObj->execute_query($check_mobno_sql, $check_mobno_param);
      if(!$result){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      $result_data = $result->fetchAll();

      if(!is_array($result_data)){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      if(count($result_data) <= 0){

        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_000",
          "message" => "Invalid data"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

      // Send Otp to mobile no
      $otp = mt_rand(10000, 99999);
      //Insert data into table

      $insert_user_sql = " INSERT INTO TSBONLINE_MOB_APP_USER_LOGIN ( INIT_ID, OTP, OTP_TIME, IS_VALID ) ";
      $insert_user_sql .= " VALUES ( ?, ?, CURRENT_TIMESTAMP, 'N')";
      $insert_user_params = array();
      $insert_user_params[] = $result_init_data[0]["ID"];
      $insert_user_params[] = $otp;
      $result = $dbObj->execute_query($insert_user_sql, $insert_user_params);

      if(!$result){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }
      $insertId = $dbObj->conn->lastInsertId();
      //generate hash string
      $hash = hash("sha256", $insertId.$decrypted_mobile);

      $update_hash_sql = " UPDATE tsbonline_mob_app_user_login SET HASH = ? WHERE ID = ? ";
      $update_hash_params = array($hash, $insertId);
      $result = $dbObj->execute_query($update_hash_sql, $update_hash_params);

      if(!$result){
        $api_output["response"]["operation"]["status"] = "fail";
        $api_output["response"]["operation"]["error"] = [
          "code" => "ERR_001",
          "message" => "System error"
        ];
        $app->response->setBody(json_encode($api_output));
        return;
      }

    	$api_output["response"]["api"] = $api_info;
      $api_output["response"]["data"]["userKey"] = $hash;
      $app->response->setBody(json_encode($api_output));



  });
?>

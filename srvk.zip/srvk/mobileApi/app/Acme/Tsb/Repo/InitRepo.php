<?php
  namespace Acme\Tsb\Repo;

  class InitRepo implements \MobileRest\Init\InitRepositoryInterface{

    protected  $_entity;

    protected $_init_entity_generator;

    protected $_conn;

    public function __construct( \MobileRest\Init\InitEntityGeneratorInterface $entity_generator, $conn){
        $this->setEntityGenerator($entity_generator);
        $this->setConnection($conn);
    }

    public function setEntityGenerator($entity_generator){
      $this->_init_entity_generator = $entity_generator;
    }

    public function getEntityGenerator(){
      return $this->_init_entity_generator;
    }

    public function getConnection(){
      return $this->_conn;
    }

    public function setConnection($conn){
        $this->_conn = $conn;
    }

    public function getEntity(){
        if(!$this->_entity){
          $this->_entity = $this->getEntityGenerator()->generate();
        }
        return $this->_entity;
    }

    public function setEntity( \MobileRest\Init\InitInterface $entity){
      $this->_entity = $entity;
    }



    public function create(){
      $sql = " INSERT INTO TSBONLINE_MOB_APP (DEVICE_ID, DEVICE_OS, LOCATION_X, LOCATION_Y, INIT_KEY, INIT_TIME, IP_ADDR, INIT_HASH, INIT_IV) ";
      $sql .= " VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
      $params = array();
      $params[] = $this->getEntity()->getDeviceId();
      $params[] = $this->getEntity()->getDeviceOs();
      $params[] = $this->getEntity()->getLocationX();
      $params[] = $this->getEntity()->getLocationY();
      $params[] = $this->getEntity()->getInitKey();
      $params[] = $this->getEntity()->getInitTime();
      $params[] = $this->getEntity()->getDeviceIp();
      $params[] = $this->getEntity()->getInitHash();
      $params[] = $this->getEntity()->getInitIv();

      $result = $this->getConnection()->execute_query($sql, $params);
      if($result && $result->rowCount() > 0){
          $this->getEntity()->setId($this->getConnection()->getConnection()->lastInsertId());
          return $this->getEntity();
      }
      return false;

    }

    public function update(){

      $sql = " UPDATE TSBONLINE_MOB_APP SET ";
      $sql .= " DEVICE_ID = ? , DEVICE_OS = ?, LOCATION_X = ?, LOCATION_Y = ?, ";
      $sql .= " INIT_KEY = ?, INIT_TIME = ?, IP_ADDR = ?, INIT_HASH = ?, INIT_IV = ? ";
      $sql .= " WHERE ID = ?";

      $params = array();
      $params[] = $this->getEntity()->getDeviceId();
      $params[] = $this->getEntity()->getDeviceOs();
      $params[] = $this->getEntity()->getLocationX();
      $params[] = $this->getEntity()->getLocationY();
      $params[] = $this->getEntity()->getInitKey();
      $params[] = $this->getEntity()->getInitTime();
      $params[] = $this->getEntity()->getDeviceIp();
      $params[] = $this->getEntity()->getInitHash();
      $params[] = $this->getEntity()->getInitIv();
      $params[] = $this->getEntity()->getId();

      $result = $this->getConnection()->execute_query($sql, $params);
      if($result && $result->rowCount() > 0){
          return $this->getEntity();
      }
      return false;

    }


    public function save(){
        if($this->getEntity()->getID()){
          return  $this->update();
        }
        return $this->create();
    }

    public function delete(){

    }

    public function findById($id){
      $sql = " SELECT * FROM TSBONLINE_MOB_APP WHERE ID = ? ";
      $params = array();
      $params[] = $id;
      $result = $this->getConnection()->execute_query($sql, $params);
      if($result){
        $resultSet = $result->fetchAll();
        if(is_array($resultSet) && count($resultSet) > 0 ){
            $this->getEntity()->setId($resultSet[0]["ID"]);
            $this->getEntity()->setDeviceId($resultSet[0]["DEVICE_ID"]);
            $this->getEntity()->setDeviceOs($resultSet[0]["DEVICE_OS"]);
            $this->getEntity()->setInitHash($resultSet[0]["INIT_HASH"]);
            $this->getEntity()->setLocationX($resultSet[0]["LOCATION_X"]);
            $this->getEntity()->setLocationY($resultSet[0]["LOCATION_Y"]);
            $this->getEntity()->setInitKey($resultSet[0]["INIT_KEY"]);
            $this->getEntity()->setInitIv($resultSet[0]["INIT_IV"]);
            $this->getEntity()->setDeviceIp($resultSet[0]["IP_ADDR"]);
            return $this->getEntity();
        }
        return null;
      }
      throw new Exception("Database query execution failed");
      return null;
    }

    public function findByDevice($device_id, $device_os){
      $sql = " SELECT * FROM TSBONLINE_MOB_APP WHERE DEVICE_ID = ? AND DEVICE_OS = ? ";
      $params = array();
      $params[] = $device_id;
      $params[] = $device_os;
      $result = $this->getConnection()->execute_query($sql, $params);
      if($result){
        $resultSet = $result->fetchAll();
        if(is_array($resultSet) && count($resultSet) > 0 ){
            $this->getEntity()->setId($resultSet[0]["ID"]);
            $this->getEntity()->setDeviceId($resultSet[0]["DEVICE_ID"]);
            $this->getEntity()->setDeviceOs($resultSet[0]["DEVICE_OS"]);
            $this->getEntity()->setInitHash($resultSet[0]["INIT_HASH"]);
            $this->getEntity()->setLocationX($resultSet[0]["LOCATION_X"]);
            $this->getEntity()->setLocationY($resultSet[0]["LOCATION_Y"]);
            $this->getEntity()->setInitKey($resultSet[0]["INIT_KEY"]);
            $this->getEntity()->setInitIv($resultSet[0]["INIT_IV"]);
            $this->getEntity()->setDeviceIp($resultSet[0]["IP_ADDR"]);
            return $this->getEntity();
        }
        return null;
      }
      throw new Exception("Database query execution failed");
      return null;

    }

    public function findByInitKey(){

    }

  }
?>

<?php
  namespace App\Tsb\Repo;
  /* TsbMobApp repo
   *
   *
  */

  class TsbMobAppRepo implements ServiceInitRepositoryInterface{

    private $_model = new App\Tsb\Model\TsbMobApp();

    private $_id;

    private $_init_key;

    private $_init_time;

    private $_device_id;

    private $_device_os;

    private $_device_location_x;

    private $_device_location_y;

    private $_ip_addr;

    /**
     * get Id
     * @return integer id
     */
     public function getID(){
       return $this->_id;
     }

     /**
      * Set id
      * @param integer
      */
      public function setId($id){
        $this->_id = $id;
      }

    /**
     * SetInitKey
     * Set init key setter funcion
     * @param String $init_key;
     */
    public funcion setInitKey($init_key){
      $this->_init_key = $init_key;
    }


    /**
     * SetInitTime
     * Set init time setter funcion
     * @param Unix timestamp $init_time;
     */
    public funcion setInitTime($time){
        $this->_init_time = $time;
    }


    /**
     * set device id
     * @param string $device_id;
     */
    public funcion setDeviceID($device_id){
        $this->_device_id;
    }


    /**
     * get Device id
     * @return string device id
     */
    public funcion getDeviceId(){
      return $this->_device_id;
    }


    /**
     * set Device os
     * set device os
     * @param string $device_os
     */
    public function setDeviceOs($device_os){
      $this->_device_os = $device_os;
    }

    /**
     * get device os
     * get device os
     * @return string device os
     */
    public function getDeviceOs(){
      return $this->_device_os;
    }

    /**
     * set device location x
     * @param string $device_locations_x
     */
    public function setDeviceLocationX($device_locations_x){
        $this->_device_location_x = $device_locations_x;
    }

    /**
     * set device location y
     * @param string $device_locations_y
     */
    public function setDeviceLocationY($device_locations_y){
        $this->_device_location_y = $device_locations_y;
    }

    /**
     * set ip adderss
     * @param string
     */
    public function setIpAddr($device_ip){
      $this->_device_ip = $device_ip;
    }

    /**
     * get ip address
     * @return string device ip
     */
    public function getIpAddr(){
      return $this->_device_id;
    }


    /**
     * Find by devic id
     * @param string $device_id
     * @return integer on data and null if no device id
     */
     public function get_id_for_device($device_id){
       $result = $this->_model->getIdForDeviceId($device_id);
       return ($result)? $result : null;
     }


    /**
     * Save
     * Save the data into db
     * @return boolean true on success and false on failure
     */
    public funcion save(){
      $data = [];
      $data["DEVICE_ID"] =  $this->_device_id;
      $data["DEVICE_OS"] =  $this->_device_os;
      $data["LOCATION_X"] =  $this->_location_x;
      $data["LOCATION_Y"] =  $this->_location_y;
      $data["INIT_KEY"] =  $this->_init_key;
      $data["INIT_TIME"] =  $this->_init_time;
      $data["IP_ADDR"] =  $this->_ip_addr;
      return $this->_model->save($data, $this->_id);
    }


    /**
     * Get init info
     * @param integer $id
     */

     public function getInitData($id){
       return $this->_model->find_by_deviceId($id);
     }

  }
?>

<?php
  namespace Acme\Tsb\Auth\Init;

  class InitEntityGenerator implements \MobileRest\Init\InitEntityGeneratorInterface{

      public function generate(){
        return new \Acme\Tsb\Entity\InitEntity();
      }

  }
?>

<?php
  namespace Acme\Tsb\Auth\Init;
  class TsbInitManager extends \MobileRest\Init\InitManager {
    public function initializeDevice(){
      if(!$this->_repo->getEntity()->getId()){
        $entity = $this->_repo->save();
        if($entity){
            $this->_repo->setEntity($entity);
        }else{
          throw new \Exception("Failed to save init data");
          return null;
        }
      }
      return parent::initializeDevice();
    }
  }
?>

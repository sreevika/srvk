<?php
  namespace \Aceme\Tsb\Extensions\Init;

    class Db2InitTimeGenerator implements generatorType{
        public function generate($time){
          return date('Y-m-d-H.i.s.u', $time);
        }
    }
?>

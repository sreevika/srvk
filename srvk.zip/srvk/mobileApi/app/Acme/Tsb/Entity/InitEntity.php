<?php
  namespace Acme\Tsb\Entity;
  class InitEntity implements \MobileRest\Init\InitInterface{


    private $_id;
    private $_init_key;
    private $_init_hash;
    private $_init_iv;
    private $_device_id;
    private $_device_os;
    private $_init_time;
    private $_device_ip;
    private $_location_x;
    private $_location_y;

    public function setId($id){
      $this->_id = $id;
    }

    public function getId(){
      return $this->_id;
    }

    public function getInithash(){
      return $this->_init_hash;
    }

    public function setInitHash($hash){
      $this->_init_hash = $hash;
    }

    public function setInitIv($iv){
        $this->_init_iv = $iv;
    }

    public function getInitIv(){
      return $this->_init_iv;
    }

    public function setInitKey($key){
      $this->_init_key = $key;
    }

    public function getInitKey(){
      return $this->_init_key;
    }

    public function setInitTime($time){
      $this->_init_time = $time;
    }

    public function getInitTime(){
      return $this->_init_time;
    }

    public function setDeviceId($device_id){
      $this->_device_id = $device_id;
    }

    public function getDeviceId(){
      return $this->_device_id;
    }

    public function setDeviceIp($ip){
      $this->_device_ip = $ip;
    }

    public function getDeviceIp(){
      return $this->_device_ip;
    }

    public function setDeviceOs($device_os){
      $this->_device_os = $device_os;
    }

    public function getDeviceOs(){
      return $this->_device_os;
    }

    public function getLocationX(){
        return $this->_location_x;
    }

    public function setLocationX($location_x){
      $this->_location_x = $location_x;
    }

    public function setLocationY($location_y){
      return $this->_location_y;
    }

    public function getLocationY(){
      return $this->_location_x;
    }

  }

?>

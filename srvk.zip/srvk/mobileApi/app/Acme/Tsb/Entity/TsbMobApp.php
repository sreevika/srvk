<?php
	namespace Lib\Tsb\Entity;

	use \Database\DbObject;

	class TsbMobApp {
		public $_dbObj;

		public function __construct(){
				$this->_dbObj = new DbObject("tsb");
		}

		public static function find_by_id($id){
			$sql = "SELECT * FROM TSBONLINE_MOB_APP WHERE ID = ? "
			$params = array($id);
			$result = $this->_dbObj->execute_query($sql, $params);
			if($result){
				$data = $result->fetchAll();
				if(is_array($data)){
						return array_pop($data);
				}
			}
			return false;
		}

		public function find_by_init_key(){
			$sql = "SELECT * FROM TSBONLINE_MOB_APP WHERE INIT_KEY = ? "
			$params = array($id);
			$result = $this->_dbObj->execute_query($sql, $params);
			if($result){
					$data = $result->fetchAll();
					if(is_array($data)){
						return array_pop($data);
					}
			}
			return false;
		}


		public function find_by_deviceId($device_id){
			$sql = "SELECT * FROM TSBONLINE_MOB_APP WHERE DEVICE_ID = ? "
			$params = array($id);
			$result = $this->_dbObj->execute_query($sql, $params);
			if($result){
					$data = $result->fetchAll();
					if(is_array($data)){
						return array_pop($data);
					}
			}
			return false;
		}

		public function getIdForDeviceId($device_id){
				$result = $this->find_by_deviceId($device_id);
				if($result){
					return $result['ID'];
				}
		}

		public function insert($data){
			$sql = "INSERT INTO TSBONLINE_MOB_APP  ( DEVICE_ID, DEVICE_OS, LOCATION_X, LOCATION_Y, INIT_KEY, INIT_TIME, IP_ADDR )  ";
			$sql .= " VALUES  ( ?, ?, ?, ?, ?, ?, ?) "
			$params = $data;
			$result  = $this->_dbObj->execute_query($sql, $params);
			if($result){
				if($resutl->rowCount() > 0){
					return true;
				}
			}
			return false;
		}

		public function update($data, $id){
			$sql = " UPDATE TSBONLINE_MOB_APP SET  ".
			$fields = array_keys($data);
			$values = array_values($data);
			$sql .= implode(" = ? , ", $fields)." = ? ";
			$sql .= " WHERE ID = ? "
			$params = $values;
			$params[] = $id;
			$result = $thid->_dbObj->execute_query($sql, $params);
			if($result){
					return ($result->rowcount() > 0 )? true : false;
			}
			return false;
		}

		public function save($data, $id = null){
				return ($id !== null)? $this->insert($data) : $this->update($data, $id);
		}

	}

?>

;(function(namespace, app,  global, $){
    namespace.pages.changeTransactionPassword = (function(){
      "use strict";
      var $change_transaction_password_form,
      $change_transaction_password_submit_btn;

      var clearError = function(){
        $(".has-error").removeClass('has-error');
        $(".help-block").text('');
      }


      var ParseFormError = function (errorArray){
        $.each(errorArray, function(key, val){
            $("[name='"+key+"']").parent().addClass('has-error');
            $("[name='"+key+"']").siblings(".help-block").text(val);
        })
      }


      var change_transaction_password_ajax_success_response = function(data){
        app.hideLoader();
        var is_change_transaction_success = null;
        try{is_change_transaction_success = data.data.trasactionKeyChanged}catch(e){};
        if(is_change_transaction_success){
          app.namespace.alert.showMessage('Change Transaction key', 'Change trasaction key successfully', 'success');
          $change_transaction_password_form[0].reset();
          return;
        }
        if(data.errors){
          ParseFormError(data.errors);
        }
      }

      var change_transaction_password_process = function(e){
        e.preventDefault();
        clearError();
        var data = $change_transaction_password_form.serializeArray();
        var ajaxObject = {
          method: 'post',
          data: data,
          url: app.getConfig().baseUrl+'dashboard/changeTransactionPasswordAction',
          success: change_transaction_password_ajax_success_response
        }
        app.showLoader();
        app.namespace.ajax.send(ajaxObject);
      }

      var bindEvent = function(){
          $change_transaction_password_submit_btn.on('click', change_transaction_password_process);
      }

      var init = function(){
        $change_transaction_password_form = $("[rel='js-change-transaction-key-form']");
        $change_transaction_password_submit_btn = $("[rel='js-change-transaction-key-form-submit-btn']");
        bindEvent();
      }

      // public api
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

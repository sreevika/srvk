;(function(namespace, app, global, $){
  namespace.pages.InterBankBeneficiary = (function(){
    'use strict';
    var $beneficiary_view_list_view,
  	    $beneficiary_view_list_template,
        $beneficiary_add_new_form,
        $beneficiary_add_new_form_submit_btn,
        $beneficiary_add_new_form_reset_btn,
        $beneficiary_add_new_form_ifsc_field,
        $beneficiary_add_new_form_bankname_field,
        $beneficiary_add_new_form_bankid_field,
        $beneficiary_add_new_form_branchname_field,
        $beneficiary_add_new_form_acc_no,
        $beneficiary_add_new_form_acc_no_confirm,
        $beneficiary_edit_btn,
        $beneficiary_edit_modal,
        $beneficiary_edit_form_submit_btn,
        $beneficiary_view_list_table_row,
        $beneficiary_edit_form;


    // current updating tabel row reference
    // when user edit particular row in the table via modal then this variable
    // store the reference of the table row
    var $currentUpdatingTableRow = null;


    var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }


    var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent('.form-group').addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }


    var buildBeneficiaryView = function(data){
        var compiled_template = Handlebars.compile($beneficiary_view_list_template.html());
        var parsed_html = compiled_template(data);
        $beneficiary_view_list_view.html(parsed_html);
    };

    var processIfscDetails = function(data){
      clearError();
      if(data.status == false){
        ParseFormError(data.errors);
        return;
      }
      $beneficiary_add_new_form_bankname_field.val(data.data.bankDetails.bankName);
      $beneficiary_add_new_form_bankid_field.val(data.data.bankDetails.bankId);
      $beneficiary_add_new_form_branchname_field.val(data.data.bankDetails.branchName);
    }

    var fetchBankDetailsFromIfsc = function(e){
      e.preventDefault();
      var $ifsc_field = $(e.target);
      var data = [{
        name: 'ifsCode',
        value: $ifsc_field.val()
      }];
      var ajaxObj = {
        url: app.getConfig().baseUrl+'beneficiary/getBankDetailsFromIfsc',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processIfscDetails
      };
      app.namespace.ajax.send(ajaxObj);
    };

    var updateBeneficiaryEditForm = function(data){
      $beneficiary_edit_form[0].reset();
      $.each(data, function(i,v){
        $beneficiary_edit_form.find("[name='"+i+"']").val(v);
      });
    }

    var updateBeneficiaryEditModal = function(e){
      e.preventDefault();
      var editBtn = $(e.target);
      var tr = editBtn.closest('tr');
      var data = tr.data('benf');
      updateBeneficiaryEditForm(data);
      $currentUpdatingTableRow = tr;
      $beneficiary_edit_modal.modal('show');
    }

  	var attachEvents = function(){
      $beneficiary_add_new_form_ifsc_field.on('change', fetchBankDetailsFromIfsc);
      $beneficiary_add_new_form_submit_btn.on('click', saveInterBankBenf);
      $beneficiary_view_list_view.on('click', '[rel="js-beneficiary-edit-btn"]', updateBeneficiaryEditModal);
      $beneficiary_add_new_form_ifsc_field.on('keyup', function(e){e.preventDefault(); $(e.target).val( ($(e.target).val()).toUpperCase())});
      $beneficiary_add_new_form_acc_no.on('blur', function(e){ e.preventDefault(); $(e.target).attr('type','password')});
      $beneficiary_add_new_form_acc_no.on('focus', function(e){ e.preventDefault(); $(e.target).attr('type','text')});
      $beneficiary_add_new_form_acc_no_confirm.on('change', function(e){ e.preventDefault(); if($beneficiary_add_new_form_acc_no.val() == $beneficiary_add_new_form_acc_no_confirm.val()){ $beneficiary_add_new_form_acc_no.attr('type','text');}else{ $beneficiary_add_new_form_acc_no.attr('type','password');} });
      $beneficiary_edit_form_submit_btn.on('click', updateBeneficiary);
  	};

    var processSaveInterBenfResponse = function(data){
      debugger;
      clearError();
      if(data.status == true){
        $beneficiary_add_new_form[0].reset();
        alert("Beneficairy created successfully");
      }
      if(data.errors){
        ParseFormError(data.errors);
      }
    }


    var saveInterBankBenf = function(e){
      e.preventDefault();
      var form_data = $beneficiary_add_new_form.serializeArray();
      var post_request_obj = {
          url: app.getConfig().baseUrl+'beneficiary/addNewInterBeneficiary',
          dataType: 'json',
          method: 'post',
          data: form_data,
          success: processSaveInterBenfResponse
      }
      app.namespace.ajax.send(post_request_obj);
    };

    var updateTableRow = function(data){
      if(data){
        data.slNo = $currentUpdatingTableRow.data('benf').slNo;
      }
      var compiled_template = Handlebars.compile($beneficiary_view_list_table_row.html());
      var parsed_html = compiled_template(data);
      $currentUpdatingTableRow.replaceWith(parsed_html);
    }


    var updateBeneficiarySuccessResponse = function(data){
        app.hideLoader();
        if(data.errors){
          ParseFormError(data.errors);
          return;
        }
        var success_info = null;
        try{success_info =  data.data.beneficiaryUpdated}catch(e){};
        if(success_info === true){
          updateTableRow(data.data.benefData);
          $beneficiary_edit_modal.modal('hide');
          app.namespace.alert.showMessage('Benficiary Updated', 'Beneficiary Updated Successfully' ,'success');
        }
    };
    var updateBeneficiary = function(e){
      clearError();
      e.preventDefault();
      var data = $beneficiary_edit_form.serializeArray();
      var ajaxObject = {
        method: 'post',
        url: app.getConfig().baseUrl+'beneficiary/updateInterBankBeneficiary',
        data: data,
        dataType: 'json',
        success: updateBeneficiarySuccessResponse
      };
      app.showLoader();
      app.namespace.ajax.send(ajaxObject);
    }


    var init = function(route, data){
      if(data.status == true){
    		$beneficiary_view_list_view = $("[rel='inter-beneficiary-view-list-view']");
    		$beneficiary_view_list_template = $("[rel='inter-beneficiary-view-list-template']");
        $beneficiary_add_new_form = $("[rel='js-inter-bank-add-new-benf-form']");
        $beneficiary_add_new_form_submit_btn = $("[rel='js-inter-bank-add-new-benf-submit-btn']");
        $beneficiary_add_new_form_reset_btn = $("[rel='js-inter-bank-add-new-benf-reset-bnt']");
        $beneficiary_add_new_form_ifsc_field = $("[rel='js-inter-bank-add-new-benf-ifsc-field']");
        $beneficiary_add_new_form_bankname_field = $("[rel='js-inter-bank-add-new-benf-bankname-field']");
        $beneficiary_add_new_form_bankid_field = $("[rel='js-inter-bank-add-new-benf-bankid-field']");
        $beneficiary_add_new_form_branchname_field = $("[rel='js-inter-bank-add-new-benf-branchname-field']");
        $beneficiary_add_new_form_acc_no = $("[rel='js-inter-bank-add-new-benf-acc-no']");
        $beneficiary_add_new_form_acc_no_confirm = $("[rel='js-inter-bank-add-new-benf-acc-no-confirm']");
        $beneficiary_edit_btn = $("[rel='js-beneficiary-edit-btn']");
        $beneficiary_edit_modal = $("[rel='js-beneficiary-edit-modal']");
        $beneficiary_edit_form_submit_btn = $("[rel='js-beneficiary-edit-form-save-btn']");
        $beneficiary_view_list_table_row = $("[rel='js-beneficiary-view-list-table-row']");
        $beneficiary_edit_form = $("[rel='js-beneficiary-edit-form']");
        Handlebars.registerPartial('app.namespace.pages.InterBankBeneficiary.benfTableRow', $beneficiary_view_list_table_row.html());
     		attachEvents();
        buildBeneficiaryView(data.data.beneficiaryList.interBank);
      }
    };


    // Public Api
    return {
      init: init
    }
  })();
})( window._tsbApp.namespace, window._tsbApp, window, jQuery);

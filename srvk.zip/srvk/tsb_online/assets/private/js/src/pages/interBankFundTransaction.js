;(function(namespace, app,  global, $){
	namespace.pages.InterBankFundTransaction = (function(){
	'use strict';
	 var $inter_bank_account_list_template,
         $inter_bank_account_list_view,
         $inter_bank_beneficiary_list_template,
         $inter_bank_beneficiary_list_view,
         $payment_option_checkbox,
         $select_date_view,
				 $inter_bank_fund_transfer_form,
				 $inter_bank_amount_field,
				 $amount_to_word_view,
         $schedule_date;

		 var NumberToWordsIndia = function(num) {
	    	var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
	    	var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

				if ((num = num.toString()).length > 9) return 'Invalid';
					 var n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
					 if (!n) return; var str = '';
					 str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
					 str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
					 str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
					 str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
					 str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
					 return str;
		}
     var buildInterBankAccountListView = function(data){
         var compiled_template = Handlebars.compile($inter_bank_account_list_template.html());
         var parsed_html = compiled_template(data);
         $inter_bank_account_list_view.html(parsed_html);
     };

     var buildInterBankBeneficiaryListView = function(data){
         var compiled_template = Handlebars.compile($inter_bank_beneficiary_list_template.html());
         var parsed_html = compiled_template(data);
         $inter_bank_beneficiary_list_view.html(parsed_html);
     };

     var onChangePayOption = function(e){
			 debugger;
          e.preventDefault();
          var $this = $(e.target);
          $select_date_view.addClass('hide');
          if($this.val() == "SL"){
            $select_date_view.removeClass('hide');
            bindDatePicker();
          }
      };

    var showBalnce = function(e){
          e.preventDefault();
          var $link = $(e.target);
          $link.text($link.data("balance"));
      };


		var bindDatePicker = function(){
			$schedule_date .datepicker({ format: 'dd/mm/yyyy',
			 startDate:moment().add(1,'d').format('DD/MM/YYYY'),
			 endDate: moment().add(3,'M').format('DD/MM/YYYY')
			});
		}


		var checkFundTransferResponse = function(data){
			reset_form_error();
			if(data.status == false && data.errors){
				process_error(data.errors);
			}
			if(data.status == true){
				if($payment_option_checkbox.val() == 'SL'){
            app.namespace.alert.showMessage('Fund Transfer', 'Fund Transter Scheduled Successfully', 'success');
        }else{
          app.namespace.alert.showMessage('Fund Transfer', 'Fund Transter Successfully', 'success');
        }
				$inter_bank_fund_transfer_form[0].reset();
			}
		};


		var reset_form_error = function(){
				$("[rel|='js-name']").text('');
				$('.form-group').removeClass('has-error');
		};

		var process_error = function(errorArray){
			$.each(errorArray, function(key, val){
					var current_item = $("[rel='js-name-"+key+"']");
					if(current_item.length > 0){
							current_item.text(val);
							if(current_item.parent().hasClass('form-group')){
								current_item.parent().addClass('has-error');
							}
					}
			});
		};

		var processTransterMoney = function(e){
				e.preventDefault();
				var data = $inter_bank_fund_transfer_form.serializeArray();
				var ajaxObject = {
					url: app.getConfig().baseUrl+'fund-transfer/intraFundTransfer',
					method: 'post',
					dataType: 'json',
					data: data,
					success: checkFundTransferResponse
				};
				app.namespace.ajax.send(ajaxObject);

		}
    var amountToWord = function(e){
        e.preventDefault();
        var $this = $(this);
        var value = $this.val();
        if(value && $.isNumeric(value)){
          var word = NumberToWordsIndia(value);
          $amount_to_word_view.val(word.toUpperCase());
        }else{
          $amount_to_word_view.val('');
        }
    }

  	var attachEvents = function(){
          $payment_option_checkbox.on('change', onChangePayOption);
          $("[rel='data-container']").on('click', "[rel='account-balance-btn']", showBalnce);
					$inter_bank_fund_transfer_form.on('submit', processTransterMoney );
					$inter_bank_amount_field.on('keyup',amountToWord );
  	 };

  	var init = function(route, data){
        if(data.status == true){
          $inter_bank_account_list_template = $("[rel='js-inter-bank-account-list-template']");
          $inter_bank_account_list_view = $("[rel='js-inter-bank-account-list-view']");
          $inter_bank_beneficiary_list_template = $("[rel='js-inter-bank-beneficiary-list-template']");
          $inter_bank_beneficiary_list_view = $("[rel='js-inter-bank-beneficiary-list-view']");
          $payment_option_checkbox = $("[rel~='js-payment-option']");
          $select_date_view = $("[rel='js-select-date-view']");
          $schedule_date = $("[rel='inter-bank-fund-transaction-schedule-date']");
					$inter_bank_fund_transfer_form  = $("[rel='js-inter-bank-fund-transfer-form']");
					$inter_bank_amount_field = $("[rel='js-inter-bank-amount-field']");
					$amount_to_word_view = $("[rel='js-amount-to-word']");
     			attachEvents();
          buildInterBankAccountListView(data.data.accountList.savingsAccounts);
          buildInterBankBeneficiaryListView(data.data.accountList.interBankBeneficiaries);
        }
      };
      // Public Api
      return {
        init: init
      }
	})();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

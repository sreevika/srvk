;(function(namespace, app,  global, $){
    namespace.pages.IntraBankFundTransaction = (function(){
      var $intra_bank_account_list_template,
          $intra_bank_account_list_view,
          $intra_bank_beneficiary_list_template,
          $intra_bank_beneficiary_list_view,
          $payment_option_checkbox,
          $select_date_view,
          $schedule_date,
          $intra_bank_fund_transfer_form,
          $intra_bank_amount_field,
          $amount_to_word_view
          ;

      var NumberToWordsIndia = function(num) {
          	var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
          	var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

          	 if ((num = num.toString()).length > 9) return 'Invalid';
          	    var n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
          	    if (!n) return; var str = '';
          	    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
          	    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
          	    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
          	    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
          	    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
          	    return str;
      }
      var buildIntraBankAccountListView = function(data){
        var compiled_template = Handlebars.compile($intra_bank_account_list_template.html());
        var parsed_html = compiled_template(data);
        $intra_bank_account_list_view.html(parsed_html);
      };

      var buildIntraBankBeneficiaryListView = function(data){
        var compiled_template = Handlebars.compile($intra_bank_beneficiary_list_template.html());
        var parsed_html = compiled_template(data);
        $intra_bank_beneficiary_list_view.html(parsed_html);
      };

      var onChangePayOption = function(e){
          e.preventDefault();
          debugger;
          var $this = $(e.target);
          $select_date_view.addClass('hide');
          if($this.val() == "SL"){
            $select_date_view.removeClass('hide');
            bindDatePicker();
          }
      };

      var showBalnce = function(e){
          e.preventDefault();
          var $link = $(e.target);
          $link.text($link.data("balance"));
      };

      var checkFundTransferResponse = function(data){
        console.log(data);
        reset_form_error();
        if(data.status == false && data.errors){
          process_error(data.errors);
        }
        if(data.status == true){
          if($payment_option_checkbox.val() == 'SL'){
            app.namespace.alert.showMessage('Fund Transfer', 'Fund Transter Scheduled Successfully', 'success');
          }else{
            app.namespace.alert.showMessage('Fund Transfer', 'Fund Transter Successfully', 'success');
          }
          $intra_bank_fund_transfer_form[0].reset();
        }

      };
      var reset_form_error = function(){
          $("[rel|='js-name']").text('');
          $('.form-group').removeClass('has-error');
      };

      var process_error = function(errorArray){
        $.each(errorArray, function(key, val){
            var current_item = $("[rel='js-name-"+key+"']");
            if(current_item.length > 0){
                current_item.text(val);
                if(current_item.parent().hasClass('form-group')){
                  current_item.parent().addClass('has-error');
                }
            }
        });
      };

      var processTransterMoney = function(e){
          e.preventDefault();
          var data = $intra_bank_fund_transfer_form.serializeArray();
          var ajaxObject = {
            url: app.getConfig().baseUrl+'fund-transfer/intraFundTransfer',
            method: 'post',
            dataType: 'json',
            data: data,
            success: checkFundTransferResponse
          };
          app.namespace.ajax.send(ajaxObject);
      }
      var amountToWord = function(e){
          e.preventDefault();
          var $this = $(this);
          var value = $this.val();
          if(value && $.isNumeric(value)){
            var word = NumberToWordsIndia(value);
            $amount_to_word_view.val(word.toUpperCase());
          }else{
            $amount_to_word_view.val('');
          }
        }
      // attach all the events
      var attachEvents = function(){
        $payment_option_checkbox.on('change', onChangePayOption);
        $("[rel='data-container']").on('click', "[rel='account-balance-btn']", showBalnce);
        $intra_bank_fund_transfer_form.on('submit', processTransterMoney);
        $intra_bank_amount_field.on('keyup',amountToWord );
      };

      var bindDatePicker = function(){
        $schedule_date .datepicker({ format: 'dd/mm/yyyy',
         startDate:moment().add(1,'d').format('DD/MM/YYYY'),
         endDate: moment().add(3,'M').format('DD/MM/YYYY')
        });
      }

      // initialize
      var init = function(route, data){
        $intra_bank_account_list_template = $("[rel='js-intra-bank-account-list-template']");
        $intra_bank_account_list_view = $("[rel='js-intra-bank-account-list-view']");
        $intra_bank_beneficiary_list_template = $("[rel='js-intra-bank-beneficiary-list-template']");
        $intra_bank_beneficiary_list_view = $("[rel='js-intra-bank-beneficiary-list-view']");
        $payment_option_checkbox = $("[rel~='js-payment-option']");
        $select_date_view = $("[rel='js-select-date-view']");
        $schedule_date = $("[rel='intra-bank-fund-transaction-schedule-date']");
        $intra_bank_fund_transfer_form = $("[rel='js-intra-bank-fund-transfer-form']");
        $amount_to_word_view = $("[rel='js-amount-to-word']");
        $intra_bank_amount_field = $("[rel='js-intra-bank-amount-field']");
        buildIntraBankAccountListView(data.data.accountList.savingsAccounts);
        buildIntraBankBeneficiaryListView (data.data.accountList.intraBankBeneficiaries);
        attachEvents();
      };


      // Public Api
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

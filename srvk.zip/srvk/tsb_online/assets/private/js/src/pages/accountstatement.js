;(function(namespace, app,  global, $){
    namespace.pages.AccountSatement = (function(){
      var $savings_accuntstatement_list_Template,
          $savings_accountsatement_list_view,
          $fd_account_statement_select_template,
          $fd_account_statement_select_view,
          $fd_account_statement_template,
          $fd_account_statement_view,
          $select_statement_period,
          $select_statement_period_by_date,
          $select_statement_period_by_month,
          $account_balance_btn,
          $account_statement_savings_form,
          $account_statement_fd_form,
          $generate_savings_account_statement,
          $savings_account_statement_start_date,
          $savings_account_statement_end_date,
          $savings_account_statement_template,
          $savings_account_statement_view,
          $data_container;
      // reset form
      var resetForm = function($form){
          $form.find("[rel|='name']").text('');
          $form.find('.has-error').removeClass('has-error');
          $form.find('.help-block').text('');
      };
      // bind errors to the form
      var bindFormError = function($form, errors){
        $.each(errors, function(i, v){
          $form.find("[rel~='name-"+i+"']").text(v);
          $form.find("[name='"+i+"']").siblings('span.help-block').text(v).closest('.form-group').addClass('has-error');
        })
      };

      var buildSavingsAccountListView = function(data){
        var compiled_template = Handlebars.compile($savings_accuntstatement_list_Template.html())
        var parsed_html = compiled_template(data.accountList.savingsAccounts);
        $savings_accountsatement_list_view.html(parsed_html);
      }

      var showBalnce = function(e){
          e.preventDefault();
          var $link = $(e.target);
          $link.text($link.data("balance"));
      }

      var showStatementPeriodView = function(e){
        e.preventDefault();
        $period = $(e.target);
        $select_statement_period_by_date.addClass('hide');
        $select_statement_period_by_month.addClass('hide');
        if($period.val() == 'byDate'){
          $select_statement_period_by_date.removeClass('hide');
          bindDatePicker();
        }
        if($period.val() == 'byMonth'){
          $select_statement_period_by_month.removeClass('hide');
        }
      }

      var buildSavingsAccountStatementView = function(data){
        app.hideLoader();
        // check status fails
        if(data.status === false){
          var error = (!data.error || data.error == '')? 'Sorry somthing went wrong!' : data.error;
          namespace.alert.showMessage('Sorry Error', error, 'error');
          return;
        }
        // check form errors
        if(data.errors){
          bindFormError($account_statement_savings_form, data.errors)
        }
        var savingsStatementData = [];
        try{
          savingsStatementData = data.data.savingsStatement;
        }catch(e){}
        var compiled_template = Handlebars.compile($savings_account_statement_template.html());
        var parsed_html = compiled_template(savingsStatementData);
        $savings_account_statement_view.html(parsed_html);

      }

      var buildFdAccountStatementView = function(data){
        app.hideLoader();
        // check status fails
        if(data.status === false){
          var error = (!data.error || data.error == '')? 'Sorry somthing went wrong!' : data.error;
          namespace.alert.showMessage('Sorry Error', error, 'error');
          return;
        }
        // check form errors
        if(data.errors){
          bindFormError($account_statement_fd_form, data.errors)
        }
        var fd_account_statement_data = [];
        try{
          fd_account_statement_data = data.data.fixedAccountStatement;
        }catch(e){fd_account_statement_data = []}

        var compiled_template = Handlebars.compile($fd_account_statement_template.html());
        var parsed_html = compiled_template(fd_account_statement_data);
        $fd_account_statement_view.html(parsed_html);
      }

      var buildFdAccountSelectView = function(data){
        var compiled_template = Handlebars.compile($fd_account_statement_select_template.html());
        var parsed_html = compiled_template(data.accountList.fdAccounts);
        $fd_account_statement_select_view.html(parsed_html);
      }
      var generateSavingsAccountStatement = function(e){
          e.preventDefault();
          resetForm($account_statement_savings_form);
          var data = $account_statement_savings_form.serializeArray();
          var requestObj = {
            url: app.getConfig().baseUrl+'account-statement/getSbAccountStatement',
            data: data,
            method: 'post',
            dataType: 'json',
            success:buildSavingsAccountStatementView
          }
          app.showLoader();
          namespace.ajax.send(requestObj);
      }

      var generateFdsAccountStatement = function(e){
        e.preventDefault();
        debugger;
        var data = $account_statement_fd_form.serializeArray();
        var requestObj = {
          url: app.getConfig().baseUrl+'account-statement/getFdAccountStatement',
          data: data,
          method: 'post',
          dataType: 'json',
          success:buildFdAccountStatementView
        };
        app.showLoader();
        namespace.ajax.send(requestObj);
      };

      var bindDatePicker = function(){
        $savings_account_statement_start_date .datepicker({format: 'dd/mm/yyyy'});
        $savings_account_statement_end_date.datepicker({format: 'dd/mm/yyyy'});
      }

      var attachEvents = function(){
          $data_container.on('click', "[rel='account-balance-btn']", showBalnce);
          $data_container.on('change', "[rel='select-statement-period']", showStatementPeriodView);
          $data_container.on('click', "[rel='generate-savings-account-statement']", generateSavingsAccountStatement);
          $data_container.on('click', "[rel='generate-fd-account-statement']", generateFdsAccountStatement);
      }

      function init(route, data){
        if(data.status == true){
        $data_container = $("[rel='data-container']");
        $savings_accuntstatement_list_Template = $("[rel='savings-account-list-template']");
        $savings_accountsatement_list_view = $("[rel='savings-account-list-view']");
        $fd_account_statement_select_template = $("[rel='fd-account-select-template']");
        $fd_account_statement_select_view = $("[rel='fd-account-select-view']");
        $fd_account_statement_template = $("[rel='fd-account-statement-template']");
        $fd_account_statement_view = $("[rel=fd-account-statement-view");
        $account_balance_btn = $("[rel='account-balance-btn']");
        $select_statement_period = $("[rel='select-statement-period']");
        $select_statement_period_by_date = $("[rel='period-by-date']");
        $select_statement_period_by_month = $("[rel='period-by-month']");
        $generate_savings_account_statement = $("[rel='generate-savings-account-statement']");
        $account_statement_savings_form = $("[rel='account-statement-savings-form']");
        $account_statement_fd_form = $("[rel='account-statement-fd-form']");
        $savings_account_statement_start_date = $("[rel='savings-account-statement-start-date']");
        $savings_account_statement_end_date = $("[rel='savings-account-statement-end-date']");
        $savings_account_statement_template = $("[rel='savings-account-statement-template']");
        $savings_account_statement_view = $("[rel='savings-account-statement-view']");
        buildSavingsAccountListView(data.data);
        buildFdAccountSelectView(data.data);
        attachEvents();
        }
      }
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

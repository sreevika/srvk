;(function(namespace, app, global, $){
  namespace.pages.ChangeLogInPassword = (function(){
    "use strict";
    var $change_login_password_form,
        $change_login_password_form_submit_btn;


    var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }


    var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent().addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }


    var processChangeLogInPasswordResponse = function(data){
      app.hideLoader();
      clearError();
      if(data.errors){
        ParseFormError(data.errors);
      }
      var passwordChangeStatus = null;
      try{passwordChangeStatus = data.data.passwordChanged}catch(e){};
      if(passwordChangeStatus){
        $change_login_password_form[0].reset();
        app.namespace.alert.showMessage('Login Password Change', 'Login password changed successfully', 'success');
      }
    }


    var changeLogInPassword = function(e){
      e.preventDefault();
      var form_data = $change_login_password_form.serializeArray();
      var post_request_obj = {
          url: app.getConfig().baseUrl+'dashboard/changeLoginPasswordAction',
          dataType: 'json',
          method: 'post',
          data: form_data,
          success: processChangeLogInPasswordResponse
      }
      app.showLoader();
      app.namespace.ajax.send(post_request_obj);
    };


    var attachEvents = function(){
      $change_login_password_form_submit_btn.on('click', changeLogInPassword);
  	};


    var init = function(route, data){
      if(data.status == true){
        $change_login_password_form = $("[rel='js-change-password-form']");
        $change_login_password_form_submit_btn = $("[rel='js-change-login-password-submit-btn']");
     		attachEvents();
      }
    };


    // Public Api
    return {
      init: init
    }
  })();
})( window._tsbApp.namespace, window._tsbApp, window, jQuery);

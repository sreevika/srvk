;(function(namespace, app,  global, $){
    namespace.pages.TransactionHistory = (function(){

      var $transaction_history_view,
          $transaction_history_template;

      var buildTransactionHistoryView = function(data){
          var transHist = data.transHist || [];
          var compiled_template = Handlebars.compile($transaction_history_template.html());
          var parsed_html = compiled_template(transHist);
          $transaction_history_view.html(parsed_html);
      }

      // attach all the events
      var attachEvents = function(){
        $data_container.on('click', "[rel='account-balance-btn']", showBalnce);
        $data_container.on('change', "[rel='select-statement-period']", showStatementPeriodView);
      };



      // initialize
      var init = function(route, data){
       if(data.status == true){
         $transaction_history_view = $("[rel='js-transaction-history-view']");
         $transaction_history_template = $("[rel='js-transaction-history-template']");
         buildTransactionHistoryView(data.data);
       }
      };


      // Public Api
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

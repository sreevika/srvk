;(function(namespace, app, global, $){

  namespace.pages.IntraBankBeneficiary = (function(){
    'user strict';
    var $beneficiary_view_list_view,
        $beneficiary_view_list_table_row,
        $beneficiary_view_list_template,
        $form_benf_acc_no,
        $form_benf_acc_no_cnf,
        $form_benf_name,
        $form_intra_bank_benf,
        $form_save_btn_intra_bank_benf,
        $beneficiary_edit_modal,
        $beneficiary_edit_form_save_btn,
        $beneficiary_edit_form;

    // this variable stores the current updating beneficiary table row
    var $currentUpdatingTableRow = null;
    var resetForm = function(form){
      form[0].reset();
    }
    var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }
    var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent().addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }

    var getBeneficiaryNameFromAccno = function(e){
      e.preventDefault();

      if($form_benf_acc_no.val() == ""){
        alert("Please enter account number");
        $form_benf_acc_no[0].focus();
        return;
      }

      // check are same
      if($form_benf_acc_no.val() != $form_benf_acc_no_cnf.val()){
        alert("Account number not matching");
        return;
      }
      var data = [{
        'name': 'benefAccNo',
        'value': $form_benf_acc_no.val()
      }];
      var options = {
        url: app.getConfig().baseUrl+'beneficiary/getBeneficiaryNameForAccountNum',
        data: data,
        method: 'post',
        dataType: 'json',
        success: function(data){
          // clear all the error in the form
          clearError();
          if(data.status == true && !(data.errors)){
            $form_benf_name.val(data.data.name);
            $form_benf_acc_no.attr('type', 'text');
          }else{
            ParseFormError(data.errors);
          }
        }
      }
      app.namespace.ajax.send(options);
    }

    var buildBeneficiaryView = function(data){
      debugger;
      var compiled_template = Handlebars.compile($beneficiary_view_list_template.html());
      var parsed_html = compiled_template(data);
      $beneficiary_view_list_view.html(parsed_html);
    };

    var processSaveIntraBenfResponse = function(data){
      debugger;
      clearError();
      if(data.status == true){
        $form_intra_bank_benf[0].reset();
        app.namespace.alert.showMessage('Beneficiary Created', 'Beneficiary Created Successfully', 'success');
      }
      if(data.errors){
        ParseFormError(data.errors);
      }
    }

    var saveIntraBankBenf = function(e){
      e.preventDefault();
      var form_data = $form_intra_bank_benf.serializeArray();
      var post_request_obj = {
          url: app.getConfig().baseUrl+'beneficiary/addNewIntraBeneficiary',
          dataType: 'json',
          method: 'post',
          data: form_data,
          success: processSaveIntraBenfResponse
      }
      app.namespace.ajax.send(post_request_obj);
    };

    var updateEditForm = function(data){
      $.each(data, function(i,v){
        $beneficiary_edit_form.find("[name='"+i+"']").val(v);
      });
    }

    var updateBeneficiaryEditModal = function(e){
      e.preventDefault();
      var edit_btn = $(this);
      var tr = edit_btn.closest('tr');
      var data = tr.data('benf');
      resetForm($beneficiary_edit_form);
      updateEditForm(data);
      $currentUpdatingTableRow = tr;
      $beneficiary_edit_modal.modal('show');
    };

    var updateTableRow = function(data){
      if(data){
        data.slNo = $currentUpdatingTableRow.data('benf').slNo;
      }
      var compiled_template = Handlebars.compile($beneficiary_view_list_table_row.html());
      var parsed_html = compiled_template(data);
      $currentUpdatingTableRow.replaceWith(parsed_html);
    }

    var updateBeneficiarySuccessResponse = function(data){
        app.hideLoader();
        if(data.errors){
          ParseFormError(data.errors);
          return;
        }
        var success_info = null;
        try{success_info =  data.data.beneficiaryUpdated}catch(e){};
        if(success_info === true){
          updateTableRow(data.data.benefData);
          $beneficiary_edit_modal.modal('hide');
          app.namespace.alert.showMessage('Benficiary Updated', 'Beneficiary Updated Successfully' ,'success');
        }
    };
    var updateBeneficiary = function(e){
      clearError();
      e.preventDefault();
      var data = $beneficiary_edit_form.serializeArray();
      var ajaxObject = {
        method: 'post',
        url: app.getConfig().baseUrl+'beneficiary/updateIntraBankBeneficiary',
        data: data,
        dataType: 'json',
        success: updateBeneficiarySuccessResponse
      };
      app.showLoader();
      app.namespace.ajax.send(ajaxObject);
    }

    var attachEvents = function(){
      $("[rel='data-container']").on('change', "[rel='js-form-benf-acc-no-cnf']", getBeneficiaryNameFromAccno);
      $("[rel='data-container']").on('click', "[rel='js-form-bnt-save-intra-bank-benf']", saveIntraBankBenf);
      $beneficiary_view_list_view.on('click', '[rel="js-beneficiary-edit-btn"]', updateBeneficiaryEditModal);
      $beneficiary_edit_form_save_btn.on('click', updateBeneficiary);
      $form_benf_acc_no.on('blur', function(e){ e.preventDefault(); $(e.target).attr('type', 'password')});
      $form_benf_acc_no.on('focus', function(e){ e.preventDefault(); $(e.target).attr('type', 'text')});
    };

    var init = function(route, data){
      if(data.status == true){
          $beneficiary_view_list_view = $("[rel='beneficiary-view-list-view']");
          $beneficiary_view_list_table_row = $("[rel='js-beneficiary-view-list-table-row']");
          $beneficiary_view_list_template = $("[rel='beneficiary-view-list-template']");
          $form_benf_acc_no = $("[rel='js-form-benf-acc-no']");
          $form_benf_acc_no_cnf = $("[rel='js-form-benf-acc-no-cnf']");
          $form_benf_name = $("[rel='js-form-benf-name']");
          $form_save_btn_intra_bank_benf = $("[rel='js-form-bnt-save-intra-bank-benf']");
          $form_intra_bank_benf = $("[rel='js-form-save-intra-bank-benf']");
          $beneficiary_edit_modal = $("[rel='js-beneficiary-edit-modal']");
          $beneficiary_edit_form = $("[rel='js-beneficiary-update-form']");
          $beneficiary_edit_form_save_btn = $("[rel='js-beneficiary-edit-form-save-btn']");
          // register handlebars partial template
          Handlebars.registerPartial('app.namespace.pages.IntraBankBeneficiary.benfTableRow', $beneficiary_view_list_table_row.html());
          attachEvents();
          buildBeneficiaryView(data.data.beneficiaryList.intraBank);
      }
    };


    // public api
    return {
      init: init
    }

  })();

})( window._tsbApp.namespace, window._tsbApp, window, jQuery);

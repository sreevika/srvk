;(function(namespace, app,  global, $){
    namespace.pages.RejectionClear = (function(){
      "use strict";
      var $rejection_clear_view,
          $rejection_edit_modal,
          $rejection_edit_form,
          $rejection_edit_form_submit_btn,
          $check_beneficiary_list,
          $rejection_beneficiary_account_number,
          $rejection_clear_template;
      var $currentUpdatingTableRow = null;
      var buildRejectionClearView = function(data){
        console.log(data);
        var compiled_template = Handlebars.compile($rejection_clear_template.html());
        var parsed_html = compiled_template(data);
       $rejection_clear_view.html(parsed_html);
       
      };
    var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }
    var updateRejectionEditForm = function(data){
      $rejection_edit_form [0].reset();
      $.each(data, function(i,v){
      $rejection_edit_form .find("[name='"+i+"']").val(v);
      });
    }
    var updateRejectionEditModal = function(e){
      e.preventDefault();
      var editBtn = $(e.target);
      var tr = editBtn.closest('tr');
      var data = tr.data('rej');
      updateRejectionEditForm(data);
      $currentUpdatingTableRow = tr;
      $rejection_edit_modal.modal('show');
    }

    var attachEvents = function(){
     
     $rejection_clear_view.on('click', '[rel="js-rejection-edit-btn"]', updateRejectionEditModal);
     $rejection_edit_form_submit_btn.on('click', updateRejectionClear);
     $check_beneficiary_list.on('change', checkBeneficiaryList);
     $rejection_beneficiary_account_number.on('change', removeCheckBoxOnBeneficiary);
    };
    
    var beneficiaryCheckSuccessResponse = function(data){
      app.hideLoader();
       if(data.status == false){
          removeCheckBoxOnBeneficiary();
          app.namespace.alert.showMessage('failed','This account number already added in beneficiary!','error');
          return;
        }
        else{

        }
    }

    var removeCheckBoxOnBeneficiary = function(){
      $check_beneficiary_list.prop('checked',false);
      return;
    }

    var checkBeneficiaryList = function(e){
      if(!$check_beneficiary_list.is(':checked')){
        return;
      }
      clearError();
      e.preventDefault();
      var data = $rejection_edit_form.serializeArray();
      var ajaxObject = {
        method: 'post',
        url: app.getConfig().baseUrl+'rejectionClearBeneficiaryCheck',
        data: data,
        dataType: 'json',
        success: beneficiaryCheckSuccessResponse
      };
      app.showLoader();
      app.namespace.ajax.send(ajaxObject);
    }

    var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent().addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }

    var updateRejectionClearSuccessResponse = function(data){
        app.hideLoader();
        if(data.errors){
          ParseFormError(data.errors);
          return;
        }
        var success_info = null;
        try{success_info =  data.status}catch(e){};
        if(success_info === true){
          var schedule_later_alert = "";
          if(data.data.isSchedule == true){
           app.namespace.alert.showMessage('Info','!','info');
           schedule_later_alert = 'This changes also effected on Scheduling Beneficiary';
          }
          $rejection_edit_modal.modal('hide');
          app.namespace.alert.showMessage('Rejection Clear Updated', schedule_later_alert ,'success');
          $currentUpdatingTableRow.fadeOut(1000, function(){ $currentUpdatingTableRow.remove(); });
        }
        
    };

    var updateRejectionClear = function(e){

      clearError();
      e.preventDefault();
      var data = $rejection_edit_form.serializeArray();
      var ajaxObject = {
        method: 'post',
        url: app.getConfig().baseUrl+'rejectionClearUpdate',
        data: data,
        dataType: 'json',
        success: updateRejectionClearSuccessResponse
      };
      app.showLoader();
      app.namespace.ajax.send(ajaxObject);
    }

  
      var init = function(route, data){
        $rejection_clear_view = $("[rel='rejection-clear-view']");
        $rejection_clear_template = $("[rel='rejection-clear-table-template']");
        $rejection_edit_modal = $("[rel='rejection-clear-edit-modal']");
        $rejection_edit_form = $("[rel='js-rejection-edit-form']");
        $rejection_edit_form_submit_btn = $("[rel='js-update-rejection-clear-btn']");
        $check_beneficiary_list = $("[rel='update-beneficiary-check-box']");
        $rejection_beneficiary_account_number = $("[rel='rejection-update-account-number']");
        var rejection_clear_data = null;
        try{ rejection_clear_data = data.data.rejectionClear; }catch(e){};
        buildRejectionClearView(rejection_clear_data);
        attachEvents();
        };

      // Public api
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

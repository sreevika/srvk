;(function(namespace, app,  global, $){
    namespace.pages.SalaryInstruction = (function(){
      "use strict";

      var $salary_instruction_view,
          $salary_instruction_template,
          $salary_instruction_edit_form_name_percentage,
          $salary_instruction_edit_form_name_beneficiary_trans_type,
          $salary_instruction_edit_form_name_beneficiary_id,
          $salary_instruction_update_btn,
          $page_data_container,
          $salary_instruction_update_form,
          $salary_instruction_edit_form_name_id,
          $salary_instruction_model,
          $salary_instructino_beneficiary_select_list_template;


      var clearError = function(){
        $(".has-error").removeClass('has-error');
        $(".help-block").text('');
      }


      var ParseFormError = function (errorArray){
        $.each(errorArray, function(key, val){
            $("[name='"+key+"']").parent().addClass('has-error');
            $("[name='"+key+"']").siblings(".help-block").text(val);
        })
      }


      // build view for the standing instruction
      var buildSalaryInstructionView = function(data){
        var compiled_template = Handlebars.compile($salary_instruction_template.html());
        var parsed_html = compiled_template(data);
        $salary_instruction_edit_form_name_percentage.val(data.percentage);
        $salary_instruction_view.html(parsed_html);
        $salary_instruction_edit_form_name_beneficiary_trans_type.val(data.transType);
        $salary_instruction_edit_form_name_id.val(data.id);
      };

      var buildBeneficiaryList = function(data, currentBenf){
        var compiled_template = Handlebars.compile($salary_instructino_beneficiary_select_list_template.html());
        var parsed_html = compiled_template(data);
        $salary_instruction_edit_form_name_beneficiary_id.html(parsed_html);
        if(currentBenf){
          $salary_instruction_edit_form_name_beneficiary_id.val(currentBenf);
        }
      }
      // @todo error handling
      var updateBeneficiaryListSuccess = function(data){
        app.hideLoader();
        if(data.errors){
          return;
        }
        var benef_data = null
        try{benef_data = data.data.beneficiaries}catch(e){}
        buildBeneficiaryList(benef_data);
      }

      var updateBeneficiaryList = function(e){
        e.preventDefault();
        if($salary_instruction_edit_form_name_beneficiary_trans_type.val() === ""){
          $salary_instruction_edit_form_name_beneficiary_id.val('');
          buildBeneficiaryList(null);
          return;
        }
        var data = [];
        data.push({
          name: $salary_instruction_edit_form_name_beneficiary_trans_type.attr('name'),
          value: $salary_instruction_edit_form_name_beneficiary_trans_type.val()
        });
        var ajaxObject = {
          dataType: 'json',
          method: 'post',
          url: app.getConfig().baseUrl+'beneficiary/getCustomerBeneficiaries',
          data: data,
          success:updateBeneficiaryListSuccess
        }
        app.showLoader();
        app.namespace.ajax.send(ajaxObject);
      }

      // update standing instructin success ajax function
      var updateStandingInstructionSuccess = function(data){
        app.hideLoader();
        if(data.errors){
          ParseFormError(data.errors);
          return;
        }
        if(data.status == true && data.data){
          var salary_instruction_data = null;
          try{salary_instruction_data = data.data.salaryInstructionInfo; }catch(e){};
          buildSalaryInstructionView(salary_instruction_data);
          var benf_list = null;
          try{benf_list = data.data.beneficiaryListForCurrentBenfTransType}catch(e){};
          buildBeneficiaryList(benf_list ,salary_instruction_data && salary_instruction_data.benfId);
          $salary_instruction_model.modal('hide');
          app.namespace.alert.showMessage('Done', 'Salary Instruction updated successfully', 'success' );
        }
      }

      // update standing instruciton
      var updateStandingInstruction = function(e){
        e.preventDefault();
        clearError();
        var data = $salary_instruction_update_form .serializeArray();
        var ajaxObject = {
          dataType: 'json',
          method: 'post',
          url: app.getConfig().baseUrl+'periodic-scheduled-payment/updateSalaryInstruction',
          data: data,
          success:updateStandingInstructionSuccess
        }
        app.showLoader();
        app.namespace.ajax.send(ajaxObject);
      };


      var init = function(route, data){
        $salary_instruction_view = $("[rel='salary-instruction-view']");
        $salary_instruction_template = $("[rel='salary-instruction-table-template']");
        $salary_instruction_edit_form_name_percentage = $("[name='salaryInstructionPercentage']");
        $salary_instruction_update_btn = $("[rel='update-salary-instuction-btn']");
        $salary_instruction_update_form = $("[rel='salary-instuction-update-form']");
        $salary_instruction_edit_form_name_beneficiary_trans_type = $("[name='beneficiaryTransType']");
        $salary_instruction_edit_form_name_beneficiary_id = $("[name='beneficiaryId']");
        $page_data_container = $("[rel='data-container']");
        $salary_instructino_beneficiary_select_list_template = $("[rel='salary-instruction-beneficiary-select-list-template']");
        $salary_instruction_edit_form_name_id = $("[name='salaryInstructinId']");
        $salary_instruction_model = $("[rel='salary-instruction-edit-modal']");

        var salary_instruction_data = null;
        try{ salary_instruction_data = data.data.salaryInstructionInfo; }catch(e){};
        buildSalaryInstructionView(salary_instruction_data);
        var beneficiary_select_list_data = null;
        try{ beneficiary_select_list_data = data.data.beneficiaryListForCurrentBenfTransType; }catch(e){};
        buildBeneficiaryList(beneficiary_select_list_data, salary_instruction_data && salary_instruction_data.benfId || null );
        $salary_instruction_update_btn.on('click', updateStandingInstruction);
        $salary_instruction_edit_form_name_beneficiary_trans_type.on('change', updateBeneficiaryList);
      };

      // Public api
      return {
        init: init
      }
    })();
})(window._tsbApp.namespace, window._tsbApp, window, jQuery);

;(function(namespace, app, global, $){
  namespace.pages.Dashboard = (function(){
      var $profile_template_view,
          $profile_template,
          $account_list_template,
          $savings_account_list_view,
          $fd_account_list_view;

      var buildProfileView = function(data){
          var compiled_template = Handlebars.compile($profile_template.html());
          var parsed_html = compiled_template(data);
          $profile_template_view.html(parsed_html);
      }

      var buildSavingsView = function(data){
           var compiled_template = Handlebars.compile($account_list_template.html());
           var parsedHtml = compiled_template(data.accountDetails.savingsAccounts);
           $savings_account_list_view.html(parsedHtml);
      }

      var buildFdView = function(data){
           var compiled_template = Handlebars.compile($account_list_template.html());
           var parsedHtml = compiled_template(data.accountDetails.fdAccounts);
           $fd_account_list_view.html(parsedHtml);
      }

      var buildView  = function(data){
        buildProfileView(data.data.profile);
      }


      var showBalnce = function(e){
          e.preventDefault();
          var $link = $(e.target);
          $link.text($link.data("balance"));
      }

      var attachEvents = function(){
        $("[rel='data-container']").on('click', "[rel='account-balance-btn']", showBalnce);
      }


      var init = function(route, data){
        if(data.status == true){
          $profile_template_view = $("[rel='profile-template-view']");
          $profile_template = $("[rel='profile-template']");
          $account_list_template = $("[rel='account-list-template']");
          $savings_account_list_view = $("[rel='savings-account-list-view']");
          $fd_account_list_view = $("[rel='fd-account-list-view']");
          attachEvents();
          buildView(data);
          buildSavingsView(data.data);
          buildFdView(data.data);
        }
      }
      return {
        init: init
      }
    })();
})( window._tsbApp.namespace, window._tsbApp, window, jQuery);

$(function(){
  // Handlebars Helpers
  Handlebars.registerHelper('ifCond', function(v1, v2, options) {
  if(v1 === v2) {
    return options.fn(this);
  }
  return options.inverse(this);
  });

  // handlebars json stringify helper
  Handlebars.registerHelper('json', function(context) {
    return JSON.stringify(context);
  });
  // routes
  window._tsbApp.namespace.router.on("#!/", 'dashboard/home', window._tsbApp.namespace.pages.Dashboard.init);
  window._tsbApp.namespace.router.on("#!/account-statement", 'account-statement', window._tsbApp.namespace.pages.AccountSatement.init);
  window._tsbApp.namespace.router.on("#!/intra-bank-beneficiary", 'beneficiary/intraBankBeneficiary', window._tsbApp.namespace.pages.IntraBankBeneficiary.init);
  window._tsbApp.namespace.router.on("#!/inter-bank-beneficiary", 'beneficiary/interBankBeneficiary', window._tsbApp.namespace.pages.InterBankBeneficiary.init);
  window._tsbApp.namespace.router.on("#!/standing-instruction", 'standing-instruction');

  window._tsbApp.namespace.router.on("#!/intra-bank-fund-transaction", 'fund-transfer/intraBankTransfer', window._tsbApp.namespace.pages.IntraBankFundTransaction.init);
  window._tsbApp.namespace.router.on("#!/inter-bank-fund-transaction", 'fund-transfer/interBankTransfer', window._tsbApp.namespace.pages.InterBankFundTransaction.init);
    window._tsbApp.namespace.router.on("#!/transaction-history", 'fund-transfer/transactionHistory', window._tsbApp.namespace.pages.TransactionHistory.init);
 // window._tsbApp.namespace.router.on("#!/rejection-clear", 'rejectionClear', window._tsbApp.namespace.pages.RejectionClear.init);
  window._tsbApp.namespace.router.on("#!/change-login-password", 'dashboard/changeLoginPassword', window._tsbApp.namespace.pages.ChangeLogInPassword.init);
  window._tsbApp.namespace.router.on("#!/change-transaction-password", 'dashboard/changeTransactionPassword', window._tsbApp.namespace.pages.changeTransactionPassword.init);
  window._tsbApp.namespace.router.on("#!/periodic-scheduled-payment/salary-instruction", 'periodic-scheduled-payment/salaryInstruction', window._tsbApp.namespace.pages.SalaryInstruction.init);
  window._tsbApp.namespace.router.on("#!/rejection-clear", 'rejection-clear', window._tsbApp.namespace.pages.RejectionClear.init);
  window._tsbApp.namespace.router.init();
});

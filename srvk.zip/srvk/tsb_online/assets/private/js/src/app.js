// admin lte menu hover
$(function(){
    $('.sidebar-menu').on('click', 'li', function(e){
        var $this = $(this);
        if($this.parent().hasClass('sidebar-menu')){
          $('.sidebar-menu > li').removeClass('active');
          $this.siblings().find('ul').css('display', 'none');
          $this.addClass('active');
          return;
        }
        if($this.parent().hasClass('treeview-menu')){
          $this.parent().find('li').removeClass('active');
          $this.addClass('active');
        }
    });
});
(function(global, $){
  window._tsbApp = function(){
    var namespace = {
      pages: {}
    };

    // App config options
    var options = {
        baseUrl:  $("meta[data-type='base-url']").attr('content'),
        dataContainer: 'div.data-container',
        csrfName: $('meta[data-type="csrf"]').attr('name'),
        csrfValue: $('meta[data-type="csrf"]').attr('content')
    };

    var getConfig = function(){
      return options;
    };

    var setconfig = function(key, value){
      options[key] = value;
    };

    // loading ui component
    var show_loading = function(){
      var html_markup =  '<div class="spinner-container " style="display:none;"><svg class="spinner" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div>';
      if(!$('div.spinner-container').length){
        $('body').append(html_markup);
        $('.spinner-container').fadeIn(300);
      }
    };

    var hide_loading = function(){
      var spinner = $('div.spinner-container');
      if(spinner.length > 0){
        spinner.fadeOut(600, function(){
          $(this).remove();
        });
      }
    };

    var logOut = function(){
      window.location = options.baseUrl+'dashboard/logout';
    }

    var init = function(configOptions){
      $.extend(options, configOptions);
      global.EVENT = new EventEmitter2();
      EVENT.emit('app_init');
    };
    // Public api
    return {
      namespace: namespace,
      showLoader: show_loading,
      hideLoader: hide_loading,
      getConfig: getConfig,
      logOut: logOut,
      init: init
    };
  }();
})(window, jQuery);
window._tsbApp.init();

(function(global, $){
    var Login = (function(){

      var init = function(){

      }

      return {
          init: init
      }
    })();
})(window, jQuery);

;(function(global, $){
  global._app = (function(){
    // namesapce
    var namespace = {};
    // config options
    var options = {
      baseurl: '',
      csrfName: '',
      csrfValue: ''
    }

    // login initialization
    var loginUser = function(evt){
        evt.preventDefault();

    };

    // initialization
    var init = function(){

    }
    // pulic api
    return{
      init: init
    }
  })();
})(window, jQuery);

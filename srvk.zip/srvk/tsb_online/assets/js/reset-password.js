$(function(){
	'use strict';

	var $reset_password_submit = $('#reset_password_submit');
	var $forget_password_form = $("form.forget-password-form");
  var $level_2_template = $("#reset_password_level_2_template");
  var $template_view = $("#forget-password_view");
  var $level_3_template = $("#reset_password_level_3_template");


	var clearFormErrors = function(form){
			form.find('.has-error').removeClass('has-error');
			form.find('span.help-block').text('');
	};


  var processFormError = function(form, errorArray){
    debugger;
    $.each(errorArray, function(key, val){
      var field = form.find("[name='"+key+"']");
      if(field.length > 0){
        field.parent().addClass('has-error');
        field.siblings('span.help-block').text(val);
      }
    });
  };

	$("[rel='js-forget-password-form-dob']").datepicker({format: 'dd/mm/yyyy'});

    var processActionSubmitResponse = function(data){
      clearFormErrors($forget_password_form);
      TsbOnlineApp.hideLoader();
      if(data.errors){
        processFormError($forget_password_form , data.errors);
        return;
      }
      if(data.status == true){
        var compiled_template = Handlebars.compile($level_2_template.html());
        var parsed_template = compiled_template(data.data);
        $template_view.html(parsed_template);
      }

    };

	//Forget Password

	$reset_password_submit.on('click', function(e){
      e.preventDefault();
			debugger;
      var form = $(this).closest('form');
      var data = form.serializeArray();
			console.log(data);
      var csrf_name = TsbOnlineApp.getConfig().csrfName;
      var csrf_value = TsbOnlineApp.getConfig().csrfValue;
      data.push({
        name: csrf_name,
        value: csrf_value
      });
      TsbOnlineApp.showLoader();
      $.ajax({
        url: TsbOnlineApp.getBaseUrl()+'forget-password-action-submit',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processActionSubmitResponse,
        error: function(){
          TsbOnlineApp.hideLoader();
          alert('Sorry something went wrong');
        }
      })
  });

  var processVerifyOtp = function(data){
      TsbOnlineApp.hideLoader();
      if(data.status == false){
        alert('Failed to Reset Password');
        return
      }
      // show next template
    
      $("#reset-password-content-view").html($level_3_template.html());
  }


  var verifyOtp = function(e){
    e.preventDefault();
    var btn = $(e.target);
    var form = btn.closest('form');
    var data = form.serializeArray();
    var csrf_name = TsbOnlineApp.getConfig().csrfName;
    var csrf_value = TsbOnlineApp.getConfig().csrfValue;
    data.push({
      name: csrf_name,
      value: csrf_value
    });
    TsbOnlineApp.showLoader();
    $.ajax({
      url: TsbOnlineApp.getBaseUrl()+'verify-forget-password-otp',
      method: 'post',
      dataType: 'json',
      data: data,
      success: processVerifyOtp,
      error: function(){
        TsbOnlineApp.hideLoader();
        alert('Sorry something went wrong');
      }
    })
  }

  $template_view.on('click', '.verify_otp', verifyOtp);

  //To change Login Password
  var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }


  var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent().addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }

  var processActionNewPasswordResponse = function(data){
     var $new_password_form = $("[rel='js-new-password-form']");
     TsbOnlineApp.hideLoader();
      clearError();
      if(data.errors){
        ParseFormError(data.errors);
      }
      var passwordChangeStatus = null;
      try{passwordChangeStatus = data.data.passwordChanged}catch(e){};
      if(passwordChangeStatus){
        $new_password_form[0].reset();
        alert('Login password changed successfully');
        window.location = TsbOnlineApp.getBaseUrl()+'login';
        //TsbOnlineApp.namespace.alert.showMessage('Login Password Change', 'Login password changed successfully', 'success');
      }

  };

  $("body").on('click', "#new-login-password-submit-btn", function(e){
      e.preventDefault();
      debugger;
      var form = $(this).closest('form');
      var data = form.serializeArray();
      console.log(data);
      var csrf_name = TsbOnlineApp.getConfig().csrfName;
      var csrf_value = TsbOnlineApp.getConfig().csrfValue;
      data.push({
        name: csrf_name,
        value: csrf_value
      });
      TsbOnlineApp.showLoader();
      $.ajax({
        url: TsbOnlineApp.getBaseUrl()+'new-forget-password-action-submit',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processActionNewPasswordResponse,
        error: function(){
          TsbOnlineApp.hideLoader();
          alert('Sorry something went wrong');
        }
      })
  });

});

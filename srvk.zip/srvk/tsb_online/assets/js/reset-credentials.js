$(function(){
    "use strict";
    var $reset_credentials_form = $("[rel='js-reset-credentials-form']");
    var $reset_credentials_submit = $("[rel='js-submi-reset-credentials']");
    var $page_container = $("[rel='page-container']");
    var $reset_credentials_success = $("[rel='js-reset-credentials-success']");



    var processFormError = function(form, errorArray){
      debugger;
      $.each(errorArray, function(key, val){
        var field = form.find("[name='"+key+"']");
        if(field.length > 0){
          field.parent().addClass('has-error');
          field.siblings('span.help-block').text(val);
        }
      });
    };

    var clearFormErrors = function(form){
        form.find('.has-error').removeClass('has-error');
        form.find('span.help-block').text('');
    };


    $reset_credentials_form.on('submit', function(e){
        e.preventDefault();
        clearFormErrors($reset_credentials_form);
        var data = $reset_credentials_form.serializeArray();
        data.push({ name: TsbOnlineApp.getConfig().csrfName, value: TsbOnlineApp.getConfig().csrfValue});
        $.post(TsbOnlineApp.getBaseUrl()+'reset-credentials-action', data, function(data){
          // if error
          if(!data.status){
            if(data.error && data.error.message){
              alert(data.error.message);
            }else{
              alert('Somthing went wrong');
            }
            return;
          }

          if(data.errors){
            processFormError($reset_credentials_form, data.errors);
            return;
          }
          debugger;
          if(data.data.resetCredentials == true){
            $page_container.html($reset_credentials_success.html());
          }
        }).fail(function(){
            alert("somthing went wrong");
        });
    });



});

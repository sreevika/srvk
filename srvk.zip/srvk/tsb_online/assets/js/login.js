$(function(){
    var $username = $('.username');
    var $password = $('.password');
    var $form = $('#tsb_main_form');
    var $submit_login = $('.submit-login');
    var clearError = function(){
      $(".has-error").removeClass('has-error');
      $(".help-block").text('');
    }


    var ParseFormError = function (errorArray){
      $.each(errorArray, function(key, val){
          $("[name='"+key+"']").parent().addClass('has-error');
          $("[name='"+key+"']").siblings(".help-block").text(val);
      })
    }

    var login = function(e){
      e.preventDefault();
      var csrfName = $('meta[data-type="csrf"]').attr('name');
      var csrfValue = $('meta[data-type="csrf"]').attr('content');
      var data = $form.serializeArray();
      data.push({
        name: csrfName,
        value: csrfValue
      });
      // hash password
      $.post(TsbOnlineApp.getBaseUrl()+'login-action', data, function(data){
        clearError();
        debugger;
        if(data.loginStatus === true){
          window.location = TsbOnlineApp.getBaseUrl()+"dashboard/";
        }
        if(data.resetCredentials == true){
          window.location = TsbOnlineApp.getBaseUrl()+'reset-credentials';
        }
        if(data.error && data.error != ""){
          alert(data.error);
        }
        if(data.errors){
          ParseFormError(data.errors);
        }
      });
    };

    // Enable virtual keyboard
    $("body").on("click", ".keyboard-toggle", function(){
        var checkbox = $(this);
        if(checkbox.prop("checked")){
          var keyboard = $('.keyboard').keyboard({
              layout: 'custom',
              appendTo: 'div.login-banner',
              stayOpen: true,
              alwaysOpen: true,
              autoAccept: true,
            //  userClosed: true,
              customLayout: {
                'normal': [
            '` 1 2 3 4 5 6 7 8 9 0 - = {bksp}',
            '{tab} q w e r t y u i o p [ ] \\',
            'a s d f g h j k l ; \' {enter}',
            '{shift} z x c v b n m , . / {shift}',
            '{accept} {space} {left} {right} {sp:.2} {del} {combo} {toggle} {extender}'
                ],
                'shift': [
            '~ ! @ # $ % ^ & * ( ) _ + {bksp}',
            '{tab} Q W E R T Y U I O P { } |',
            'A S D F G H J K L : " {enter}',
            '{shift} Z X C V B N M < > ? {shift}',
            '{accept} {space} {left} {right} {sp:.2} {del} {combo} {toggle} {extender}'
                ]
              },
              usePreview: false,
              acceptValid: true,
              validate: function(kb, val) {
                return val.length > 3;
              }
            });

        }else{
          $('.keyboard').eq(0).keyboard().getkeyboard().destroy();
          $('.keyboard').eq(1).keyboard().getkeyboard().destroy();
        }
      });


    $form.on('click', '.submit-login', login);
});

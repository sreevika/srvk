
(function($){

/*
 Navigation control
*/

	$(function(){
		$('span.site-header-menu-btn').on('click', function(){
			$("section.site-header nav").addClass("open");
		});
		$("span.close-nav-btn").on("click", function(){
			$("section.site-header nav").removeClass("open");
		});
	});




/*
* Tsbonline app
*/

window.TsbOnlineApp = (function(config){

	// Module configuration

	var  appConfig = {
		loaderHtml : '<div class="spinner-container" style="display: none;"><div class="spinner"></div></div>',
		baseUrl: $('body').data('base-url'),
		csrfName: '',
		csrfValue: ''
	}


	// Private data

	var updateCsrf = function(){
		appConfig.csrfName = $("meta[data-type='csrf']").attr('name');
		appConfig.csrfValue = $("meta[data-type='csrf']").attr('content');
	}

	var init = function(){
		showConsoleWarning();
		SmoothScroll({ stepSize: 100, animationTime : 300, accelerationDelta : 1,  });
		clearLoaderOnPageload();
		updateCsrf();
		new WOW().init();
	}
	var clearLoaderOnPageload = function(){
		$(window).on("load", function(){
			hideLoader();
		})
	}
	var showConsoleWarning = function(){
		var message = "WARNING! Using this console may allow attackers to impersonate you and steal your information using an attack called Self-XSS.Do not enter or paste code that you do not understand.";
		console.log("%c%s", "font-size: 22px; color: red; background: yellow; ", message);
	}
	var showLoader = function(){
		var body = $("body");
		(body.find("div.spinner-container").length === 0) && body.prepend(appConfig.loaderHtml);
		$(".spinner-container").fadeIn('300');
	}

	var getBaseUrl = function(){
		return appConfig.baseUrl;
	}

	var hideLoader = function(){
		$(".spinner-container").fadeOut('300', function(){
			$("div.spinner-container").remove();
		});
	}

	var getConfig = function(){
		return appConfig;
	}

	return {
		init : init,
		showLoader : showLoader,
		hideLoader : hideLoader,
		getBaseUrl: getBaseUrl,
		getConfig: getConfig
	}

})();

})(jQuery);



TsbOnlineApp.init();

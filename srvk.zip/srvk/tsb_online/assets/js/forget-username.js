$(function(){
	'use strict';
	var $forget_username_submit = $('#forget_username_submit');
	var $forget_username_form = $("form.forget-username-form");
	var $level_2_template = $("#forget_username_level_2_template");
    var $template_view = $("#forget-username_view");

	$("[rel='js-forget-username-form-dob']").datepicker({format: 'dd/mm/yyyy'});

	var clearFormErrors = function(form){
			form.find('.has-error').removeClass('has-error');
			form.find('span.help-block').text('');
	};


    var processFormError = function(form, errorArray){
    debugger;
    $.each(errorArray, function(key, val){
      var field = form.find("[name='"+key+"']");
      if(field.length > 0){
        field.parent().addClass('has-error');
        field.siblings('span.help-block').text(val);
      }
    });
   };

    var processUsernameActionSubmitResponse = function(data){
      clearFormErrors($forget_username_form);
      TsbOnlineApp.hideLoader();
      if(data.errors){
        processFormError($forget_username_form , data.errors);
        return;
      }
      if(data.status == true){
        var compiled_template = Handlebars.compile($level_2_template.html());
        var parsed_template = compiled_template(data.data);
        $template_view.html(parsed_template);
      }

    };

	$forget_username_submit.on('click',function(e){
		e.preventDefault();
		var form = $(this).closest('form');
		var data = form.serializeArray();
		var csrf_name = TsbOnlineApp.getConfig().csrfName;
        var csrf_value = TsbOnlineApp.getConfig().csrfValue;
        data.push({
        name: csrf_name,
        value: csrf_value
        });
        TsbOnlineApp.showLoader();
        $.ajax({
        url: TsbOnlineApp.getBaseUrl()+'forget-username-action-submit',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processUsernameActionSubmitResponse,
        error: function(){
          TsbOnlineApp.hideLoader();
          alert('Sorry something went wrong');
        }
      })
	});
	
});

$(function(){
  var $level_1_submit = $('#level_1_submit');
  var $level_1_form = $("form.user-registration-level-1-form");
  var $level_1_username = $("[name='level_1_username']");
  var $level_2_template = $("#new_user_level_2_template");
  var $template_view = $("#new_user_registration_view");
  var $level_3_template = $("#otp_success");
  var $level_1_form_confirm_tsb_accno = $("[name='level_1_confirm_tsb_account_number']");
  var $level_1_form_tsb_accno = $("[name='level_1_tsb_account_number']");


  var processFormError = function(form, errorArray){
    debugger;
    $.each(errorArray, function(key, val){
      var field = form.find("[name='"+key+"']");
      if(field.length > 0){
        field.parent().addClass('has-error');
        field.siblings('span.help-block').text(val);
      }
    });
  };

  var clearFormErrors = function(form){
      form.find('.has-error').removeClass('has-error');
      form.find('span.help-block').text('');
  };

  var processLevelOneResponse = function(data){
      clearFormErrors($level_1_form);
      TsbOnlineApp.hideLoader();
      if(data.status == false){
        processFormError($level_1_form, data.errors);
        return;
      }
      if(data.status == true){
        var compiled_template = Handlebars.compile($level_2_template.html());
        var parsed_template = compiled_template(data.data);
        $template_view.html(parsed_template);
      }

  };

  // level one form submission
  $level_1_submit.on('click', function(e){
      e.preventDefault();
      var form = $(e.target).closest('form');
      var data = form.serializeArray();
      var csrf_name = TsbOnlineApp.getConfig().csrfName;
      var csrf_value = TsbOnlineApp.getConfig().csrfValue;
      data.push({
        name: csrf_name,
        value: csrf_value
      });
      TsbOnlineApp.showLoader();
      $.ajax({
        url: TsbOnlineApp.getBaseUrl()+'registration-level-1',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processLevelOneResponse,
        error: function(){
          TsbOnlineApp.hideLoader();
          alert('Sorry something went wrong');
        }
      })
  });

  var processUsernameSearch = function(data){
    clearFormErrors($level_1_form);
    TsbOnlineApp.hideLoader();
    if(data.status == false){
      processFormError($level_1_form, data.errors);
    }
  }

  var searchUsername = function(e){

    e.preventDefault();
    var data = [{
      name: $level_1_username.attr('name'),
      value: $level_1_username.val()
    }];
    var csrf_name = TsbOnlineApp.getConfig().csrfName;
    var csrf_value = TsbOnlineApp.getConfig().csrfValue;
    data.push({
      name: csrf_name,
      value: csrf_value
    })

    TsbOnlineApp.showLoader();
    $.ajax({
        url: TsbOnlineApp.getBaseUrl()+'find-username',
        method: 'post',
        dataType: 'json',
        data: data,
        success: processUsernameSearch,
        error: function(){
          TsbOnlineApp.hideLoader();
          alert('Sorry something went wrong');
        }
    });
  }

  var processVerifyOtp = function(data){
      TsbOnlineApp.hideLoader();
      if(data.status == false){
        var errorMessage = (data.error && data.error.message )? data.error.message : 'Somthing Went Wrong' ;
        alert(errorMessage);
        return
      }
      if(!data.data.registrationSuccess){
        var message = (data.error && data.error.message )? data.error.message : 'Somthing Went Wrong' ;
        alert(message);
        return;
      }
      // show next template
      $template_view.html($level_3_template.html());
  }


  var verifyOtp = function(e){
    e.preventDefault();
    var btn = $(e.target);
    var form = btn.closest('form');
    var data = form.serializeArray();
    var csrf_name = TsbOnlineApp.getConfig().csrfName;
    var csrf_value = TsbOnlineApp.getConfig().csrfValue;
    data.push({
      name: csrf_name,
      value: csrf_value
    });
    TsbOnlineApp.showLoader();
    $.ajax({
      url: TsbOnlineApp.getBaseUrl()+'verify-registration-otp',
      method: 'post',
      dataType: 'json',
      data: data,
      success: processVerifyOtp,
      error: function(){
        TsbOnlineApp.hideLoader();
        alert('Sorry something went wrong');
      }
    })
  }

  // Level one usernaem search
  $level_1_username.on('change', searchUsername);
  $template_view.on('click', '.verify_otp', verifyOtp);
  $level_1_form_confirm_tsb_accno.on('paste', function(e){
      e.preventDefault();
  });
  $level_1_form_tsb_accno.on('blur', function(e){
      e.preventDefault();
      if($(e.target).val() != ''){
        $(e.target).attr('type', 'password');
      }
  });
  $level_1_form_tsb_accno.on('focus', function(e){
    e.preventDefault();
    $(e.target).attr('type', 'text');
  });
});

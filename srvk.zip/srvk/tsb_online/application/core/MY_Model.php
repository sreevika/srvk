<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Extending Codeigniter model
 * Created by : Maneksh MS
 * Created at : 23-01-2018
 */
class MY_Model extends CI_Model{
		//PDO Connection Object
		public $conn;

		//Table Name
		protected $_table;

		//Table column name and data type array
		protected $_columns_info;

		//Column Name array
		protected $_column_name_array = array();

		public $primary_key;


		private $_errors = array();

    /**
     * Constructor
     *
     */
    public function __construct($table_name = null, $table_columns = [], $primary_key = null){
			if(!isset($this->db)){
				$this->load->database();
			}
			$this->conn = $this->db->conn_id;
			$this->conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			$this->_table = $table_name;
			$this->_columns_info = $table_columns;
			$this->primary_key = $primary_key;

			//Make column array
			foreach($this->_columns_info as $key => $val){
				$this->_column_name_array[] = $key;
			}
    }
		/*
		*Insert
		*Insert new row into database
		*@RETURN BOOLEAN TRUE ON SUCCESS OR BOOLEAN FALSE ON FAIL
		*/
		public function insert(){
			$column_name_array = $this->_column_name_array;
			//column name array
			$column_name = array();
			//value reference for bind param (? is used)
			$column_value_referance = array();

			foreach($column_name_array as  $value){
				//if property exists
				if($this->_check_property_exists($value)){
					$column_name[] = $value;
					$column_value_referance[] = "?";
				}
			}
			//generate sql
			$sql = " INSERT INTO ".$this->_table." (";
			$sql .= implode(', ',  $column_name)." ) ";
			$sql .= " VALUES ( ";
			$sql .= implode(', ', $column_value_referance)." ) ";
			//Prepare sql
			$PdoStatementObj = $this->conn->prepare($sql);
			//Bind parameters
			for($i = 0; $i < count($column_name); $i++){
				$bind_index = $i + 1;
				$param_data_type  = $this->_get_data_type_constant($column_name[$i]);
				$PdoStatementObj->bindParam($bind_index, $this->$column_name[$i], $param_data_type);
			}
			//execure Pdo statement
			$result = $PdoStatementObj->execute();

			if($result){
				//if executed successfully
				$primary_key = $this->primary_key;
				//Set primary key
				$this->$primary_key = $this->lastInsertId();
				return true;
			}else{
				return false;
			}


		}

		/*
		*Update
		*Update sql
		*@RETURN (INTEGER) number of affected row  on success or BOOLEAN FALSE on fail
		*/
		public function update(){
			$column_name_array = $this->_column_name_array;
			//Remove primary key from column name
			//find primary array key index ( Search the primary key in array and get the index of the array)
			$primary_key_index = array_search($this->primary_key, $column_name_array);
			//remove the primary key via uset function
			unset($column_name_array[$primary_key_index]);
			//Reassign the value (re ordering the array)
			$column_name_array = array_values($column_name_array);
			//Creating name value pair (example: [username = 'username', password = 'your password'])
			$name_value_pair = array();
			//column name
			$column_name = array();
			foreach($column_name_array as  $value){
				if($this->_check_property_exists($value)){
					$column_name[] = $value;
					$name_value_pair[] = $value." = ?";
				}
			}

			//generate sql
			$sql = " UPDATE ".$this->_table." SET ";
			$sql .= implode(', ',  $name_value_pair)."  WHERE ID =".$this->{$this->primary_key};
			//prepare sql
			$PdoStatementObj = $this->conn->prepare($sql);

			//bind param
			for($i = 0; $i < count($name_value_pair); $i++){
				$pram_index = $i + 1;
				//$param_data_type  = $this->_get_data_type_constant($column_name[$i]);
				$PdoStatementObj->bindParam($pram_index, $this->$column_name[$i]);
			}

			//execute
			$result = $PdoStatementObj->execute();
			if($result){
				return $PdoStatementObj->rowCount();
			}
			return false;

		}

		/*
		*Delete
		*Delete operation
		*@RETURN INTEGER affected rows number on success OR BOOLEAN false on fail
		*/
		public function delete(){
			$id = (integer) $this->{$this->primary_key};
			$sql = "DELETE FROM ".$this->_table." WHERE ID = ".$id;
			$result = $this->query($sql);
			if($result){
				$affected_row = $result->rowCount();
				return ($affected_row > 0)? true : false;
			}
			return false;
		}
    /*
    *FETCH BY ID
    *Get row object for the given id
    *@PARAM INTEGER ID
    *@RETURN ROW OBJECT ON SUCCESS OR RETURN FALSE
    */
    public function findById($id){
        $id = (integer) $id;
        $sql = " SELECT ";
        //$sql .= implode(',', $this->_column_name_array);
        $sql .= " * ";
        $sql .= " FROM ".$this->_table;
        $sql .= " WHERE ID = ".$id;
        $resultResource = $this->conn->query($sql);
        $obj_array = $this->_process_result($resultResource);
        return !empty($obj_array)? array_pop($obj_array) : FALSE;
    }

  		/*
  		*fetch_all
  		*Fetch all the records from a table
  		*@RETURN PDO STATEMENT OBJECT ON SUCCESSFUL QUERY OR RETURN BOOLEAN FALSE
  		*/
  		public function findAll($order = NULL){

  			$sql = "SELECT ";
  			$sql .= implode(',', $this->_column_name_array);
  			$sql .= " FROM ".$this->_table;
  			if($order != NULL & $order == 'desc'){
  				$sql .= " ORDER BY ID DESC";
  			}

  			//$result =  $this->query($sql);
  			$result_stmt =  $this->conn->prepare($sql);
  			$result =  $result_stmt->execute();
  			if($result){
  				$obj_array = $this->_process_result($result_stmt);
  				return $obj_array;
  			}


  		}


      /**
  		* Get by sql
  		* Get data by sql
  		**/
  		public function findBySql($sql, $param = array()){
  				$stmt = $this->conn->prepare($sql);
  				if($stmt){
  					if(is_array($param) && count($param) > 0){
  						$i = 1;
  						foreach($param as &$prm){
  							$stmt->bindParam($i, $prm);
  							$i++;
  						}
  					}
  					$result = $stmt->execute();
  					if($result){
  						$obj_array = $this->_process_result($stmt);
  						return $obj_array;
  					}
  				}
  		}

      /*
  		*Process result
  		*Process a result PDO Statement object and return result object
  		*@PARAM PDOStatement object
  		*@RETURN ARRAY
  		*/
  		protected function _process_result($result){
  			$result_array = $result->fetchAll();
				if($result_array == false){
					return false;
				}
  			$obj_array = [];
  			if($result_array && count($result_array) > 0){
  				foreach($result_array as $result){
  					$obj_array[] = $this->_make_object($result);
  				}
  			}
  			return $obj_array;
  		}

  		/*
  		*Make Object
  		*Make Object and assign property
  		*@PARAM ARRAY RESULT ROW
  		*@RETURN OBJECT
  		*/
  		protected function _make_object($result){
  			$obj = new static;
  			foreach($result as $key => $val){
  				if($this->_check_column_exists($key)){
  					$obj->$key = $val;
  				}
  			}
  			return $obj;
  		}

  		/*
  		*Check column exists
  		*Check the name exests in table column array
  		*/
  		protected function _check_column_exists($column_name){
  			if(in_array($column_name, $this->_column_name_array, true)){
  				return true;
  			}
  			return false;
  		}


  		protected function _check_property_exists($key){
  			$prop = get_object_vars($this);
  			return array_key_exists($key, $prop)? true : false;
  		}


      /*
      *LastInsertId
      *Get last insert ID
      *@RETURN INTEGER
      */
      public function lastInsertId(){
        return $this->conn->lastInsertId();
      }


    /**
     * execute query
     * Prepare statement query execute
     * @param $sql String, @param $param array
     * @return $tmt PDOStatement on success and false on failure
     */
     public function execute_query($sql, $param = array()){

       // Prepare sql query
       $stmt = $this->conn->prepare($sql);
       if(!$stmt){
         log_message('error', "PREPARE QUERY FAILED SQL : ".$sql." PARAMS ".implode(', ', $param));
         return false;
       }

       // Bind params
       if(!empty($param)){
         $index = 1;
         foreach($param as &$p){
           $status = $this->bind($stmt, $index, $p);
           if(!$status){
             return false;
           }
           $index++;
         }
       }

       // execute prepare statement
       $result = $stmt->execute();
       if(!$result){
         log_message('error', "EXECUTE PREPARE STATEMENT : ".$sql." PARAMS : ".implode(', ', $param));
         return false;
       }
       return $stmt;

     }


     /**
      * bind value to a prepare statement
      * @param PDOStatement $stmt, $param mixed, $value mixed, $data_type [pdo constant]
      * @return boolean true on success and false on failure
      */
     public function bind($stmt, $params, $value, $data_type = null){
          $data_type = (!is_null($data_type))? $data_type : $this->getPDODateType($value);
          $status = $stmt->bindParam($params, $value, $data_type);
          if($status){
            return true;
          }
          log_message('error', "PREPARE PARAM FAILED PARAM : ".$value);
          return false;
     }

     /**
      * get pdo date type
      * @param $value Mixed
      * @return  PDO database constant
      */
     public function getPDODateType($value){
       switch (true) {
          case is_bool($value):
          $var_type = PDO::PARAM_BOOL;
          break;
       case is_int($value):
           $var_type = PDO::PARAM_INT;
           break;
			/**
       case is_null($value):
           $var_type = PDO::PARAM_NULL;
           break;
			**/
       default:
           $var_type = PDO::PARAM_STR;
       }
       return $var_type;
     }

		 public function setError($error_msg, $error_code){
			 $error = array();
			 $error['code'] = $error_code;
			 $error['message'] = $error_msg;
			 $this->_errors[] = $error;
		 }

		 public function getError(){
			 return $this->_errors;
		 }
		 public function getFirstError(){
			 if(count($this->_errors) > 0){
				 return array_shift($this->_errors);
			 }
		 }

}
?>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-01 09:20:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 10:40:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 11:53:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 11:54:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 11:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-01 11:55:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 12:12:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 13:48:20 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 113
ERROR - 2018-02-01 13:49:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 13:49:46 --> Severity: Notice --> Undefined variable: codeigeniter_instance /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 14
ERROR - 2018-02-01 13:49:46 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 14
ERROR - 2018-02-01 13:49:46 --> Severity: Error --> Call to a member function item() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 14
ERROR - 2018-02-01 13:50:02 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 14
ERROR - 2018-02-01 13:50:41 --> Severity: Notice --> Undefined index: id /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 111
ERROR - 2018-02-01 13:50:41 --> Severity: Notice --> Undefined variable: username /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 41
ERROR - 2018-02-01 13:50:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 13:51:47 --> Severity: Notice --> Undefined variable: username /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 41
ERROR - 2018-02-01 13:54:02 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Exceptions\UserException::getMessge() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 16
ERROR - 2018-02-01 13:54:14 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Exceptions\UserException::getMessge() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 16
ERROR - 2018-02-01 14:50:55 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 85
ERROR - 2018-02-01 14:51:15 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Customer\CustomerEntity::setConfirmedBy() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 42
ERROR - 2018-02-01 14:53:32 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Customer\CustomerEntity::setMiddletName() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 47
ERROR - 2018-02-01 14:54:02 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Customer\CustomerEntity::setReligionCategory() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 56
ERROR - 2018-02-01 14:54:47 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Customer\CustomerEntity::setPremPostOffice() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 60
ERROR - 2018-02-01 14:55:55 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\Customer\CustomerEntity::setOnlineBenfCounter() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/CustomerRepository.php 62
ERROR - 2018-02-01 14:59:00 --> Severity: Notice --> Undefined variable: _customer_repo /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/Customer/Customer.php 21
ERROR - 2018-02-01 15:07:50 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-02-01 15:10:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 15:11:05 --> 404 Page Not Found: Dashboard/pages
ERROR - 2018-02-01 15:38:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 15
ERROR - 2018-02-01 15:38:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 15:40:09 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 21
ERROR - 2018-02-01 15:40:13 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 21
ERROR - 2018-02-01 15:40:15 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/User/UserRepository.php 21
ERROR - 2018-02-01 15:40:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 15:42:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 15:42:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 15:56:15 --> Severity: Error --> Call to a member function getLocked() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 125
ERROR - 2018-02-01 15:56:16 --> Severity: Error --> Call to a member function getLocked() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 125
ERROR - 2018-02-01 15:56:17 --> Severity: Error --> Call to a member function getLocked() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 125
ERROR - 2018-02-01 15:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-01 15:56:20 --> Severity: Error --> Call to a member function getLocked() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 125
ERROR - 2018-02-01 15:57:11 --> Severity: Error --> Call to a member function getLocked() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 126
ERROR - 2018-02-01 15:59:22 --> Severity: Notice --> Undefined variable: e /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 52
ERROR - 2018-02-01 15:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-01 16:00:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:34:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:46:38 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 44
ERROR - 2018-02-01 16:46:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:47:15 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 44
ERROR - 2018-02-01 16:53:41 --> Severity: Notice --> Undefined variable: accont /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 50
ERROR - 2018-02-01 16:53:41 --> Severity: Error --> Call to undefined method CI_Output::set_content_header() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-01 16:53:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:53:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:53:44 --> Severity: Notice --> Undefined variable: accont /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 50
ERROR - 2018-02-01 16:53:44 --> Severity: Error --> Call to undefined method CI_Output::set_content_header() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-01 16:54:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:54:02 --> Severity: Error --> Call to undefined method CI_Output::set_content_header() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-01 16:54:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:54:18 --> Severity: Error --> Call to undefined method CI_Output::set_output_header() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-01 16:54:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:54:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:56:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:56:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:56:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:57:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:57:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:57:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:58:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:58:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 16:58:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 16:59:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:06:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 17:06:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:10:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:14:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:14:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 17:14:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 17:14:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:14:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:15:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:15:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:16:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:17:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:19:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 17:19:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:19:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 17:19:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:21:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:26:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:27:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:27:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:28:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 17:58:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 18:51:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 18:51:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 18:52:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 18:58:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:01:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:02:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:02:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:04:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-01 19:04:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:05:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:05:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:06:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:06:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-01 19:07:33 --> 404 Page Not Found: Assets/private

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-16 10:52:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:53:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:53:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:53:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:53:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:53:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:53:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:53:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:55:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:56:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:56:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:56:08 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:57:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:57:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:58:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:58:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 10:58:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:58:47 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:58:50 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:59:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 10:59:11 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:59:26 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:59:31 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 10:59:38 --> 404 Page Not Found: Private/AccountSatementController/getSbAccountStatements
ERROR - 2018-02-16 11:10:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:11:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:11:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 11:11:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:12:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:12:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 11:12:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:29:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:29:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 11:29:37 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 136
ERROR - 2018-02-16 11:29:49 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 139
ERROR - 2018-02-16 11:30:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:30:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 11:30:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:31:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:31:29 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 135
ERROR - 2018-02-16 11:31:32 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 135
ERROR - 2018-02-16 11:31:37 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 135
ERROR - 2018-02-16 11:31:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 11:31:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 12:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-16 12:01:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 12:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-16 12:58:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 12:58:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 12:58:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 12:58:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:03:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:03:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:06:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:08:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:08:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:09:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:09:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:10:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:10:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:10:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:10:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:11:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:11:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:11:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:12:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:13:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:13:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:14:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:15:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:15:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:15:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:18:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:18:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:21:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:21:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:22:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:22:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:22:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:23:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:23:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:24:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:24:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:27:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:29:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:31:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:32:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:32:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:34:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:34:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 13:34:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:34:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 13:34:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 13:34:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-16 14:28:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:28:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 14:28:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:34:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 14:35:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:35:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:37:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:38:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:42:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 14:42:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:42:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:42:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:01 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 271
ERROR - 2018-02-16 14:50:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:05 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 271
ERROR - 2018-02-16 14:50:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:35 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 271
ERROR - 2018-02-16 14:50:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:50:47 --> Severity: Parsing Error --> syntax error, unexpected 'user' (T_STRING), expecting '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 271
ERROR - 2018-02-16 14:51:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:51:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:53:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:54:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:54:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:55:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:57:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 14:57:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 14:57:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 15:01:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:17:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 15:17:42 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 255
ERROR - 2018-02-16 15:17:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:17:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 15:17:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:17:46 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 255
ERROR - 2018-02-16 15:17:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 15:17:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:19:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:25:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:25:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:25:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:25:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 15:26:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:26:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:26:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:27:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:27:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:38:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:38:34 --> Severity: Notice --> Undefined variable: customer_id /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 130
ERROR - 2018-02-16 15:38:34 --> Severity: Error --> Call to undefined method AccountSatementController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 140
ERROR - 2018-02-16 15:38:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:38:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:39:00 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 137
ERROR - 2018-02-16 15:39:00 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 137
ERROR - 2018-02-16 15:39:00 --> Severity: Error --> Call to undefined method AccountSatementController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 140
ERROR - 2018-02-16 15:39:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:39:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:39:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:39:58 --> Severity: Error --> Call to undefined method AccountSatementController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 140
ERROR - 2018-02-16 15:41:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:42:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:42:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:44:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:44:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:44:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:45:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:47:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:47:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:48:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 15:48:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-16 16:31:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 16:58:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 17:10:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 17:11:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 17:13:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-16 23:33:58 --> 404 Page Not Found: Assets/private

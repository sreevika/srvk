<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-23 09:38:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 09:45:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 09:58:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 09:58:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 10:01:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 10:01:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 10:01:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 10:02:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 10:57:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 10:57:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:05:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:05:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 11:06:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:07:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 11:08:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 11:08:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:08:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 11:09:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:10:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 11:24:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 12:26:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 12:26:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 12:29:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:32:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:37:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:37:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 12:42:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:42:54 --> Severity: Notice --> Undefined index: ACCTYPE /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 268
ERROR - 2018-02-23 12:44:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 12:44:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:45:01 --> Severity: Notice --> Undefined index: benAccType /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 190
ERROR - 2018-02-23 12:45:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:45:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:46:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 12:54:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 15:22:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 15:25:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 15:25:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 15:25:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-23 15:25:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 15:32:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-23 16:50:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

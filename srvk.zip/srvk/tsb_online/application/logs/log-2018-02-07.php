<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-07 09:56:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 09:57:08 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:57:08 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:57:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 09:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 09:57:22 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:57:22 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:57:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 09:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 09:59:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 09:59:45 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:59:45 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 09:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 09:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 10:01:26 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 10:01:26 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 10:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 10:01:41 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 10:01:41 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-07 10:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 10:06:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-07 10:07:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-07 10:07:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:08:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:08:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:08:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:13:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:13:30 --> Severity: Notice --> Undefined property: BeneficiaryController::$post /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 249
ERROR - 2018-02-07 10:13:30 --> Severity: Error --> Call to a member function input() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 249
ERROR - 2018-02-07 10:13:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:13:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 10:13:35 --> Severity: Notice --> Undefined property: BeneficiaryController::$post /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 249
ERROR - 2018-02-07 10:13:35 --> Severity: Error --> Call to a member function input() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 249
ERROR - 2018-02-07 10:14:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 10:20:21 --> Severity: Notice --> Undefined offset: 0 /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 138
ERROR - 2018-02-07 10:25:01 --> Severity: Notice --> Undefined variable: result1 /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 143
ERROR - 2018-02-07 10:27:03 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 138
ERROR - 2018-02-07 10:27:03 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 138
ERROR - 2018-02-07 10:27:03 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 143
ERROR - 2018-02-07 10:31:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 10:32:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 10:32:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:42:30 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 265
ERROR - 2018-02-07 10:42:31 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 265
ERROR - 2018-02-07 10:42:39 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 265
ERROR - 2018-02-07 10:42:41 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 265
ERROR - 2018-02-07 10:42:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:42:46 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 265
ERROR - 2018-02-07 10:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 10:45:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:46:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:46:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:48:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:48:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 10:49:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:01:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:01:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-07 11:01:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-07 11:01:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:01:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-07 11:02:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:02:14 --> Severity: Notice --> Undefined variable: intrabank_beneficiary /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 62
ERROR - 2018-02-07 11:02:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:03:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:04:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:06:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:09:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 11:09:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:13:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 11:43:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 11:47:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 11:50:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:51:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:51:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:51:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:52:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:52:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:52:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:52:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 11:52:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:27:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:27:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:27:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:28:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:28:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:28:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:34:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:34:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:34:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:35:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:36:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:36:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:36:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:43:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:43:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:43:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:44:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:44:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:48:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:48:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:50:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:50:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:52:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:52:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:52:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:52:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:54:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:54:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:54:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:57:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 12:57:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:58:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:58:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 12:58:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:00:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:01:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:01:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:03:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:04:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:04:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:04:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:04:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:05:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:05:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:05:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:07:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:07:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:07:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:08:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:08:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:08:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:09:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:09:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 13:09:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:09:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:09:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:10:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:11:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:11:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 13:11:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:11:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 13:11:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:12:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:12:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:12:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:12:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:13:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 13:13:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:00:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:23:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:35:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:37:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:37:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:37:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:37:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:37:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:38:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:38:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:39:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:40:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:40:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:49:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:51:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:51:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:51:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:53:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:53:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:53:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 14:53:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 14:54:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:05:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:06:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:06:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:06:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:06:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:06:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:06:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:07:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:07:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:07:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:07:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:07:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:07:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:07:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:07:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:10:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:10:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:10:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:11:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:11:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:11:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:11:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:11:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:11:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:12:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:12:30 --> Severity: Warning --> array_pop() expects parameter 1 to be array, object given /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 211
ERROR - 2018-02-07 15:12:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:12:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:13:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:13:34 --> Severity: Warning --> array_pop() expects parameter 1 to be array, object given /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 211
ERROR - 2018-02-07 15:13:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:13:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:14:13 --> Severity: Warning --> array_pop() expects parameter 1 to be array, object given /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 212
ERROR - 2018-02-07 15:14:15 --> Severity: Warning --> array_pop() expects parameter 1 to be array, object given /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 212
ERROR - 2018-02-07 15:16:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:17:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:17:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:17:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:18:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:20:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:21:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:21:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:21:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:21:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:21:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:25:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:26:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:26:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:26:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:26:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:31:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:42:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:42:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:47:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 15:47:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:48:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 15:48:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 15:48:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:54:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:55:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:55:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:56:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:57:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 15:57:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 18:11:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 18:11:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 18:15:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 18:15:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 18:15:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-07 18:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:31:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 18:31:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:31:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:32:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:32:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:32:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:33:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:52:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 18:53:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 18:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:03:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 19:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:05:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:05:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:06:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:23:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:24:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:24:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:25:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:25:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:25:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:36:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 19:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-07 22:39:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 22:39:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 22:41:31 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-02-07 22:42:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 22:42:54 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-02-07 22:44:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 22:44:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-07 22:44:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

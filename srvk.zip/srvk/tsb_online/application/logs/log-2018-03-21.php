<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-21 10:57:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 11:00:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:05:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 11:13:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:54:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 11:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 11:54:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 11:54:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:54:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 11:54:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 11:54:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:54:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:55:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 11:55:15 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING) /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 294
ERROR - 2018-03-21 11:55:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:00:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:05:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:10:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:28:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:30:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 12:50:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:57:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 12:57:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 12:57:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 13:02:38 --> Severity: Notice --> Undefined index: max_otp_per_day /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 43
ERROR - 2018-03-21 13:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 13:47:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 13:47:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 13:47:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 13:54:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:02:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:02:43 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 383
ERROR - 2018-03-21 14:03:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:03:08 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 427
ERROR - 2018-03-21 14:03:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:03:19 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 427
ERROR - 2018-03-21 14:03:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:03:36 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 427
ERROR - 2018-03-21 14:04:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:05:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:05:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:11:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:27:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 14:28:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:34:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:34:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 14:39:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:42:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:44:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:51:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 14:59:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 15:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 17:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 17:59:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 18:02:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 18:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 18:02:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 18:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 18:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-21 18:02:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 18:02:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-21 18:03:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 18:04:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-21 18:05:10 --> 404 Page Not Found: Assets/css

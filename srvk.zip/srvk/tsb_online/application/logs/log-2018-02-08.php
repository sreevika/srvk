<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-08 09:56:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 09:56:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 10:11:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:11:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:12:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:18:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 10:18:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:18:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:19:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:21:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 10:28:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 10:28:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 10:29:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 10:30:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:38:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 11:46:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:46:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:47:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:53:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:53:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:53:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:53:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 11:53:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:55:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 11:55:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 11:55:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:04:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:04:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:05:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:05:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:06:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:06:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:10:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:10:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:10:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:10:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:10:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:19:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:19:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:20:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:20:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:20:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:20:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:21:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:25:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:25:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:26:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:26:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:29:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:30:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:31:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:31:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:31:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:31:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:33:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:34:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:45:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:45:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:45:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:48:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:48:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:50:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:50:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:51:16 --> Could not find the language line "form_validation_"
ERROR - 2018-02-08 12:57:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 12:57:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:57:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 12:58:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:01:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:01:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:02:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:02:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:03:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:03:23 --> Severity: Error --> Call to undefined function post() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 130
ERROR - 2018-02-08 13:03:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 13:03:38 --> Severity: Error --> Call to undefined function post() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 130
ERROR - 2018-02-08 13:04:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:11:10 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 182
ERROR - 2018-02-08 15:11:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 15:11:14 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 182
ERROR - 2018-02-08 15:11:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 15:11:16 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 182
ERROR - 2018-02-08 15:11:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:11:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:11:25 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 182
ERROR - 2018-02-08 15:13:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:13:00 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 189
ERROR - 2018-02-08 15:13:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:13:50 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 189
ERROR - 2018-02-08 15:18:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:18:07 --> Severity: Compile Error --> Can't use function return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 189
ERROR - 2018-02-08 15:19:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:19:10 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 200
ERROR - 2018-02-08 15:19:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:19:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 200
ERROR - 2018-02-08 15:19:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:19:43 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 233
ERROR - 2018-02-08 15:20:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:35:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:35:44 --> Severity: Notice --> Undefined variable: createFromFormat /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 131
ERROR - 2018-02-08 15:35:44 --> Severity: Error --> Function name must be a string /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 131
ERROR - 2018-02-08 15:37:01 --> Severity: Error --> Call to undefined function DateInterval() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 144
ERROR - 2018-02-08 15:37:09 --> Severity: Error --> Call to undefined function DateInterval() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 144
ERROR - 2018-02-08 15:40:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 15:40:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:40:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 15:40:38 --> Severity: Error --> Call to undefined function DateInterval() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 144
ERROR - 2018-02-08 17:01:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 17:01:37 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 298
ERROR - 2018-02-08 17:02:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 178
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 178
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 205
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 205
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:02:31 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 205
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 205
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:03:40 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 260
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined index: LEDGER_BAL /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 216
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:05:22 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 229
ERROR - 2018-02-08 17:07:00 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:00 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined offset: 0 /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 236
ERROR - 2018-02-08 17:07:44 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:07:44 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined offset: 0 /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 236
ERROR - 2018-02-08 17:08:16 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:16 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined index: TRANSACTION_LIMIT /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 236
ERROR - 2018-02-08 17:08:34 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:08:34 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 261
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:36 --> Severity: Notice --> Undefined variable: benf_id /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 262
ERROR - 2018-02-08 17:11:56 --> Severity: Notice --> Undefined index: opt /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 295
ERROR - 2018-02-08 17:11:56 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 150
ERROR - 2018-02-08 17:12:19 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 150
ERROR - 2018-02-08 17:13:13 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 150
ERROR - 2018-02-08 17:13:15 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 183
ERROR - 2018-02-08 17:20:58 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:22:24 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:22:52 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:23:22 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:24:19 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:26:30 --> Severity: Compile Error --> Can't use method return value in write context /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 294
ERROR - 2018-02-08 17:27:24 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 298
ERROR - 2018-02-08 17:27:57 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 295
ERROR - 2018-02-08 17:29:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 18:19:06 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getuserId() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 163
ERROR - 2018-02-08 18:19:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-08 18:19:10 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getuserId() /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 163
ERROR - 2018-02-08 18:19:42 --> Severity: Notice --> Undefined variable: trans_password /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 285
ERROR - 2018-02-08 18:19:42 --> Could not find the language line "form_validation_check_transaction_password"
ERROR - 2018-02-08 18:19:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 18:20:11 --> Could not find the language line "form_validation_check_transaction_password"
ERROR - 2018-02-08 18:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:29:22 --> 404 Page Not Found: Assets/js
ERROR - 2018-02-08 18:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:31:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:53:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:54:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:54:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:56:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:56:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 18:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:02:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 19:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:04:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:05:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:05:29 --> Could not find the language line "form_validation_match"
ERROR - 2018-02-08 19:07:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 19:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:08:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:08:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:13:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 19:18:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-08 19:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:31:09 --> 404 Page Not Found: Find-user-name/index
ERROR - 2018-02-08 19:32:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-08 19:32:52 --> 404 Page Not Found: Find-usernam/index
ERROR - 2018-02-08 19:33:05 --> 404 Page Not Found: Assets/css

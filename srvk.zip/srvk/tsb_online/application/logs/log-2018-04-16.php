<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 16:43:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 16:44:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 16:50:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 16:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-16 16:51:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 16:52:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-16 16:52:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:38:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 17:39:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-16 17:39:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 17:39:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 17:39:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:39:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 17:39:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-16 17:39:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:46:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-16 17:46:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:47:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:47:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 17:49:56 --> Severity: Error --> Call to undefined method Fund_transaction_model::coretisRows() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 322
ERROR - 2018-04-16 18:09:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-16 18:10:29 --> 404 Page Not Found: Assets/private

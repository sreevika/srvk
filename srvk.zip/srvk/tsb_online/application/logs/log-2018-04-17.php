<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-17 10:15:39 --> 404 Page Not Found: Private/DashboardController/user
ERROR - 2018-04-17 10:15:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-17 10:41:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:42:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:42:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:42:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:44:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:44:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-17 10:45:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:46:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:51:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 10:54:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-17 11:54:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-17 11:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-17 11:56:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-17 11:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-17 16:55:34 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369

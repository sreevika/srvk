<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-17 10:11:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 10:15:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:36:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 10:36:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:36:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:36:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:37:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:57:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 10:57:59 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 127
ERROR - 2018-02-17 10:58:03 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 127
ERROR - 2018-02-17 10:58:04 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 127
ERROR - 2018-02-17 10:58:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:58:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:58:06 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 127
ERROR - 2018-02-17 10:58:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 10:58:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:01:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:01:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:01:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:01:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 11:01:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:01:26 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 162
ERROR - 2018-02-17 11:08:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:13:01 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 139
ERROR - 2018-02-17 11:13:01 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 139
ERROR - 2018-02-17 11:13:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:13:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:37:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 11:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 11:37:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:37:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:37:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:38:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:46:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 11:52:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 11:54:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 11:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 11:56:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 12:01:09 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 177
ERROR - 2018-02-17 12:02:28 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 177
ERROR - 2018-02-17 12:02:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 12:04:34 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 177
ERROR - 2018-02-17 12:08:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 12:26:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 13:05:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 13:05:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 13:06:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 13:06:38 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 177
ERROR - 2018-02-17 13:10:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 13:16:30 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/views/private/pages/account_statement/index.php 93
ERROR - 2018-02-17 13:16:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/views/private/pages/account_statement/index.php 93
ERROR - 2018-02-17 13:17:22 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/views/private/pages/account_statement/index.php 93
ERROR - 2018-02-17 13:17:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 13:17:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 13:17:28 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/views/private/pages/account_statement/index.php 93
ERROR - 2018-02-17 13:17:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 13:17:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/views/private/pages/account_statement/index.php 93
ERROR - 2018-02-17 13:18:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 14:31:55 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 290
ERROR - 2018-02-17 14:31:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 14:31:59 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 290
ERROR - 2018-02-17 14:32:26 --> Severity: Notice --> Undefined variable: output /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 44
ERROR - 2018-02-17 14:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 14:35:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 14:35:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 14:36:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 16:35:57 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-02-17 16:40:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 16:40:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 16:40:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 16:55:52 --> Severity: Notice --> Undefined variable: mobNoHind /home/webmast/htdocs/tsb_online/application/views/private/pages/beneficiary_details/intra_bank_beneficiary.php 71
ERROR - 2018-02-17 17:01:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:02:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:05:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:06:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:07:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 17:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:08:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:08:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:09:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:13:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 17:16:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 17:18:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:29:41 --> 404 Page Not Found: Assets/img
ERROR - 2018-02-17 17:32:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:32:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:33:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:34:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:39:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-17 17:47:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:47:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:48:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:51:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:53:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:53:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:55:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 17:58:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-17 18:02:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 23:26:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 23:27:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-17 23:27:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

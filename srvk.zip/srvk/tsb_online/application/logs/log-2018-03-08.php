<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-08 10:44:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 10:53:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 10:55:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 10:58:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 11:22:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 11:22:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 11:23:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 11:23:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 11:23:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 11:30:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 11:30:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 13:45:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 13:45:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 13:48:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 13:55:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 14:36:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 14:36:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 14:36:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 14:36:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 14:36:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 14:36:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 14:37:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 14:37:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 14:37:52 --> 404 Page Not Found: Private/DashboardController/bootstrap.min.css.map
ERROR - 2018-03-08 14:37:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-08 16:43:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-08 21:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 21:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:40:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:40:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:41:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-08 22:43:25 --> 404 Page Not Found: Assets/css

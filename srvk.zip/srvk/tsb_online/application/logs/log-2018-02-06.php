<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 09:35:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 09:35:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 09:35:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 10:00:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 10:01:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 10:02:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 10:03:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 10:03:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 10:04:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 12:09:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 13:55:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 13:58:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 13:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 14:02:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 14:03:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 14:04:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 14:04:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 14:09:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 14:24:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 14:33:48 --> Severity: Parsing Error --> syntax error, unexpected '(' /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 29
ERROR - 2018-02-06 14:33:49 --> Severity: Parsing Error --> syntax error, unexpected '(' /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 29
ERROR - 2018-02-06 14:34:21 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 102
ERROR - 2018-02-06 14:35:09 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 138
ERROR - 2018-02-06 14:35:19 --> Severity: Parsing Error --> syntax error, unexpected '$session' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 158
ERROR - 2018-02-06 14:35:32 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 225
ERROR - 2018-02-06 14:35:47 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 298
ERROR - 2018-02-06 14:35:56 --> Severity: Notice --> Object of class DashboardController could not be converted to int /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 41
ERROR - 2018-02-06 14:35:56 --> Severity: Error --> Call to a member function load() on a non-object /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 42
ERROR - 2018-02-06 14:36:39 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 42
ERROR - 2018-02-06 14:37:59 --> Severity: Notice --> Object of class DashboardController could not be converted to int /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 41
ERROR - 2018-02-06 14:37:59 --> Severity: Error --> Call to a member function load() on a non-object /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 42
ERROR - 2018-02-06 14:38:29 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 42
ERROR - 2018-02-06 14:38:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php:42) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-06 14:38:55 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 43
ERROR - 2018-02-06 14:39:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php:42) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-06 14:39:18 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 43
ERROR - 2018-02-06 14:39:21 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 42
ERROR - 2018-02-06 14:39:43 --> Severity: Error --> Call to undefined method DashboardController::load() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 43
ERROR - 2018-02-06 14:40:39 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:41:08 --> Severity: Notice --> Undefined property: DashboardController::$otpmanaget /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:41:12 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:42:16 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:42:26 --> Severity: Notice --> Undefined property: DashboardController::$libray /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:42:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 174
ERROR - 2018-02-06 14:42:52 --> Unable to load the requested class: Otpmanager
ERROR - 2018-02-06 14:43:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:09:34 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 15:10:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:10:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:20:55 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:20:55 --> Severity: Error --> Call to a member function setData() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:20:56 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:20:56 --> Severity: Error --> Call to a member function setData() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:21:18 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:21:18 --> Severity: Error --> Call to a member function setData() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 178
ERROR - 2018-02-06 15:21:31 --> Severity: Notice --> Undefined property: DashboardController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 179
ERROR - 2018-02-06 15:21:31 --> Severity: Error --> Call to a member function setUsername() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 179
ERROR - 2018-02-06 15:22:21 --> Severity: Error --> Call to undefined method OtpManager::createMessagesend() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 226
ERROR - 2018-02-06 15:22:47 --> Severity: Notice --> Undefined variable: otp /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 144
ERROR - 2018-02-06 15:22:47 --> Severity: Notice --> Undefined variable: false /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 228
ERROR - 2018-02-06 15:22:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:23:10 --> Severity: Notice --> Undefined variable: false /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 228
ERROR - 2018-02-06 15:26:10 --> Severity: Notice --> Undefined property: OtpManager::$config /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 179
ERROR - 2018-02-06 15:28:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:28:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 15:28:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:28:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:29:58 --> Severity: Error --> Call to undefined method PDOException::getMessge() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 197
ERROR - 2018-02-06 15:30:00 --> Severity: Error --> Call to undefined method PDOException::getMessge() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 197
ERROR - 2018-02-06 15:30:14 --> Severity: Error --> Call to undefined method PDOException::getMessge() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 197
ERROR - 2018-02-06 15:33:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:33:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:33:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:33:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:34:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:34:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:36:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:36:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:36:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 15:37:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:39:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 15:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 15:59:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 16:15:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 16:15:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 16:21:46 --> Severity: Error --> Call to undefined method OtpManager::vefiryOtp() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 155
ERROR - 2018-02-06 16:22:16 --> Severity: Notice --> Undefined variable: opt_setting /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 257
ERROR - 2018-02-06 16:23:13 --> Severity: Notice --> Undefined index: otp_id /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 267
ERROR - 2018-02-06 16:24:57 --> Severity: Notice --> Undefined index: otp_id /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 268
ERROR - 2018-02-06 16:24:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 16:26:21 --> Severity: Notice --> Undefined index: otp /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 266
ERROR - 2018-02-06 16:26:21 --> Severity: Notice --> Undefined index: otp_id /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 267
ERROR - 2018-02-06 16:26:21 --> Severity: Notice --> Undefined index: success_msg /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 268
ERROR - 2018-02-06 16:38:44 --> Severity: Error --> Call to undefined method DashboardController::account_model() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 16:39:35 --> Severity: Error --> Call to undefined method OtpManager::getData() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 16:39:42 --> Severity: Error --> Call to undefined method DashboardController::account_model() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 16:40:14 --> Severity: Error --> Call to undefined method DashboardController::account_model() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 16:40:15 --> Severity: Error --> Call to undefined method DashboardController::account_model() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 157
ERROR - 2018-02-06 16:40:43 --> 404 Page Not Found: Private/DashboardController/ver
ERROR - 2018-02-06 16:41:07 --> Severity: Error --> Call to undefined method OtpManager::getData() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 158
ERROR - 2018-02-06 16:42:04 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'CI_Loader' does not have a method 'test' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 158
ERROR - 2018-02-06 16:43:38 --> Severity: Parsing Error --> syntax error, unexpected ',' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 158
ERROR - 2018-02-06 16:44:37 --> Severity: Error --> Call to undefined function var_dum() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 300
ERROR - 2018-02-06 16:54:43 --> Severity: Error --> Call to undefined function getOptUsage() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 55
ERROR - 2018-02-06 16:54:43 --> Severity: Error --> Call to undefined function getOptUsage() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 55
ERROR - 2018-02-06 16:57:48 --> Severity: Error --> Call to undefined method PDOException::getMessge() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 222
ERROR - 2018-02-06 17:00:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:00:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:00:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:00:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:03:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:03:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:03:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:08:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:08:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:08:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:09:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:09:11 --> Severity: Notice --> Undefined variable: cutomer_id /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 29
ERROR - 2018-02-06 17:09:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:09:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:10:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:13:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:14:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:14:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:15:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:15:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:15:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:15:41 --> 404 Page Not Found: AddNewIntraBeneficiary/index
ERROR - 2018-02-06 17:15:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:15:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:16:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:17:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:17:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:17:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:17:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:18:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 88
ERROR - 2018-02-06 17:18:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:18:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:18:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:18:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:18:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:18:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:19:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-06 17:20:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:20:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:20:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:21:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:21:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:22:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:22:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:22:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:23:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:23:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:32:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:32:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-06 17:32:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:51:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 17:51:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 18:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:06:51 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 231
ERROR - 2018-02-06 19:07:33 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 221
ERROR - 2018-02-06 19:07:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:07:39 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 221
ERROR - 2018-02-06 19:07:42 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 221
ERROR - 2018-02-06 19:08:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:08:00 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 223
ERROR - 2018-02-06 19:08:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:08:47 --> Severity: Warning --> Missing argument 2 for BeneficiaryController::{closure}(), called in /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php on line 730 and defined /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:08:47 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 215
ERROR - 2018-02-06 19:12:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:12:59 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:13:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:13:27 --> Severity: Warning --> Missing argument 2 for BeneficiaryController::{closure}(), called in /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php on line 730 and defined /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:14:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:14:41 --> Severity: Notice --> Undefined variable: trans_password /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 221
ERROR - 2018-02-06 19:14:41 --> Severity: Warning --> Missing argument 2 for BeneficiaryController::{closure}(), called in /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php on line 730 and defined /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:15:05 --> Severity: Warning --> Missing argument 2 for BeneficiaryController::{closure}(), called in /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php on line 730 and defined /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:16:44 --> Severity: Warning --> Missing argument 2 for BeneficiaryController::{closure}(), called in /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php on line 730 and defined /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 208
ERROR - 2018-02-06 19:16:44 --> Could not find the language line "form_validation_check_valid_trans_password[3]"
ERROR - 2018-02-06 19:18:12 --> Severity: Parsing Error --> syntax error, unexpected 'usr' (T_STRING), expecting '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 209
ERROR - 2018-02-06 19:18:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:18:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:18:43 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 215
ERROR - 2018-02-06 19:19:19 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 215
ERROR - 2018-02-06 19:19:49 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 215
ERROR - 2018-02-06 19:20:41 --> Severity: Runtime Notice --> Non-static method TsbApp\Authentication\AuthenticationService::vefiryTransactionPassword() should not be called statically, assuming $this from incompatible context /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 215
ERROR - 2018-02-06 19:21:41 --> Could not find the language line "form_validation_check_valid_trans_password"
ERROR - 2018-02-06 19:30:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:30:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:36:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-06 19:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-06 19:44:21 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:45:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-06 19:45:45 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-06 19:45:47 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:45:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-02-06 19:45:48 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:46:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 23
ERROR - 2018-02-06 19:46:07 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:46:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/webmast/htdocs/tsb_online/application/config/hooks.php 23
ERROR - 2018-02-06 19:46:10 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 186
ERROR - 2018-02-06 19:47:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:48:01 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:01 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:48:09 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:09 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:48:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:48:20 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:20 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:48:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-06 19:49:05 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:49:05 --> Severity: Notice --> Undefined index: status /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 100
ERROR - 2018-02-06 19:49:05 --> 404 Page Not Found: Assets/css

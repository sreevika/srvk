<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-12 10:36:22 --> 404 Page Not Found: Home/index
ERROR - 2018-02-12 10:36:30 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 106
ERROR - 2018-02-12 10:37:06 --> Severity: error --> Exception: SoapClient::SoapClient(): Invalid parameters /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 89
ERROR - 2018-02-12 10:37:06 --> Severity: Error --> SoapClient::SoapClient(): Invalid parameters /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 89
ERROR - 2018-02-12 10:37:49 --> Severity: Notice --> Undefined variable: number /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 94
ERROR - 2018-02-12 10:42:06 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 95
ERROR - 2018-02-12 10:42:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 10:44:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 11:30:31 --> Severity: Parsing Error --> syntax error, unexpected ''Otp'' (T_CONSTANT_ENCAPSED_STRING) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 212
ERROR - 2018-02-12 11:50:51 --> Severity: Parsing Error --> syntax error, unexpected '$account_details' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 199
ERROR - 2018-02-12 12:00:29 --> Severity: Parsing Error --> syntax error, unexpected '$params' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/User_model.php 52
ERROR - 2018-02-12 12:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:00:47 --> Severity: Parsing Error --> syntax error, unexpected '$params' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/User_model.php 52
ERROR - 2018-02-12 12:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:06:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:07:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:07:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:19:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:24:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:24:40 --> Severity: Error --> Call to undefined function id_array() /home/webmast/htdocs/tsb_online/application/helpers/app_helper.php 102
ERROR - 2018-02-12 12:25:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:26:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:26:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:26:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 12:42:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 12:59:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 13:00:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 13:01:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 13:01:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 13:04:29 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 23
ERROR - 2018-02-12 13:55:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 13:56:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 13:56:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 13:56:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 14:01:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 14:09:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 14:09:39 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 23
ERROR - 2018-02-12 14:10:17 --> Severity: Parsing Error --> syntax error, unexpected '$query' (T_VARIABLE), expecting function (T_FUNCTION) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 416
ERROR - 2018-02-12 14:14:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 14:14:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 14:20:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 14:21:42 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\fundTransferManager' not found /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 16
ERROR - 2018-02-12 14:22:36 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 47
ERROR - 2018-02-12 14:22:50 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 65
ERROR - 2018-02-12 14:23:13 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 65
ERROR - 2018-02-12 14:23:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 221
ERROR - 2018-02-12 14:24:00 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 305
ERROR - 2018-02-12 14:24:13 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\FundTransferManager' not found /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 16
ERROR - 2018-02-12 14:24:38 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\FundTransferManager' not found /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 16
ERROR - 2018-02-12 14:25:40 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\FundTransferManager' not found /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 16
ERROR - 2018-02-12 14:27:12 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 22
ERROR - 2018-02-12 14:27:12 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 25
ERROR - 2018-02-12 14:27:47 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 25
ERROR - 2018-02-12 14:28:09 --> Severity: Warning --> Illegal string offset 'SCHEDULE_ID' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 98
ERROR - 2018-02-12 14:28:09 --> Severity: Notice --> Undefined variable: max_schedule_id /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 31
ERROR - 2018-02-12 14:30:10 --> Severity: Notice --> Undefined variable: max_schedule_id /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 31
ERROR - 2018-02-12 14:30:50 --> Severity: Error --> Call to undefined method Fund_transaction_model::scheduleFundTransfer() /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 39
ERROR - 2018-02-12 14:32:38 --> Severity: Notice --> Undefined index: transDate /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 136
ERROR - 2018-02-12 14:32:38 --> Severity: Notice --> Undefined index: userName /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 138
ERROR - 2018-02-12 14:32:38 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:36:49 --> Severity: Notice --> Undefined index: transDate /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 136
ERROR - 2018-02-12 14:36:49 --> Severity: Notice --> Undefined index: userName /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 138
ERROR - 2018-02-12 14:36:49 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:38:47 --> Severity: Notice --> Undefined index: userName /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 138
ERROR - 2018-02-12 14:38:47 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:38:47 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 63
ERROR - 2018-02-12 14:39:49 --> Severity: Notice --> Undefined index: userName /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 138
ERROR - 2018-02-12 14:39:49 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:40:05 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:40:36 --> Severity: Notice --> Undefined index: option /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 140
ERROR - 2018-02-12 14:44:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 14:48:14 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 62
ERROR - 2018-02-12 14:48:56 --> Severity: Notice --> Undefined index: LEDGER_BAL /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 82
ERROR - 2018-02-12 14:48:56 --> Severity: Notice --> Undefined index: ACCTYPE_CATEGORY_CODE /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 83
ERROR - 2018-02-12 14:48:56 --> Severity: Notice --> Undefined index: SCRT_BAL /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 84
ERROR - 2018-02-12 14:48:56 --> Severity: Notice --> Undefined property: TsbApp\Domain\FundTransfer\FundTransferManager::$beneficiary_model /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 86
ERROR - 2018-02-12 14:48:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/system/core/Exceptions.php:271) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-12 14:48:56 --> Severity: Error --> Call to a member function getBeneficiaryDetails() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 86
ERROR - 2018-02-12 14:49:43 --> Severity: Notice --> Undefined property: TsbApp\Domain\FundTransfer\FundTransferManager::$beneficiary_model /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 86
ERROR - 2018-02-12 14:49:43 --> Severity: Error --> Call to a member function getBeneficiaryDetails() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 86
ERROR - 2018-02-12 14:50:46 --> Severity: Notice --> Undefined index: ACCNO /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 90
ERROR - 2018-02-12 14:50:46 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 125
ERROR - 2018-02-12 14:51:57 --> Severity: Notice --> Undefined index: ACCNO /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 91
ERROR - 2018-02-12 14:51:57 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 126
ERROR - 2018-02-12 14:52:21 --> Severity: Error --> Class 'TsbApp\Domain\FundTransfer\DateTime' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 125
ERROR - 2018-02-12 14:52:34 --> Severity: Warning --> array_pop() expects parameter 1 to be array, string given /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 378
ERROR - 2018-02-12 14:52:34 --> Severity: Notice --> Undefined variable: sb_transaction_type /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 132
ERROR - 2018-02-12 14:55:07 --> Severity: Notice --> Undefined variable: sb_transaction_type /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 133
ERROR - 2018-02-12 14:55:38 --> Severity: Notice --> Undefined index: currentTimetamp /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 197
ERROR - 2018-02-12 14:55:38 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 14:56:01 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 14:58:33 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 14:58:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 15:05:53 --> Severity: Notice --> Undefined index: benfaccNo /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 254
ERROR - 2018-02-12 15:10:23 --> Severity: Notice --> Undefined index: finyearCode /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 319
ERROR - 2018-02-12 15:10:23 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 15:12:30 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 15:12:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 15:13:14 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 330
ERROR - 2018-02-12 16:01:32 --> Severity: Parsing Error --> syntax error, unexpected '$params' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 181
ERROR - 2018-02-12 16:14:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 16:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 16:50:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 16:50:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 16:57:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 17:03:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-12 17:32:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 17:32:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-12 17:38:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:40:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:41:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-12 17:43:54 --> 404 Page Not Found: Assets/css

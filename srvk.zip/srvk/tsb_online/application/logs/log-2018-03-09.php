<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-09 09:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:17:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:19:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 09:20:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 09:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:29:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 09:36:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:36:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:36:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:37:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:37:45 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 655
ERROR - 2018-03-09 09:38:15 --> Could not find the language line "form_validation_isValidTransKey"
ERROR - 2018-03-09 09:38:15 --> Could not find the language line "form_validation_matchs"
ERROR - 2018-03-09 09:39:15 --> Could not find the language line "form_validation_matchs"
ERROR - 2018-03-09 09:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:42:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:42:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:42:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 09:43:04 --> Could not find the language line "form_validation_differs[loginNewPassword"
ERROR - 2018-03-09 09:59:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 10:10:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 10:11:07 --> Severity: Notice --> Undefined variable: user_id /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 175
ERROR - 2018-03-09 10:11:07 --> Severity: Error --> Call to a member function getTransactionKey() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 236
ERROR - 2018-03-09 10:11:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 10:11:10 --> Severity: Notice --> Undefined variable: user_id /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 175
ERROR - 2018-03-09 10:11:10 --> Severity: Error --> Call to a member function getTransactionKey() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 236
ERROR - 2018-03-09 10:12:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 10:13:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 10:16:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 10:20:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 10:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 10:23:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 10:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 10:39:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 10:44:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 10:44:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 10:48:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 10:49:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 10:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 11:13:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:14:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:14:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:15:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:16:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:16:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:16:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:16:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:17:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:17:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:18:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:18:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:18:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:18:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:23:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:23:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:23:44 --> 404 Page Not Found: Private/RejectionClearController/(:any)
ERROR - 2018-03-09 11:26:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:28:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:32:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:40:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:40:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 11:41:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:43:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 11:50:14 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:50:31 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:51:20 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:53:29 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:27 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:27 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:36 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:36 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:36 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:36 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:37 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:37 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:54:45 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:56:11 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 11:56:37 --> Severity: Notice --> Undefined variable: lastLoginTime /home/webmast/htdocs/tsb_online/application/views/private/pages/dashboard/home.php 52
ERROR - 2018-03-09 12:11:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:12:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:12:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 12:12:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:12:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 12:12:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 12:12:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:16:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:16:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 12:16:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:16:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:26:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:29:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 12:29:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:36:42 --> Could not find the language line "form_validation_checkEligibleToAddAsIntraBenf"
ERROR - 2018-03-09 12:37:44 --> Could not find the language line "form_validation_checkEligibleToAddAsIntraBenf"
ERROR - 2018-03-09 12:46:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 12:47:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:43:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 13:44:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:44:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:44:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:44:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:44:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:44:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:44:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:44:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:44:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:46:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:46:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:46:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:46:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:46:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:46:34 --> 404 Page Not Found: RejectionClearBeneficiaryCheck/index
ERROR - 2018-03-09 13:50:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:50:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 13:51:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:52:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 13:57:05 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 13:57:14 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 13:59:04 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:03:34 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:03:43 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:06:36 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:06:38 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:10:26 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:10:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:10:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:10:52 --> Severity: Error --> Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 149
ERROR - 2018-03-09 14:12:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:12:18 --> Severity: Notice --> Undefined variable: is_added /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 132
ERROR - 2018-03-09 14:12:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:13:21 --> Severity: Notice --> Undefined variable: is_added /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 132
ERROR - 2018-03-09 14:13:24 --> Severity: Notice --> Undefined variable: is_added /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 132
ERROR - 2018-03-09 14:14:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:14:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:14:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:14:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:14:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:14:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:14:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:15:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:15:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 14:15:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:18:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:18:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:18:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:18:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:18:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:18:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:20:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:20:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:20:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:20:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:21:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:23:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:29:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:31:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:31:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:34:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:34:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:35:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:35:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:35:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:35:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:45:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 14:45:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:47:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:49:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:50:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:50:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:52:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 14:59:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:00:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:00:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:05:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:05:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:06:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:06:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:06:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:06:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:06:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:11:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:12:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:12:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:12:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:13:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:13:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:14:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:14:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:16:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:21:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:21:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:21:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:22:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:22:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:22:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:25:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:25:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:26:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:28:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:32:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:32:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:33:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:33:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:34:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:34:17 --> Severity: Error --> Call to undefined method Beneficiary_model::rejectionClearUpdateBeneficiary() /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 233
ERROR - 2018-03-09 15:34:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:34:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:36:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:36:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:37:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:37:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:40:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:40:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:40:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:40:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:45:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 15:45:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:46:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 15:48:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:15:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:16:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:19:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 16:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 16:19:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:19:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 16:19:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:25:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:26:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:27:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:30:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:30:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 16:32:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:32:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:34:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 16:34:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 17:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-09 17:01:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 17:08:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 17:15:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 17:15:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 17:15:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 17:51:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-09 17:52:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 17:54:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 17:54:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-09 18:00:24 --> 404 Page Not Found: Assets/private

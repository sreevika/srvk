<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-14 09:35:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:37:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:41:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:43:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:43:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:43:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:44:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:44:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:45:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:50:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:50:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:51:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:53:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:53:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:53:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:53:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:53:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:53:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:53:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 09:53:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:55:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 09:57:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 10:34:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 10:36:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 10:36:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 11:34:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 11:42:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-14 12:39:43 --> Severity: Notice --> Undefined property: FundTransferController::$fund_transaction_model /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 418
ERROR - 2018-03-14 12:39:43 --> Severity: Error --> Call to a member function getFundTransactionHistrory() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 418
ERROR - 2018-03-14 12:39:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:39:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:39:49 --> Severity: Notice --> Undefined property: FundTransferController::$fund_transaction_model /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 418
ERROR - 2018-03-14 12:39:49 --> Severity: Error --> Call to a member function getFundTransactionHistrory() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 418
ERROR - 2018-03-14 12:41:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:42:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:42:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:42:50 --> Severity: Notice --> Undefined variable: account /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 433
ERROR - 2018-03-14 12:43:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:43:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 12:43:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 14:56:09 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-14 14:56:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-14 15:02:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:03:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:03:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:03:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:03:13 --> Severity: Notice --> Undefined variable: ekuber_trans_id_collection /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 438
ERROR - 2018-03-14 15:03:13 --> Severity: Notice --> Undefined variable: coretis_tsb_to_bank_trans /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 441
ERROR - 2018-03-14 15:03:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:03:41 --> Severity: Error --> Call to a member function fetchAll() on a non-object /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 721
ERROR - 2018-03-14 15:05:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:05:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:08:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:08:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:08:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:08:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:34:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-14 15:35:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:35:08 --> Severity: Parsing Error --> syntax error, unexpected ',' /home/webmast/htdocs/tsb_online/application/controllers/Private/FundTransferController.php 453
ERROR - 2018-03-14 15:36:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:39:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:39:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 15:40:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:41:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:45:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 15:45:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:21:26 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-14 17:39:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:39:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:42:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:46:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:46:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:46:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:48:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:48:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:48:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 17:48:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:48:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:56:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:58:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 17:59:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 18:00:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 18:01:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-14 18:18:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 20:18:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-14 20:18:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

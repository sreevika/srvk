<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-29 10:13:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 10:15:21 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:15:21 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:20:24 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:20:24 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:20:52 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:20:52 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:21:12 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:21:12 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:33:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:33:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:34:11 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:34:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:34:39 --> Severity: Warning --> preg_match(): No ending matching delimiter ')' found /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 10:35:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:35:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:36:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:37:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:38:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:38:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:44:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:44:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 10:44:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 10:44:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:02:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:03:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:09:00 --> Could not find the language line "form_validation_valid_dob"
ERROR - 2018-01-29 11:09:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 11:09:23 --> Could not find the language line "form_validation_valid_fromDate"
ERROR - 2018-01-29 11:10:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:10:57 --> Severity: Warning --> Illegal string offset 'month' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 21
ERROR - 2018-01-29 11:10:57 --> Severity: Notice --> Undefined variable: day /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 21
ERROR - 2018-01-29 11:10:57 --> Severity: Notice --> Undefined variable: day /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 21
ERROR - 2018-01-29 11:10:57 --> Could not find the language line "form_validation_valid_dob"
ERROR - 2018-01-29 11:12:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 11:12:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:12:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:26 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 1073
ERROR - 2018-01-29 11:14:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:14:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:15:43 --> Could not find the language line "form_validation_valid_date"
ERROR - 2018-01-29 11:16:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:16:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:17:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:17:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:18:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:18:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 11:18:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 11:18:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:19:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:19:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:19:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:20:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:21:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:21:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:21:21 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-01-29 11:21:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:21:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:21:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:22:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:22:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:22:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:22:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:23:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:23:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:24:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:24:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:24:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:24:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:25:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:25:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:25:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:27:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:27:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:27:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:29:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:29:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:29:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:29:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:30:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:32:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:32:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 11:32:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:33:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:36:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:36:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:36:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:36:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:38:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:38:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:38:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:38:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:39:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:39:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:40:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:40:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:41:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:41:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:41:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:42:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:44:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:44:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:45:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:46:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:46:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:48:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:48:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 11:48:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:48:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:49:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:49:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:49:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:51:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:51:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:53:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:53:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:54:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:56:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:56:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:57:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:57:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:57:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:57:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:57:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:58:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:58:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:58:29 --> 404 Page Not Found: Dashboard/nulldashboard
ERROR - 2018-01-29 11:59:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 11:59:13 --> 404 Page Not Found: Dashboard/nulldashboard
ERROR - 2018-01-29 12:01:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:01:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:01:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:01:18 --> 404 Page Not Found: Dashboard/home
ERROR - 2018-01-29 12:01:49 --> 404 Page Not Found: Dashboard/home
ERROR - 2018-01-29 12:01:52 --> 404 Page Not Found: Dashboard/home
ERROR - 2018-01-29 12:02:07 --> 404 Page Not Found: Dashboard/home
ERROR - 2018-01-29 12:02:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:02:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:03:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:03:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:03:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:03:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 12:03:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:04:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:06:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:06:12 --> Severity: Notice --> Undefined variable: data /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 18
ERROR - 2018-01-29 12:06:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:06:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:06:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 19
ERROR - 2018-01-29 12:10:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:10:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 19
ERROR - 2018-01-29 12:10:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:11:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:11:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:11:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:12:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:12:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:13:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:13:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:13:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:13:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:14:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:14:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:17:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:19:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:22:43 --> 404 Page Not Found: Private/DashboardController/account-statement
ERROR - 2018-01-29 12:22:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:22:48 --> 404 Page Not Found: Private/DashboardController/account-statement
ERROR - 2018-01-29 12:22:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:22:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:23:00 --> 404 Page Not Found: Private/DashboardController/account-statement
ERROR - 2018-01-29 12:23:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:23:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:24:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:25:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:32:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:32:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:34:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:36:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 12:37:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:37:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:37:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:37:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:38:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:39:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:39:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:39:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:39:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:40:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:50:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:53:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 12:59:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:05:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:05:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:07:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:07:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:07:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:07:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:08:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:08:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:09:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:41:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:43:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:44:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:46:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:46:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:46:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 13:46:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 13:47:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 14:02:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:05:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:09:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 15:16:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 15:17:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 15:17:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 15:18:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 15:18:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:18:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:33:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:54:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 15:54:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-29 16:00:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 16:00:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 16:00:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 16:39:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 16:39:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 16:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-01-29 16:39:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 16:39:35 --> 404 Page Not Found: Dashboard/pages
ERROR - 2018-01-29 16:41:22 --> 404 Page Not Found: Private/DashboardController/lo
ERROR - 2018-01-29 17:52:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-29 17:53:55 --> 404 Page Not Found: Assets/private

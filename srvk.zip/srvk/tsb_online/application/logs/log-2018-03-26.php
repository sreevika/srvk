<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-26 09:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:31:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 09:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:32:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 09:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:33:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:35:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:36:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:37:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:44:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:45:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:46:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:47:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:49:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:58:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 09:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 09:58:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 10:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:06:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 10:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:09:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 10:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:15:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 10:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-26 10:20:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-26 10:37:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-24 10:29:08 --> Severity: Notice --> Undefined variable: header_login_button /home/webmast/htdocs/tsb_online/application/views/public/inc/header.php 22
ERROR - 2018-02-24 10:36:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:13:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:28:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:39:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:44:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:44:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:48:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 11:49:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:49:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:49:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:49:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 11:51:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 12:10:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 231
ERROR - 2018-02-24 12:11:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 247
ERROR - 2018-02-24 12:37:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 12:42:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 12:42:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 12:48:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 13:06:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:00:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:05:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:10:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:18:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:32:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 14:38:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:46:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 14:52:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 14:53:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 14:53:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:53:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 14:58:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:01:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 15:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 15:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 15:18:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:18:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:19:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:20:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:20:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:24:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:30:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 15:31:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 15:33:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 15:38:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:40:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:59:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 15:59:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 15:59:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 16:00:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 16:35:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 16:36:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-24 17:02:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:02:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:05:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 17:05:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:05:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:06:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:06:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:07:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:07:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 17:08:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-24 17:09:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:09:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:09:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:15:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:17:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:17:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:17:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:18:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:18:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:23:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:23:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:30:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:30:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:30:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:39:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:39:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:39:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:39:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:40:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:40:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:41:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:41:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:41:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:41:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:43:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:43:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:48:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 17:49:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 18:03:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-24 18:03:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

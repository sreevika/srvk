<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-14 09:57:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 10:09:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 10:26:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 10:40:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 10:43:12 --> Severity: Warning --> Illegal string offset 'SEQNO' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 55
ERROR - 2018-02-14 10:43:12 --> Severity: Warning --> Illegal string offset 'SEQNO' /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 55
ERROR - 2018-02-14 10:43:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 10:57:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 10:59:40 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-14 10:59:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 11:00:24 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-02-14 11:24:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 11:25:51 --> Severity: Notice --> Undefined property: TsbApp\Domain\FundTransfer\FundTransferManager::$beneficiary_model /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 96
ERROR - 2018-02-14 11:25:51 --> Severity: Error --> Call to a member function getBankDetailsFromIfsc() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 96
ERROR - 2018-02-14 11:26:34 --> Severity: Warning --> array_pop() expects parameter 1 to be array, string given /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 361
ERROR - 2018-02-14 11:26:34 --> Unable to connect to the database
ERROR - 2018-02-14 11:26:34 --> Severity: Error --> Call to a member function setAttribute() on a non-object /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 25
ERROR - 2018-02-14 12:04:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 12:05:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 12:06:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:06:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:06:52 --> Unable to connect to the database
ERROR - 2018-02-14 12:06:52 --> Severity: Error --> Call to a member function setAttribute() on a non-object /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 25
ERROR - 2018-02-14 12:07:44 --> Unable to connect to the database
ERROR - 2018-02-14 12:07:44 --> Severity: Error --> Call to a member function setAttribute() on a non-object /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 26
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Undefined index: current_date /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 502
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Undefined index: current_date /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 503
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Undefined index: benfifsc /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 506
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Undefined variable: thid /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:08:11 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:08:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/system/core/Exceptions.php:271) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-14 12:08:11 --> Severity: Error --> Call to a member function commit() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:09:51 --> Severity: Notice --> Undefined index: benfifsc /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 506
ERROR - 2018-02-14 12:09:51 --> Severity: Notice --> Undefined variable: thid /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:09:51 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:09:51 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:09:51 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:09:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/system/core/Exceptions.php:271) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-14 12:09:51 --> Severity: Error --> Call to a member function commit() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:10:04 --> Severity: Notice --> Undefined variable: thid /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:10:04 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:10:04 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:10:04 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:10:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/system/core/Exceptions.php:271) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-02-14 12:10:04 --> Severity: Error --> Call to a member function commit() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Domain/FundTransfer/FundTransferManager.php 330
ERROR - 2018-02-14 12:20:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 12:21:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:37:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:39:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 12:41:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:41:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:46:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:46:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 12:46:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:50:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:50:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 12:50:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 13:16:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 13:16:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 13:16:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 13:17:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 13:18:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 14:17:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:29:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:29:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:32:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:33:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:33:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:35:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:35:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:36:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:36:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:46:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 14:46:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:47:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 14:54:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 15:24:42 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:42 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:42 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:44 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:44 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:44 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:24:45 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:02 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:02 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:02 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:05 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:06 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:07 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:24 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:24 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:24 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:25 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:26 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:27 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:27 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:27 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:47 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:47 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:47 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:48 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:49 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:49 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:25:49 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55
ERROR - 2018-02-14 15:49:48 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 69
ERROR - 2018-02-14 16:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:19:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:20:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:27:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:27:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:28:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:28:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:29:33 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 54
ERROR - 2018-02-14 17:29:33 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 54
ERROR - 2018-02-14 17:29:33 --> Severity: Error --> Call to a member function getChangePassword() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 54
ERROR - 2018-02-14 17:29:56 --> Severity: Notice --> Undefined variable: thia /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 57
ERROR - 2018-02-14 17:29:56 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 57
ERROR - 2018-02-14 17:29:56 --> Severity: Error --> Call to a member function getTransactionKey() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 57
ERROR - 2018-02-14 17:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:33:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 17:33:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-14 17:37:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 17:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 17:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 18:00:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-14 19:04:03 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\User::getId() /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 35
ERROR - 2018-02-14 19:04:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-14 19:04:07 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\User::getId() /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 35
ERROR - 2018-02-14 19:06:45 --> 404 Page Not Found: Assets/private

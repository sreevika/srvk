<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-26 10:33:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-26 10:45:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:49:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:53:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:53:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-26 10:53:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:53:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-26 10:53:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:55:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:57:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-26 10:57:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 10:58:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 11:01:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-26 13:34:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-26 14:44:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-27 14:08:57 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 25
ERROR - 2018-01-27 14:12:05 --> Severity: Notice --> Undefined variable: param /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 327
ERROR - 2018-01-27 14:12:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-27 14:21:43 --> Severity: Error --> Call to undefined function implod() /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 312
ERROR - 2018-01-27 14:22:38 --> EXECUTE PREPARE STATEMENT : SELECT A.*, B.DESCRIPTION FROM V_SBPASSBOOK_ONLINE_PAID A LEFT JOIN SB_TRANSTYPE B ON A.SB_TRANSTYPE=B.SB_TRANSTYPE
               WHERE ACCNO=? AND DT_ACC_DATE BETWEEN ? AND  ? 
                order by counter_date desc,BPO_INIT_SYSDATE desc ,bpo_init_date desc,daily_seqno desc PARAMS : 701120100000883, 2017-01-01, 2017-01-31
ERROR - 2018-01-27 16:01:25 --> Severity: Parsing Error --> syntax error, unexpected '[' /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 54
ERROR - 2018-01-27 16:18:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:18:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:18:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:18:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:18:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:18:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:19:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:19:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:19:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:20:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:20:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:20:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:21:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:21:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:21:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:21:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:22:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:44:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:45:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:46:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:46:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:47:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:48:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:48:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:49:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:49:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:49:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:51:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:52:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:53:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:53:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:55:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:56:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:57:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:57:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:57:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:58:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:58:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:58:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-27 16:59:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:59:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-27 16:59:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 16:59:40 --> Severity: Notice --> Undefined variable: startDate /home/webmast/htdocs/tsb_online/application/models/Account_model.php 61
ERROR - 2018-01-27 16:59:40 --> Severity: Notice --> Undefined variable: endDate /home/webmast/htdocs/tsb_online/application/models/Account_model.php 62
ERROR - 2018-01-27 17:00:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 17:00:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 17:00:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 17:01:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 17:01:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 18:14:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-27 18:14:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

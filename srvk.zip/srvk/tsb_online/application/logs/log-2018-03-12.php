<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-12 10:02:25 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 896
ERROR - 2018-03-12 10:04:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:14:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:15:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:15:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:16:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:31:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:31:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:31:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:32:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:34:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:36:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:39:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:39:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 10:44:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:54:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:54:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:54:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:56:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 10:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 10:58:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:04:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 11:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 11:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 11:13:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:14:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:18:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:20:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:20:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:21:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:25:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:25:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:36:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:36:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:40:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:40:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:40:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:40:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:42:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:42:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 11:42:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:43:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:43:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:44:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 11:53:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 12:14:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:14:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:15:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:15:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:15:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:15:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:15:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:15:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:15:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:18:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:18:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:18:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:19:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:20:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:21:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:21:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:21:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:23:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:24:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:26:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:27:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:31:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 12:31:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:34:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 12:38:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 12:52:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:35:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:38:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 13:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:38:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 13:41:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:45:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:45:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:45:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:46:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 13:46:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:50:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:50:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 13:50:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:50:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:55:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:56:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 13:57:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 14:05:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 14:13:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:20:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:26:50 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-03-12 15:26:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:26:52 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-03-12 15:27:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:27:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:27:33 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-03-12 15:27:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:30:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:30:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:30:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:31:33 --> 404 Page Not Found: Private/DashboardController/index2.html
ERROR - 2018-03-12 15:31:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:32:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:33:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:33:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:33:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:33:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:33:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:33:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:33:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:33:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:33:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:34:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:34:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:34:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:36:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:37:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:37:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:37:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:37:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:44:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:45:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:45:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:49:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:49:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:49:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:49:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:53:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:53:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 15:54:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:54:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:56:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:56:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:56:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:56:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:57:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 15:58:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:05:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 16:05:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:08:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 16:08:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:08:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:09:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 16:09:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:10:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:10:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 16:28:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 16:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:30:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:47:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 16:55:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 16:58:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:12:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:19:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:19:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:26:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 17:26:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-12 17:26:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:27:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:34:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:34:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:44:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:46:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:46:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:49:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:49:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:49:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-12 17:49:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:49:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:50:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:51:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:51:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:52:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-12 17:52:23 --> 404 Page Not Found: Assets/private

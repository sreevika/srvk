<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-19 10:37:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:38:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:38:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:43:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:43:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:43:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:46:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:46:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:52:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:54:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:54:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 10:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 10:54:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 13:01:28 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-19 13:01:28 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-19 13:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 13:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 13:01:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 13:04:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 13:04:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 13:05:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 13:56:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 13:57:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:11:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 14:33:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 14:33:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 14:33:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:34:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:35:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:39:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:39:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:39:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:39:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:40:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:42:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:43:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:47:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 14:48:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 14:49:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:49:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:50:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:50:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:50:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:52:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 14:53:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:16:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 15:16:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:18:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:18:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:19:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:21:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:36:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-19 15:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-19 15:59:11 --> 404 Page Not Found: Testotp/index
ERROR - 2018-03-19 15:59:26 --> 404 Page Not Found: Homecontroller/testotp
ERROR - 2018-03-19 15:59:36 --> Severity: Error --> Call to undefined method CI_Loader::setconfig() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:00:22 --> Severity: Error --> Call to undefined method CI_Loader::setConfig() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:01:07 --> Severity: Error --> Call to undefined method CI_Loader::setConfig() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:02:55 --> Severity: Notice --> Undefined property: HomeController::$otpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:02:55 --> Severity: Error --> Call to a member function setConfig() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:04:14 --> Severity: Notice --> Undefined property: HomeController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:04:14 --> Severity: Error --> Call to a member function setConfig() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:04:36 --> Severity: Notice --> Undefined property: HomeController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:04:36 --> Severity: Error --> Call to a member function setConfig() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:05:08 --> Severity: Notice --> Undefined property: HomeController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1022
ERROR - 2018-03-19 16:06:36 --> Severity: Notice --> Undefined property: HomeController::$otpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1028
ERROR - 2018-03-19 16:06:36 --> Severity: Error --> Call to a member function processOtp() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1028
ERROR - 2018-03-19 16:06:51 --> Severity: Notice --> Undefined index: opt_debug_value /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 62
ERROR - 2018-03-19 16:09:09 --> Severity: Notice --> Undefined index: opt_debug_value /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 62
ERROR - 2018-03-19 16:09:38 --> Severity: Notice --> Undefined index: opt_debug_value /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 63
ERROR - 2018-03-19 16:11:22 --> Severity: Notice --> Undefined property: HomeController::$otpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1033
ERROR - 2018-03-19 16:11:22 --> Severity: Error --> Call to a member function verifyOtp() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1033
ERROR - 2018-03-19 16:47:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-19 16:49:47 --> Severity: Notice --> Undefined property: HomeController::$OtpManager /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1034
ERROR - 2018-03-19 16:49:47 --> Severity: Error --> Call to a member function getError() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1034
ERROR - 2018-03-19 16:54:25 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:55:38 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:55:38 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:56:01 --> Severity: 4096 --> Object of class HomeController could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:56:01 --> Severity: Notice --> Object of class HomeController to string conversion /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:56:01 --> Severity: Notice --> Undefined property: HomeController::$Object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:56:01 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 16:56:01 --> Severity: Error --> Call to a member function getModelName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:21 --> Severity: 4096 --> Object of class HomeController could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:21 --> Severity: Notice --> Object of class HomeController to string conversion /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:21 --> Severity: Notice --> Undefined property: HomeController::$Object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:21 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:21 --> Severity: Error --> Call to a member function getModelName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:05:48 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1039
ERROR - 2018-03-19 17:08:14 --> Severity: Warning --> call_user_func() expects parameter 1 to be a valid callback, first array member is not a valid class name or object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1042
ERROR - 2018-03-19 17:08:38 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, first array member is not a valid class name or object /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1042
ERROR - 2018-03-19 17:10:34 --> Severity: Error --> Cannot access empty property /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1043
ERROR - 2018-03-19 17:10:49 --> 404 Page Not Found: HomeController/sendOtp

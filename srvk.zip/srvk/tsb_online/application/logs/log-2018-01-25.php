<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-25 15:31:07 --> Severity: error --> Exception: SQLSTATE[42601]: Syntax error: -104 [IBM][CLI Driver][DB2/LINUXX8664] SQL0104N  An unexpected token "END-OF-STATEMENT" was found following "sdfsdf sdfsdf".  Expected tokens may include:  "JOIN <joined_table>".  SQLSTATE=42601
 (SQLExecute[-104] at /home/PDO_IBM-1.3.4/ibm_statement.c:1136) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 210
ERROR - 2018-01-25 15:31:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 15:31:10 --> Severity: error --> Exception: SQLSTATE[42601]: Syntax error: -104 [IBM][CLI Driver][DB2/LINUXX8664] SQL0104N  An unexpected token "END-OF-STATEMENT" was found following "sdfsdf sdfsdf".  Expected tokens may include:  "JOIN <joined_table>".  SQLSTATE=42601
 (SQLExecute[-104] at /home/PDO_IBM-1.3.4/ibm_statement.c:1136) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 210
ERROR - 2018-01-25 15:32:08 --> Severity: Notice --> Undefined variable: result /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 25
ERROR - 2018-01-25 15:32:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 15:32:29 --> Severity: Notice --> Undefined variable: result /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 25
ERROR - 2018-01-25 15:34:31 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:34:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 15:35:04 --> Severity: Parsing Error --> syntax error, unexpected '$stmt' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 202
ERROR - 2018-01-25 15:35:37 --> Severity: Parsing Error --> syntax error, unexpected '$stmt' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 202
ERROR - 2018-01-25 15:35:38 --> Severity: Parsing Error --> syntax error, unexpected '$stmt' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 202
ERROR - 2018-01-25 15:35:39 --> Severity: Parsing Error --> syntax error, unexpected '$stmt' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 202
ERROR - 2018-01-25 15:35:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 15:37:25 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:37:26 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:37:40 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:38:26 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:38:27 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:38:49 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:39:13 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 26
ERROR - 2018-01-25 15:39:57 --> Severity: error --> Exception: hai there /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 201
ERROR - 2018-01-25 15:39:57 --> Severity: error --> Exception: hai there /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 201
ERROR - 2018-01-25 15:39:58 --> Severity: error --> Exception: hai there /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 201
ERROR - 2018-01-25 15:41:39 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting catch (T_CATCH) /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 25
ERROR - 2018-01-25 15:41:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 17:00:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 17:17:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 17:17:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 17:18:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 17:22:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 17:34:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-01-25 17:44:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 17:45:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-01-25 19:06:59 --> Severity: Parsing Error --> syntax error, unexpected 'getOnlineUser' (T_STRING), expecting variable (T_VARIABLE) or '$' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 18
ERROR - 2018-01-25 19:10:44 --> Severity: Error --> Class 'TsbApp\Domain\OnlineUserFactory' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 18

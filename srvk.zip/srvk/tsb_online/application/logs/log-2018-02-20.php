<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-20 00:13:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 00:17:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 09:18:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:18:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:31:00 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php 20
ERROR - 2018-02-20 09:31:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:31:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:31:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:46:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:46:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:48:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:48:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:56:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:57:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:57:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:58:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:58:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:58:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 09:58:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 10:07:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:07:04 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php 19
ERROR - 2018-02-20 10:07:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:07:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:07:09 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php 19
ERROR - 2018-02-20 10:07:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:14:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:15:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:17:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:17:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:18:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:19:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:26:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:26:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:28:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:29:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:32:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:32:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:32:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:33:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:34:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:34:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 10:34:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:35:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:37:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:42:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:42:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 10:42:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:44:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:44:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:44:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:45:01 --> Severity: Warning --> Missing argument 1 for Beneficiary_model::getActivatedCustomerInterBankBeneficiarys(), called in /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php on line 442 and defined /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 85
ERROR - 2018-02-20 10:45:01 --> Severity: Notice --> Undefined variable: customer_id /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 86
ERROR - 2018-02-20 10:45:01 --> Severity: Notice --> Undefined variable: beneficiaries /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 448
ERROR - 2018-02-20 10:45:01 --> Severity: Error --> Call to undefined method CI_Output::set_content() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 453
ERROR - 2018-02-20 10:48:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:48:51 --> Severity: Notice --> Undefined variable: beneficiaries /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 446
ERROR - 2018-02-20 10:48:51 --> Severity: Error --> Call to undefined method CI_Output::set_content() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 451
ERROR - 2018-02-20 10:49:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:49:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:49:37 --> Severity: Error --> Call to undefined method CI_Output::set_content() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 466
ERROR - 2018-02-20 10:50:09 --> Severity: Error --> Call to undefined method CI_Output::set_content() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 466
ERROR - 2018-02-20 10:52:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:53:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:53:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:53:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 10:55:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:13:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:13:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:15:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 171
ERROR - 2018-02-20 11:42:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:42:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 171
ERROR - 2018-02-20 11:42:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:43:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:43:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:44:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:44:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:44:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:46:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 11:52:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 11:52:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 11:52:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:03:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:03:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:03:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:03:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:03:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:03:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:04:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:04:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:05:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:06:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:06:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:20:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:20:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:20:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:20:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:20:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:20:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:24:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:38:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:39:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:39:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 12:58:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 12:58:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:00:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:00:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:01:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:02:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:02:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:02:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:03:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:05:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:41:55 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 135
ERROR - 2018-02-20 13:42:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 13:42:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:42:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:46:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:46:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:49:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:49:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:50:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:50:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:50:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:52:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:52:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:52:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:53:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:53:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:57:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:57:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:57:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 13:58:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 13:59:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:01:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 14:02:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:04:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:10:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:12:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:12:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:12:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:13:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:13:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:13:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:13:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:14:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:14:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:14:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:14:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:15:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:15:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:37:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:37:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:49:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 14:49:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:15:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:17:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 15:17:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:17:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:18:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:18:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:25:14 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 100
ERROR - 2018-02-20 15:25:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:25:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:26:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:26:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 15:26:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:27:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:30:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:30:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 15:30:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:31:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:31:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:32:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:33:06 --> Could not find the language line "form_validation_match"
ERROR - 2018-02-20 15:33:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:33:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 15:33:57 --> Could not find the language line "form_validation_match"
ERROR - 2018-02-20 15:34:45 --> Could not find the language line "form_validation_match"
ERROR - 2018-02-20 15:36:13 --> Could not find the language line "form_validation_matchs"
ERROR - 2018-02-20 16:15:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:15:57 --> Severity: Error --> Class 'TsbApp\Authenticaion\AuthenticationService' not found /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 78
ERROR - 2018-02-20 16:16:19 --> Severity: Notice --> Undefined variable: trans_password /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 81
ERROR - 2018-02-20 16:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 16:53:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:54:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 16:55:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:57:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:59:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:59:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:59:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 16:59:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:02:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:02:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 17:04:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:06:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:06:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:10:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 17:11:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:11:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:11:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:22:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:24:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:26:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 17:26:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 17:34:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-20 17:35:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:31:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 177
ERROR - 2018-02-20 18:32:04 --> Severity: Parsing Error --> syntax error, unexpected '$new_transaction_passwordsswor' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 201
ERROR - 2018-02-20 18:32:28 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 207
ERROR - 2018-02-20 18:33:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:33:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:33:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:33:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:34:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:35:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:36:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:36:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:37:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:37:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:37:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:38:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:38:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:38:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:38:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:22 --> Could not find the language line "form_validation_isValidNewTransactionPassword"
ERROR - 2018-02-20 18:39:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:39:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:40:08 --> Could not find the language line "form_validation_isValidNewTransactionPassword"
ERROR - 2018-02-20 18:40:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:43:59 --> Could not find the language line "form_validation_isValidNewTransactionPassword"
ERROR - 2018-02-20 18:44:40 --> Severity: Error --> Call to undefined function TsbApp\Authentication\AuthenticationService\newTransactionKey() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 221
ERROR - 2018-02-20 18:46:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 18:46:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 19:00:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-20 19:01:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-20 19:01:52 --> 404 Page Not Found: Assets/private

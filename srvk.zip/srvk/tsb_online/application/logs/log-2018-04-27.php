<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-27 12:08:39 --> 404 Page Not Found: Assets/css

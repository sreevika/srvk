<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-25 11:56:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-25 11:56:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-25 11:56:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-25 11:57:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-25 11:58:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-25 12:14:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-25 12:14:29 --> 404 Page Not Found: Assets/private

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 10:10:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:10:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:10:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:10:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:10:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:40:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 10:40:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 10:40:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 10:41:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 10:41:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 10:48:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 10:48:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 11:00:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 11:00:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 11:37:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 11:37:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:39:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 11:40:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:40:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:40:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:42:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:43:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:44:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:48:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:49:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 11:51:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 12:01:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 12:01:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 12:24:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 12:37:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 12:38:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 14:56:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 14:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 14:56:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 14:56:23 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php 21
ERROR - 2018-02-19 14:56:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 14:56:44 --> Severity: error --> Exception: /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php exists, but doesn't declare class Salary_instruction_model /home/webmast/htdocs/tsb_online/system/core/Loader.php 340
ERROR - 2018-02-19 15:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 15:21:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:21:35 --> Severity: error --> Exception: /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php exists, but doesn't declare class Salary_instruction_model /home/webmast/htdocs/tsb_online/system/core/Loader.php 340
ERROR - 2018-02-19 15:22:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:22:14 --> Severity: Error --> Call to undefined method Salary_instruction_model::excecute_query() /home/webmast/htdocs/tsb_online/application/models/PeriodicScheduledPayment/Salary_instruction_model.php 25
ERROR - 2018-02-19 15:22:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:22:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:23:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 15:24:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:25:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:26:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:26:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:35:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 15:35:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 15:57:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:57:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:58:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 15:59:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:00:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:00:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:00:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:01:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:03:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:04:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:04:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:04:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:05:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:08:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:45:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:51:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 16:51:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:51:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 16:51:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 16:51:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:51:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:52:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:52:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:53:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 16:53:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 16:53:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 17:52:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 17:53:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 17:53:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 17:53:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 17:53:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:09:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:10:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:36:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 18:36:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:36:47 --> Severity: Notice --> Undefined variable: beneficiary_trans_type /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 92
ERROR - 2018-02-19 18:36:47 --> Severity: Notice --> Undefined variable: beneficiary_trans_type /home/webmast/htdocs/tsb_online/application/controllers/Private/PeriodicScheduledPayment.php 96
ERROR - 2018-02-19 18:37:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:38:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:39:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 18:39:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 19:04:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:11:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:11:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:15:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:15:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-19 19:15:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-19 19:17:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:19:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-19 19:24:26 --> 404 Page Not Found: Assets/private

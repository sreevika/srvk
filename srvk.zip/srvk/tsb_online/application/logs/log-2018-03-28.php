<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-28 17:50:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

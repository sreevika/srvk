<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-16 11:05:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:05:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:05:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 11:05:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:13:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:16:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:16:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:17:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:17:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:19:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:19:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 11:24:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 12:04:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 12:32:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 12:32:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 12:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:37:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:38:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:38:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 12:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:38:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-16 12:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:45:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-16 12:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-16 12:45:17 --> 404 Page Not Found: Assets/private

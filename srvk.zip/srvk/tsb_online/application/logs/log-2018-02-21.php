<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-21 09:55:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 10:02:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 10:05:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 10:12:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 10:19:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 10:29:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 10:30:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 11:19:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 11:23:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 11:25:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 11:26:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 11:27:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 11:36:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 11:36:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 11:36:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 11:39:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 11:56:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:03:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:03:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:21:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:21:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:21:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:22:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:22:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:23:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:23:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:25:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:25:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:25:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:26:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:26:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:26:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:28:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:28:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:29:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:29:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:29:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:39:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:39:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:39:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:40:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:40:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:40:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:43:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:43:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:43:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:43:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:43:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:43:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:44:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:44:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 12:44:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:44:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:44:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:55:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 12:55:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 13:07:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 13:07:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 13:07:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 13:08:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 13:11:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 13:11:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 13:11:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 14:12:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 14:23:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:23:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:28:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:30:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:30:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:31:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:31:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:31:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:31:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:31:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:35:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:35:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:36:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:36:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:36:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:38:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 14:41:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 15:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 15:06:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 15:06:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 15:06:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 15:06:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 15:16:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 15:23:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 15:23:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:04:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:05:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:05:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:08:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:09:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:09:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:09:36 --> 404 Page Not Found: Benficiary/updateIntraBankBeneficiary
ERROR - 2018-02-21 17:10:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:10:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:10:07 --> Severity: Error --> Call to undefined method Beneficiary_model::updateBeneficiary() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 335
ERROR - 2018-02-21 17:18:58 --> Severity: Notice --> Undefined index: transType /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 223
ERROR - 2018-02-21 17:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:19:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:19:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:20:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:20:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:20:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:20:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:20:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:20:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:20:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:21:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:21:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:21:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:22:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:22:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:22:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:22:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:23:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:23:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:25:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-21 17:25:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:26:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:27:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:29:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:29:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:30:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:30:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:30:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:31:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:31:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:31:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:33:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:34:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:34:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 17:34:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:36:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:36:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:39:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:39:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:39:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:48:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 17:48:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 18:22:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-21 18:38:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-21 18:40:13 --> 404 Page Not Found: Assets/private

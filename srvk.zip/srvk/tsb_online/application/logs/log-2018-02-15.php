<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-15 09:28:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 09:29:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 12:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 12:49:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 12:49:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 15:44:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 15:44:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 15:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 15:46:18 --> Severity: Error --> Class 'TsbApp\Authentication\Exceptions\PasswordChangeException' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 79
ERROR - 2018-02-15 15:49:13 --> Severity: Error --> Class 'TsbApp\Authentication\Exceptions\PasswordChangeException' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 79
ERROR - 2018-02-15 15:50:13 --> Severity: Error --> Cannot access parent:: when current class scope has no parent /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/Exceptions/PasswordChangeException.php 12
ERROR - 2018-02-15 15:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 15:58:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 15:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 15:59:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:01:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 16:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:04:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:04:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 16:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 16:57:37 --> Severity: Parsing Error --> syntax error, unexpected 'new' (T_NEW) /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 86
ERROR - 2018-02-15 16:59:35 --> Severity: Parsing Error --> syntax error, unexpected '>' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 154
ERROR - 2018-02-15 17:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:00:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 17:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:03:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 17:07:10 --> Severity: Error --> Class 'TsbApp\Authentication\Exceptions\TransactionKeyException' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 82
ERROR - 2018-02-15 17:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:07:13 --> Severity: Error --> Class 'TsbApp\Authentication\Exceptions\TransactionKeyException' not found /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 82
ERROR - 2018-02-15 17:08:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:08:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 17:20:45 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 214
ERROR - 2018-02-15 17:22:08 --> Severity: Notice --> Undefined variable: new_password /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 169
ERROR - 2018-02-15 17:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:22:11 --> Severity: Notice --> Undefined variable: new_password /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 169
ERROR - 2018-02-15 17:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:26:59 --> Severity: Notice --> Undefined variable: username /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 152
ERROR - 2018-02-15 17:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:33:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 17:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:34:10 --> Severity: Notice --> Undefined variable: new_password /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 182
ERROR - 2018-02-15 17:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:34:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 17:34:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 17:34:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 17:35:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 17:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 18:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 18:11:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:14:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 18:14:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 18:15:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 18:19:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 18:21:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:21:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:21:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-15 18:21:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:23:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:23:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:24:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:25:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:25:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:25:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:25:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:26:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-15 18:28:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-15 18:28:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

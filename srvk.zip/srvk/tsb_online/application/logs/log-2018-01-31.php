<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-31 09:36:35 --> Unable to connect to the database
ERROR - 2018-01-31 09:36:36 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:36:44 --> Unable to connect to the database
ERROR - 2018-01-31 09:36:44 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:36:47 --> Unable to connect to the database
ERROR - 2018-01-31 09:36:48 --> Severity: error --> Exception: Call to a member function setAttribute() on boolean /home/db2admin/public_html/tsb_online/application/TsbApp/Util/Database/Database.php 17
ERROR - 2018-01-31 09:36:51 --> Unable to connect to the database
ERROR - 2018-01-31 09:36:51 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:36:56 --> Unable to connect to the database
ERROR - 2018-01-31 09:37:35 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:02 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:25 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:27 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:27 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:28 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:28 --> Severity: Core Warning --> Module 'ibm_db2' already loaded Unknown 0
ERROR - 2018-01-31 09:38:34 --> Severity: error --> Exception: syntax error, unexpected '/', expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) /home/db2admin/public_html/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 47
ERROR - 2018-01-31 10:01:54 --> Severity: error --> Exception: syntax error, unexpected '/', expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) /home/db2admin/public_html/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 47
ERROR - 2018-01-31 10:03:30 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) /home/db2admin/public_html/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 55

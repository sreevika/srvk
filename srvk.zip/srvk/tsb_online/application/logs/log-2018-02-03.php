<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-03 09:31:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:35:58 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:35:58 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:36:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:37:35 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:37:35 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:37:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:38:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:38:29 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:38:29 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:41:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:42:45 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:42:45 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 09:42:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:43:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:46:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:47:00 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:47:00 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:47:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 09:47:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:48:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:48:39 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:48:39 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:48:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:49:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:50:06 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:50:06 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:50:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:50:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:50:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:50:51 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:50:51 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:50:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 09:50:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:51:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:51:45 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:51:45 --> Severity: Error --> Call to a member function getSbAccountSatement() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 168
ERROR - 2018-02-03 09:54:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:54:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 09:57:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 10:05:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:05:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:05:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:05:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:06:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:06:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:07:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:07:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:09:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:09:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:09:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:09:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:11:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:19:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:19:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:20:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:20:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:20:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:21:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:21:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:22:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:22:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:22:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:24:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:24:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:24:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:25:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:25:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:27:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:29:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-03 10:50:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 10:59:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 10:59:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:01:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:01:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:08:01 --> Severity: Notice --> Undefined variable: account_statement /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 170
ERROR - 2018-02-03 11:10:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:10:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:10:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:11:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:12:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:13:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:16:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:16:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:22:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:23:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:27:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:32:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:32:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:32:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:33:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:34:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:34:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:34:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:34:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:40:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:40:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:41:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:41:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:42:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:42:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:43:38 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 248
ERROR - 2018-02-03 11:43:38 --> Severity: Error --> Call to a member function getFdAccountDetails() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 248
ERROR - 2018-02-03 11:43:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:43:45 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 248
ERROR - 2018-02-03 11:43:45 --> Severity: Error --> Call to a member function getFdAccountDetails() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 248
ERROR - 2018-02-03 11:46:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:46:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:51:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:51:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:51:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:51:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:51:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:51:55 --> Severity: Notice --> Undefined property: AccountSatementController::$form_validation /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:51:55 --> Severity: Error --> Call to a member function set_rules() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:52:32 --> Severity: Notice --> Undefined property: AccountSatementController::$form_validation /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:52:32 --> Severity: Error --> Call to a member function set_rules() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:53:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:53:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 11:53:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:53:20 --> Severity: Notice --> Undefined property: AccountSatementController::$form_validation /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:53:20 --> Severity: Error --> Call to a member function set_rules() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 239
ERROR - 2018-02-03 11:53:50 --> Severity: Notice --> Undefined property: AccountSatementController::$Account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 250
ERROR - 2018-02-03 11:53:50 --> Severity: Error --> Call to a member function getFdAccountDetails() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 250
ERROR - 2018-02-03 11:54:16 --> Severity: Notice --> Undefined variable: response /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 317
ERROR - 2018-02-03 11:57:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 11:57:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 12:01:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:02:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:02:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:03:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:03:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:07:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:08:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:09:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:10:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:12:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:13:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:13:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:13:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:13:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:14:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:15:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:17:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 12:19:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 12:19:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 13:52:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 13:54:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 13:55:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 14:58:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 17:25:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 17:40:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:40:45 --> Severity: Notice --> Undefined property: BeneficiaryController::$beneficiary_model /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 61
ERROR - 2018-02-03 17:40:45 --> Severity: Error --> Call to a member function getActivatedCustomerIntraBankBeneficiarys() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 61
ERROR - 2018-02-03 17:40:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:41:05 --> Severity: Notice --> Undefined property: BeneficiaryController::$beneficiary_model /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 61
ERROR - 2018-02-03 17:41:05 --> Severity: Error --> Call to a member function getActivatedCustomerIntraBankBeneficiarys() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 61
ERROR - 2018-02-03 17:41:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:41:41 --> Severity: Parsing Error --> syntax error, unexpected '$e' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 33
ERROR - 2018-02-03 17:42:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:42:12 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 39
ERROR - 2018-02-03 17:42:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:42:29 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 68
ERROR - 2018-02-03 17:42:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:42:56 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 68
ERROR - 2018-02-03 17:43:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:43:12 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 84
ERROR - 2018-02-03 17:43:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:43:29 --> Severity: error --> Exception: /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php exists, but doesn't declare class Beneficiary_model /home/webmast/htdocs/tsb_online/system/core/Loader.php 340
ERROR - 2018-02-03 17:44:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:44:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 17:44:27 --> Severity: Error --> Call to undefined function getCustomerBeneficiarys() /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 48
ERROR - 2018-02-03 17:45:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-03 17:46:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 64
ERROR - 2018-02-03 17:46:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:48:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:50:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:52:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:52:49 --> Severity: Notice --> Undefined property: BeneficiaryController::$baneficiary_model /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 62
ERROR - 2018-02-03 17:52:49 --> Severity: Error --> Call to a member function getFirstError() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 62
ERROR - 2018-02-03 17:52:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:52:56 --> Severity: Notice --> Undefined property: BeneficiaryController::$baneficiary_model /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 62
ERROR - 2018-02-03 17:52:56 --> Severity: Error --> Call to a member function getFirstError() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 62
ERROR - 2018-02-03 17:53:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:54:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:54:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:54:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:57:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-03 17:57:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 17:58:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 18:05:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-03 18:10:21 --> 404 Page Not Found: Assets/private

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-22 09:41:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:05:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:05:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 341
ERROR - 2018-02-22 10:05:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:05:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:06:04 --> Could not find the language line "form_validation_isValidTransKey"
ERROR - 2018-02-22 10:08:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:13:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:13:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:13:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:13:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:13:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:13:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:16:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:16:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:16:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:16:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:09 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:19:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:19:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:19:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:19:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:19:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:20:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:20:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:21:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:21:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:23:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:25:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:26:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:27:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 10:27:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:34:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 10:39:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 12:08:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:11:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:12:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 14:12:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:12:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:23:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:25:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:25:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:39:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:39:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:39:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:41:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:41:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:45:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 14:50:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:52:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:53:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:55:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:55:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:57:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 14:57:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:00:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:00:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:00:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:00:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:00:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:00:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:00:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:00:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:02:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:04:10 --> Severity: Error --> Call to undefined function switch_data_format() /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 227
ERROR - 2018-02-22 15:07:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:07:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:07:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:08:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:08:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:10:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:10:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:10:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:17:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:22:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:24:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:30:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:30:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:31:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:31:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:32:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:32:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:33:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:34:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:36:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:42:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-22 15:48:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:49:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:49:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:52:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:53:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 15:55:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:55:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:59:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 15:59:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 16:00:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:02:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:03:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:03:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:46:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:46:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:46:39 --> Severity: Warning --> Missing argument 1 for MY_Model::execute_query(), called in /home/webmast/htdocs/tsb_online/application/models/Account_model.php on line 238 and defined /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 291
ERROR - 2018-02-22 16:46:39 --> Severity: Notice --> Undefined variable: sql /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 294
ERROR - 2018-02-22 16:46:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:46:42 --> Severity: Warning --> Missing argument 1 for MY_Model::execute_query(), called in /home/webmast/htdocs/tsb_online/application/models/Account_model.php on line 238 and defined /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 291
ERROR - 2018-02-22 16:46:42 --> Severity: Notice --> Undefined variable: sql /home/webmast/htdocs/tsb_online/application/core/MY_Model.php 294
ERROR - 2018-02-22 16:47:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:50:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:50:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:50:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:51:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:56:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 16:58:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 16:58:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 17:08:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 17:09:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 17:09:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-22 17:30:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 17:33:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 18:03:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 18:05:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 18:17:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 18:18:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-22 18:20:29 --> 404 Page Not Found: Assets/private

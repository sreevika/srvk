<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-05 09:30:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 09:30:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-05 10:19:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:27:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 10:27:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:27:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 10:28:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:28:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:31:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:31:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:31:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:31:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:32:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:33:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:34:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:35:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:36:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:37:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:37:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:44:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 10:45:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:23:03 --> Severity: Compile Error --> Cannot use [] for reading /home/webmast/htdocs/tsb_online/application/models/Account_model.php 229
ERROR - 2018-02-05 14:23:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:23:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:23:08 --> Severity: Compile Error --> Cannot use [] for reading /home/webmast/htdocs/tsb_online/application/models/Account_model.php 229
ERROR - 2018-02-05 14:23:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:23:25 --> Severity: Parsing Error --> syntax error, unexpected '$e' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 233
ERROR - 2018-02-05 14:23:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:23:51 --> Severity: Parsing Error --> syntax error, unexpected '$account_details' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 110
ERROR - 2018-02-05 14:24:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:24:11 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting '(' /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 121
ERROR - 2018-02-05 14:24:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:29:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 14:29:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:31:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:31:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 14:40:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 14:43:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-05 15:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-05 15:11:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:11:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:12:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:12:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:14:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:14:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 15:15:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:15:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:16:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:16:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:17:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:17:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:17:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:17:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:18:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:21:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:21:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:21:59 --> Severity: Error --> Call to undefined method CI_Loader::form_validation() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 97
ERROR - 2018-02-05 15:22:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:32:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:33:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:33:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:35:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:36:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:38:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:39:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:39:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:40:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:41:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:42:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:43:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:45:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:48:12 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 227
ERROR - 2018-02-05 15:48:15 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 227
ERROR - 2018-02-05 15:48:21 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 227
ERROR - 2018-02-05 15:48:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 15:52:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 15:55:43 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 139
ERROR - 2018-02-05 16:25:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-05 16:25:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:25:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:26:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:26:47 --> Severity: Notice --> Undefined variable: account_number /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 139
ERROR - 2018-02-05 16:33:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:33:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:35:56 --> Severity: Notice --> Undefined variable: e /home/webmast/htdocs/tsb_online/application/models/Account_model.php 225
ERROR - 2018-02-05 16:35:56 --> Severity: Error --> Call to a member function getCode() on a non-object /home/webmast/htdocs/tsb_online/application/models/Account_model.php 225
ERROR - 2018-02-05 16:36:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:36:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:41:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:41:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:42:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:42:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:42:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:43:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:43:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:45:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:45:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 16:53:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:53:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:53:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:55:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:55:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:56:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:56:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:58:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:58:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 16:59:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:09:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:09:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:09:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:09:48 --> Severity: Notice --> Undefined variable: e /home/webmast/htdocs/tsb_online/application/models/Account_model.php 224
ERROR - 2018-02-05 17:09:48 --> Severity: Error --> Call to a member function getCode() on a non-object /home/webmast/htdocs/tsb_online/application/models/Account_model.php 224
ERROR - 2018-02-05 17:17:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:17:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:18:05 --> Severity: Parsing Error --> syntax error, unexpected 'did' (T_STRING) /home/webmast/htdocs/tsb_online/application/libraries/MY_Form_validation.php 73
ERROR - 2018-02-05 17:18:32 --> Severity: Error --> Class 'CI_Form_validation' not found /home/webmast/htdocs/tsb_online/application/libraries/MY_Form_validation.php 38
ERROR - 2018-02-05 17:21:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:21:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:26:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:27:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:27:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:27:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:31:17 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:31:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:32:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:32:05 --> 404 Page Not Found: Change-password/changeLoginPassword
ERROR - 2018-02-05 17:32:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:46:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:49:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:50:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:50:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:50:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:50:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:56:45 --> Severity: Notice --> Object of class PDOStatement could not be converted to int /home/webmast/htdocs/tsb_online/application/models/Account_model.php 207
ERROR - 2018-02-05 17:56:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:56:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:56:57 --> Severity: Notice --> Object of class PDOStatement could not be converted to int /home/webmast/htdocs/tsb_online/application/models/Account_model.php 207
ERROR - 2018-02-05 17:57:37 --> Severity: Notice --> Undefined variable: acc_no /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 106
ERROR - 2018-02-05 17:58:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 17:58:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 17:59:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:01:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:02:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:02:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:03:02 --> Severity: Notice --> Undefined index: ACC_JOINT /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 109
ERROR - 2018-02-05 18:05:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:06:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:07:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 18:07:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-05 19:16:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:17:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:17:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:17:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:19:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:19:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:20:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:20:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:20:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:20:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:21:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:21:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:22:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:22:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:23:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:23:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-05 19:23:49 --> 404 Page Not Found: Assets/private

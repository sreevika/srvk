<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-05 10:32:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 10:42:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 10:46:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 11:21:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 11:21:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 11:25:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-05 11:25:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-05 11:41:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 11:50:58 --> 404 Page Not Found: Img/index
ERROR - 2018-03-05 12:15:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 12:26:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:26:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 12:29:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 12:29:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:30:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:30:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:30:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 12:31:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:32:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:34:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 12:35:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 12:35:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:15:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:19:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 14:19:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 14:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:25:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:25:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 14:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:26:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 14:26:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:01:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:02:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:22:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 15:23:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 15:23:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:26:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 15:49:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:49:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:50:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 15:54:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 15:54:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:01:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 16:02:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:04:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-05 16:04:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-05 16:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-05 16:11:06 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-13 09:30:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-13 09:31:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-13 09:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-13 09:34:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 09:36:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 10:24:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 10:29:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 10:32:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 10:54:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:01:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:02:35 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 223
ERROR - 2018-03-13 11:03:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:03:40 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 223
ERROR - 2018-03-13 11:07:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:07:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:07:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:07:58 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 223
ERROR - 2018-03-13 11:08:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:08:39 --> Severity: Warning --> Illegal string offset 'BENEFICIARY_ID' /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 225
ERROR - 2018-03-13 11:09:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:09:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:09:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:10:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:11:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:11:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:14:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:20:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:20:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:20:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:36:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:37:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:44:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:46:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:47:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:47:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:47:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:47:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:47:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 11:48:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 11:48:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 12:01:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 12:08:16 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 12:08:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 12:09:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 12:09:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 12:10:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 12:10:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 12:17:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 12:17:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 12:23:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 14:45:12 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-13 14:45:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 14:45:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 14:45:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 14:45:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 15:47:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 16:07:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 16:52:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 16:52:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 16:52:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 16:57:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 16:58:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 16:58:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 17:00:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:01:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:02:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:04:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:04:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:05:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:05:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 17:06:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:06:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 17:06:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:10:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 17:10:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-13 17:14:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:15:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-13 17:21:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

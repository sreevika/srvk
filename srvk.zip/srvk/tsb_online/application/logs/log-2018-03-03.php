<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-03 09:32:35 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 09:32:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 10:04:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 10:09:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 10:13:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:15:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:17:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:28:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 10:28:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:29:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:29:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:30:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:33:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 10:33:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:33:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:34:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:58:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 10:59:02 --> Severity: Warning --> Missing argument 1 for CI_Form_validation::set_rules(), called in /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php on line 410 and defined /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 167
ERROR - 2018-03-03 10:59:02 --> Severity: Notice --> Undefined variable: field /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 178
ERROR - 2018-03-03 10:59:02 --> Severity: Notice --> Undefined variable: field /home/webmast/htdocs/tsb_online/system/libraries/Form_validation.php 202
ERROR - 2018-03-03 11:55:31 --> Severity: Notice --> Undefined variable: account_model /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 121
ERROR - 2018-03-03 11:55:31 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 125
ERROR - 2018-03-03 11:55:31 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 141
ERROR - 2018-03-03 11:55:31 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 169
ERROR - 2018-03-03 11:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 11:55:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 11:56:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 11:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 11:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 11:56:43 --> Severity: Notice --> Undefined variable: account_model /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 121
ERROR - 2018-03-03 11:56:43 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 125
ERROR - 2018-03-03 11:56:43 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 141
ERROR - 2018-03-03 11:56:43 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 169
ERROR - 2018-03-03 11:57:17 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 125
ERROR - 2018-03-03 11:57:17 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 141
ERROR - 2018-03-03 11:57:17 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 169
ERROR - 2018-03-03 12:00:19 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 126
ERROR - 2018-03-03 12:00:19 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 142
ERROR - 2018-03-03 12:00:19 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 170
ERROR - 2018-03-03 12:06:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 12:07:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:07:15 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 416
ERROR - 2018-03-03 12:07:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'function' (T_FUNCTION), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 416
ERROR - 2018-03-03 12:07:52 --> Severity: Parsing Error --> syntax error, unexpected 'true' (T_STRING) /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 437
ERROR - 2018-03-03 12:07:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:08:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:08:15 --> Severity: Error --> Call to undefined method Beneficiary_model::getCustomerInterBankBeneficiarys() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 400
ERROR - 2018-03-03 12:08:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 127
ERROR - 2018-03-03 12:08:43 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 127
ERROR - 2018-03-03 12:09:11 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 128
ERROR - 2018-03-03 12:09:11 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 144
ERROR - 2018-03-03 12:09:11 --> Severity: Notice --> Undefined variable: user_entity /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 172
ERROR - 2018-03-03 12:13:16 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/system/core/Output.php 538
ERROR - 2018-03-03 12:13:46 --> Severity: Error --> Call to undefined function json_enocode() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 461
ERROR - 2018-03-03 12:15:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:18:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:18:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:25:28 --> Severity: Compile Error --> Cannot use [] for reading /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 471
ERROR - 2018-03-03 12:31:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:35:03 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 512
ERROR - 2018-03-03 12:35:35 --> Severity: Notice --> Undefined index: BANK_NAME /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 491
ERROR - 2018-03-03 12:35:35 --> Severity: Notice --> Undefined index: BRANCH_NAME /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 492
ERROR - 2018-03-03 12:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 12:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 12:40:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 12:40:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 12:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 12:47:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:45:17 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 273
ERROR - 2018-03-03 14:45:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:45:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:45:24 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Beneficiary_model.php 273
ERROR - 2018-03-03 14:45:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:45:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 14:52:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:53:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:57:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:57:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:58:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 14:58:00 --> Severity: Error --> Call to undefined method Beneficiary_model::getCustomerInterBankBeneficiarys() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 95
ERROR - 2018-03-03 14:59:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 15:01:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 15:12:09 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-03 15:12:10 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-03 16:47:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:49:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:49:35 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/system/core/Output.php 538
ERROR - 2018-03-03 16:50:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:50:16 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/system/core/Output.php 538
ERROR - 2018-03-03 16:51:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:52:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 16:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:07:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:08:23 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:08:25 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:08:25 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:08:26 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:08:26 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:08:27 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:09:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:09:10 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 605
ERROR - 2018-03-03 17:10:14 --> Severity: Notice --> Undefined variable: loginNewPassword /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 627
ERROR - 2018-03-03 17:10:14 --> Severity: Error --> Call to undefined method HomeController::set_message() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 628
ERROR - 2018-03-03 17:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:19:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:20:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:20:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:20:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:21:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 17:30:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:37:53 --> Severity: Parsing Error --> syntax error, unexpected '$output' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 695
ERROR - 2018-03-03 17:38:09 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:38:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 17:38:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:40:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:40:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:40:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:40:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:41:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:42:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:42:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:42:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:43:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:44:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:45:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:45:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:48:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:48:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-03 17:50:28 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-03 17:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-03 17:55:36 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-13 10:44:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 10:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 10:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:02:05 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 11:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:12:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 11:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:12:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 11:13:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:13:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:14:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 11:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 14:12:13 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ']' /home/webmast/htdocs/tsb_online/application/config/hooks.php 20
ERROR - 2018-04-13 14:12:46 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/config/hooks.php 22
ERROR - 2018-04-13 14:12:57 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/config/hooks.php 27
ERROR - 2018-04-13 14:13:12 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/webmast/htdocs/tsb_online/application/config/hooks.php 35
ERROR - 2018-04-13 14:13:44 --> Severity: Parsing Error --> syntax error, unexpected '$hook' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/config/hooks.php 41
ERROR - 2018-04-13 14:20:51 --> Severity: Notice --> Undefined variable: refDAta /home/webmast/htdocs/tsb_online/application/config/hooks.php 32
ERROR - 2018-04-13 14:22:11 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/config/hooks.php 33
ERROR - 2018-04-13 14:25:25 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:25:53 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:26:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 14:26:04 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:29:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 14:39:22 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:39:58 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:44:04 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:44:58 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:46:29 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:48:10 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:48:19 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:50:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 14:51:10 --> Severity: Notice --> Use of undefined constant CI_Controller - assumed 'CI_Controller' /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 14:54:27 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 370
ERROR - 2018-04-13 14:57:00 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 370
ERROR - 2018-04-13 14:57:13 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 371
ERROR - 2018-04-13 14:57:26 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 371
ERROR - 2018-04-13 15:42:13 --> Severity: Notice --> Use of undefined constant CI_Controller - assumed 'CI_Controller' /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 371
ERROR - 2018-04-13 15:42:13 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 372
ERROR - 2018-04-13 15:43:08 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 15:46:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 15:47:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:01:37 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 16:02:11 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-04-13 16:37:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:37:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:37:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:37:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:37:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:37:53 --> Severity: 4096 --> Object of class HomeController could not be converted to string /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 43
ERROR - 2018-04-13 16:37:53 --> Severity: Notice --> Object of class HomeController to string conversion /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 43
ERROR - 2018-04-13 16:37:53 --> Severity: Notice --> Undefined variable: Object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 43
ERROR - 2018-04-13 16:37:53 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 43
ERROR - 2018-04-13 16:37:53 --> Severity: Error --> Call to a member function sess_regenerate() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 43
ERROR - 2018-04-13 16:39:22 --> Severity: 4096 --> Object of class HomeController could not be converted to string /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:22 --> Severity: Notice --> Object of class HomeController to string conversion /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:22 --> Severity: Notice --> Undefined variable: Object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:22 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:22 --> Severity: Error --> Call to a member function sess_regenerate() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:39:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:39:37 --> Severity: 4096 --> Object of class HomeController could not be converted to string /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:37 --> Severity: Notice --> Object of class HomeController to string conversion /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:37 --> Severity: Notice --> Undefined variable: Object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:37 --> Severity: Notice --> Trying to get property of non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:37 --> Severity: Error --> Call to a member function sess_regenerate() on a non-object /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/AuthenticationService.php 42
ERROR - 2018-04-13 16:39:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:40:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:43:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:43:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:43:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:43:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:44:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:44:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:44:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:44:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:44:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 16:44:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:54:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:54:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:54:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 16:55:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 16:55:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:10:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:11:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:11:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:11:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:11:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:12:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-04-13 17:21:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:28:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:29:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:32:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-13 17:32:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-04-13 17:32:55 --> 404 Page Not Found: Assets/private

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-25 08:06:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-25 08:06:32 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-28 09:30:53 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 184
ERROR - 2018-02-28 09:41:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 09:41:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 09:43:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 09:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 09:44:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 10:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 10:32:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 10:32:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 10:35:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 10:36:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 11:25:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 11:28:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 11:31:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 11:32:51 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 11:33:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 11:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 11:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 11:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:04:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 12:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:04:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:04:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:06:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:06:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:06:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 12:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 12:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:07:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:08:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:08:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:09:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-28 12:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:13:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 12:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 12:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:09:14 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 216
ERROR - 2018-02-28 17:09:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:12:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 17:14:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-28 17:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:22:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:23:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 17:26:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-28 18:03:23 --> 404 Page Not Found: Assets/private

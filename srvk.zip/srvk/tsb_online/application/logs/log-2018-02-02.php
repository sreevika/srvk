<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-02 09:53:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 09:53:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 09:53:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 10:36:29 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 18
ERROR - 2018-02-02 10:36:29 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 18
ERROR - 2018-02-02 10:36:58 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 195
ERROR - 2018-02-02 10:37:13 --> Severity: Notice --> Undefined variable: resultSet /home/webmast/htdocs/tsb_online/application/models/Account_model.php 204
ERROR - 2018-02-02 10:44:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:45:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:47:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:47:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:47:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:47:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:47:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:48:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:52:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:53:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:53:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:53:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 10:54:43 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:54:43 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:54:43 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:55:03 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:55:03 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:55:03 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 10:57:54 --> Severity: Notice --> Use of undefined constant ARRAY_FILTER_USE_BOTH - assumed 'ARRAY_FILTER_USE_BOTH' /home/webmast/htdocs/tsb_online/application/models/Account_model.php 238
ERROR - 2018-02-02 10:57:54 --> Severity: Warning --> array_filter() expects at most 2 parameters, 3 given /home/webmast/htdocs/tsb_online/application/models/Account_model.php 238
ERROR - 2018-02-02 10:57:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 11:00:19 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:19 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:19 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:25 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:26 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:26 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:00:26 --> Severity: Warning --> Missing argument 2 for filter() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 236
ERROR - 2018-02-02 11:02:59 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 237
ERROR - 2018-02-02 11:02:59 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 237
ERROR - 2018-02-02 11:02:59 --> Severity: Warning --> Missing argument 2 for Account_model::{closure}() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 237
ERROR - 2018-02-02 11:09:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 11:09:59 --> Severity: Notice --> Undefined index: ACCNO /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-02 11:10:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 11:10:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 11:10:05 --> Severity: Notice --> Undefined index: ACCNO /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-02 11:10:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 11:10:27 --> Severity: Notice --> Undefined index: ACCNO /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 55
ERROR - 2018-02-02 12:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-02 12:17:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:17:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:17:36 --> Severity: Notice --> Undefined variable: savingsAccount /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 60
ERROR - 2018-02-02 12:18:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:18:07 --> Severity: Notice --> Undefined variable: savingsAccount /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 60
ERROR - 2018-02-02 12:18:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:18:25 --> Severity: Notice --> Undefined variable: savingsAccount /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 60
ERROR - 2018-02-02 12:18:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:26:04 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:26:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:36:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:36:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:36:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:36:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:37:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:38:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:40:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:40:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:43:21 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 198
ERROR - 2018-02-02 12:43:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:43:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:43:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:43:25 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 198
ERROR - 2018-02-02 12:43:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:43:27 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 198
ERROR - 2018-02-02 12:43:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 12:43:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:45:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:45:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 12:47:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 13:15:31 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 25
ERROR - 2018-02-02 13:15:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 13:15:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 13:15:34 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 25
ERROR - 2018-02-02 13:16:23 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 13:16:52 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 13:16:53 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 13:16:53 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 13:17:47 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 34
ERROR - 2018-02-02 13:18:51 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 13:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-02 13:19:07 --> Severity: 4096 --> Object of class DashboardController could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:07 --> Severity: Notice --> Object of class DashboardController to string conversion /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:07 --> Severity: Warning --> Creating default object from empty value /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:07 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:07 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:28 --> Severity: 4096 --> Object of class DashboardController could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:28 --> Severity: Notice --> Object of class DashboardController to string conversion /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:28 --> Severity: Warning --> Creating default object from empty value /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:28 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:28 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:29 --> Severity: 4096 --> Object of class DashboardController could not be converted to string /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:29 --> Severity: Notice --> Object of class DashboardController to string conversion /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:29 --> Severity: Warning --> Creating default object from empty value /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 42
ERROR - 2018-02-02 13:19:29 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:29 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:59 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:19:59 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:20:20 --> Severity: Notice --> Undefined variable: _customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:20:20 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:20:40 --> Severity: Notice --> Undefined property: DashboardController::$_customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:20:40 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:20:56 --> Severity: Error --> Call to a member function getName() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 51
ERROR - 2018-02-02 13:22:29 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getName() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 56
ERROR - 2018-02-02 13:25:23 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getName() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 57
ERROR - 2018-02-02 13:25:32 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getName() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 47
ERROR - 2018-02-02 13:26:07 --> Severity: Error --> Call to undefined method TsbApp\Domain\User\UserEntity::getBirthDate() /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 57
ERROR - 2018-02-02 13:26:20 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 68
ERROR - 2018-02-02 13:26:20 --> Severity: Error --> Call to a member function getPermAdd1() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 68
ERROR - 2018-02-02 13:27:05 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 68
ERROR - 2018-02-02 13:27:05 --> Severity: Error --> Call to a member function getPermAdd1() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 68
ERROR - 2018-02-02 14:06:30 --> Severity: Error --> Call to a member function getCustomer() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 33
ERROR - 2018-02-02 14:07:54 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 69
ERROR - 2018-02-02 14:07:54 --> Severity: Error --> Call to a member function getPermAdd1() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 69
ERROR - 2018-02-02 14:08:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:08:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:08:02 --> Severity: Notice --> Undefined variable: customer /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 69
ERROR - 2018-02-02 14:08:02 --> Severity: Error --> Call to a member function getPermAdd1() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 69
ERROR - 2018-02-02 14:09:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:09:07 --> Severity: Notice --> Undefined variable: user /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 80
ERROR - 2018-02-02 14:09:07 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 80
ERROR - 2018-02-02 14:09:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:09:25 --> Severity: Notice --> Undefined variable: user /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 81
ERROR - 2018-02-02 14:09:25 --> Severity: Error --> Call to a member function getCustomerId() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 81
ERROR - 2018-02-02 14:09:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:17:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:17:48 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 14:17:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:17:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 14:19:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:20:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:21:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:22:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:22:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:22:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:22:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:23:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:23:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:23:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:24:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:24:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:24:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:24:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:25:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:29:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:30:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:32:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:32:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:32:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:37:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:39:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:39:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:40:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:40:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:41:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:41:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:41:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 14:41:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:03:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:03:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:04:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:11:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 15:18:20 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 15:18:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:18:31 --> Severity: Notice --> Undefined property: AccountSatementController::$account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 62
ERROR - 2018-02-02 15:18:31 --> Severity: Error --> Call to a member function getCustomerSavingsAccounts() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 62
ERROR - 2018-02-02 15:18:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:18:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:18:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 15:18:39 --> Severity: Notice --> Undefined property: AccountSatementController::$account_model /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 62
ERROR - 2018-02-02 15:18:39 --> Severity: Error --> Call to a member function getCustomerSavingsAccounts() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 62
ERROR - 2018-02-02 15:19:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:19:31 --> Severity: Notice --> Undefined variable: output /home/webmast/htdocs/tsb_online/application/controllers/Private/AccountSatementController.php 107
ERROR - 2018-02-02 15:21:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:44:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:44:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:44:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:44:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:45:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:45:30 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:47:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:47:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:48:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:48:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:49:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:51:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:52:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:52:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:53:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:53:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:54:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:56:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:56:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:57:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:58:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:58:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 15:59:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:06:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:06:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:06:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:07:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:36:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 16:46:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 16:46:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:08:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-02 17:09:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:09:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:09:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:10:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:10:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:10:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:11:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:12:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:12:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:12:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:12:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:13:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:14:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:14:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:14:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:14:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:15:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:15:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:15:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:15:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:17:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:18:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:18:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:18:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:18:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:18:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:19:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:19:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:19:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:20:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:20:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:20:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:21:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:21:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:22:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:25:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:30:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:30:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:39:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:40:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:42:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:42:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:45:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:45:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 17:45:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:46:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:46:25 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:47:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:47:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:48:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:58:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:59:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 17:59:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:00:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:01:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:03:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:04:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:04:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 18:04:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:05:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:09:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:09:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 18:09:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:10:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:11:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-02 18:11:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-02 18:15:43 --> 404 Page Not Found: Assets/private

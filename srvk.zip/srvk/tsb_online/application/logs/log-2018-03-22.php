<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-22 10:26:10 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 10:26:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 10:26:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 11:53:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 11:55:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 11:55:32 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:36:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-22 12:36:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:36:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:36:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:37:05 --> Severity: Parsing Error --> syntax error, unexpected '$params' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 717
ERROR - 2018-03-22 12:37:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:37:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:37:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:37:14 --> Severity: Parsing Error --> syntax error, unexpected '$params' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/models/Fund_transaction_model.php 717
ERROR - 2018-03-22 12:37:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:37:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:38:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:38:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:38:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:38:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 12:39:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:40:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:43:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:44:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:48:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:48:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:49:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:49:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:52:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 12:52:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:39:27 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:39:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-22 14:39:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:39:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:44:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:44:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:45:00 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:45:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:45:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:45:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:45:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:49:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:50:42 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:50:46 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:50:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:55:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:55:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:55:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:56:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:56:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 14:56:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 14:59:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:00:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:00:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:08:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:25:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:25:38 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 15:25:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:25:44 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 15:26:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:26:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:26:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 15:26:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 15:27:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-22 15:27:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-22 17:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-22 17:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-22 17:44:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-22 17:44:58 --> 404 Page Not Found: Assets/private

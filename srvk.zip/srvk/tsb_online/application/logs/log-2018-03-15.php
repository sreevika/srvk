<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-15 09:44:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 09:51:47 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 09:51:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 09:52:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 09:52:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 09:52:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 09:52:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 09:52:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 09:53:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 10:18:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:18:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 10:18:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:18:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:19:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:21:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:21:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:23:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:23:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:23:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:24:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:31:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:32:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:34:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:35:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:38:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 10:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 10:54:12 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 10:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 10:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 10:57:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 11:03:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 11:20:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 11:20:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 11:25:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 11:25:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 11:25:41 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 16:27:42 --> 404 Page Not Found: Test/index
ERROR - 2018-03-15 16:38:21 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 17:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 17:40:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-15 17:40:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-15 17:46:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 17:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-15 17:55:07 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-20 09:56:31 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 09:57:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 09:57:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 09:57:53 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 09:58:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 09:59:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:00:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:00:23 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:02:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:02:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:05:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:06:28 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:07:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:07:19 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:47:19 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:47:19 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:47:19 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:47:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-20 10:47:45 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:47:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:48:00 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:48:00 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:00 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:01 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:48:01 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:01 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:02 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:48:02 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:02 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 10:48:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:48:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 10:48:11 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:48:11 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:11 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:35 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 10:48:35 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 10:48:35 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:01:06 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 11:01:06 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:01:06 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:02:19 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:02:19 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:02:19 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:02:21 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:02:21 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:02:21 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:56 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:56 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 11:57:56 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 11:57:57 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:57 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:57 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:58 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:58 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:58 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:58 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:58 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:58 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:59 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:59 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:59 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:59 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:57:59 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:57:59 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:00 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:58:00 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:00 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:37 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 11:58:37 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:37 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:45 --> Unable to load the requested class: BeneficiaryController
ERROR - 2018-03-20 11:58:45 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:45 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:52 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:58:52 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:58:52 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:59:33 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:59:33 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:59:33 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:59:33 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 11:59:41 --> Unable to load the requested class: Beneficiarycontroller
ERROR - 2018-03-20 11:59:42 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:59:42 --> 404 Page Not Found: HomeController/assets
ERROR - 2018-03-20 11:59:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 12:00:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 12:02:37 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1048
ERROR - 2018-03-20 12:02:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 12:10:43 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1052
ERROR - 2018-03-20 12:10:51 --> Severity: Notice --> Use of undefined constant APP_PATH - assumed 'APP_PATH' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1047
ERROR - 2018-03-20 12:10:51 --> Severity: Warning --> require_once(APP_PATH/controllers/Private/BeneficiaryController.php): failed to open stream: No such file or directory /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1048
ERROR - 2018-03-20 12:10:51 --> Severity: Compile Error --> require_once(): Failed opening required 'APP_PATH/controllers/Private/BeneficiaryController.php' (include_path='.:/usr/local/lib/php') /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 1048
ERROR - 2018-03-20 12:10:59 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 14:49:36 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 378
ERROR - 2018-03-20 14:49:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 14:49:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 14:49:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 14:49:44 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 378
ERROR - 2018-03-20 14:50:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 14:50:23 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 378
ERROR - 2018-03-20 14:50:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 14:50:49 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 14:54:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 14:54:45 --> Severity: Parsing Error --> syntax error, unexpected ''beneficiary/verifyOtpForIntra' (T_CONSTANT_ENCAPSED_STRING) /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 378
ERROR - 2018-03-20 14:55:00 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 15:10:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:11:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:13:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:13:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:15:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:16:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:16:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:17:10 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:17:35 --> Severity: Error --> Call to undefined method CI_Output::set_content() /home/webmast/htdocs/tsb_online/application/controllers/Private/BeneficiaryController.php 413
ERROR - 2018-03-20 15:39:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:44:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:44:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 15:44:52 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 15:44:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:46:52 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:47:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:47:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 15:47:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:48:46 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:50:09 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:51:50 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:58:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 15:59:31 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 16:01:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:47:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:47:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-20 17:48:18 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:48:44 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:49:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:49:47 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:51:22 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:51:22 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:51:22 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:51:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 17:56:20 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:56:20 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:56:20 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:56:23 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:57:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-20 17:58:21 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:58:36 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:58:36 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:58:36 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:59:05 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:59:06 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:59:06 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:59:38 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 17:59:38 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 17:59:38 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:00 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 18:00:01 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:01 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 18:00:07 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 18:00:07 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:07 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 18:00:34 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 18:00:34 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:34 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:34 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-20 18:00:39 --> Unable to load the requested class: Otpmanager
ERROR - 2018-03-20 18:00:39 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:00:39 --> 404 Page Not Found: Dashboard/assets
ERROR - 2018-03-20 18:01:32 --> Severity: Notice --> Undefined property: DashboardController::$otpManager /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 348
ERROR - 2018-03-20 18:01:32 --> Severity: Error --> Call to a member function resendOtp() on a non-object /home/webmast/htdocs/tsb_online/application/controllers/Private/DashboardController.php 348
ERROR - 2018-03-20 18:01:46 --> Severity: Error --> Call to undefined method OtpManager::createMessagesend() /home/webmast/htdocs/tsb_online/application/libraries/OtpManager.php 289
ERROR - 2018-03-20 18:06:15 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-06 17:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 17:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 17:31:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 17:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 17:32:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 17:32:43 --> 404 Page Not Found: Assets/css

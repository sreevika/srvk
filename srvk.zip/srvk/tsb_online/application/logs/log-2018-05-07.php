<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-07 09:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-05-07 09:53:26 --> 404 Page Not Found: Assets/css
ERROR - 2018-05-07 09:54:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-05-07 09:55:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-05-07 09:56:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-05-07 10:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-05-07 10:03:37 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0

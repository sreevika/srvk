<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-24 09:48:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-24 17:35:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-24 17:35:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-24 17:38:06 --> 404 Page Not Found: Assets/private

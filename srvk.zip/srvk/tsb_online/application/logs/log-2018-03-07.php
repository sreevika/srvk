<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-07 10:09:36 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 10:26:20 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 10:26:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 10:35:13 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 10:38:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 10:55:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:24:25 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 11:36:50 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 11:36:56 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:41:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:55:42 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 11:55:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:57:02 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:58:21 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 11:59:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:27:58 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 13:48:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 13:49:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:49:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:49:21 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:50:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:50:05 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:50:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:50:12 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:52:26 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:52:31 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:52:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:52:35 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:53:06 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 13:53:10 --> 404 Page Not Found: Rejection-clear/index
ERROR - 2018-03-07 13:56:15 --> Severity: Error --> Call to undefined method Account_model::getCoretisConnection() /home/webmast/htdocs/tsb_online/application/models/Account_model.php 268
ERROR - 2018-03-07 14:04:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:04:05 --> Severity: Notice --> Undefined variable: statement1 /home/webmast/htdocs/tsb_online/application/models/Account_model.php 279
ERROR - 2018-03-07 14:04:05 --> Severity: Error --> Call to a member function bindValue() on a non-object /home/webmast/htdocs/tsb_online/application/models/Account_model.php 279
ERROR - 2018-03-07 14:04:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:04:27 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 279
ERROR - 2018-03-07 14:04:27 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 279
ERROR - 2018-03-07 14:04:27 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 279
ERROR - 2018-03-07 14:04:27 --> Severity: error --> Exception: SQLSTATE[22005]: Error in assignment: -99999 [IBM][CLI Driver] CLI0112E  Error in assignment. SQLSTATE=22005 (SQLExecute[-99999] at /home/PDO_IBM-1.3.4/ibm_statement.c:1136) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 282
ERROR - 2018-03-07 14:07:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:07:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:07:07 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 280
ERROR - 2018-03-07 14:07:07 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 280
ERROR - 2018-03-07 14:07:07 --> Severity: Notice --> Array to string conversion /home/webmast/htdocs/tsb_online/application/models/Account_model.php 280
ERROR - 2018-03-07 14:07:07 --> Severity: error --> Exception: SQLSTATE[22005]: Error in assignment: -99999 [IBM][CLI Driver] CLI0112E  Error in assignment. SQLSTATE=22005 (SQLExecute[-99999] at /home/PDO_IBM-1.3.4/ibm_statement.c:1136) /home/webmast/htdocs/tsb_online/application/models/Account_model.php 283
ERROR - 2018-03-07 14:07:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/webmast/htdocs/tsb_online/application/models/Account_model.php:278) /home/webmast/htdocs/tsb_online/system/core/Common.php 570
ERROR - 2018-03-07 14:08:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: CREDIT_DATE /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 77
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: TRANSACTION_ID /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 78
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: BENEFICIARY_NAME /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 79
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: ACCOUNT_NO /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 80
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: IFSC /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 81
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: NET_PAY /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 82
ERROR - 2018-03-07 14:08:59 --> Severity: Notice --> Undefined index: ROWID /home/webmast/htdocs/tsb_online/application/controllers/Private/RejectionClearController.php 83
ERROR - 2018-03-07 14:19:03 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:19:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:19:37 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:20:34 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-07 14:20:38 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:20:40 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:20:41 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:20:44 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:38:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:39:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:42:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:42:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 14:42:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:42:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:42:45 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:44:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:44:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:44:18 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:44:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:44:51 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:44:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:45:55 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:46:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:48:33 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 14:54:08 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 14:58:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:11 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:14 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:17 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:22 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:24 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 15:00:24 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 15:25:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 15:52:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 15:52:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 16:35:06 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 16:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 16:37:28 --> Severity: Parsing Error --> syntax error, unexpected 'to' (T_STRING), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 105
ERROR - 2018-03-07 16:37:44 --> Severity: Parsing Error --> syntax error, unexpected 'to' (T_STRING), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 105
ERROR - 2018-03-07 16:37:59 --> Severity: Parsing Error --> syntax error, unexpected 'to' (T_STRING), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 105
ERROR - 2018-03-07 16:40:16 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 16:40:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 16:42:43 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 16:47:55 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 146
ERROR - 2018-03-07 16:48:05 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/webmast/htdocs/tsb_online/application/TsbApp/Authentication/UserAuthentication.php 146
ERROR - 2018-03-07 16:55:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 16:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-07 16:58:14 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-07 17:04:29 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:11:48 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:12:15 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:13:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:15:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:16:08 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:16:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-07 17:27:52 --> Severity: Error --> Class 'CI_Controller' not found /home/webmast/htdocs/tsb_online/system/core/CodeIgniter.php 369
ERROR - 2018-03-07 17:28:25 --> 404 Page Not Found: Assets/private

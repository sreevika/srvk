<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-09 09:49:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 10:03:50 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 130
ERROR - 2018-02-09 10:03:55 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 130
ERROR - 2018-02-09 10:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 10:03:59 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 130
ERROR - 2018-02-09 10:38:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 128
ERROR - 2018-02-09 10:44:32 --> Severity: Notice --> Undefined variable: result /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 116
ERROR - 2018-02-09 10:44:32 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:44:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 10:44:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 10:44:39 --> Severity: Notice --> Undefined variable: result /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 116
ERROR - 2018-02-09 10:44:39 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:45:57 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:46:17 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 10:47:57 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:48:15 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:48:28 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 10:49:26 --> Could not find the language line "form_validation_check_account_number"
ERROR - 2018-02-09 11:02:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 11:23:14 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY), expecting ')' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 155
ERROR - 2018-02-09 11:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 11:42:07 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 11:42:07 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 11:42:47 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 11:42:49 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 11:45:39 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 12:01:03 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 12:01:05 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:19:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:19:19 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:20:01 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:27:57 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:29:54 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 12:29:54 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:29:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 12:29:59 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:30:04 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:31:35 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:32:53 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:32:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:33:58 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 12:39:12 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-09 13:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 13:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 18:18:18 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 192
ERROR - 2018-02-09 18:42:37 --> Severity: Error --> Call to undefined method HomeController::set_tempdata() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 192
ERROR - 2018-02-09 18:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 18:42:42 --> Severity: Error --> Call to undefined method HomeController::set_tempdata() /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 192
ERROR - 2018-02-09 18:54:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 18:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 18:56:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 18:56:29 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-09 18:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:10:17 --> Severity: Notice --> Undefined variable: accNo /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 185
ERROR - 2018-02-09 19:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:14:14 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 193
ERROR - 2018-02-09 19:14:15 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 193
ERROR - 2018-02-09 19:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-09 19:15:56 --> 404 Page Not Found: Assets/css

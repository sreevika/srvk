<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-23 10:40:57 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-23 10:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-23 10:41:36 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-23 10:44:39 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-23 10:46:43 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-23 10:59:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-23 10:59:12 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-03-23 11:13:34 --> 404 Page Not Found: Assets/private
ERROR - 2018-03-23 16:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-03-23 16:28:54 --> 404 Page Not Found: Assets/private

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-26 10:58:26 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 10:58:27 --> 404 Page Not Found: Assets/private
ERROR - 2018-02-26 11:02:11 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 11:02:51 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 11:03:02 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 11:04:13 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 11:08:56 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 12:11:30 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 12:14:01 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 12:21:22 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 12:51:55 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 14:24:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 14:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 14:25:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 14:26:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 14:27:56 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 14:28:04 --> 404 Page Not Found: Reset-credentials/index
ERROR - 2018-02-26 17:07:45 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /home/webmast/htdocs/tsb_online/application/controllers/HomeController.php 81
ERROR - 2018-02-26 17:13:49 --> Severity: Notice --> Undefined property: CI_Exceptions::$load /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:13:49 --> Severity: Error --> Call to a member function view() on a non-object /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:13:54 --> Severity: Notice --> Undefined property: CI_Exceptions::$load /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:13:54 --> Severity: Error --> Call to a member function view() on a non-object /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:13:54 --> Severity: Notice --> Undefined property: CI_Exceptions::$load /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:13:54 --> Severity: Error --> Call to a member function view() on a non-object /home/webmast/htdocs/tsb_online/application/views/errors/html/error_general.php 3
ERROR - 2018-02-26 17:19:32 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 17:23:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 17:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 17:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 17:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 17:58:40 --> Severity: Core Warning --> PHP Startup: mbstring: Unable to initialize module
Module compiled with module API=20090626
PHP    compiled with module API=20100525
These options need to match
 Unknown 0
ERROR - 2018-02-26 17:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-02-26 17:59:05 --> 404 Page Not Found: Assets/css

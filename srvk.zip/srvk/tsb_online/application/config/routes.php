<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'HomeController';
$route['about'] = 'HomeController/about';
$route['contact'] = 'HomeController/contact';
$route['login_instruction'] = 'HomeController/loginInstruction';
$route['login'] = 'HomeController/login';
$route['reset-credentials'] = 'HomeController/resetCredentials';
$route['reset-credentials-action'] = 'HomeController/resetCredentialsAction';

$route['login-action'] = 'HomeController/loginAction';
$route['new-user-registration'] = 'HomeController/registerNewUser';
//forget password
$route['forget-password'] = 'HomeController/forgetPassword';
$route['forget-password-action-submit'] = 'HomeController/forgetPasswordActionSubmit';
$route['verify-forget-password-otp'] = 'HomeController/verifyForgetPasswordOtpActionSubmit';
$route['new-forget-password-action-submit'] = 'HomeController/newForgetPasswordActionSubmit';

//forget username
$route['forget-username'] = 'HomeController/forgetUsername';
$route['forget-username-action-submit'] = 'HomeController/forgetUsernameActionSubmit';

//New user registration
$route['registration-level-1'] = 'HomeController/registrationActionLevel1';
$route['verify-registration-otp'] = 'HomeController/vefiryRegistrationOtp';
$route['find-username'] = 'HomeController/findValidUserName';
// Dashboard routes
$route['dashboard/(:any)'] = 'Private/DashboardController/$1';
$route['dashboard'] = 'Private/DashboardController';

// Account statements
$route["account-statement/(:any)"] = "Private/AccountSatementController/$1";
$route["account-statement"] = "Private/AccountSatementController";

//Beneficiary Details
$route["beneficiary/(:any)"] = "Private/BeneficiaryController/$1";

//Standing Instruction
$route["standing-instruction/(:any)"] = "Private/StandingInstructionController/$1";
$route["standing-instruction"] = "Private/StandingInstructionController";



//Fund Transaction
$route["fund-transfer/(:any)"] = "Private/FundTransferController/$1";
//Rejection Clear
$route["rejection-clear"] = "Private/RejectionClearController/rejectionClear";
$route["rejectionClearUpdate"] = "Private/RejectionClearController/updateRejectionClear";
$route["rejectionClearBeneficiaryCheck"] = "Private/RejectionClearController/rejectionClearBeneficiaryCheck";
// Peridic scheduled payment controller
$route["periodic-scheduled-payment/(:any)"] = "Private/PeriodicScheduledPayment/$1";
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	https://codeigniter.com/user_guide/general/hooks.html
|
*/

/**
 *
 * Allow only http get post
 * do not accept request with other referer
 */
$hook['pre_system'][] = function(){
	if(!in_array($_SERVER['REQUEST_METHOD'], ['POST', 'GET'])){
		// temporary exit will change redirect request to other page or somthing
		echo "Access Denied";
		exit;
	}

	if(isset($_SERVER["HTTP_REFERER"])){
		$ref = $_SERVER['HTTP_REFERER'];
		$refData = parse_url($ref);
		if($refData['host'] !== '103.251.43.79') {
		  // Output string and stop execution
		  die("Access Denied ".$refData['host']);
		}
	}


};
/**
 * Access control
 */
$hook['post_controller_constructor'][] = function(){
  $ci =& get_instance();
  $current_url = $ci->uri->segment(1);
  $ci->config->load("app_config", TRUE);
  $access_control = $ci->config->item('access_control', 'app_config');
  if(in_array($current_url, $access_control["protected"])){
    if(TsbApp\Authentication\AuthenticationService::isLoggedIn()){

      // to do other stuff
    }else{
      // if Ajax request
      if($ci->input->is_ajax_request()){
        $output = array();
        $output['status'] = false;
        $output['loginStatus'] = false;
        header('Content-Type: application/json');
        die($ci->output->set_output(json_encode($output))->get_output());
      }else{
        // if normal request
        redirect(base_url().'login');
      }

    }
  }
};

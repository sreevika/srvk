<?php
/*
|-------------------------------------------------------------------------
| Access controls
|-------------------------------------------------------------------------
|
| Add the protected url segments into the protected array it will automatically
| Check wether the user is logged in
| If the request was an ajax request then return json response,
| For normal request it will redirect to the login page
|
| The access controll is defined in hooks. If you want to alter
| acccss control functionality you can edit the hooks.php file inside config
| directory
*/

$config["access_control"]["protected"] = [
  'dashboard',
  'account-statement',
  'beneficiary',
  'standing-instruction',
  'periodic-scheduled-payment',
  'fund-transfer',
  'rejection-clear'
];


/*
|--------------------------------------------------------------------------
| Authentication configuration
|--------------------------------------------------------------------------
|
|
|
|
*/

// TRUE Enable otp for login, FALSE Disabele otp on login
$config["authentication"]["otp"] = TRUE;
// Enable login limit check TRUE for enable , FALSE for disable
$config["authentication"]["login_limit"]["check"] = TRUE;
// Number of invalid login attempts for an user
$config["authentication"]["login_limit"]["limit"] = 3;
// Login lock expiration time in seconds seconds
$config["authentication"]["login_limit"]["lock_expiration"] = (24 * 60 * 60);
// Login session name
$config["authentication"]["login_session_name"] = 'login_data';
// login expiration time in seconds
$config["authentication"]["login_expiration"] = (60 * 20);


/*
|--------------------------------------------------------------------------
| GLOBAL OTP SETTINGS
|--------------------------------------------------------------------------
|
*/
$config['otp']['max_otp_per_day'] = 10;


/*
|---------------------------------------------------------------------------
| Beneficiary settings
|---------------------------------------------------------------------------
|
|
*/
// enable/disable otp for beneficiary
$config['beneficiary']['otp'] = false;
// set debugg otp for debugging
$config['beneficiary']['otp_debug'] = false;
// if default otp is enabled then this will be the dafault otp
$config['beneficiary']['otp_debug_value'] = '12345';
// otp timeout in seconds
$config['beneficiary']['otp_timeout'] = (60 * 5);
// opt purpose code
$config['beneficiary']['otp_purpose_code'] = 'BENF';


/*
 |---------------------------------------------------------------------------
 | Fund transfer settings
 |---------------------------------------------------------------------------
 |
 |
 */
 $config['fundtransfer']['otp'] = false;
 $config['fundtransfer']['otp_debug'] = false;
 $config['fundtransfer']['otp_debug_value'] = '12345';
 $config['fundtransfer']['otp_timeout'] = (60 * 5);
 $config['fundtransfer']['otp_purpose_code'] = 'FUND_TRANSFER';
?>

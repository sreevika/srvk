<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Homecontroller
 * This controller contain all the public pages
 */
class HomeController extends CI_Controller{

    /**
     * index
     * Home page
     */
    public function index(){
      $data = array();
      $data["page_name"] = "home";
      $data['active_page'] = 'home';
      $this->load->view("public/main",$data);
    }

    /**
     * loginInstruction
     * Login Instruction page
     */
    public function loginInstruction(){
      $data = array();
      $data["page_name"] = "loginInstruction";
      $this->load->view("public/main",$data);
    }

    /**
     * About page
     * About tsb online
     */
    public function about(){
      $data = array();
      $data['page_name'] = 'about';
      $data['active_page'] = 'about';
      $this->load->view("public/main",$data);
    }

    /**
     * Contact
     * Contact page informatation
     */
    public function contact(){
      $data = array();
      $data['page_name'] = 'contact';
      $data['active_page'] = 'contact';
      $this->load->view("public/main",$data);
    }

    /**
     * login
     * Login page
     */
    public function login(){
      $data = array();
      $data["page_name"] = "login";
      $this->load->view("public/main",$data);
    }

    /**
     * Login action login check
     * This actino method deals three form submission
     * 1. Normal user login
     * 2. User Password change
     * 3. New Transaction Key
     * @todo refactor the code currently code is repeated
     */
     public function loginAction(){
       $output = array();
       $output['status'] = false;
       $output['loginStatus'] = false;
       $output['error'] = [];
       $output['errors'] = [];

       // form validation
       $this->load->library('form_validation');

       $this->form_validation->set_rules('username', 'Username', 'required|trim');
       $this->form_validation->set_rules('password', 'Password', 'required|trim');

       // if form contains error
       if($this->form_validation->run() == false){
         $output['errors'] = $this->form_validation->error_array();
         $this->output->set_content_type('application/json');
         return $this->output->set_output(json_encode($output));
       }


       // If the purpose is normal user login

       $username = $this->input->post("username");
       $password = hash('sha256',$this->input->post("password"));
       try{
         $status = TsbApp\Authentication\AuthenticationService::checkLogin($username, $password);
         if($status === true){
           $output['loginStatus'] = true;
           $output['status'] = true;
         }
       }catch(TsbApp\Authentication\Exceptions\PasswordChangeException $e){
           $output['resetCredentials'] = true;
           $this->session->set_tempdata(array('resetCredentials' => array('resetCredentials' => true, 'username' => $username)), 60 * 6);
       }catch(TsbApp\Authentication\Exceptions\TransactionKeyChangeException $e){
           $this->session->set_tempdata(array('resetCredentials' => array('resetCredentials' => true, 'username' => $useWelcome)) , 60 * 6);
           $output['resetCredentials'] = true;
       }catch(Exception $e){
         $output['error'] = $e->getMessage();
       }
       $this->output->set_content_type('application/json');
       return $this->output->set_output(json_encode($output));

     }

     /**
      * New user forget password
      *
      */
     public function forgetUsername(){
       $data = array();
       $data["page_name"] = "forget_username";
       $this->load->view("public/main",$data);
     }


     /**
      * Action for Forget password submit
      *
      */
     public function forgetUsernameActionSubmit(){
        $response = array();
        $response['status'] = false;
        $response['error']['code'] = null ;
        $response['error']['message'] = null ;
        $response['data'] = array();

        $this->load->model('user_model');
        $this->load->model('account_model');
        $this->load->library('form_validation');

        $accNo = $this->input->post('tsb_acc_no');

        $account_details = $this->account_model->getAccountDetails($accNo);
        $customer_id = $account_details[0]['CUSTOMER_ID'];
        $birth_date = $account_details[0]['BIRTH_DATE'];
        $user_details = $this->user_model->getUserByCustomerId($customer_id);




        // Validating account number
        $this->form_validation->set_rules('tsb_acc_no', 'Tsb Account Number', array('trim', 'required','max_length[18]',
          array('check_account_number', function($accNo) use($account_details, $user_details){
              // if account number is empty then other validation will fire
              if(empty($accNo)){
                  return true;
              }
              // check account number exists
              if(!is_array($account_details)){
                  $this->form_validation->set_message('check_account_number', 'Invalid account number');
                  return false;
              }
              // check user entity
              if(!$user_details){
                $this->form_validation->set_message('check_account_number', 'Invalid account number');
                return false;
              }
               // check account details customer id is same as $user_entity customer id
              if($user_details[0]['CUSTOMERID'] != $account_details[0]['CUSTOMER_ID']){
                $this->form_validation->set_message('check_account_number', 'Invalid account number');
                return false;
              }


              return true;
          })
        ));

        // validate mobile number
        $this->form_validation->set_rules('tsb_reg_mobile_number', 'Mobile Number', array('trim', 'required', 'numeric',
          array('check_mobile_number', function($mobile_number) use($user_details){
            // if empty then other validation method will deal
            if(empty($mobile_number)){
                return true;
            }
            // check user entity
            if(!$user_details){
                $this->form_validation->set_message('check_mobile_number', 'Invalid mobile number');
                return false;
            }
            if($mobile_number != $user_details[0]['MOBILE']){
                $this->form_validation->set_message('check_mobile_number', 'This {field} is not linked with given account');
                return false;
            }
            return true;
          })
        ));

        // validating date of birth
        $this->form_validation->set_rules('tsb_account_dob', 'Date of Birth', array('required', 'trim',
          array('isValidDOB', function($dob) use($account_details){
            // if dob is empty the  other validation method will trigger
            if(empty($dob)){
                return true;
            }
            // check dob is in valid date format
            if(!isValidDate($dob, 'd/m/Y')){
                $this->form_validation->set_message('isValidDOB', 'Invalid {field} format');
                return false;
            }
            // is valid date in db
            if(switch_date_format($account_details[0]['BIRTH_DATE'], 'Y-m-d', 'd/m/Y') != $dob){
                $this->form_validation->set_message('isValidDOB', 'Invalid {field}');
                return false;
            }
            return true;
          })
        ));

        // check form validation result
        if($this->form_validation->run() === false){
          $response['status'] = true;
          $response['errors'] = $this->form_validation->error_array();
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
        }

        $data = array();

        $data['accNo'] = $accNo;
        $data['dob'] = $this->input->post('tsb_account_dob');
        $data['mobNo'] = $this->input->post('tsb_reg_mobile_number');
        $data['name'] = (empty($account_details[0]['NAME']))?  'User' :
        (strlen($account_details[0]['NAME']) > 8)? substr($account_details[0]['NAME'], 0, 8).".." : $account_details[0]['NAME'] ;
        $this->session->set_tempdata('user_info',$data,(60 * 10));

        $username = $user_details[0]['USERNAME'];
        $message = " Username for TSBONLINE ".$username;

        send_otp($data['mobNo'], $message);
        $response['status'] = true;
        $response['data'] = $data;
        $response['otp'] = true;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($response));
        return;
     }



      /**
      * New user forget password
      *
      */
     public function forgetPassword(){
       $data = array();
       $data["page_name"] = "forget_password";
       $this->load->view("public/main",$data);
     }


     /**
      * Action for Forget password submit
      *
      */

     public function forgetPasswordActionSubmit(){
        $response = array();
        $response['status'] = false;
        $response['error']['code'] = null ;
        $response['error']['message'] = null ;
        $response['data'] = array();

        $this->load->model('user_model');
        $this->load->model('account_model');
        $this->load->library('form_validation');

        $accNo = $this->input->post('tsb_account_number');
        $userName = $this->input->post('tsb_account_username');
        $account_details = $this->account_model->getAccountDetails($accNo);
        $user = new TsbApp\Domain\User\User();
        try{
          $user_entity = $user->getUserByusername($userName);

        }catch(Exception $e){
          $response['error']['message'] = 'Somthing went wrong';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
        }
        // Validating username
        $this->form_validation->set_rules('tsb_account_username', 'Username', array('trim','required','alpha_numeric','min_length[5]',
          array('check_username_exists', function($username) use($user_entity){
            // if empty username
            if(empty($username)){
                return true;
            }
            // is user exists
            if(!$user_entity){
                $this->form_validation->set_message('check_username_exists', 'Invalid {field}');
                return false;
            }
            return true;
          })
        ));

        // Validating account number
        $this->form_validation->set_rules('tsb_account_number', 'Tsb Account Number', array('trim', 'required','max_length[18]',
          array('check_account_number', function($accNo) use($account_details, $user_entity){
              // if account number is empty then other validation will fire
              if(empty($accNo)){
                  return true;
              }
              // check account number exists
              if(!is_array($account_details)){
                  $this->form_validation->set_message('check_account_number', 'Invalid account number');
                  return false;
              }
              // check user entity
              if(!$user_entity){
                $this->form_validation->set_message('check_account_number', 'Invalid account number');
                return false;
              }

              // check account details customer id is same as $user_entity customer id
              if($user_entity->getCustomerId() != $account_details[0]['CUSTOMER_ID']){
                $this->form_validation->set_message('check_account_number', 'Invalid account number');
                return false;
              }

              return true;
          })
        ));

        // validate mobile number
        $this->form_validation->set_rules('tsb_account_mobile_number', 'Mobile Number', array('trim', 'required', 'numeric',
          array('check_mobile_number', function($mobile_number) use($user_entity){
            // if empty then other validation method will deal
            if(empty($mobile_number)){
                return true;
            }
            // check user entity
            if(!$user_entity){
                $this->form_validation->set_message('check_mobile_number', 'Invalid mobile number');
                return false;
            }
            if($mobile_number != $user_entity->getMobile()){
                $this->form_validation->set_message('check_mobile_number', 'This {field} is not linked with given account');
                return false;
            }
            return true;
          })
        ));

        // validating date of birth
        $this->form_validation->set_rules('tsb_account_date_of_birth', 'Date of Birth', array('required', 'trim',
          array('isValidDOB', function($dob) use($account_details){
            // if dob is empty the  other validation method will trigger
            if(empty($dob)){
                return true;
            }
            // check dob is in valid date format
            if(!isValidDate($dob, 'd/m/Y')){
                $this->form_validation->set_message('isValidDOB', 'Invalid {field} format');
                return false;
            }
            // is valid date in db
            if(switch_date_format($account_details[0]['BIRTH_DATE'], 'Y-m-d', 'd/m/Y') != $dob){
                $this->form_validation->set_message('isValidDOB', 'Invalid {field}');
                return false;
            }
            return true;
          })
        ));

        // check form validation result
        if($this->form_validation->run() === false){
          $response['status'] = true;
          $response['errors'] = $this->form_validation->error_array();
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
        }

        $data = array();
        $data['username'] = $this->input->post('tsb_account_username');
        $data['accNo'] = $this->input->post('tsb_account_number');
        $data['dob'] = $this->input->post('tsb_account_date_of_birth');
        $data['mobNo'] = $this->input->post('tsb_account_mobile_number');
        $data['name'] = (empty($account_details[0]['NAME']))?  'User' :
        (strlen($account_details[0]['NAME']) > 8)? substr($account_details[0]['NAME'], 0, 8).".." : $account_details[0]['NAME'] ;
        $this->session->set_tempdata('user_info',$data,(60 * 10));
        //$otp = mt_rand(10000, 99999);
        $otp = 12345;
        $message = " Temporary Password for TSBONLINE ".$otp;
        $this->session->set_tempdata('temp_password', $otp, (60 * 10));
        //send_otp($data['mobileNo'], $message);
        $response['status'] = true;
        $response['data'] = $data;
        $response['otp'] = true;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($response));
        return;
     }


    public function verifyForgetPasswordOtpActionSubmit(){
     $response['status'] = false;
     $response['error'] = array();
     $response['errors'] = array();
     $this->load->library('form_validation');
     $this->form_validation->set_rules('otp', 'Otp', 'required');
     // validate request
     if($this->form_validation->run() === false){
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($response));
        return;
     }
     // retrive otp from the sesison
     $otp_session_data = $this->session->tempdata('temp_password');
     if(!$otp_session_data){
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($response));
       return;
     }
     $user_otp = trim($this->input->post('otp'));
     if($user_otp != $otp_session_data){
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
     }
     $user_data = $this->session->tempdata('user_info');
      if(!$user_data){
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
      }
      $this->session->set_tempdata('otp_status', true, (60 * 10));
      // if success then true status
       $response['status'] = true;
       $response['data'] = $user_data;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($response));
       return;
     }


    public function newForgetPasswordActionSubmit(){
    	$response = array();
    	$response['status'] = true;
    	$response['data'] = array();
		  if($this->session->tempdata('otp_status') !== true){
  			$response['data']['otp_Status'] = false ;
  			$this->output->set_content_type('application/json');
  			$this->output->set_output(json_encode($response));
  			return;
		  }
		  $user_info = $this->session->tempdata('user_info');

		  if(empty($user_info)){
  			$response['error']['message'] = 'Access Denied' ;
  			$response['status'] = false;
  			$this->output->set_content_type('application/json');
  			$this->output->set_output(json_encode($response));
  			return;
		  }
   		$username = $user_info['username'];
     	$this->load->library('form_validation');
     	$this->form_validation->set_rules('confirmNewPassword', 'Confirm New Password', 'trim|required|matches[newPassword]');

     	// validate new password
     	$this->form_validation->set_rules('newPassword', 'New Password', array('trim','required', 'min_length[6]',
        array('isValidNewPassword', function($new_password){
          // if new password is empty then other validation method will complain
      if(empty($new_password)){
          return true;
      }
      // check atleast one special character
      $special_character = '/[\'^£$%&*()}{@#~?><>,|=_+¬-]/';
      if(preg_match($special_character, $new_password, $match) === 0){
        $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast  one special character');
        return false;
      }
      // check atleast one numeric data
      $alpha_character = '/[a-zA-Z]/';
      if(preg_match($alpha_character, $new_password, $match) === 0){
        $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast one Alphanumeric');
        return false;
      }
      $numeric_character = '/[\d]/';
      if(preg_match($numeric_character, $new_password, $match) === 0){
        $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast  one Alphanumeric');
        return false;
      }
        return true;
         })
     	));

     	if($this->form_validation->run() == false){
	       $this->response['status'] = true;
	       $this->response['errors'] = $this->form_validation->error_array();
	       $this->output->set_content_type('application/json');
	       $this->output->set_output(json_encode($this->response));
	       return;
     	}

     	// update new password
     	$new_password = hash('sha256', $this->input->post('newPassword'));
     	try{
     	 $status = TsbApp\Authentication\AuthenticationService::changePassword($username, $new_password);
     	}catch(Exception $e){
	       $this->response['status'] = false;
	       $this->response['error']['message'] = 'Somthing went wrong!';
	       $this->output->set_content_type('application/json');
	       $this->output->set_output(json_encode($this->response));
	       return;
     	}
     if($status){
       $this->session->unset_tempdata('user_info');
       $this->session->unset_tempdata('temp_password');
       $this->response['status'] = true;
       $this->response['data']['passwordChanged'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
   }




     /**
      * Reset Credentials
      * reset password and transation key
      * This process will run when user try to login first time
      */
     public function resetCredentials(){
       // check reset Credentials session is active

       $reset_user_credentials = $this->session->tempdata('resetCredentials');
       if(!$reset_user_credentials ||  (!$reset_user_credentials && $reset_user_credentials['resetCredentials'] == true) ){
         show_error('No Permission', 403, 'You dont have permission');
         return;
       }

       $username = $reset_user_credentials['username'];
       // get user details from username
       $user = new TsbApp\Domain\User\User();
       try{
         $user_entity = $user->getUserByusername($username);
       }catch(Exception $e){
         show_error('Error Occured', 500, 'Sorry Somthing went wrong');
         return;
       }
       // check user change password or change transation key is set to flag 'Y'
       if(($user_entity->getChangePassword() != 'Y' && $user_entity->getTransactionKeyChanged() != 'Y')){
         show_error('No Permission', 403, 'You dont have permission');
         return;
       }

       $page_name = 'resetCredentials';
       $data['page_name'] = $page_name;
       $this->load->view('public/main', $data);
       return;
     }

     /**
      * Reset Password aciton
      *
      */
     public function resetCredentialsAction(){
       $output = array();
       $output['status'] = true;
       $output['error'] = array();
       $output['data'] = array();
       // check reset Credentials session is active
       $reset_user_credentials = $this->session->tempdata('resetCredentials');

       if(!$reset_user_credentials ||  !($reset_user_credentials && $reset_user_credentials['resetCredentials'] == true) ){
         $output['status'] = false;
         $output['error']['code'] = null;
         $output['error']['message'] = 'Access Denied';
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($output));
         return;
       }

       $username = $reset_user_credentials['username'];
       // get user details from username
       $user = new TsbApp\Domain\User\User();
       try{
         $user_entity = $user->getUserByusername($username);
       }catch(Exception $e){
         $output['status'] = false;
         $output['error']['code'] = null;
         $output['error']['message'] = 'Somthing Went Wrong!';
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($output));
         return;
       }
       // check user change password or change transation key is set to flag 'Y'
       if(($user_entity->getChangePassword() != 'Y' && $user_entity->getTransactionKeyChanged() != 'Y')){
         $output['status'] = false;
         $output['error']['code'] = null;
         $output['error']['message'] = 'Access Denied';
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($output));
         return;
       }

       // validation start here
       $this->load->library('form_validation');
       $this->form_validation->set_rules("loginNewPassword", 'New Login Password', array('trim', 'required',
          array('isValidNewLoginPassword', function($loginNewPassword){
              // if empty then other validation method will trigger
              if(empty($loginNewPassword)){
                  return true;
              }
              // check password contain at least one lowercase character
              if(!preg_match('/[a-z]+/', $loginNewPassword)){
                $this->set_message('isValidNewLoginPassword', '{field} field must contain atleast one lowercase character');
                return false;
              }
              // check password contain at least one uppercase character
              if(!preg_match('/[A-Z]+/',$loginNewPassword)){
                $this->form_validation->set_message('isValidNewLoginPassword', '{field} field must contain atleast one Uppercase character');
                return false;
              }

              // check password contain at least one digit
              if(!preg_match('/["!"#$%&\'()*+,-.\/:;<=>?@[\]^_`{|}~"]+/', $loginNewPassword)){
                $this->set_message('isValidNewLoginPassword', '{field} field must contain atleast one special character');
                return false;
              }

              return true;

          })
       ));
       $this->form_validation->set_rules("confirmNewLoginPassword", 'Confirm New Login Password', 'trim|required|matches[loginNewPassword]');
       $this->form_validation->set_rules("newTransKey", 'New Transaction Key', array('trim', 'required', 'differs[loginNewPassword]',
          array('isValidTransKey', function($trans_key){
              // if trans key is empty then other validation method will handle
              if(empty($trans_key)){
                  return true;
              }
              // check password contain at least one lowercase character
              if(!preg_match('/[a-z]+/', $trans_key)){
                $this->set_message('isValidTransKey', '{field} field must contain atleast one lowercase character');
                return false;
              }
              // check password contain at least one uppercase character
              if(!preg_match('/[A-Z]+/',$trans_key)){
                $this->form_validation->set_message('isValidTransKey', '{field} field must contain atleast one Uppercase character');
                return false;
              }
              // check password contain at least one digit
              if(!preg_match('/["!"#$%&\'()*+,-.\/:;<=>?@[\]^_`{|}~"]+/', $trans_key)){
                $this->set_message('isValidTransKey', '{field} field must contain atleast one special character');
                return false;
              }
              return true;
          })
       ));
       $this->form_validation->set_rules("confirmNewTransKey", 'Confirm New Transaction Key', 'trim|required|matches[newTransKey]');

       if($this->form_validation->run() === false){
          $output['status'] = true;
          $output['errors'] = $this->form_validation->error_array();
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($output));
          return;
       }

       // update new login password
       try{
         $password_change_status = TsbApp\Authentication\AuthenticationService::changePassword($username, hash('sha256', $this->input->post('loginNewPassword')));
       }catch(Exception $e){
          $output['status'] = true;
          $output['error']['message'] = 'Somthing went wrong!!';
          $output['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($output));
          return;
       }
       if(!$password_change_status ){
          $output['status'] = true;
          $output['error']['message'] = 'Unable to update password';
          $output['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($output));
          return;
       }


       // update new transaction Key
       try{
         $trans_key_change_status = TsbApp\Authentication\AuthenticationService::newTransactionKey($username, hash('sha256', $this->input->post('newTransKey')));
       }catch(Exception $e){
          $output['status'] = true;
          $output['error']['message'] = 'Somthing went wrong!!';
          $output['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($output));
          return;
       }
       if(!$trans_key_change_status){
          $output['status'] = true;
          $output['error']['message'] = 'Unable to update Transaction Key';
          $output['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($output));
          return;
       }
       $this->session->unset_tempdata('resetCredentials');
       $output['status'] = true;
       $output['data']['resetCredentials'] = true;
       $output['error']['message'] = null;
       $output['error']['code'] = null;
       $output['errors'] = null;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($output));
       return;
     }


     /**
      * New user registration
      *
      */
     public function registerNewUser(){
       $data = array();
       $data["page_name"] = "new_user_registration";
       $this->load->view("public/main",$data);
     }


     /**
      * User registration action level 1
      *
      */
     public function registrationActionLevel1(){
        $response = array();
        $this->load->model('user_model');
        $this->load->model('account_model');
        $this->load->library('form_validation');
        $accNo = $this->input->post('level_1_tsb_account_number');
        $this->form_validation->set_rules('level_1_confirm_tsb_account_number', 'Confirm TSB Account Number', 'trim|required|matches[level_1_tsb_account_number]|max_length[18]',
        array( 'matches' => 'TSB A/C No does not match')
        );
        $this->form_validation->set_rules('level_1_aadhar_number', 'Aadhar Number', array('trim','required','numeric','exact_length[12]',
          array('isValidAadhaar', function($aadhaar_no) use($accNo){
              // other validation method will deal if empty
              if(empty($aadhaar_no)){
                  return true;
              }
              $account_details = $this->account_model->getAccountDetails($accNo);
              // check account number exists
              if(!is_array($account_details)){
                  $this->form_validation->set_message('isValidAadhaar', 'Invalid Aadhaar No');
                  return false;
              }
              if($account_details[0]['AADHAR'] != $aadhaar_no){
                $this->form_validation->set_message('isValidAadhaar', 'Invalid Aadhaar No');
                return false;
              }
              return true;
          })

        ));
        $this->form_validation->set_rules('level_1_email', 'Email', array('trim', 'valid_email'), array('valid_email' => 'Enter a valid Email Address'));

        // validate account number
        $this->form_validation->set_rules('level_1_tsb_account_number', 'Tsb Account Number', array('trim', 'required','max_length[18]',

          array('check_account_number', function($accNo){
              // if account number is empty then other validation will fire
              if(empty($accNo)){
                  return true;
              }
              $account_details = $this->account_model->getAccountDetails($accNo);
              // check account number exists
              if(!is_array($account_details)){
                  $this->form_validation->set_message('check_account_number', 'Invalid account number');
                  return false;
              }

              // check account holder customer has already created online TSB ACCOUNT
              $user =  $this->user_model->getUserByCustomerId($account_details[0]['CUSTOMER_ID']);
              // if any error occured
              if($user === false){
                  $this->form_validation->set_message('check_account_number', 'Somthing went wrong');
                  return false;
              }
              // if user exists
              if(is_array($user)){
                $this->form_validation->set_message('check_account_number', 'This {field} is already linked with an online account');
                return false;
              }
              return true;
          })

        ));

        // validate usernaem
        $this->form_validation->set_rules('level_1_username', 'Username', array('trim','required','alpha_numeric','min_length[5]',
          array('check_username_exists', function($username){

            // if empty username
            if(empty($username)){
                $this->form_validation->set_message('check_username_exists', '{field} required');
                return false;
            }
            // if username exists
            try{
              $result = $this->user_model->usernameExists($username);
            }catch(Exception $e){
                $this->form_validation->set_message('check_username_exists', 'Something went wrong');
                return false;
            }
            if($result == true){
              $this->form_validation->set_message('check_username_exists', '{field} already exists');
              return false;
            }
            return true;
          })
        ));


        // validate mobile number
        $this->form_validation->set_rules('level_1_mobile_number', 'Mobile Number', array('trim', 'required', 'numeric',
          array('check_mobile_number', function($mobile_number){
            // if empty then other validation method will deal
            $accNo = $this->input->post('level_1_tsb_account_number');
            if(empty($mobile_number) || empty($accNo)){
                return true;
            }
            // check mobile number is linked with account
            $account_details = $this->account_model->getAccountDetails($accNo);
            // check account number exists
            if(!is_array($account_details)){
                return true;;
            }

            if($mobile_number != $account_details[0]['MOBILE_NO']){
                $this->form_validation->set_message('check_mobile_number', 'This {field} is not linked with given account');
                return false;
            }
            return true;
          })
        ));

        $response['status'] = false;
        $response['error'] = array();
        $response['errors'] = array();
        if($this->form_validation->run() === false){
          $response['errors'] = $this->form_validation->error_array();
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
        }
        $account_details = $this->account_model->getAccountDetails($this->input->post('level_1_tsb_account_number'));
        if(!is_array($account_details) || is_array($account_details) && count($account_details) == 0 ){
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
        }
        $data = array();
        $data['accNo'] = trim($this->input->post('level_1_tsb_account_number'));
        $data['aadharNo'] = trim($this->input->post('level_1_aadhar_number'));
        $data['mobileNo'] = trim($this->input->post('level_1_mobile_number'));
        $data['email'] = trim($this->input->post('level_1_email'));
        $data['username'] = trim($this->input->post('level_1_username'));
        $data['name'] = (empty($account_details[0]['NAME']))?  'User' :
        (strlen($account_details[0]['NAME']) > 8)? substr($account_details[0]['NAME'], 0, 8).".." : $account_details[0]['NAME'] ;
        $data['customerId'] = $account_details[0]['CUSTOMER_ID'];
        $this->session->set_tempdata('new_user_info',$data,(60 * 10));
        if(ENVIRONMENT == "production"){
          $otp = mt_rand(10000, 99999);
        }else{
          $otp = 12345;
        }
        $message = " OTP for TSBONLINE ".$otp;
        $this->session->set_tempdata('register_otp', $otp, (60 * 10));
        if(ENVIRONMENT == "production"){
          send_otp($data['mobileNo'], $message);
        }
        $response['status'] = true;
        $response['data'] = $data;
        $response['otp'] = true;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($response));
        return;
     }


     public function vefiryRegistrationOtp(){

       $response['status'] = false;
       $response['error']['message'] = '';
       $response['error']['code'] = null;
       $response['data'] = array();
       $response['errors'] = array();
       $this->load->library('form_validation');
       $this->form_validation->set_rules('otp', 'Otp', 'required');

       // retrive otp from the sesison
       $otp_session_data = $this->session->tempdata('register_otp');
       if(!$otp_session_data){
         $response['status'] = true;
         $response['error']['message'] = 'Access Denied';
         $response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
       }
       // Check user information is avaliable in the session
       $user_data = $this->session->tempdata('new_user_info');
       if(!$user_data){
         $response['status'] = true;
         $response['error']['message'] = 'Access Denied';
         $response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
       }

       // validate request
       if($this->form_validation->run() === false){
          $response['status'] = true;
          $response['errors'] = $this->form_validation->error_array();
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($response));
          return;
       }

       $user_otp = trim($this->input->post('otp'));
       if($user_otp != $otp_session_data){
         $response['status'] = true;
         $response['error']['message'] = 'Invalid Otp';
         $response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
       }

       $this->load->model('user_model');
       $save_user_status = $this->user_model->saveUser($user_data);
       //  check user is saved to the database
       if($save_user_status !== true){
         $response['error']['message'] = 'Somthing Went wrong';
         $response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($response));
         return;
       }

       // if success then true status
       $response['status'] = true;
       $response['data']['userData'] = $user_data;
       $response['data']['registrationSuccess'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($response));
       return;
     }


     /**
      * Find Valid username
      *
      */
     public function findValidUserName(){
      $response = array();
      $this->load->library('form_validation');
      $this->form_validation->set_rules('level_1_username', 'Username', array('trim','required','alpha_numeric','min_length[5]',
        array('check_username_exists', function($username){
          // if empty username
          if(empty($username)){
              $this->form_validation->set_message('check_username_exists', '{field} required');
              return false;
          }
          // if username exists
          $this->load->model('user_model');
          try{
            $result = $this->user_model->usernameExists($username);
          }catch(Exception $e){
              $this->form_validation->set_message('check_username_exists', 'Something went wrong');
              return false;
          }
          if($result == true){
            $this->form_validation->set_message('check_username_exists', '{field} already exists');
            return false;
          }
          return true;
        })
      ));

      $response['status'] = false;
      $response['error'] = array();
      $response['errors'] = array();
      if($this->form_validation->run() == false){
        $response['errors'] = $this->form_validation->error_array();
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($response));
        return;
      }
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($response));
      return;
     }

     public function test(){
       $this->load->model('Fund_transaction_model');
      var_dump($this->Fund_transaction_model->transactionId(1));
      // send_otp('8089275598', "Hai there 12367 ");
     }

     public function testotp(){
       $config = $this->config->item('beneficiary', 'app_config');
       $this->load->library('OtpManager');
       $this->otpmanager->setConfig($config);
       $this->otpmanager->setModel('account_model', 'getTreasuryInfo');
       $this->otpmanager->setData('9901');
       $this->otpmanager->setSuccessMessage("tesing done");
       $this->otpmanager->setUsername("aswathy");
       $this->otpmanager->setMobileNumber("8089275598");
       var_dump($this->otpmanager->processOtp());
     }

     public function verifyOtp(){
       $this->load->library('OtpManager');
       var_dump($this->otpmanager->verifyOtp('30468'));
       var_dump($this->otpmanager->getError());
       var_dump($this->otpmanager->getModelName());
       var_dump($this->otpmanager->getModelMethodName());
       var_dump($this->otpmanager->getData());
       $this->load->model($this->otpmanager->getModelName());
       $model_name = $this->otpmanager->getModelName();
       $method_name = $this->otpmanager->getModelMethodName();
       $data = $this->otpmanager->getData();
       $this->load->model($model_name);
       var_dump(call_user_func_array(array($this->$model_name,$method_name), array($data)));
     }

     public function cntrl(){
       $benf = APPPATH.'/controllers/Private/BeneficiaryController.php';
       require_once($benf);
       var_dump( new BeneficiaryController());

       //$this->beneficiarycontroller->test();
     }

}





?>

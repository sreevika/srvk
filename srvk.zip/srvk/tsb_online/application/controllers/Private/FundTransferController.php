<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Fund Transaction  Controller
 * Created by : Sreevika VS
 * Created at : 22-11-2017
 * Updated by : Fahad A
 * Updated at : 07-02-2018
 */
 class FundTransferController extends CI_Controller{


   public $customer;

   public $user;

   public $response;

   public function __construct(){
     parent::__construct();
     $this->load->model("beneficiary_model");
     $this->load->model("account_model");
     $this->load->model('fund_transaction_model');
     $this->init();
   }

    public function init(){
       $this->response = [
          'status' => false,
          'loginStatus' => true,
          'data' => [],
          'error' => [],
        ];

        try{
          $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
          if($user){
            $customer = $user->getCustomer();
          }
        }catch(Exception $e){
          // If ajax request
          if($this->input->is_ajax_request()){
            header('Content-Type: application/json');
            echo json_encode($output);
            exit;
          }
          // for normal http request show error page
          show_error('Sorry something went wrong '.$e->getMessage(), 500);
        }
      if($user){
        $this->user = $user;
        $this->customer = $customer;
      }
    }





    /**
    * TSB Accounts Transfer Controller
    *
    */

   public function intraBankTransfer(){
     $data = array();
     $account = array();

     $savingsAccounts = $this->account_model->getCustomerSavingsAccounts($this->user->getCustomerId());
     $intrabank_beneficiaries = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($this->user->getCustomerId());

     if($savingsAccounts == false ){
     $this->response['error'] = $this->account_model->getFirstError();
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
     }

      // savings account processing
      $savingsAccountData = array();
      $siNo = 1;
      foreach($savingsAccounts as $v){
        $single_account = array();
        $single_account['siNo'] = $siNo;
        $single_account['accNo'] = $v['ACCNO'];
        $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
        $single_account['accTrcode'] = $v['BRANCH_TRCODE'];
        $single_account['accBal'] =  $v['SCRT_BAL'];
        $siNo++;
        $savingsAccountData[] = $single_account;
      }
      $account['savingsAccounts'] = $savingsAccountData;

      //Intra bank Beneficiary Processing
      $intrabank_beneficiary_list = array();
      $siNo = 1;
      foreach($intrabank_beneficiaries as $v){
        $intrabank_beneficiary = array();
        $intrabank_beneficiary['slNo'] = $siNo;
        $intrabank_beneficiary['benfAccNo'] = $v['BENEFICIARY_ACCNO'];
        $intrabank_beneficiary['benfName'] = $v['BENEFICIARY_NAME'];
        $intrabank_beneficiary['transLimit'] = $v['TRANSACTION_LIMIT'];
        $intrabank_beneficiary['benfId'] = $v['BENEFICIARY_ID'];
        $siNo++;
        $intrabank_beneficiary_list[] = $intrabank_beneficiary;
      }
      $account['intraBankBeneficiaries'] = $intrabank_beneficiary_list;


     $data["page_name"] = "fund_transfer/intra_bank_fund_transfer.php";
     $this->response['data']['template'] = $this->load->view("private/pages/fund_transfer/intra_bank_fund_transfer",null, true);
     $this->response['data']['accountList'] = $account;
     $this->response['status'] = true;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
   }


   /**
    * Intra Fund tranasfer
    *
    */
    public function intraFundTransfer(){


        $this->load->library('form_validation');
        $this->form_validation->set_rules('remark', 'Remark', 'trim|max_length[100]');
        $this->form_validation->set_rules('paymentOption', 'Payment Option', 'trim|required|in_list[PN,SL]');
        $this->form_validation->set_rules('transType', 'Transaction Type', 'trim|required|in_list[I,O]');
        if($this->input->post('paymentOption') == 'SL'){
          $this->form_validation->set_rules('scheduleDate', 'Schedule date', array('trim', 'required',
            array('checkValidDate', function($data){
                // check data is correct
                $schedule_date = DateTime::createFromFormat('d/m/Y', $data);
                // check data is correct format
                if($schedule_date === false){
                  $this->form_validation->set_message('checkValidDate', 'Invalid {field}');
                  return false;
                }
                // check data is greater than today
                $today_date = new DateTime();
                if($schedule_date <= $today_date){
                  $this->form_validation->set_message('checkValidDate', '{field} Must be greater than today');
                  return false;
                }
                // check maximun date limit
                $maximum_date_limit = (new DateTime())->add(new DateInterval('P3M'));
                if($schedule_date > $maximum_date_limit){
                  $this->form_validation->set_message('checkValidDate', '{field} Must be less than 3 Months');
                  return false;
                }
                return true;

            })
          ));
        }
        $this->load->model('account_model');
        $this->load->model('beneficiary_model');

        // customer savings acocunt list
        $customer_savings_accounts = $this->account_model->getCustomerSavingsAccounts($this->user->getCustomerId());

        // customer benefiarys
        $customer_beneficiarys = null;
        if($this->input->post('transType') == 'I'){
          $customer_beneficiarys = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($this->user->getCustomerId());
        }
        if($this->input->post('transType') == 'O'){
          $customer_beneficiarys = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($this->user->getCustomerId());
        }
        // user id
        $user_id = $this->user->getId();
        // validate account number
        $this->form_validation->set_rules('accNo', 'Account Number', array('trim','required',
          array('check_account_number', function($accNo) use($customer_savings_accounts){
            // check account number is not empty
            if(empty($accNo)){
                $this->form_validation->set_message('check_account_number', '{field} is required');
                return false;
            }
            // check accounts exists for the customer
            if(!is_array($customer_savings_accounts) || empty($customer_savings_accounts)){
              $this->form_validation->set_message('check_account_number', 'Invalid {field}');
              return false;
            }
            // check account number in the customer savings list
            $filtered_account = array_filter($customer_savings_accounts, function($v) use($accNo){
                return ($v['ACCNO'] == $accNo);
            });

            if(count($filtered_account) == 0){
              $this->form_validation->set_message('check_account_number', 'Invalid {field}');
              return false;
            }
            return true;
          })

        ));

        // validate amount
        $this->form_validation->set_rules('amount', 'Amount', array('trim','required','numeric',
          array('check_valid_amount', function($amount) use($customer_savings_accounts, $customer_beneficiarys){
            $accNo = $this->input->post('accNo');
            // if payment option is not pay now then no need  further custom validation
            if($this->input->post('paymentOption') != 'PN'){
                return true;
            }

            // check accounts exists for the customer
            if(!is_array($customer_savings_accounts) || empty($customer_savings_accounts)){
              $this->form_validation->set_message('check_valid_amount', 'Invalid {field}');
              return false;
            }
            // check account number in the customer savings list
            $filtered_account = array_filter($customer_savings_accounts, function($v) use($accNo){
                if(($v['ACCNO'] == $accNo)){
                    return true;
                }
            });
            if( !is_array($filtered_account) || count($filtered_account) == 0){
              $this->form_validation->set_message('check_valid_amount', 'Invalid {field}2');
              return false;
            }
            $filtered_account = array_pop($filtered_account);
            // check account balance is enough
            if($amount > $filtered_account['LEDGER_BAL']){
              $this->form_validation->set_message('check_valid_amount', 'Insufficient Account Balance');
              return false;
            }

            // check minimum balance for the account
            $minbal = $this->fund_transaction_model->getMinimumAccBalForAccType($filtered_account['ACCTYPE'], $filtered_account['FACILITY']);
            if($minbal == false || $minbal == null){
              $this->form_validation->set_message('check_valid_amount', 'Somthing went wrong');
              return false;
            }
            $balance = ($filtered_account['LEDGER_BAL'] - $amount);
            if($balance <= $minbal){
              $this->form_validation->set_message('check_valid_amount', 'You must keep minimum balance '.$minbal);
              return false;
            }

            // check beneficiary transter limit
            if(!is_array($customer_beneficiarys) || is_array($customer_beneficiarys) && count($customer_beneficiarys) == 0){
              $this->form_validation->set_message('check_valid_amount', 'Invalid {field}');
              return;
            }
            // check beneficiary id in the benefiary list
            $benf_id = $this->input->post('benfId');
            $filtered_beneficiary = array_filter($customer_beneficiarys, function($v) use($benf_id){
                return ($v['BENEFICIARY_ID'] == $benf_id);
            });
            if(count($filtered_beneficiary) == 0){
              $this->form_validation->set_message('check_valid_amount', 'Invalid {field}');
              return false;
            }
            $filtered_beneficiary = array_pop($filtered_beneficiary);
            if($amount > $filtered_beneficiary['TRANSACTION_LIMIT']){
              $this->form_validation->set_message('check_valid_amount', '{field} Greater than Transaction Limit');
              return false;
            }
            return true;

          })
        ));

        // Check beneficiary id is correct
        $this->form_validation->set_rules('benfId', 'Beneficiary Account', array('trim','required',

          array('check_valid_benfId', function($benf_id) use($customer_beneficiarys){

            // check beneficiary id is empty
            if(empty($benf_id)){
              $this->form_validation->set_message('check_valid_benfId', '{field} is required');
              return false;
            }
            if(!is_array($customer_beneficiarys) || is_array($customer_beneficiarys) && count($customer_beneficiarys) == 0){
              $this->form_validation->set_message('check_valid_benfId', 'Invalid {field}');
              return;
            }
            // check beneficiary id in the benefiary list
            $filtered_beneficiary = array_filter($customer_beneficiarys, function($v) use($benf_id){
                return ($v['BENEFICIARY_ID'] == $benf_id);
            });
            // if count greater than 0 then benefiiary exists
            if(count($filtered_beneficiary) == 0){
              $this->form_validation->set_message('check_valid_benfId', 'Invalid {field}');
              return false;
            }
            return true;
          })

         ));

         // Validate transaction password
         $this->form_validation->set_rules('transPassword', 'Transaction Password', array('trim','required',

          array('check_transaction_password', function($transaction_password) use($user_id){
              // check transaction password is empty
              if(empty($transaction_password)){
                  $this->form_validation->set_message('check_transaction_password', 'Incorrect {field}');
                  return false;
              }
              // check password in database
              $hashed_password = hash('sha256', $transaction_password);
              $status = \TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $hashed_password);
              if(!$status){
                $this->form_validation->set_message('check_transaction_password', 'Incorrect {field} ');
                return false;
              }
              return true;
          })

        ));


        // check form is valid
        if($this->form_validation->run() === false){
          $this->response['errors'] = $this->form_validation->error_array();
          $this->response['status'] = false;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }




        $data = array();
        $data['accNo'] = trim($this->input->post('accNo'));
        $data['benfId'] = trim($this->input->post('benfId'));
        $data['amount'] = number_format(trim($this->input->post('amount')),2,'.', '');
        $data['paymentOption'] = trim($this->input->post('paymentOption'));
        $data['remark'] = trim($this->input->post('remark'));
        $data['transType'] = trim($this->input->post('transType'));
        $data['username'] = $this->user->getuserName();
        $data['customerId'] = $this->user->getCustomerId();
        $schedule_date = $this->input->post('scheduleDate');
        if(!empty($schedule_date)){
          $data['scheduleDate'] =   DateTime::createFromFormat('d/m/Y', $schedule_date )->format('Y-m-d H:i:s.u');
        }else{
          $data['scheduleDate'] = (new DateTime())->format('Y-m-d H:i:s.u');
        }
        //$data['scheduleDate'] = ( !empty($this->input->post('scheduleDate')))?  DateTime::createFromFormat('d/m/Y', $this->input->post('scheduleDate') )->format('Y-m-d H:i:s:u') : new DateTime()->format('Y-m-d H:i:s:u');
       $fundtransfer_config = $this->config->item('fundtransfer', 'app_config');
           if($fundtransfer_config['otp'] == true){
             $this->response['status'] = true;
             $this->response['data']['otpManager'] = true;
             $this->load->library('otpManager');
             $this->otpmanager->setConfig($fundtransfer_config);
             $this->otpmanager->setData($data);
             $this->otpmanager->setUsername($this->user->getUsername());
             $this->otpmanager->setMobileNumber($this->user->getMobile());
             if($this->otpmanager->processOtp()){
            // if(true){
                $this->response['data']['otpManager'] = true;
                $this->response['data']['otpVerificationUrl'] = base_url().'fund-transfer/verifyOtpForFundTransaction';
                $this->output->set_content_type('application/json');
                $this->output->set_output(json_encode($this->response));
                return;
             }
            $error = $this->otpmanager->getError();
             $this->response['status'] = true;
             $this->response['error']['message'] = (!empty($error))? $error : "Somthing Went Wrong!";
             $this->response['error']['code'] = null;
             $this->output->set_content_type('application/json');
             $this->output->set_output(json_encode($this->response));
             return;
            }
           $this->verifyOtpForFundTransaction($data, false);

        }

   public function verifyOtpForFundTransaction($data = null, $validation = true){

       if($validation  == true){
       $this->load->library('otpManager');
       $this->load->library('form_validation');
       $this->form_validation->set_rules('otp', 'Otp', array('required',
         array('isValidOtp', function($otp){
           // other validation method will show erro
           if(empty($otp)){
             return true;
           }
           if(!$this->otpmanager->verifyOtp($otp)){
             $error = $this->otpmanager->getError();
             $this->form_validation->set_message('isValidOtp', ($error) ? $error : 'Invalid Otp' );
             return false;
           }
           return true;
         })
       ));
       // check form validation error
       if($this->form_validation->run() === false){
         $this->response['errors'] = $this->form_validation->error_array();
         $this->response['status'] = true;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
       }
       $data = $this->otpmanager->getData();
     }

        $this->load->model('fund_transaction_model');
        $status = $this->fund_transaction_model->fundTransferManager($data);
        if($status == true){
          $this->response['status'] = true;
        }
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
    }

    /**
    * Other Bank Accounts Transfer Controller
    *
    */
   public function interBankTransfer(){
     $data = array();
     $account = array();

     $savingsAccounts = $this->account_model->getCustomerSavingsAccounts($this->user->getCustomerId());
     $interbank_beneficiaries = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($this->user->getCustomerId());

     if($savingsAccounts == false ){
     $this->response['error'] = $this->account_model->getFirstError();
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
     }

      // savings account processing
      $savingsAccountData = array();
      $siNo = 1;
      foreach($savingsAccounts as $v){
        $single_account = array();
        $single_account['siNo'] = $siNo;
        $single_account['accNo'] = $v['ACCNO'];
        $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
        $single_account['accTrcode'] = $v['BRANCH_TRCODE'];
        $single_account['accBal'] =  $v['SCRT_BAL'];
        $siNo++;
        $savingsAccountData[] = $single_account;
      }
      $account['savingsAccounts'] = $savingsAccountData;

      //Inter bank Beneficiary Processing
      $interbank_beneficiary_list = array();
      $siNo = 1;
      foreach($interbank_beneficiaries as $v){
        $interbank_beneficiary = array();
        $interbank_beneficiary['slNo'] = $siNo;
        $interbank_beneficiary['benfAccNo'] = $v['BENEFICIARY_ACCNO'];
        $interbank_beneficiary['benfName'] = $v['BENEFICIARY_NAME'];
        $interbank_beneficiary['bankName'] = $v['BANK_NAME'];
        $interbank_beneficiary['branch'] = $v['BRANCH_NAME'];
        $interbank_beneficiary['ifsCode'] = $v['IFS_CODE'];
        $interbank_beneficiary['transLimit'] = $v['TRANSACTION_LIMIT'];
        $interbank_beneficiary['benfId'] = $v['BENEFICIARY_ID'];
        $siNo++;
        $interbank_beneficiary_list[] = $interbank_beneficiary;
      }
      $account['interBankBeneficiaries'] = $interbank_beneficiary_list;


     $data["page_name"] = "fund_transfer/inter_bank_fund_transfer.php";
     $this->response['data']['template'] = $this->load->view("private/pages/fund_transfer/inter_bank_fund_transfer",null, true);
     $this->response['data']['accountList'] = $account;
     $this->response['status'] = true;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));

   }

   /**
    * Transaction History main page
    *
    */
   public function transactionHistory(){
    $customer_id = $this->user->getCustomerId();
    // get transction history from tsb database
    // for getting other bank transaction status via coretis database
    $trans_history = $this->fund_transaction_model->getFundTransactionHistrory($customer_id);
    if(!is_array($trans_history)){
      $this->response['status'] = false;
      $this->response['error']['message'] = "Somthing went wrong";
      $this->response['error']['code'] = null;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }

    // create ekuber transaction id collection
    $customer_accounts_num = array();

    foreach($trans_history as $trans){
      if($trans['SOURCE_ACCNO']){
        $customer_accounts_num[] = $trans['SOURCE_ACCNO'];
      }
    }
    $unique_customer_accounts_num  = array_unique($customer_accounts_num);

    $coretis_tsb_to_bank_trans = array();
    if($unique_customer_accounts_num){
        $coretis_tsb_to_bank_trans = $this->fund_transaction_model->getCoretisTsbToBankLast3MonthsTransFromSourceAccnos($unique_customer_accounts_num);
        if(!is_array($coretis_tsb_to_bank_trans)){
          $this->response['status'] = false;
          $this->response['error']['message'] = "Somthing went wrong";
          $this->response['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
    }

    foreach($coretis_tsb_to_bank_trans as $coretis_trans){
        array_walk($trans_history, function(&$val, $ind, $coretis_trans_det){
          if(trim($coretis_trans_det['TRANSACTION_ID']) == trim($val['EKUBER_TRANS_ID'])){
            $val['EKUBER_ACK_STATUS'] = $coretis_trans_det['ACK_STATUS'];
            $val['EKUBER_DN_STATUS'] = $coretis_trans_det['DN_STATUS'];
            $val['EKUBER_RN_STATUS'] = $coretis_trans_det['RN_STATUS'];
            $val['EKUBER_CN_STATUS'] = $coretis_trans_det['CN_STATUS'];
            $val['EKUBER_RECORD_PROCESSED'] = $coretis_trans_det['RECORD_PROCESSED'];
          }
        }, $coretis_trans);
    }

    // Build data for output
    $output = array();
    foreach($trans_history as $trans_data){
        $out = array();
        $out['transDate'] = (!empty($trans_data['TRANS_DATE']))? switch_date_format($trans_data['TRANS_DATE'],'Y-m-d', 'd/m/Y') : null;
        $out['sourceAccNo'] = $trans_data['SOURCE_ACCNO'];
        $out['amount'] = $trans_data['AMOUNT'];
        $out['transId'] = $trans_data['TRANSACTION_ID'];
        $out['transType'] = (isset($trans_data['EKUBER_DEST_ACCNO']))? 'Other Bank Transaction' : "TSB Transaction";
        $out['destnationAccNo'] = (isset($trans_data['RECPT_DEST_ACCNO']) && $trans_data['RECPT_DEST_ACCNO'])? $trans_data['RECPT_DEST_ACCNO'] :  (( isset($trans_data['EKUBER_DEST_ACCNO']) && $trans_data['EKUBER_DEST_ACCNO'] )? $trans_data['EKUBER_DEST_ACCNO'] : null);
        $out['receivedDate'] = ( isset($trans_data['RECPT_RECEIVED_DATE']) && $trans_data['RECPT_RECEIVED_DATE'])? $trans_data['RECPT_RECEIVED_DATE'] : ((isset($trans_data['EKUBER_RECEIVED_DATE']) && $trans_data['EKUBER_RECEIVED_DATE'])? $trans_data['EKUBER_RECEIVED_DATE'] : null);
        if(isset($trans_data['EKUBER_ACK_STATUS'])){
            switch($trans_data['EKUBER_ACK_STATUS']){

              case 'RJCT':
                $status = "Rejected";
                break;

              case 'ACCP':

                if($trans_data['EKUBER_DN_STATUS'] == 'BANKAPIFAILED'){
                  $status = "Failed";
                }
                if($trans_data['EKUBER_DN_STATUS'] == 'RETURN'){
                  $status = "Failed";
                }else if($trans_data['EKUBER_DN_STATUS'] == 'SETTLED'){
                  $status = "Completed";
                }else if($trans_data['EKUBER_DN_STATUS'] == 'DELIVERED' && empty($trans_data['EKUBER_RN_STATUS']) || empty($trans_data['EKUBER_CN_STATUS'])){
                  $status = 'Failed';
                }else{
                  $status = 'Processing';
                }
                break;

              default:
                $status = "Failed";
                break;
            }
        }else{
          if($trans_data['RECPT_RECEIVED_DATE']){
            $status = 'Completed';
          }else{
            $status = 'Processing';
          }
        }
        // if transfer type is schedule later then schedule status
        if($trans_data['TRANS_OPTION'] == 'SL_DATA'){
            $status = "Scheduled";
        }
        $out['status'] = $status;
        $output[] = $out;
    }

    $data["page_name"] = "account_statement/index.php";
    $this->response['data']['template'] = $this->load->view("private/pages/fund_transfer/transaction_history",null, true);
    $this->response['data']['transHist'] = $output;
    $this->response['status'] = true;
    $this->output->set_content_type('application/json');
    $this->output->set_output(json_encode($this->response));
    return;

   }

 }
?>

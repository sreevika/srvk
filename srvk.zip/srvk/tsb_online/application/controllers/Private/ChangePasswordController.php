<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Account Statement Controller
 * Created by : Sreevika VS
 * Created at : 22-11-2017
 */
 class ChangePasswordController extends CI_Controller{

   /**
    * Main page for the Account statement
    *
    */
   public function changeLoginPassword(){
      echo $this->load->view("private/pages/change_password/change_login_password",null, true);
   }

   public function changeTransactionPassword(){
      echo $this->load->view("private/pages/change_password/change_transaction_password", null, true);
   }

 }
?>
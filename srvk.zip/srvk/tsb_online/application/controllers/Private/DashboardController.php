<?php
/**
 * Dashboard Controller
 * Created by : Sreevika VS
 * Created at : 23-11-2017
 */
class DashboardController extends CI_Controller{


   public $customer;

   public $user;

   public $response;



   public function __construct(){
     parent::__construct();
     $this->init();
   }

   public function init(){
      $this->response = [
         'status' => false,
         'loginStatus' => true,
         'data' => [],
         'error' => [],
       ];

     try{
       $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
       if($user){
         $customer = $user->getCustomer();
       }
     }catch(Exception $e){
       // If ajax request
       if($this->input->is_ajax_request()){
         header('Content-Type: application/json');
         echo json_encode($output);
         exit;
       }
       // for normal http request show error page
       show_error('Sorry something went wrong '.$e->getMessage(), 500);
     }
     if($user){
       $this->user = $user;
       $this->customer = $customer;
     }
   }
   /**
   * Change password action
   */
   public function changeLoginPassword(){
      $user_name = $this->user->getUsername();
      $data = array();
      $data['user_name'] = $user_name;
      $this->response['data']['template'] = $this->load->view("private/pages/change_password/change_login_password", $data, true);
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));

   }

   public function changeLoginPasswordAction(){
     $user_id = $this->user->getId();
     $username = $this->user->getUsername();
     $old_password = $this->input->post('oldPassword');
     $this->load->library('form_validation');
     $this->form_validation->set_rules('confirmNewPassword', 'Confirm New Password', 'trim|required|matches[newPassword]');
     // validate old password
     $this->form_validation->set_rules('oldPassword', 'Old Password', array('trim', 'required',
        array('isValidOldPassword', function($old_password) use($user_id){
          // if old password is empty then other validation methods will trigger
          if(empty($old_password)){
              return true;
          }
          // check old password is correct
          $is_valid_password_flag = TsbApp\Authentication\AuthenticationService::verifyLoginPassword($user_id, hash('sha256',$old_password));
          if(!$is_valid_password_flag){
            $this->form_validation->set_message('isValidOldPassword', "Wrong {field} ");
            return false;
          }
          return true;

        })
     ));
     // validate new password
     $this->form_validation->set_rules('newPassword', 'New Password', array('trim','required', 'differs[oldPassword]', 'min_length[6]',
        array('isValidNewPassword', function($new_password){
          // if new password is empty then other validation method will complain
          if(empty($new_password)){
              return true;
          }
          // check atleast one special character
          $special_character = '/[\'^£$%&*()}{@#~?><>,|=_+¬-]/';
          if(preg_match($special_character, $new_password, $match) === 0){
              $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast  one special character');
              return false;
          }
          // check atleast one numeric data
          $alpha_character = '/[a-zA-Z]/';
          if(preg_match($alpha_character, $new_password, $match) === 0){
              $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast one Alphanumeric');
              return false;
          }
          $numeric_character = '/[\d]/';
          if(preg_match($numeric_character, $new_password, $match) === 0){
              $this->form_validation->set_message('isValidNewPassword', '{field} field must contain atleast  one Alphanumeric');
              return false;
          }
          return true;
        })
     ));

     if($this->form_validation->run() == false){
       $this->response['status'] = true;
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }

     // update new password
     $new_password = hash('sha256', $this->input->post('newPassword'));
     try{
     $status = TsbApp\Authentication\AuthenticationService::changePassword($username, $new_password);
     }catch(Exception $e){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     if($status){
       $this->response['status'] = true;
       $this->response['data']['passwordChanged'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
   }

   public function changeTransactionPassword(){

      $this->response['data']['template'] = $this->load->view("private/pages/change_password/change_transaction_password", null, true);
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
   }


   /**
    * Change Transaction key form action
    * page
    */
   public function changeTransactionPasswordAction(){
     $user_id = $this->user->getId();
     $username = $this->user->getUsername();
     $this->load->library('form_validation');
     $this->form_validation->set_rules('oldTransactionKey', 'Old Transaction Key', array('required', 'trim',

        array('isValidOldTransactionPassword', function($old_transaction_password) use($user_id, $username){
          // If old trasaction key is empty then other validation method will deal
          if(empty($old_transaction_password)){
              return true;
          }

          // check old trasaction password is correct
          $is_valid_old_transaction_password = TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, hash('sha256', $old_transaction_password));
          if(!$is_valid_old_transaction_password){
            $this->form_validation->set_message('isValidOldTransactionPassword', "Wrong {field} ");
            return false;
          }

          return true;
        })

     ));
     $this->form_validation->set_rules('newTransactionKey', 'New Transaction Key', array('required', 'trim', 'differs[oldTransactionKey]', 'min_length[6]',

        array('isValidNewTransactionPassword', function($new_transaction_password){
          // if new password is empty then other validation will deal
          if(empty($new_transaction_password)){
              return true;
          }

          // check atleast one special character
          $special_character = '/[\'^£$%&*()}{@#~?><>,|=_+¬-]/';
          if(preg_match($special_character, $new_transaction_password, $match) === 0){
              $this->form_validation->set_message('isValidNewTransactionPassword', '{field} field must contain atleast  one special character');
              return false;
          }
          // check atleast one numeric data
          $alpha_character = '/[a-zA-Z]/';
          if(preg_match($alpha_character, $new_transaction_password, $match) === 0){
              $this->form_validation->set_message('isValidNewTransactionPassword', '{field} field must contain atleast one Alphanumeric');
              return false;
          }
          $numeric_character = '/[\d]/';
          if(preg_match($numeric_character, $new_transaction_password, $match) === 0){
              $this->form_validation->set_message('isValidNewTransactionPassword', '{field} field must contain atleast  one Alphanumeric');
              return false;
          }

          return true;
        })

     ));
     $this->form_validation->set_rules('confirmNewTransactionKey', 'Confirm New Transaction Key', array('required', 'trim', 'matches[newTransactionKey]'));
     if($this->form_validation->run() === false){
       $this->response['status'] = true;
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }

     $new_transaction_key = $this->input->post('newTransactionKey');
     try{
       $new_transaction_key_update_status = TsbApp\Authentication\AuthenticationService::newTransactionKey($username, hash('sha256', $new_transaction_key));
     }catch(Exception $e){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     if($new_transaction_key_update_status){
       $this->response['status'] = true;
       $this->response['data']['trasactionKeyChanged'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
   }

  /**
   * Main dashboard action
   */
  public function index(){
    $data["page_name"] = "dashboard/index";
    $data['name'] = $this->customer->getName();
    $data['birth_date'] = $this->customer->getBirthDate();
    $this->load->view("private/main", $data);
  }

  public function home(){
    // load account model
    $this->load->model('account_model');

    $data = array();
    // profile details
    $profile = array();
    $profile['address'] = $this->customer->getPermAdd1()." ".$this->customer->getPermAdd2()." ".$this->customer->getPermAdd3();
    $profile['pinCode'] = $this->customer->getPermPinCode();
    $trname = $this->account_model->getTreasuryInfo($this->customer->getBrTrcode());
    $profile['treasury'] = (!is_array($trname))? 'No data' : $trname['TRNAME'] ;
    $profile['birthDate'] =  $this->customer->getBirthDate();
    $profile['name'] = $this->customer->getName();
    // get treasury information
    $data['profile'] = $profile;

    // account details
    $account = array();

    $savingsAccounts = $this->account_model->getCustomerSavingsAccounts($this->user->getCustomerId());
    $fdAccounts = $this->account_model->getCustomerFdAccounts($this->user->getCustomerId());
    if($savingsAccounts === false || $fdAccounts === false){
      $this->response['error'] = $this->account_model->getFirstError();
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }

    // savings account processing
    $savingsAccountData = array();
    $siNo = 1;
    foreach($savingsAccounts as $v){
      $single_account = array();
      $single_account['siNo'] = $siNo;
      $single_account['accNo'] = $v['ACCNO'];
      $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
      $single_account['accBal'] =  $v['SCRT_BAL'];
      $siNo++;
      $savingsAccountData[] = $single_account;
    }
    $account['savingsAccounts'] = $savingsAccountData;

    // fd account processing
    $siNo = 1;
    $fdAccountData = array();
    foreach($fdAccounts as $v){
      $single_account = array();
      $single_account['siNo'] = $siNo;
      $single_account['accNo'] = $v['ACCNO'];
      $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
      $single_account['accBal'] = $v['SCRT_BAL'];
      $siNo++;
      $fdAccountData[] = $single_account;
    }
    $account['fdAccounts'] = $fdAccountData;


    $data['lastLoginTime'] = ($this->user->getAttemptedAt())? switch_date_format($this->user->getAttemptedAt(), 'Y-m-d H:i:s.u', 'd/m/Y H:i a') : (new DateTime)->format('d/m/Y H:i a');
    $data['template'] = $this->load->view("private/pages/dashboard/home",$data, true);
    $data['accountDetails'] = $account;
    $this->response['data'] =$data;
    $this->response['status'] = true;
    $this->output->set_content_type('application/json');
    $this->output->set_output(json_encode($this->response));
  }

  public function logOut(){
    $status = TsbApp\Authentication\AuthenticationService::logOut();
    redirect(base_url().'login');
  }

  /**
   * Verify Otp
   *
   */
  public function vefiryOtp(){
    $this->response['status'] = false;
    $this->load->library('OtpManager');
    if($this->otpmanager->verifyOtp('29329')){
      $this->load->model($this->otpmanager->getModelName());
      $status = call_user_func_array( array($this->{$this->otpmanager->getModelName()}, $this->otpmanager->getModelMethodName() ), $this->otpmanager->getData() );
      $this->response['status'] = true;
      $this->response['data']['otpStatus'] = true;
      $this->response['data']['otpData'] = $status;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }
    $this->response['status'] = true;
    $this->output->set_content_type('application/json');
    $this->output->set_output(json_encode($this->response));
    return;
  }

  /**
   * Resend Otp
   *
   */
  public function resendOtp(){
      $this->load->library('otpManager');
      $status = $this->otpmanager->resendOtp();
      if($status){
          $this->response['status'] = true;
          $this->response['data']['otpResendStatus'] = true;
      }else{
          $error_message = $this->otpmanager->getError();
          $this->response['status'] = true;
          $this->response['error']['message'] = ($error_message)? $error_message :  'Somthing Went wrong';
          $this->response['error']['code'] = null;
      }
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
  }



  /**
   * for testing purpose
   *
   */
  public function test(){
    $this->load->library('OtpManager');
    $this->otpmanager->setData(['data' => "data to persisit"]);
    $this->otpmanager->setUsername('test');
    $this->load->config('app_config', true);
    $this->otpmanager->setConfig($this->config->item('beneficiary'));
    $this->otpmanager->setModel('account_model', 'test');
    $this->otpmanager->setSuccessMessage("success message test");
    var_dump($this->otpmanager->processOtp());
    var_dump($this->otpmanager->getError());
  }

}
?>

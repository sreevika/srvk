<?php
  /**
   * Periodic scheduled payment controller
   * This controller contain the methods for standing instruction and
   * salary instruction
   * Standing instruction feature facilitates periodic fund transfer
   * Salary instruction feature facilitates fund transfer to a ETSB account in
   * ETSB account are only available for the government employees
   */
  class RejectionClearController extends CI_Controller{

       public $customer;

       public $user;

       public $response;


       public function __construct(){
         parent::__construct();
         // psp stands for periodic scheduled payment
         $this->load->model('account_model');
         $this->load->model('beneficiary_model');
         $this->load->model('fund_transaction_model');
         $this->init();
       }

       public function init(){
          $this->response = [
             'status' => false,
             'loginStatus' => true,
             'data' => [],
             'error' => [],
           ];

         try{
           $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
           if($user){
             $customer = $user->getCustomer();
           }
         }catch(Exception $e){
           // If ajax request
           if($this->input->is_ajax_request()){
             header('Content-Type: application/json');
             echo json_encode($output);
             exit;
           }
           // for normal http request show error page
           show_error('Sorry something went wrong '.$e->getMessage(), 500);
         }
         if($user){
           $this->user = $user;
           $this->customer = $customer;
         }  /****************************************************************************/

       }


    /***************************************************************************
     Rejection clear
    ****************************************************************************/

    public function rejectionClear(){
      $customer_id = $this->user->getCustomerId();
      // load rejected transactions for the customer
      $rejections_result = $this->account_model->getRejectedTransactionsByCustomerId($customer_id);
      // if error occured inside the fetching process
      if($rejections_result === false){
        $this->response['error']['message'] = 'Unable to fetch Rejection Clear data';
        $this->response['error']['code'] = null;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      // process required data
      if(is_array($rejections_result)){
        $rejectionclear_data = array();
        foreach ($rejections_result as $key => $value) {
          $rejection_data_array = array();
          $rejection_data_array['credit_date'] =  $value['CREDIT_DATE'];
          $rejection_data_array['transaction_id'] = $value['TRANSACTION_ID'];
          $rejection_data_array['benf_name'] = $value['BENEFICIARY_NAME'];
          $rejection_data_array['account_number'] = $value['ACCOUNT_NO'];
          $rejection_data_array['ifsc'] =  $value['IFSC'];
          $rejection_data_array['amount'] =  $value['NET_PAY'];

          $rejection_data_array['reason'] =  $value['RN_STATUS'].((!empty($value['CN_STATUS']))? ' - '.$value['CN_STATUS'] : '');
          $rejectionclear_data[] = $rejection_data_array;
        }

      }


      $this->response['status'] = true;
      $this->response['data']['template'] = $this->load->view("private/pages/rejection_clear/rejection_clear",null, true);
      $this->response['data']['rejectionClear'] = $rejectionclear_data;

      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
    }
    /**
    * Check Beneficiary as already used
    *
    */

  public function rejectionClearBeneficiaryCheck(){

     $customer_id = $this->user->getCustomerId();
     $user_id = $this->user->getId();
     $account_number = $this->input->post('account_number');
     $transaction_id = $this->input->post('transaction_id');
     $transaction_data = $this->fund_transaction_model->getTransactionDetailsFromTsbToBank($transaction_id);
     // given customer Id Beneficiaries
      if(!is_array($transaction_data)){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     if($account_number == $transaction_data['ACCOUNT_NO']){
       $this->response['status'] = true;
     }
     else{
        try{
          $is_added = $this->beneficiary_model->isAlreadyAddedAsBenf($customer_id,$account_number);
        }catch(Exception $e){
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Something went wrong';
          $this->response['error']['code'] = NULL;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        if($is_added == false){
          $this->response['status'] = true;
        }
        else{
          $this->response['status'] = false;
        }
     }

     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
  }

    /**
    * Update Rejection Clear
    *
    */
   public function updateRejectionClear(){
     $customer_id = $this->user->getCustomerId();
     $user_id = $this->user->getId();
     // get bank details of IFSC used
     $bank_details = $this->beneficiary_model->getBankDetailsFromIfsc(trim($this->input->post('ifsc')));
     // get customer beneficiaries
     $transaction_id = $this->input->post('transaction_id');
     $transaction_data = $this->fund_transaction_model->getTransactionDetailsFromTsbToBank($transaction_id);
     if(!is_array($transaction_data)){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $benf_current_acc_no = $transaction_data['ACCOUNT_NO'];
     $ack_status = $transaction_data['ACK_STATUS'];
     $process_count = $transaction_data['PROCESS_CNT'];
     if($ack_status == 'RJCT'){
        $process_count = $process_count;
     }else{
        $process_count = $process_count+1;
     }
     $this->load->library('form_validation');
     $this->form_validation->set_rules('account_number', 'Beneficiary Account Number' , array('trim', 'required'));
     $this->form_validation->set_rules('benf_name', 'Beneficiary Name' , array('trim', 'required'));
     $this->form_validation->set_rules('remark', 'Remarks' , array('trim', 'required'));
     $this->form_validation->set_rules('ifsc', 'IFSC Code', array('trim','required',

    array('check_valid_ifsc', function($ifsc) use($bank_details){
        // check empy
        if(empty($ifsc)){
          $this->form_validation->set_message('check_valid_ifsc', '{field} is required');
          return false;
        }
        // check data exists in database
        if(!is_array($bank_details)){
          $this->form_validation->set_message('check_valid_ifsc', '{field} is not a valid IFS Code');
          return false;
        }

       return true;
    })

    ));

     $this->form_validation->set_rules('transKey', 'Transaction Key' , array('trim', 'required',
        array('isValidTransKey', function($trans_key) use($user_id){
            // if empty of trans key then other validation mehod will handle
            if(empty($trans_key)){
                return true;
            }
            // check is valid transaction key
            $trans_key = hash('sha256', $trans_key);

            // check old trasaction password is correct
            $is_valid_old_transaction_password = TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $trans_key);
            if(!$is_valid_old_transaction_password){
              $this->form_validation->set_message('isValidTransKey', "Invalid {field} ");
              return false;
            }

            return true;
        })
     ));


     // if form validation failed
     if($this->form_validation->run() === false){
       $this->response['status'] = true;
       $this->response['error']['message'] = null;
       $this->response['error']['code'] = null;
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $new_accno = $this->input->post('account_number');
     $get_beneficiary_id = $this->beneficiary_model->getbeneficiaryid($customer_id,$benf_current_acc_no);
     //var_dump($get_beneficiary_id);
     $benf_id = $get_beneficiary_id['BENEFICIARY_ID'];
     $check_schedule_status = $this->fund_transaction_model->checkScheduledBenId($benf_id);

     // update beneficiary
     $data = array();
     $data['transId'] = $transaction_id;
     $data['accNo'] = $new_accno;
     $data['benfName'] = $this->input->post('benf_name');
     $data['ifsc'] = $this->input->post('ifsc');
     $data['remark'] = $this->input->post('remark');
     $data['customerId'] = $customer_id;
     $data['currentAccNo'] = $benf_current_acc_no;
     $data['newProcessCount'] = $process_count;

     // database connections and transaction start
     try{
       $tsbConnection = $this->beneficiary_model->conn;
       $coretisConnection = $this->fund_transaction_model->getCoretisConnection();
       $tsbConnection->beginTransaction();
       $coretisConnection->beginTransaction();
     }catch(Exception $e){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong';
       $this->response['error']['code'] = null;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }

     // Transaction Start of TSB database
     
     
        // Update Beneficiary Table
      if($new_accno == $benf_current_acc_no){
        $update_status_beneficiary = $this->beneficiary_model->rejectionClearUpdateBeneficiary($data);
        
        if(!$update_status_beneficiary){
          $tsbConnection->rollBack();
          $coretisConnection->rollBack();
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong';
          $this->response['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        $this->response['data']['isSchedule'] = $check_schedule_status;
        }
        else{
            $is_duplicate = $this->beneficiary_model->isAlreadyAddedAsBenf($customer_id,$new_accno);
            if($is_duplicate == false){
            $update_status_beneficiary = $this->beneficiary_model->rejectionClearUpdateBeneficiary($data);
            
            if(!$update_status_beneficiary){
              $tsbConnection->rollBack();
              $coretisConnection->rollBack();
              $this->response['status'] = false;
              $this->response['error']['message'] = 'Somthing went wrong';
              $this->response['error']['code'] = null;
              $this->output->set_content_type('application/json');
              $this->output->set_output(json_encode($this->response));
              return;
            }
            $this->response['data']['isSchedule'] = $check_schedule_status;
          }
        }
     // updating ekuber tabel in tsb
      $update_status_tsb_online_ekuber = $this->fund_transaction_model->rejectionClearTsbOnlineEkuber($data);
        if(!$update_status_tsb_online_ekuber){
          $tsbConnection->rollBack();
          $coretisConnection->rollBack();
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong';
          $this->response['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
      // updating fund transfer details in tsb
      $update_status_online_amount_transfer_details = $this->fund_transaction_model->rejectionClearOnlineAmountTransferDetails($data);
        if(!$update_status_online_amount_transfer_details){
          $tsbConnection->rollBack();
          $coretisConnection->rollBack();
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong';
          $this->response['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
      }

      // Update Tsb to bank table in coretis db
      $update_status_tsb_to_bank = $this->fund_transaction_model->rejectionCleartsbToBank($data);
      if(!$update_status_tsb_to_bank){
          $tsbConnection->rollBack();
          $coretisConnection->rollBack();
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong';
          $this->response['error']['code'] = null;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
      }
      try{
        $tsbConnection->commit();
        $coretisConnection->commit();
      }catch(Exception $e){
        $tsbConnection->rollBack();
        $coretisConnection->rollBack();
        $this->response['status'] = false;
        $this->response['error']['message'] = 'Somthing went wrong';
        $this->response['error']['code'] = null;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
     
     $this->response['status'] = true;
     $this->response['data']['rejectionClearSuccess'] = true;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
   }





  }
?>

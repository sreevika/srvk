<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Account Statement Controller
 * Created by : Sreevika VS
 * Created at : 22-11-2017
 */
 class SalaryInstructionController extends CI_Controller{
   public function __construct(){
      parent::__construct();
      //$this->load->model("Account_model");
   }
   /**
    * Main page for the Account statement
    *
    */
   public function index(){
     $data = array();
      $data["page_name"] = "salary_instruction/index.php";
      echo $this->load->view("private/pages/salary_instruction/index",null, true);
   }


 }
?>
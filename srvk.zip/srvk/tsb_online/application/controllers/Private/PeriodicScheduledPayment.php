<?php
  /**
   * Periodic scheduled payment controller
   * This controller contain the methods for standing instruction and
   * salary instruction
   * Standing instruction feature facilitates periodic fund transfer
   * Salary instruction feature facilitates fund transfer to a ETSB account in
   * ETSB account are only available for the government employees
   */
  class PeriodicScheduledPayment extends CI_Controller{

       public $customer;

       public $user;

       public $response;


       public function __construct(){
         parent::__construct();
         // psp stands for periodic scheduled payment
         $this->load->model("PeriodicScheduledPayment/Salary_instruction_model", 'psp_salary_instruction');
         $this->load->model('beneficiary_model');
         $this->init();
       }

       public function init(){
          $this->response = [
             'status' => false,
             'loginStatus' => true,
             'data' => [],
             'error' => [],
           ];

         try{
           $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
           if($user){
             $customer = $user->getCustomer();
           }
         }catch(Exception $e){
           // If ajax request
           if($this->input->is_ajax_request()){
             header('Content-Type: application/json');
             echo json_encode($output);
             exit;
           }
           // for normal http request show error page
           show_error('Sorry something went wrong '.$e->getMessage(), 500);
         }
         if($user){
           $this->user = $user;
           $this->customer = $customer;
         }  /****************************************************************************/

       }


    /***************************************************************************
     Salary Instruction
    ****************************************************************************/

    public function salaryInstruction(){
      $customer_id = $this->user->getCustomerId();
      // load salary instruction for the customer
      $salary_instruction_result = $this->psp_salary_instruction->getSalaryInstructionByCustomerId($customer_id);
      // if error occured inside the fetching process
      if($salary_instruction_result === false){
        $this->response['error']['message'] = 'Unable to fetch salary instuction data';
        $this->response['error']['code'] = null;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      // process required data
      if(is_array($salary_instruction_result)){
        $salary_instruction_data = array();
        $salary_instruction_data['id'] =  $salary_instruction_result['SI_ID'];
        $salary_instruction_data['benfAccno'] = $salary_instruction_result['ACC_NO'];
        $salary_instruction_data['percentage'] = $salary_instruction_result['PERCENTAGE'];
        $salary_instruction_data['benfName'] =  $salary_instruction_result['BENEFICIARY_NAME'];
        $salary_instruction_data['benfId'] =  $salary_instruction_result['BENEF_ID'];
        $salary_instruction_data['ifsc'] =  $salary_instruction_result['IFS_CODE'];
        $salary_instruction_data['trCode'] =  $salary_instruction_result['BRANCH_TRCODE'];
        $salary_instruction_data['transType'] = $salary_instruction_result['TRANS_TYPE'];
        $salary_instruction_result = $salary_instruction_data;
      }

      // LOAD BENEFICIARY LIST TO PREPOPULATE THE BENFICIARY SELECT LIST IN EDIT FORM
      $beneficiary_list = array();
      $beneficiary_trans_type = (is_array($salary_instruction_result)
                           && isset($salary_instruction_result['transType']))?
                              $salary_instruction_result['transType'] : null;
      // For intra bank beneficiary inside tsb
      if($beneficiary_trans_type == 'I'){
        $beneficiary_list = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($customer_id);
      }
      // For inter bank beneficay outside tsb (other banks)
      if($beneficiary_trans_type == 'O'){
        $beneficiary_list = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($customer_id);
      }

      if(!is_array($beneficiary_list)){
        $this->response['error']['message'] = 'Unable to fetch beneficiary';
        $this->response['error']['code'] = null;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      // array to store process beneficaiy info
      // there is no need to show all database column data to the user
      $output_beneficairy_data = array();
      foreach($beneficiary_list as $benf){
          $filtered_benf = array();
          $filtered_benf = array();
          $filtered_benf['id'] = $benf['BENEFICIARY_ID'];
          $filtered_benf['benfAccNo'] = $benf['BENEFICIARY_ACCNO'];
          $filtered_benf['benfName'] = $benf['BENEFICIARY_NAME'];
          $output_beneficairy_data[] = $filtered_benf;
      }
      $this->response['status'] = true;
      $this->response['data']['template'] = $this->load->view("private/pages/periodic_scheduled_payment/salary_instruction/index",null, true);
      $this->response['data']['salaryInstructionInfo'] = $salary_instruction_result;
      $this->response['data']['beneficiaryListForCurrentBenfTransType'] = $output_beneficairy_data;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
    }


    /**
     * Update salary instructino instructino
     * Update the salary instruction data
     *
     */
     public function updateSalaryInstruction(){
       $customer_id = $this->user->getCustomerId();
       $user_id = $this->user->getId();
       $benf_trans_type = $this->input->post('beneficiaryTransType');
       $this->load->library('form_validation');
       //$this->form_validation->set_rules('beneficiaryTransType', 'Beneficiary Type', 'trim|required|in_list[O,I]');
       $this->form_validation->set_rules('salaryInstructionPercentage', 'Percentage' ,'required|less_than[101]|greater_than[0]');
       // validating the salary instruction id
       $this->form_validation->set_rules('salaryInstructinId', 'Salay Instructin Id', array('required',
          array('isValidSalaryInstructionId' , function($id) use($customer_id){
            // if id is empty then other validation method will deal
            if(empty($id)){
              return true;
            }
            // Get salary instruction information for the current user
            $salary_instruction_info = $this->psp_salary_instruction->getSalaryInstructionByCustomerId($customer_id);
            if($salary_instruction_info === false){
                $this->form_validation->set_message('isValidSalaryInstructionId' ,'Sorry somthing went wrong');
                return false;
            }
            if(!is_array($salary_instruction_info)){
                $this->form_validation->set_message('isValidSalaryInstructionId' ,'Invalid {field}');
                return false;
            }
            if($id !== $salary_instruction_info['SI_ID']){
              $this->form_validation->set_message('isValidSalaryInstructionId' ,'Invalid {field}');
              return false;
            }
            return true;
          })
       ));
       // validating transaction key
       $this->form_validation->set_rules('salaryInstructionTransKey', 'Transaction Key', array('required',

          array('isValidTransKey', function($trans_key) use($user_id){

              // other validation method will show error
              if(empty($trans_key)){
                  return true;
              }
              $hashed_password = hash('sha256', $trans_key);
              $status = \TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $hashed_password);
              if(!$status){
                $this->form_validation->set_message('isValidTransKey', 'Incorrect {field} ');
                return false;
              }
              return true;

          })

       ));
       // validating beneficiary id
       /*
       $this->form_validation->set_rules('beneficiaryId', 'Beneficiary' ,array('required',
        array('isValidBeneficiaryId' , function($benf_id) use($customer_id, $benf_trans_type){
          // If beneficiary id is empty then other validation methods will catch the error
          if(empty($benf_id)){
              return true;
          }
          // if trans type is not valid then show invalid benficiary id
          if(!in_array($benf_trans_type, array('I', 'O'))){
              $this->form_validation->set_message('isValidBeneficiaryId', 'Invalid {field}');
              return false;
          }
          // load all the beneficiary for the customer id for the trans type
          if($benf_trans_type === 'I'){
                $beneficiary_list = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($customer_id);
          }
          if($benf_trans_type ===  'O'){
                $beneficiary_list = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($customer_id);
          }
          // if error occured in fetching beneficiary id
          if($beneficiary_list === false){
            $this->form_validation->set_message('isValidBeneficiaryId', 'Sorry somthing went wrong!!');
            return false;
          }
          if(!is_array($beneficiary_list)){
            $this->form_validation->set_message('isValidBeneficiaryId', 'Invalid {field}');
            return false;
          }
          $filtered_benf = array_filter($beneficiary_list, function($v) use($benf_id){
            return ($v['BENEFICIARY_ID'] === $benf_id);
          });
          // if no filtered value
          if(count($filtered_benf) == 0){
              $this->form_validation->set_message('isValidBeneficiaryId' ,'Invalid {field}');
              return;
          }
          return true;
        })
       ));
       */
       if($this->form_validation->run() === false){
         $this->response['errors'] = $this->form_validation->error_array();
         $this->response['status'] = true;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
       }

       // update the data to the datebase
       $data = array();
       $data['siId'] = trim($this->input->post('salaryInstructinId'));
       $data['beneficiaryId'] = trim($this->input->post('beneficiaryId'));
       $data['username'] = $this->user->getuserName();
       $data['percentage'] = trim($this->input->post('salaryInstructionPercentage'));
       $update_status = $this->psp_salary_instruction->updateSalaryInstructin($data);
       if($update_status == false){
         $this->response['error']['message'] = 'Sorry somthing went wrong';
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return false;
       }
       // if updated then return new data
       $salary_instruction_result = $this->psp_salary_instruction->getSalaryInstructionByCustomerId($customer_id);
       // if error occured inside the fetching process
       if($salary_instruction_result === false){
         $this->response['error']['message'] = 'Unable to fetch salary instuction data';
         $this->response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
       }
       // process required data
       if(is_array($salary_instruction_result)){
         $salary_instruction_data = array();
         $salary_instruction_data['id'] =  $salary_instruction_result['SI_ID'];
         $salary_instruction_data['benfAccno'] = $salary_instruction_result['ACC_NO'];
         $salary_instruction_data['percentage'] = $salary_instruction_result['PERCENTAGE'];
         $salary_instruction_data['benfName'] =  $salary_instruction_result['BENEFICIARY_NAME'];
         $salary_instruction_data['benfId'] =  $salary_instruction_result['BENEF_ID'];
         $salary_instruction_data['ifsc'] =  $salary_instruction_result['IFS_CODE'];
         $salary_instruction_data['trCode'] =  $salary_instruction_result['BRANCH_TRCODE'];
         $salary_instruction_data['transType'] = $salary_instruction_result['TRANS_TYPE'];
         $salary_instruction_result = $salary_instruction_data;
       }

       // LOAD BENEFICIARY LIST TO PREPOPULATE THE BENFICIARY SELECT LIST IN EDIT FORM
       $beneficiary_list = array();
       $beneficiary_trans_type = (is_array($salary_instruction_result)
                            && isset($salary_instruction_result['transType']))?
                               $salary_instruction_result['transType'] : null;
       // For intra bank beneficiary inside tsb
       if($beneficiary_trans_type == 'I'){
         $beneficiary_list = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($customer_id);
       }
       // For inter bank beneficay outside tsb (other banks)
       if($beneficiary_trans_type == 'O'){
         $beneficiary_list = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($customer_id);
       }

       if(!is_array($beneficiary_list)){
         $this->response['error']['message'] = 'Unable to fetch beneficiary';
         $this->response['error']['code'] = null;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
       }
       // array to store process beneficaiy info
       // there is no need to show all database column data to the user
       $output_beneficairy_data = array();
       foreach($beneficiary_list as $benf){
           $filtered_benf = array();
           $filtered_benf = array();
           $filtered_benf['id'] = $benf['BENEFICIARY_ID'];
           $filtered_benf['benfAccNo'] = $benf['BENEFICIARY_ACCNO'];
           $filtered_benf['benfName'] = $benf['BENEFICIARY_NAME'];
           $output_beneficairy_data[] = $filtered_benf;
       }
       $this->response['status'] = true;
       $this->response['data']['template'] = $this->load->view("private/pages/periodic_scheduled_payment/salary_instruction/index",null, true);
       $this->response['data']['salaryInstructionInfo'] = $salary_instruction_result;
       $this->response['data']['beneficiaryListForCurrentBenfTransType'] = $output_beneficairy_data;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
     }

  }
?>

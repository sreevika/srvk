<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Beneficiary Controller Controller
 * Created by : Sreevika VS
 * Created at : 22-11-2017
 * Updated by : Fahad A
 * Updated at : 06-02-2018
 */
 class BeneficiaryController extends CI_Controller{

   public $customer;

   public $user;

   public $response;


   public function __construct(){
     parent::__construct();
     $this->load->model("beneficiary_model");
     $this->init();
   }

   public function init(){
      $this->response = [
         'status' => false,
         'loginStatus' => true,
         'data' => [],
         'error' => [],
       ];

     try{
       $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
       if($user){
         $customer = $user->getCustomer();
       }
     }catch(Exception $e){
       // If ajax request
       if($this->input->is_ajax_request()){
         header('Content-Type: application/json');
         echo json_encode($output);
         exit;
       }
       // for normal http request show error page
       show_error('Sorry something went wrong '.$e->getMessage(), 500);
     }
     if($user){
       $this->user = $user;
       $this->customer = $customer;
     }  /****************************************************************************/

   }



   /**
    * TSB Beneficiaries method
    * main method for loading the template and initial
    * data
    */
   public function intraBankBeneficiary(){
      $data = array();
      $beneficiaries = array();
      $intrabank_beneficiaries = $this->beneficiary_model->getCustomerIntraBankBeneficiarys($this->user->getCustomerId());
      $user_mobile_number = $this->user->getMobile();
      $intrabank_beneficiary_list = array();
      $siNo = 1;
      foreach($intrabank_beneficiaries as $v){
        $intrabank_beneficiary = array();
        $intrabank_beneficiary['slNo'] = $siNo;
        $intrabank_beneficiary['benfAccNo'] = $v['BENEFICIARY_ACCNO'];
        $intrabank_beneficiary['benfName'] = $v['BENEFICIARY_NAME'];
        $intrabank_beneficiary['transLimit'] = $v['TRANSACTION_LIMIT'];
        $intrabank_beneficiary['benfId'] = $v['BENEFICIARY_ID'];
        $intrabank_beneficiary['activated'] = $v['ACTIVATED'];
        $siNo++;
        $intrabank_beneficiary_list[] = $intrabank_beneficiary;
      }
      $beneficiaries['intraBank'] = $intrabank_beneficiary_list;
      $data['mobNoHint'] = (!empty($user_mobile_number) && strlen($user_mobile_number) > 0)? substr($user_mobile_number, -2) : null;
      $this->response['data']['template'] = $this->load->view("private/pages/beneficiary_details/intra_bank_beneficiary",$data, true);
      $this->response['data']['beneficiaryList'] = $beneficiaries;
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
   }
    /**
    * Other Bank Beneficiaries data Controll
    *
    */
    public function interBankBeneficiary(){
      $data = array();
      $beneficiaries = array();
      $interbank_beneficiaries = $this->beneficiary_model->getCustomerInterBankBeneficiarys($this->user->getCustomerId());
      $interbank_beneficiary_list = array();
      $user_mobile_number = $this->user->getMobile();
      $data['mobNoHint'] = (!empty($user_mobile_number) && strlen($user_mobile_number) > 0)? substr($user_mobile_number, -2) : null;
      $siNo = 1;
      foreach($interbank_beneficiaries as $v){
        $interbank_beneficiary = array();
        $interbank_beneficiary['slNo'] = $siNo;
        $interbank_beneficiary['benfAccNo'] = $v['BENEFICIARY_ACCNO'];
        $interbank_beneficiary['benfName'] = $v['BENEFICIARY_NAME'];
        $interbank_beneficiary['bankName'] = $v['BANK_NAME'];
        $interbank_beneficiary['branch'] = $v['BRANCH_NAME'];
        $interbank_beneficiary['ifsCode'] = $v['IFS_CODE'];
        $interbank_beneficiary['transLimit'] = $v['TRANSACTION_LIMIT'];
        $interbank_beneficiary['benfId'] = $v['BENEFICIARY_ID'];
        $interbank_beneficiary['activated'] = $v['ACTIVATED'];
        $siNo++;
        $interbank_beneficiary_list[] = $interbank_beneficiary;
      }
      $beneficiaries['interBank'] = $interbank_beneficiary_list;
      $this->response['data']['template'] = $this->load->view("private/pages/beneficiary_details/inter_bank_beneficiary",$data, true);
      $this->response['data']['beneficiaryList'] = $beneficiaries;
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
   }





   /**
    * Get beneficiary name for a account number
    *
    */
    public function getBeneficiaryNameForAccountNum(){
      $this->load->model('account_model');
      $this->load->model('beneficiary_model');

      $this->response['status'] = true;
      // validation start here
      $this->load->library("form_validation");
      $this->form_validation->set_rules('benefAccNo','Account Number', 'trim|required|numeric|min_length[15]|callback_checkEligibleToAddAsIntraBenf');
      if($this->form_validation->run() == false){
        $this->response['errors'] = $this->form_validation->error_array();
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      // get beneficiary name
      $acc_no = $this->input->post('benefAccNo');
      $account_details = $this->account_model->getAccountDetails($acc_no);
      // check joined account
      if($account_details[0]['ACC_JOINT'] == 'Y' && count($account_details) > 1){
        $benf_name = $account_details[0]['NAME'];
        $benf_name .= " ".$account_details[1]['NAME'];
      }else{
        $benf_name = $account_details[0]['NAME'];
      }
      $this->response['data']['name'] = $benf_name;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
    }




   /**
    * validation function for the intra bank beneficiary
    * Check the given account number is elegible to add as benf
    * @param string $accountNumber
    * else
    */
   public function checkEligibleToAddAsIntraBenf($acc_no){
     $this->load->model('account_model');
     $this->load->model('beneficiary_model');

     if(!is_numeric($acc_no)){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'Invalid account number');
       return false;
     }
     // get account details
     $account_details = $this->account_model->getAccountDetails($acc_no);
     if($account_details === false){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'Somthing went wrong');
       return false;
     }
     // check account details exists
     if($account_details === null){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'Invalid {field}');
       return false;
     }
     // check closed account or not
     if($account_details[0]['SB_CLOSE'] == 'Y' || $account_details[0]['CONFIRMED'] == 'N'){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'This {field} is not active');
       return false;
     }

     if($account_details[0]['ONLINE_DESTIN_ENABLED'] !== 'Y'){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', "This {field} is not allowed to add as beneficiary");
       return false;
     }
     // check self account
     try{
       $in_customer_account = $this->account_model->inCustomerAccount( $acc_no, $this->user->getCustomerId());
       $is_added = $this->beneficiary_model->isAlreadyAddedAsBenf($this->user->getCustomerId(),$acc_no);
     }catch(Exception $e){
       $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'Something went wrong');
       return false;
     }
     if($in_customer_account == true){
        $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', 'Self {field} are not allowed to add as beneficiary');
        return false;
     }


     if($is_added == true){
      $this->form_validation->set_message('checkEligibleToAddAsIntraBenf', '{field} Already Exists in Beneficiary List');
      return false;
     }

     return true;

   }


   public function addNewIntraBeneficiary(){
     // setting validation rule
     $this->load->library('form_validation');
     $this->form_validation->set_rules('benefAccNo', 'Account Number', 'trim|required|numeric|callback_checkEligibleToAddAsIntraBenf');
     $this->form_validation->set_rules('CnfbenefAccNo', 'Confirm Account Number', 'trim|required|numeric|matches[benefAccNo]');
     $this->form_validation->set_rules('benfName', 'Beneficiary Name', 'trim|required');
     $this->form_validation->set_rules('benfTransLimit', 'Transaction limit', 'trim|required|numeric|greater_than[1]|less_than[400000]');
     $user_id = $this->user->getId();
     $this->form_validation->set_rules('benfTransKey', 'Transaction Password', array('trim','required', array('check_valid_trans_password', function($trans_password) use($user_id){
       if(empty($trans_password)){
          $this->form_validation->set_message('check_valid_trans_password', '{field} cant be empty ');
          return false;
       }
       $hashed_password = hash('sha256', $trans_password);
       $status = \TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $hashed_password);
       if(!$status){
         $this->form_validation->set_message('check_valid_trans_password', 'Incorrect {field} ');
         return false;
       }
       return true;
     })
     )

    );
     // check form is valid or not
     if($this->form_validation->run() === false){
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }

     // get beneficiary name
     $acc_no = $this->input->post('benefAccNo');
     $account_details = $this->account_model->getAccountDetails($acc_no);
     // check joined account
     if($account_details[0]['ACC_JOINT'] == 'Y' && count($account_details) > 1){
       $benf_name = $account_details[0]['NAME'];
       $benf_name .= " ".$account_details[1]['NAME'];
     }else{
       $benf_name = $account_details[0]['NAME'];
     }


     // Check otp enabled for the beneficiary in the config file
     $beneficiary_config = $this->config->item('beneficiary', 'app_config');

     $data = array();
     $data['benefAccNo'] = trim($this->input->post('benefAccNo'));
     $data['benfName'] = $benf_name;
     $data['benfTransLimit'] = trim($this->input->post('benfTransLimit'));
     $data['customerId'] = $this->user->getCustomerId();
     $data['userName'] = $this->user->getuserName();
     $data['transType'] = 'I';
     $data['benfAccType'] = $account_details[0]['ACCTYPE'];

     $beneficiary_config = $this->config->item('beneficiary', 'app_config');

     if($beneficiary_config['otp'] == true){
       $this->response['status'] = true;
       $this->response['data']['otpManager'] = true;
       $this->load->library('otpManager');
       $this->otpmanager->setConfig($beneficiary_config);
       $this->otpmanager->setData($data);
       $this->otpmanager->setUsername($this->user->getUsername());
       $this->otpmanager->setMobileNumber($this->user->getMobile());
       if($this->otpmanager->processOtp()){
      // if(true){
          $this->response['data']['otpManager'] = true;
          $this->response['data']['otpVerificationUrl'] = base_url().'beneficiary/verifyOtpForAddNewIntraBankBenef';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
       }
       $error = $this->otpmanager->getError();
       $this->response['status'] = true;
       $this->response['error']['message'] = (!empty($error))? $error : "Somthing Went Wrong!";
       $this->response['error']['code'] = null;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $this->verifyOtpForAddNewIntraBankBenef($data, false);

   }

   public function verifyOtpForAddNewIntraBankBenef($data = null, $validation = true){


   if($validation  == true){
     $this->load->library('otpManager');
     $this->load->library('form_validation');
     $this->form_validation->set_rules('otp', 'Otp', array('required',
       array('isValidOtp', function($otp){
         // other validation method will show erro
         if(empty($otp)){
           return true;
         }
         if(!$this->otpmanager->verifyOtp($otp)){
           $error = $this->otpmanager->getError();
           $this->form_validation->set_message('isValidOtp', ($error) ? $error : 'Invalid Otp' );
           return false;
         }
         return true;
       })
     ));
     // check form validation error
     if($this->form_validation->run() === false){
       $this->response['errors'] = $this->form_validation->error_array();
       $this->response['status'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $data = $this->otpmanager->getData();
   }

   $status = $this->beneficiary_model->addNewBeneficiary($data);
   if($status){
     $this->response['status'] = true;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
   }
   $error_message = $this->beneficiary_model->getFirstError();
   $this->response['error']['message'] = (!empty($error_message))? $error_message['message'] : 'Somthing went wrong';
   $this->response['error']['code'] = (!empty($error_message))? $error_message['code'] : null;
   $this->output->set_content_type('application/json');
   $this->output->set_output(json_encode($this->response));
   }

   /**
    * Update Intra bank benficiary
    *
    */
   public function updateIntraBankBeneficiary(){
     $customer_id = $this->user->getCustomerId();
     $user_id = $this->user->getId();
     // get customer beneficiaries
     $beneficiaries = $this->beneficiary_model->getCustomerIntraBankBeneficiarys($customer_id);
     if(!is_array($beneficiaries)){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $this->load->library('form_validation');
     $this->form_validation->set_rules('transLimit', "Transaction Limit", 'required|numeric|greater_than[0]|less_than[1000000]');
     $this->form_validation->set_rules('activated', 'Status' ,'required|in_list[Y,N]');
     $this->form_validation->set_rules('benfId', 'Beneficiary Id', array('required',
        array('isValidBenfId' , function($benf_id) use($beneficiaries){
            // if benficiary id is empty then other validation method will trigger
            if(empty($benf_id)){
                return true;
            }
            // check beneficiry id is valid for the customer

            // check this beneficiary is in the list
            $filtered_benef_list = array_filter($beneficiaries, function($v) use($benf_id){
              return ($v['BENEFICIARY_ID'] == $benf_id);
            });
            if(count($filtered_benef_list) == 0){
              $this->form_validation->set_message('isValidBenfId', 'Invalid {field}');
              return false;
            }
            return true;
        })
     ));
     $this->form_validation->set_rules('transKey', 'Transaction Key', array('required', 'trim', 'max_length[20]',

        array('isValidTransKey', function($trans_key) use($user_id){
            // other validation method will catch if empty
            if(empty($trans_key)){
                return true;
            }
            // check is valid transaction key
            $trans_key = hash('sha256', $trans_key);

            // check old trasaction password is correct
            $is_valid_old_transaction_password = TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $trans_key);
            if(!$is_valid_old_transaction_password){
              $this->form_validation->set_message('isValidTransKey', "Invalid {field} ");
              return false;
            }

            return true;
        })
     ));
     if($this->form_validation->run() === false){
       $this->response['errors'] = $this->form_validation->error_array();
       $this->response['status'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }

     $data = array();
     $data['benfId'] = $this->input->post('benfId');
     $data['transLimit'] = $this->input->post('transLimit');
     $data['activated'] = $this->input->post('activated');
     $beneficiary_config =$this->config->item('beneficiary', 'app_config');

     if($beneficiary_config['otp'] == true){
       $this->response['status'] = true;
       $this->response['data']['otpManager'] = true;
       $this->load->library('otpManager');
       $this->otpmanager->setConfig($beneficiary_config);
       $this->otpmanager->setData($data);
       $this->otpmanager->setUsername($this->user->getUsername());
       $this->otpmanager->setMobileNumber($this->user->getMobile());
       if($this->otpmanager->processOtp()){
      // if(true){
          $this->response['data']['otpManager'] = true;
          $this->response['data']['otpVerificationUrl'] = base_url().'beneficiary/verifyOtpForIntraBankBenefUpdate';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
       }
       $error = $this->otpmanager->getError();
       $this->response['status'] = true;
       $this->response['error']['message'] = (!empty($error))? $error : "Somthing Went Wrong!";
       $this->response['error']['code'] = null;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $this->verifyOtpForIntraBankBenefUpdate($data, false);
   }

   /**
    * Verify Otp Update Intra Bank Beneficiary
    *
    */
    public function verifyOtpForIntraBankBenefUpdate($data = null, $validation = true){

      if($validation  == true){
        $this->load->library('otpManager');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('otp', 'Otp', array('required',
          array('isValidOtp', function($otp){
            // other validation method will show erro
            if(empty($otp)){
              return true;
            }
            if(!$this->otpmanager->verifyOtp($otp)){
              $error = $this->otpmanager->getError();
              $this->form_validation->set_message('isValidOtp', ($error) ? $error : 'Invalid Otp' );
              return false;
            }
            return true;
          })
        ));
        // check form validation error
        if($this->form_validation->run() === false){
          $this->response['errors'] = $this->form_validation->error_array();
          $this->response['status'] = true;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        $data = $this->otpmanager->getData();
      }
      // update beneficiary
      $update_status = $this->beneficiary_model->updateBeneficiary($data);
      if($update_status === false){
        $this->response['status'] = false;
        $this->response['error']['message'] = 'Somthing went wrong!';
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      // fetching data from the database for the benf id
      $benf_data = $this->beneficiary_model->getBeneficiaryDetails($data['benfId']);
      if(!$benf_data){
        $this->response['status'] = false;
        $this->response['error']['message'] = 'Somthing went wrong!';
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }
      $output = array();
      $output['benfId'] = $benf_data['BENEFICIARY_ID'];
      $output['activated'] = $benf_data['ACTIVATED'];
      $output['benfName'] = $benf_data['BENEFICIARY_NAME'];
      $output['benfAccNo'] = $benf_data['BENEFICIARY_ACCNO'];
      $output['transLimit'] = $benf_data['TRANSACTION_LIMIT'];

      $this->response['data']['benefData'] = $output;
      $this->response['data']['beneficiaryUpdated'] = true;
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;

      $this->response['status'] = true;
      $this->response['data']['otpVerified'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_content(json_encode($this->response));
      return;

    }





   /**
    * Update Inter Bank beneficiary
    *
    */
   public function updateInterBankBeneficiary(){
     $customer_id = $this->user->getCustomerId();
     $user_id = $this->user->getId();
     // get customer beneficiaries
     $beneficiaries = $this->beneficiary_model->getCustomerInterBankBeneficiarys($customer_id);
     if(!is_array($beneficiaries)){
       $this->response['status'] = false;
       $this->response['error']['message'] = 'Somthing went wrong!';
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }


     $this->load->library('form_validation');
     $this->form_validation->set_rules('benfAccNo', 'Beneficiary Account Number' , array('trim', 'required'));
     $this->form_validation->set_rules('benfName', 'Beneficiary Name' , array('trim', 'required'));
     $this->form_validation->set_rules('transLimit', 'Transaction limit' , array('trim', 'required'));
     $this->form_validation->set_rules('activated', 'Status' , array('trim', 'required', 'in_list[Y,N]'));
     $this->form_validation->set_rules('benfId', 'Beneficiary Id' , array('trim', 'required',
        array('isValidBenfId', function($benf_id) use($beneficiaries){
            // if beneficiary id is empty then other validation method will trigger
            if(empty($benf_id)){
                return true;
            }
            // check beneficiary id is in the customer beneficiary list
            $filtered_benef_list = array_filter($beneficiaries, function($v) use($benf_id){
                return ($v['BENEFICIARY_ID'] == $benf_id);
            });
            if(empty($filtered_benef_list)){
                $this->form_validation->set_message('isValidBenfId', "Invalid {field}");
                return false;
            }

            return true;
        })
     ));
     $this->form_validation->set_rules('transKey', 'Transaction Key' , array('trim', 'required',
        array('isValidTransKey', function($trans_key) use($user_id){
            // if empty of trans key then other validation mehod will handle
            if(empty($trans_key)){
                return true;
            }
            // check is valid transaction key
            $trans_key = hash('sha256', $trans_key);

            // check old trasaction password is correct
            $is_valid_old_transaction_password = TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $trans_key);
            if(!$is_valid_old_transaction_password){
              $this->form_validation->set_message('isValidTransKey', "Invalid {field} ");
              return false;
            }

            return true;
        })
     ));


     // if form validation failed
     if($this->form_validation->run() === false){
       $this->response['status'] = true;
       $this->response['error']['message'] = null;
       $this->response['error']['code'] = null;
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }


     // update beneficiary
     $data = array();
     $data['benfId'] = $this->input->post('benfId');
     $data['transLimit'] = $this->input->post('transLimit');
     $data['activated'] = $this->input->post('activated');


     $beneficiary_config =$this->config->item('beneficiary', 'app_config');

     if($beneficiary_config['otp'] == true){
       $this->response['status'] = true;
       $this->response['data']['otpManager'] = true;
       $this->load->library('otpManager');
       $this->otpmanager->setConfig($beneficiary_config);
       $this->otpmanager->setData($data);
       $this->otpmanager->setUsername($this->user->getUsername());
       $this->otpmanager->setMobileNumber($this->user->getMobile());
       if($this->otpmanager->processOtp()){
      // if(true){
          $this->response['data']['otpManager'] = true;
          $this->response['data']['otpVerificationUrl'] = base_url().'beneficiary/verifyOtpForInterBankBenefUpdate';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
       }
       $error = $this->otpmanager->getError();
       $this->response['status'] = true;
       $this->response['error']['message'] = (!empty($error))? $error : "Somthing Went Wrong!";
       $this->response['error']['code'] = null;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $this->verifyOtpForInterBankBenefUpdate($data, false);

   }

   /**
    * Verify Otp Update Inter Bank Beneficiary
    *
    */
    public function verifyOtpForInterBankBenefUpdate($data = null, $validation = true){

      if($validation  == true){
        $this->load->library('otpManager');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('otp', 'Otp', array('required',
          array('isValidOtp', function($otp){
            // other validation method will show erro
            if(empty($otp)){
              return true;
            }
            if(!$this->otpmanager->verifyOtp($otp)){
              $error = $this->otpmanager->getError();
              $this->form_validation->set_message('isValidOtp', ($error) ? $error : 'Invalid Otp' );
              return false;
            }
            return true;
          })
        ));
        // check form validation error
        if($this->form_validation->run() === false){
          $this->response['errors'] = $this->form_validation->error_array();
          $this->response['status'] = true;
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        $data = $this->otpmanager->getData();

        $update_status = $this->beneficiary_model->updateBeneficiary($data);
        if($update_status === false){
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong!';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        // fetching data from the database for the benf id
        $benf_data = $this->beneficiary_model->getBeneficiaryDetails($data['benfId']);

        if(!$benf_data){
          $this->response['status'] = false;
          $this->response['error']['message'] = 'Somthing went wrong!';
          $this->output->set_content_type('application/json');
          $this->output->set_output(json_encode($this->response));
          return;
        }
        $output = array();
        $output['benfAccNo'] = $benf_data['BENEFICIARY_ACCNO'];
        $output['benfName'] = $benf_data['BENEFICIARY_NAME'];
        $output['bankName'] = $benf_data['BANK_NAME'];
        $output['branch'] = $benf_data['BRANCH_NAME'];
        $output['ifsCode'] = $benf_data['IFS_CODE'];
        $output['transLimit'] = $benf_data['TRANSACTION_LIMIT'];
        $output['benfId'] = $benf_data['BENEFICIARY_ID'];
        $output['activated'] = $benf_data['ACTIVATED'];

        $this->response['data']['benefData'] = $output;
        $this->response['data']['beneficiaryUpdated'] = true;
        $this->response['status'] = true;
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
      }


    }


   /**
    * Get Bak Details from Ifsc
    * get Bank name and branch name from the Ifsc code
    */
   public function getBankDetailsFromIfsc(){

     $this->load->library('form_validation');
     $ifsc = trim($this->input->post('ifsCode'));
     $bank_details = $this->beneficiary_model->getBankDetailsFromIfsc($ifsc);
     $this->form_validation->set_rules('ifsCode', 'IFS Code', array('required',
      array('check_valid_ifsc', function($data) use($bank_details){
          // check empy
          if(empty($data)){
            $this->form_validation->set_message('check_valid_ifsc', '{field} is required');
            return false;
          }
          // check data exists in database
          if(!is_array($bank_details)){
            $this->form_validation->set_message('check_valid_ifsc', '{field} is not a valid IFS Code');
            return false;
          }

         return true;
      })
     ));

     // If validation failed
     if($this->form_validation->run() === false){
       $this->response['errors'] = $this->form_validation->error_array();
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $this->response['status'] = true;
     $this->response['data']['bankDetails']['bankName'] = $bank_details['BANK_NAME'];
     $this->response['data']['bankDetails']['bankId'] = $bank_details['BANK_CODE'];
     $this->response['data']['bankDetails']['branchName'] = $bank_details['BRANCH_NAME'];
     $this->response['data']['bankDetails']['branchId'] = $bank_details['BRANCH_NAME'];
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
   }

  /**
   * Add Inter Bank beneficiary
   *
   */
  public function addNewInterBeneficiary(){
    $customer_id = $this->user->getCustomerId();
    // setting validation rule
    $bank_details = $this->beneficiary_model->getBankDetailsFromIfsc(trim($this->input->post('ifsCode')));
    $this->load->library('form_validation');
    $this->form_validation->set_rules('benfName', 'Beneficiary Name', 'trim|required|max_length[100]');
    $this->form_validation->set_rules('ifsCode', 'IFSC Code', array('trim','required',

    array('check_valid_ifsc', function($data) use($bank_details){
        // check empy
        if(empty($data)){
          $this->form_validation->set_message('check_valid_ifsc', '{field} is required');
          return false;
        }
        // check data exists in database
        if(!is_array($bank_details)){
          $this->form_validation->set_message('check_valid_ifsc', '{field} is not a valid IFS Code');
          return false;
        }

       return true;
    })

    ));
    $this->form_validation->set_rules('bankName', 'Account Number', 'trim|required');
    $this->form_validation->set_rules('bankId', 'Account Number', 'trim|required');

    $this->form_validation->set_rules('benefAccNo', 'Account Number', array('trim','required', array('check_already_used', function($benefAccNo) use($customer_id){
      if(empty($benefAccNo)){
         $this->form_validation->set_message('check_already_used', '{field} cant be empty ');
         return false;
      }
      $is_added = $this->beneficiary_model->isAlreadyAddedAsBenf($customer_id,$benefAccNo);

      if($is_added == true){
        $this->form_validation->set_message('check_already_used', '{field} Already Exists in Beneficiary List');
        return false;
      }
      return true;
    })
    )

   );

    $this->form_validation->set_rules('CnfbenefAccNo', 'Confirm Account Number', 'trim|required|matches[benefAccNo]');
    $this->form_validation->set_rules('benfTransLimit', 'Transaction limit', 'trim|required|numeric|greater_than[1]|less_than[400000]');
    $user_id = $this->user->getId();
    $this->form_validation->set_rules('benfTransKey', 'Transaction Password', array('trim','required', array('check_valid_trans_password', function($trans_password) use($user_id){
      if(empty($trans_password)){
         $this->form_validation->set_message('check_valid_trans_password', '{field} cant be empty ');
         return false;
      }
      $hashed_password = hash('sha256', $trans_password);
      $status = \TsbApp\Authentication\AuthenticationService::verifyTransactionPassword($user_id, $hashed_password);
      if(!$status){
        $this->form_validation->set_message('check_valid_trans_password', 'Incorrect {field} ');
        return false;
      }
      return true;
    })
    )

   );
    // check form is valid or not
    if($this->form_validation->run() === false){
      $this->response['errors'] = $this->form_validation->error_array();
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }


    // Check otp enabled for the beneficiary in the config file
    $beneficiary_config = $this->config->item('beneficiary', 'app_config');

    $data = array();
    $data['benefAccNo'] = trim($this->input->post('benefAccNo'));
    $data['benfName'] = trim($this->input->post('benfName'));
    $data['ifsCode'] = trim($this->input->post('ifsCode'));
    $data['benfTransLimit'] = trim($this->input->post('benfTransLimit'));
    $data['customerId'] = $this->user->getCustomerId();
    $data['userName'] = $this->user->getuserName();
    $data['transType'] = 'O';
    if($beneficiary_config['otp'] == true){
      $this->response['status'] = true;
      $this->response['data']['otpManager'] = true;
      $this->load->library('otpManager');
      $this->otpmanager->setConfig($beneficiary_config);
      $this->otpmanager->setData($data);
      $this->otpmanager->setUsername($this->user->getUsername());
      $this->otpmanager->setMobileNumber($this->user->getMobile());
      if($this->otpmanager->processOtp()){
     // if(true){
         $this->response['data']['otpManager'] = true;
         $this->response['data']['otpVerificationUrl'] = base_url().'beneficiary/verifyOtpForAddNewInterBankBenefUpdate';
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
      }
      $error = $this->otpmanager->getError();
      $this->response['status'] = true;
      $this->response['error']['message'] = (!empty($error))? $error : "Somthing Went Wrong!";
      $this->response['error']['code'] = null;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }
    $this->verifyOtpForAddNewInterBankBenefUpdate($data, false);

  }


  /**
   * Verify Otp for add new Inter Bank Beneficiary
   *
   */
   public function verifyOtpForAddNewInterBankBenefUpdate($data = null, $validation = true){

     if($validation  == true){
       $this->load->library('otpManager');
       $this->load->library('form_validation');
       $this->form_validation->set_rules('otp', 'Otp', array('required',
         array('isValidOtp', function($otp){
           // other validation method will show erro
           if(empty($otp)){
             return true;
           }
           if(!$this->otpmanager->verifyOtp($otp)){
             $error = $this->otpmanager->getError();
             $this->form_validation->set_message('isValidOtp', ($error) ? $error : 'Invalid Otp' );
             return false;
           }
           return true;
         })
       ));
       // check form validation error
       if($this->form_validation->run() === false){
         $this->response['errors'] = $this->form_validation->error_array();
         $this->response['status'] = true;
         $this->output->set_content_type('application/json');
         $this->output->set_output(json_encode($this->response));
         return;
       }
       $data = $this->otpmanager->getData();
     }

     $status = $this->beneficiary_model->addNewBeneficiary($data);
     if($status){
       $this->response['status'] = true;
       $this->output->set_content_type('application/json');
       $this->output->set_output(json_encode($this->response));
       return;
     }
     $error_message = $this->beneficiary_model->getFirstError();
     $this->response['error']['message'] = (!empty($error_message))? $error_message['message'] : 'Somthing went wrong';
     $this->response['error']['code'] = (!empty($error_message))? $error_message['code'] : null;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;



   }



  /**
   * Get beneficiary for the customer
   * if post request contains benefiary type then it will ferch beneficiary for that type
   * if no type is mentioned then it will give all the benefiary
   */
   public function getCustomerBeneficiaries(){
     $customer_id = $this->user->getCustomerId();
     $this->load->library('form_validation');
     $beneficiary_trans_type = $this->input->post('beneficiaryTransType');
     $this->form_validation->set_rules('beneficiaryTransType' ,'Beneficiary Type', 'in_list[I,O]');
     if($this->form_validation->run() === false){
      $this->response['errors'] = $this->form_validation->error_array();
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
     }
     // for beneficiary inside tsb
     if($beneficiary_trans_type  == 'I'){
       $beneificiaries = $this->beneficiary_model->getActivatedCustomerIntraBankBeneficiarys($customer_id);
     }
     // for benefiary outside tsb
     if($beneficiary_trans_type  === 'O'){
       $beneificiaries = $this->beneficiary_model->getActivatedCustomerInterBankBeneficiarys($customer_id);
     }
     // if benefiary type not metioned
     if($beneficiary_trans_type  === null){
       $beneificiaries = $this->beneficiary_model->getActivatedCustomerBeneficiarys($customer_id);
     }
     if(!is_array($beneificiaries)){
      $this->response['status'] = false;
      $this->response['error']['message'] = 'Error occured while fetching beneficiaries';
      $this->response['error']['code'] = null;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
     }
     $benf_collection = array();
     foreach($beneificiaries as $benf){
       $output_benefiary_data = array();
       $output_benefiary_data['id'] = $benf['BENEFICIARY_ID'];
       $output_benefiary_data['benfAccNo'] = $benf['BENEFICIARY_ACCNO'];
       $output_benefiary_data['benfName'] = $benf['BENEFICIARY_NAME'];
       $benf_collection[] = $output_benefiary_data;
     }

     $this->response['data']['beneficiaries'] = $benf_collection;
     $this->response['status'] = true;
     $this->output->set_content_type('application/json');
     $this->output->set_output(json_encode($this->response));
     return;
   }



 }
?>

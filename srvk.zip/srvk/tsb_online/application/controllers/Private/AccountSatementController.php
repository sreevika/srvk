<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Account Statement Controller
 * Created by : Sreevika V S
 * Created at : 22-11-2017
 */
 class AccountSatementController extends CI_Controller{

   // customer object
   public $customer;
   // user object
   public $user;
   // response default
   public $response = array();

   /**
    * Php magic constructor
    *
    */
   public function __construct(){
     parent::__construct();
     $this->load->model("account_model");
     $this->init();
   }


   /**
    * Initialization process are added here
    * Getting loggined user info and other data
    */
   private function init(){
     $this->response = [
         'status' => false,
         'loginStatus' => true,
         'data' => [],
         'error' => null,
     ];

     try{
       $user = TsbApp\Authentication\AuthenticationService::getCurrentLoggedinUser();
       if(!$user){
         header('Content-Type: application/json');
         echo json_encode($this->response);
         exit;
       }
       $customer = $user->getCustomer();
     }catch(Exception $e){
       // if ajax request then json outpur
       if($this->input->is_ajax_request()){
         header('Content-Type: application/json');
         echo json_encode($output);
         exit;
       }
       // for normal http request show error page
         show_error('Sorry something went wrong '.$e->getMessage(), 500);
     }
     $this->user = $user;
     $this->customer = $customer;

   }

   /**
    * Main page for the Account statement
    * This action metod return the template, account list and data
    * for the account statement
    */
   public function index(){
    $data = array();
    $account = array();
    $savingsAccounts = $this->account_model->getCustomerSavingsAccounts($this->user->getCustomerId());
    $fdAccounts = $this->account_model->getCustomerFdAccounts($this->user->getCustomerId());
    if($savingsAccounts === false || $fdAccounts === false){
      $this->response['error'] = $this->account_model->getFirstError();
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }

    // savings account processing
    $savingsAccountData = array();
    $siNo = 1;
    foreach($savingsAccounts as $v){
      $single_account = array();
      $single_account['siNo'] = $siNo;
      $single_account['accNo'] = $v['ACCNO'];
      $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
      $single_account['accTrcode'] = $v['TRNAME'];
      $single_account['accBal'] =  $v['SCRT_BAL'];
      $siNo++;
      $savingsAccountData[] = $single_account;
    }
    $account['savingsAccounts'] = $savingsAccountData;

    // fd account processing
    $siNo = 1;
    $fdAccountData = array();
    foreach($fdAccounts as $v){
      $single_account = array();
      $single_account['siNo'] = $siNo;
      $single_account['accNo'] = $v['ACCNO'];
      $single_account['accTypeAbbr'] = $v['ACCTYPE_ABBR'];
      $single_account['accTrcode'] = $v['BRANCH_TRCODE'];
      $single_account['accBal'] = $v['SCRT_BAL'];
      $siNo++;
      $fdAccountData[] = $single_account;
    }
    $account['fdAccounts'] = $fdAccountData;
    $data["page_name"] = "account_statement/index.php";
    $this->response['data']['template'] = $this->load->view("private/pages/account_statement/index",null, true);
    $this->response['data']['accountList'] = $account;
    $this->response['status'] = true;
    $this->output->set_content_type('application/json');
    $this->output->set_output(json_encode($this->response));
    return;
   }


   /**
    * Get Savings bank account statement
    * get savings bank account statnement as json
    * for the post account_number
    */
   public function getSbAccountStatement(){
     $this->load->library('form_validation');
     $this->form_validation->set_rules('periode', 'Period', 'trim|required');
     $account_number =$this->input->post('accountNumber');
     $periode_type =$this->input->post('periode');
     $customer_id = $this->user->getCustomerId();
     $customer_savings_accounts = $this->account_model->getCustomerSavingsAccounts($customer_id);

     $this->form_validation->set_rules('accountNumber', 'Account Number', array('trim', 'required', 'exact_length[15]',
        array('is_valid_account_number', function($account_number) use($customer_savings_accounts){
          if(empty($account_number)){
              $this->form_validation->set_message('is_valid_account_number', 'Please Choose an Account Number');
              return false;
          }
          //check wether the given account number is inside the customer savings account list
          if(!is_array($customer_savings_accounts)){
            $this->form_validation->set_message('is_valid_account_number' ,'Invalid {field}');
            return false;
          }
          // filterd array containing the account number details
          $filtered_account = array_filter($customer_savings_accounts, function($v) use($account_number){
            return ($v['ACCNO'] === $account_number);
          });
          if(count($filtered_account) === 0){
            $this->form_validation->set_message('is_valid_account_number' ,'Invalid {field}');
            return false;
          }
          return true;
        })
     ));

     // VALIDATING IF  BY DATE
     if($periode_type=='byDate'){

        $this->form_validation->set_rules('startDate', 'From Date', array('required','trim',
          array('is_valid_start_date', function($date){
              // if empty of date then no need to check other validation methods will deal
              if(empty($date)){
                  return true;
              }
              // check date is valid as per the format
              if(!isValidDate($date, 'd/m/Y')){
                $this->form_validation->set_message('is_valid_start_date', 'Invalid {field}');
                return false;
              }
              return true;
          })
        ));


        $this->form_validation->set_rules('endDate', 'To Date', array('required', 'trim',
          array('is_valid_end_date', function($date){
              // if empty of date then no need to check other validation methods will deal
              if(empty($date)){
                  return true;
              }
              // check date is valid as per the format
              if(!isValidDate($date, 'd/m/Y')){
                $this->form_validation->set_message('is_valid_end_date', 'Invalid {field}');
                return false;
              }
              return true;
          })
        ));

     }

     // VALIDATING IF BY MONTH
     if($periode_type=='byMonth'){
        $this->form_validation->set_rules('year', 'Year', 'required|numeric');
        $this->form_validation->set_rules('month', 'Month', 'required|numeric|less_than[13]|greater_than[0]');
     }

     if($this->form_validation->run() == false){
      $this->response['errors']= $this->form_validation->error_array();
      $this->response['status'] = true;
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return false;
     }
    $request_data = array();
    $request_data['accountNumber'] = $account_number;
    $request_data['periodeType'] = $periode_type;
    $request_data['fromDate'] = switch_date_format($this->input->post('startDate'), 'd/m/Y' , 'Y-m-d');
    $request_data['toDate'] = switch_date_format($this->input->post('endDate'), 'd/m/Y' , 'Y-m-d');
    $request_data['year'] = $this->input->post('year');
    $request_data['month'] = $this->input->post('month');
    // get account details
    $account_statements = $this->account_model->getSbAccountSatement($request_data);
    // if not array then error occured
    if(!is_array($account_statements)){
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->response));
        return;
    }

    $savingsAccountData = array();
    $siNo = 1;
    foreach($account_statements as $v){
      $single_account_statement = array();
      $single_account_statement['slNo'] = $siNo;
      $single_account_statement['description'] = $v['DESCRIPTION'];
      $single_account_statement['transId'] = $v['REF_TRANSACTIONID'];
      $single_account_statement['transDate'] =  switch_date_format($v['DT_ACC_DATE'], 'Y-m-d', 'd/m/Y');
      $single_account_statement['debit'] = $v['PAYMT_AMT'];
      $single_account_statement['credit'] = $v['RECPT_AMT'];
      $single_account_statement['accBal'] =  $v['ACC_BALANCE'];
      $single_account_statement['remark'] =  $v['REMARKS'];

      $siNo++;
      $savingsAccountData[] = $single_account_statement;
    }

    $this->response['data']['savingsStatement'] = $savingsAccountData;
    $this->response['status'] = true;

    $this->output->set_content_type('application/json');
    $this->output->set_output(json_encode($this->response));
    return;
   }


   /**
    * Get Fd account statement
    * get account statement for the given
    * post account number
    * This method gives json fd account statement for the valid customer id
    */
   public function getFdAccountStatement(){
    $this->load->library('form_validation');
    $account_number = $this->input->post('accountNumber');
    $customer_id = $this->user->getCustomerId();
    $fd_accounts = $this->account_model->getCustomerFdAccounts($customer_id);
    $this->form_validation->set_rules('accountNumber', 'Account Number', array('trim','required',
      array('is_valid_account_number', function($account_number) use($fd_accounts){
          // if account number is empty then other validation method will trigger
          if(empty($account_number)){
              return true;
          }
          if(!is_array($fd_accounts)){
              $this->form_validation->set_message('is_valid_account_number', 'Invalid {field}');
              return false;
          }
          $filtered_fd_account = array_filter($fd_accounts, function($v) use($account_number){
              return ($v['ACCNO'] === $account_number);
          });
          if(count($filtered_fd_account) === 0){
              $this->form_validation->set_message('is_valid_account_number', 'Invalid {field}');
              return false;
          }
          return true;
      })
    ));
    if($this->form_validation->run() == false){
      $this->response['status'] = true;
      $this->response['errors'] = $this->form_validation->error_array();
      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;
    }
    //Get FD Account Statement
    $get_fd_transaction = $this->account_model->getFdAccountSatement($account_number);
    //var_dump($get_fd_transaction);
    if(is_array($get_fd_transaction)){
          $output['data']['fd_transaction'] = $get_fd_transaction;
             $fixedAccountData = array();
              $siNo = 1;
              foreach($get_fd_transaction as $v){
                //To find Int Due
                 $intdue=$v['INT_AMT']-$v['INT_AMT_DRAWN']-$v['EXCESS_INT_ADJUST'];
                  if($intdue<1){
                    $intdues=0;
                  }
                  else{
                    $intdues=$intdue;
                  }
                  //To find Excess Paid
                $excess=($v['INT_AMT_DRAWN']+$v['EXCESS_INT_ADJUST'])-$v['INT_AMT'];
                  if($excess<1){
                    $excesspaid=0;
                  }
                  else{
                    $excesspaid=$excess;
                  }
                  $fromdate=date($v['INT_FROM']);
                  $todate=date($v['INT_TO']);
                  $transdate=date($v['REF_COUNTER_DATE']);
                $single_account_statement = array();
                $single_account_statement['slNo'] = $siNo;
                $single_account_statement['fromDate'] = switch_date_format($fromdate, 'Y-m-d', 'd-m-Y');
                $single_account_statement['toDate'] = switch_date_format($todate, 'Y-m-d', 'd-m-Y');
                $single_account_statement['dueDate'] =  switch_date_format($v['INT_DUE_DATE'], 'Y-m-d', 'd-m-Y');
                $single_account_statement['intAmount'] = $v['INT_AMT'];
                $single_account_statement['intAmountDrawn'] = $v['INT_AMT_DRAWN'];
                $single_account_statement['intAdjusted'] =  $v['EXCESS_INT_ADJUST'];
                $single_account_statement['intDue'] =  $intdues;
                $single_account_statement['excessPaid'] = $excesspaid;
                $single_account_statement['scrtOk'] = $v['SCRT_OK'];
                $single_account_statement['transDate'] =  $transdate;
                $single_account_statement['transNo'] =  $v['REF_DAILY_SEQNO'];
                $siNo++;
                $fixedAccountData[] = $single_account_statement;
              }



    $this->response['data']['fixedAccountStatement'] = $fixedAccountData;
    $this->response['status'] = true;

        }

     // set output response

      $this->output->set_content_type('application/json');
      $this->output->set_output(json_encode($this->response));
      return;

   }
 }
?>

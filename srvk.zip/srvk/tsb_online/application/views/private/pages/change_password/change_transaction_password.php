  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Change Password
      <small>Transaction Key</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Change Password</a></li>
      <li class="active">Transaction Key</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <!-- Custom Tabs -->
          <div class="nav-tabs-custom">

            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">

                    <div class="box-body">
                    <div class="row">
                       <div class="col-md-6">
                        <form role="form" rel="js-change-transaction-key-form">
                          <!-- text input -->
                          <!-- input states -->
                          <div class="form-group ">
                            <label>Old Transaction Key</label>
                            <input type="password" name="oldTransactionKey" class="form-control" placeholder="Old Transaction Key">
                            <span class="help-block"></span>
                          </div>
                           <div class="form-group ">
                            <label>New Transaction Key</label>
                            <input type="password" name="newTransactionKey" class="form-control" id="inputError" placeholder="Enter New Transacion Key">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group ">
                            <label>Confirm New Transaction Key</label>
                            <input type="password" name="confirmNewTransactionKey" class="form-control" placeholder="Confirm New Transacion Key">
                            <span class="help-block"></span>
                          </div>
                          <div class="row box-body">
                            <button class="btn bg-olive btn-success" rel="js-change-transaction-key-form-submit-btn" type="submit">Save</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
              </div>
              <!-- /.tab-pane -->
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
         <!-- nav-tabs-custom -->
        </div>
    </div>
  </section>
  <!-- /.content -->

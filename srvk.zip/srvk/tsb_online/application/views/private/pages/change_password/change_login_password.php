  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Change Password
      <small>Login Password</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Change Password</a></li>
      <li class="active">Login Password</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">

                    <div class="box-body">
                      <div class="row">
                       <div class="col-md-6">
                        <form role="form" rel="js-change-password-form">
                          <!-- text input -->
                          <div class="form-group">
                            <label for="username">User Name</label>
                            <input type="text" readonly class="form-control" value="<?php echo $user_name; ?>" >
                          </div>
                          <!-- input states -->
                          <div class="form-group">
                            <label for="oldPassword">Old Password</label>
                            <input type="password" class="form-control" name="oldPassword" id="old-password" placeholder="Old Password">
                            <span class="help-block"></span>
                          </div>
                           <div class="form-group ">
                            <label for="newPassword">New Password</label>
                            <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="Enter New Password">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group ">
                            <label for="confirmNewPassword">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirmNewPassword" id="confirm-new-password" placeholder="Confirm New Password">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group">
                            <button class="btn bg-olive btn-success" rel="js-change-login-password-submit-btn" type="submit">Save</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
              </div>
              <!-- /.tab-pane -->
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
         <!-- nav-tabs-custom -->
        </div>
    </div>
  </section>
  <!-- /.content -->

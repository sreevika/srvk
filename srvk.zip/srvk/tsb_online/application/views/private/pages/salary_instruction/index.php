  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Home
      <small>Salary Instruction</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Salary Instruction</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
             <div class="box">
                        <div class="box-body table-responsive no-padding">
                          <table class="table table-hover">
                            <tbody><tr>
                              <th>Beneficiary Name</th>
                              <th> Beneficiary Account Number</th>
                              <th> IFSC</th>
                              <th>  Percentage</th>
                              <th> #</th>
                            </tr>
                            <tr>
                              <td>Anjana M S</td>
                              <td>20267527535</td>
                              <td>SBIN0017230</td>
                              <td></td>
                              <td>Edit</td>
                            </tr>
                          </tbody></table>
                        </div>
                        <!-- /.box-body -->
                      </div>
      </div>
    </div>
    <div class="row"></div>
  </section>
  <!-- /.content -->

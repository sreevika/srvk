  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Fund Transfer
      <small>TSB Fund Transfer</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Fund Transaction</a></li>
      <li class="active">TSB Fund Transfer</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <form rel="js-intra-bank-fund-transfer-form">
    <div class="box box-solid">
      <div class="box-body">
      <div class="row">
        <div class="col-md-12">
          <p class="text-red"> Mandatory fields are marked with an asterisk (*)</p>
          <label class="text-light-blue"> Select the account from which you wish to transfer fund.</label>
        </div>
        <div class="col-md-12">
            <div class=" table-response" rel="js-intra-bank-account-list-view">
              <!-- Intra bank beneficay list view here  -->
            </div>
        </div>
        <div class="col-md-12">
          <div class="row">
          <div class="col-md-2 ">
            <div class="form-group">
              <label for="intra-bank-fund-transfer-amount" class=" control-label">Amount <span class="text-red"> *</span></label>
               <input type="text" name="amount" id="intra-bank-fund-transfer-amount" rel="js-intra-bank-amount-field" class="form-control"  placeholder="Amount">
               <span class="help-block text-red" rel="js-name-amount"></span>
            </div>
          </div>
          <div class="col-md-6" >
            <div class="form-group">
              <label>Amount in words</label>
              <input class='form-control' readonly type="text" value="" rel="js-amount-to-word" >
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8">
            <div class="form-group">
                <label for="intra-bank-fund-transfer-remark" class=" control-label">Remark</label>
                <textarea class="form-control" id="intra-bank-fund-transfer-remark" name="remark"  placeholder="Remark"></textarea>
                <span class="help-block text-red" rel="js-name-remark"></span>
            </div>
          </div>
        </div>
       </div>
       <div class="col-md-12">
         <label class="text-light-blue"> Select the TSB beneficiary account.</label>
       </div>
       <div class="col-md-12 " >
         <div class="table-responsive" rel="js-intra-bank-beneficiary-list-view">
         <!-- intra bank beneficay list view -->
         </div>
       </div>
       <div class="col-md-12">
         <label class="text-light-blue"> Select Payment Option.</label>
       </div>
       <div class="row">
         <div class="col-md-8">
           <div class="col-md-4 ">
             <input type="radio" class=""  value="PN" rel="js-payment-option" name="paymentOption">
             <label>Pay Now</label>
           </div>
           <div class="col-md-4 ">
             <input type="radio" class=""  value="SL" rel="js-payment-option" name="paymentOption" >
             <label>Schedule Later</label>
           </div>
         <div class=" col-md-12 text-red help-block" rel="js-name-paymentOption"></div>
         </div>
       </div>
       <div class="row form-inline box-body hide" rel="js-select-date-view" >
         <div class="col-md-4">
               <div class=" col-md-12 form-group">
                 <label for="scheduleDate">Select Date</label>
                  <div class="input-group">
                   <label class="input-group-addon" for="scheduleDate">
                     <i class="fa fa-calendar"></i>
                   </label>
                   <input type="text" class="form-control" name="scheduleDate" rel="intra-bank-fund-transaction-schedule-date" id="scheduleDate">
                 </div>
                 <span class="help-block text-red" rel="js-name-scheduleDate"></span>
               </div>
         </div>
       </div>
        <div class="col-md-4">
          <div class="form-group">
            <label>Transaction Password</label>
            <input type="Password" class="form-control" name="transPassword" placeholder="Transaction Password" >
            <span class="help-block text-red" rel="js-name-transPassword"></span>
          </div>
        </div>
        <div class="col-md-12">
          <button class='btn  btn-success bg-olive' type="submit">Transfer</button>
        </div>
      </div>
        <div class="row">
        <div class="col-md-12">
         <div class="row">
         </div>
          <div class="box-default">
            <div class="box-body">
              <div class="row box-body">

              </div>
            </div>
          <!-- /.box-body -->
          </div>
        </div>
      </div>
      <!--// row -->
      <input type="hidden" name="transType" value="I">
    </div>
    </div>
    </form>
    <script type="text/custom-template" rel="js-intra-bank-account-list-template">
        <div class="from-group ">
        <table class="table table-hover">
          <thead class="bg-blue-gray">
            <tr>
              <th>#</th>
              <th>Account Number</th>
              <th>Account Type</th>
              <th>Treasury</th>
              <th class="text-right">Balance</th>
            </tr>
          </thead>
          <tbody>
            {{#each this}}
            <tr>
              <td><input value="{{accNo}}" name="accNo" type="radio"></td>
              <td>{{accNo}}</td>
              <td>{{accTypeAbbr}}</td>
              <td>{{accTrcode}}</td>
              <td><a data-balance="{{accBal}}" rel="account-balance-btn" class="pull-right badge bg-olive">Show Balance</a></td>
            </tr>
            {{/each}}
        </tbody>
      </table>
      <span class="help-block text-red" rel="js-name-accNo"></span>
      </div>
    </script>
    <script type="text/custom-template" rel="js-intra-bank-beneficiary-list-template">
        <div class="from-group">
        <table class="table table-hover">
          <thead class="bg-blue-gray">
            <tr>
              <th>#</th>
              <th>Account Number</th>
              <th>Beneficiary Name</th>
              <th class="text-right">Transaction Limit</th>
            </tr>
          </thead>
          <tbody>
            {{#each this}}
            <tr>
              <td><input value="{{benfId}}" name="benfId" type="radio"></td>
              <td>{{benfAccNo}}</td>
              <td>{{benfName}}</td>
              <td class="text-right">{{transLimit}}</td>
            </tr>
            {{/each}}
          </tbody>
       </table>
       <span class="help-block text-red" rel="js-name-benfId"></span>
       </div>
    </script>
  </section>
  <!-- /.content -->

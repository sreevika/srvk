  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Home
      <small>Transaction History</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Transaction History</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Fund Transaction History</h3>
          </div>
          <div class="box-body " >
            <p class="text-light-blue">Last Three Month Transaction History</p>
            <div class="table-responsive" rel="js-transaction-history-view"></div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/custom-template" rel="js-transaction-history-template" >
      <table class="table table-hover">
        <thead  class="bg-blue-gray">
          <tr>
            <th>Transaction Date</th>
            <th>Account Number</th>
            <th>Transaction Id</th>
            <th>Beneficiary Account Number</th>
            <th>Transaction Type</th>
            <th class="text-right">Amount</th>
            <th class="text-center">Status</th>
          </tr>
        </thead>
        <tbody>
        {{#if this}}
        {{#each this}}
        <tr>
            <td>{{transDate}}</td>
            <td>{{sourceAccNo}}</td>
            <td>{{transId}}</td>
            <td>{{destnationAccNo}}</td>
            <td>{{transType}}</td>
            <td class="text-right">{{amount}}</td>
            <td>
            {{#ifCond status 'Completed'}}<span class="badge bg-olive">{{status}}</span>{{/ifCond}}
            {{#ifCond status 'Processing'}}<span class="badge bg-yellow">{{status}}</span>{{/ifCond}}
            {{#ifCond status 'Rejected'}}<span class="badge bg-red">{{status}}</span>{{/ifCond}}
            {{#ifCond status 'Failed'}}<span class="badge bg-red">{{status}}</span>{{/ifCond}}
            {{#ifCond status 'Scheduled'}}<span class="badge bg-blue">{{status}}</span>{{/ifCond}}
            </td>
        </tr>
        {{/each}}
        {{else}}
          <tr><td colspan="7" class="text-center">No Data</th></tr>
        {{/if}}
        </tbody>
      </table>
    </script>
  </section>
  <!-- /.content -->

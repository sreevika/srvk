  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Fund Transfer
      <small>Bank Fund Transaction</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Fund Transaction</a></li>
      <li class="active">Bank Fund Transfer</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="box">
      <div class="box-body">

        <form rel="js-inter-bank-fund-transfer-form">
        <div class="row">
          <div class="col-md-12">
              <p class="text-red"> Mandatory fields are marked with an asterisk (*)</p>
              <p class="text-light-blue"> Select the account from which you wish to transfer fund.</p>
          </div>
          <div class="col-md-12">
            <div   rel="js-inter-bank-account-list-view">
              <!-- Inter bank beneficay list view here  -->
            </div>
          </div>
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-2 ">
                <div class="form-group">
                   <label for="inter-bank-fund-transfer-amount" class=" control-label">Amount <span class="text-red"> *</span></label>
                   <input type="text" class="form-control" rel="js-inter-bank-amount-field" id="inter-bank-fund-transfer-amount" name="amount"  placeholder="Amount">
                   <span class="help-block text-red" rel="js-name-amount"></span>
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <label>Amount in words</label>
                  <input class='form-control' readonly type="text" value="" rel="js-amount-to-word" >
                </div>
              </div>
             </div>
             <div class="row">
               <div class="col-md-8">
              <div class="form-group">
                 <label for="inter-bank-fund-transfer-remark" class=" control-label">Remark</label>
                 <textarea class="form-control" id="inter-bank-fund-transfer-remark" name="remark"  placeholder="Remark"></textarea>
                 <span class="help-block text-red" rel="js-name-remark"></span>
               </div>
             </div>
            </div>
          </div>
          <div class="col-md-12" >
            <div class="table-responsive"  rel="js-inter-bank-beneficiary-list-view" >
            <!-- inter bank beneficay list view -->
            </div>
          </div>
          <div class="col-md-12">
            <p class="text-light-blue"> Select Payment Option.</p>
            <div class="row">
              <div class="col-md-8">
                  <div class="row">
                    <div class="col-md-4 ">
                      <label>Payment Options :</label>
                    </div>
                    <div class="col-md-4 ">
                      <input type="radio" class=""  value="PN" rel="js-payment-option" name="paymentOption">
                      <label>Pay Now</label>
                    </div>
                    <div class="col-md-4 ">
                      <input type="radio" class=""  value="SL" rel="js-payment-option" name="paymentOption" >
                      <label>Schedule Later</label>
                    </div>
                    <div class="col-md-12"><span class="help-block text-red" rel="js-name-paymentOption"></span></div>
                  </div>
              </div>
            </div>
            <div class="row form-inline box-body hide" rel="js-select-date-view" >
              <div class="col-md-4">
                    <div class="form-group">
                      <label for="inter_fund_transfer_schedule_date">Select Date</label>
                       <div class="input-group">
                          <label for="inter_fund_transfer_schedule_date" class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </label>
                          <input type="text" name="scheduleDate" rel="inter-bank-fund-transaction-schedule-date" class="form-control" id="inter_fund_transfer_schedule_date">
                      </div>
                      <span class="help-block text-red" rel="js-name-scheduleDate"></span>
                    </div>
              </div>
            </div>

          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>Transaction Password</label>
              <input type="password" class="form-control" name="transPassword" placeholder="Transaction Password" >
              <span class="help-block text-red" rel="js-name-transPassword"></span>
            </div>
          </div>
          <div class="col-md-12">
              <p class="text-light-blue">Please note, As per RBI Instruction credit will be effected solely on the beneficiary account number information and the beneficiary name perticulars will not be used therefor</p>
          </div>

          <input type="hidden" name="transType" value="O">
          <div class="col-md-1">
            <button class='btn  btn-success bg-olive' type="submit">Transfer</button>
          </div>
        </div>
        </form>
      </div>
    </div>
    <script type="text/custom-template" rel="js-inter-bank-account-list-template">
            <div class="form-group">
              <table class="table table-hover">
                <thead class="bg-blue-gray">
                  <tr>
                    <th>#</th>
                    <th>Account Number</th>
                    <th>Account Type</th>
                    <th class="text-right">Balance</th>
                  </tr>
                </thead>
                <tbody>
                {{#each this}}
                <tr>
                  <td><input type="radio" value="{{accNo}}" name="accNo"></td>
                  <td>{{accNo}}</td>
                  <td>{{accTypeAbbr}}</td>
                  <td><a data-balance="{{accBal}}" rel="account-balance-btn" class="pull-right badge bg-olive">Show Balance</a></td>
                </tr>
                {{/each}}
                </tbody>
            </table>
            <span class="help-block text-red" rel="js-name-accNo" ></span>
          </div>
    </script>
    <script type="text/custom-template" rel="js-inter-bank-beneficiary-list-template">
      <div class="form-group">
        <table class="table table-hover">
            <thead class="bg-blue-gray">
              <tr>
                <th>#</th>
                <th>Beneficiary Name</th>
                <th>IFS Code</th>
                <th>Beneficiary Account Number </th>
                <th>Bank Name</th>
                <th>Branch</th>
                <th class="text-right">Transfer Limit</th>
              </tr>
            </thead>
            <tbody>
            {{#each this}}
            <tr>
              <td><input type="radio" name="benfId" value="{{benfId}}"></td>
              <td>{{benfName}}</td>
              <td>{{ifsCode}}</td>
              <td>{{benfAccNo}}</td>
              <td>{{bankName}}</td>
              <td>{{branch}}</td>
              <td><a class="pull-right">{{transLimit}}</a></td>
            </tr>
            {{/each}}
          </tbody>
        </table>
        <span class="help-block text-red" rel="js-name-benfId"></span>
      </div>
    </script>
  </section>
  <!-- /.content -->

<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Dashboard
    <small>Rejection Clear</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Rejection Clear</li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class='box'>
        <div class="box-header"><h3 class="box-title">Rejection Clear</h3></div>
        <div class="box-body table-responsive" rel="rejection-clear-view">
          <!-- view for loading the salary instuction template -->
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade in" rel="rejection-clear-edit-modal" id="rejection-clear-edit-modal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Edit Transaction Details</h4>
        </div>
        <div class="modal-body">
          <form role="form" rel="js-rejection-edit-form">
            <div class="form-group">
               <lable>Transfered Amount</label>
               <input type="text" readonly class="form-control" name="amount" >
               <span class="help-block"></span>
             </div>
            <div class="form-group">
               <lable>Beneficiary Account Number</label>
               <input type="text"  class="form-control" name="account_number" placeholder="Beneficiary Account Number"
                rel="rejection-update-account-number">
               <span class="help-block"></span>
             </div>
             <div class="form-group">
               <lable>Beneficiary Name</label>
               <input type="text"  class="form-control" name="benf_name" placeholder="Beneficiary Name">
               <span class="help-block"></span>
             </div>
             <div class="form-group">
               <lable>IFS Code</label>
               <input type="text"  class="form-control" name="ifsc" placeholder="IFS Code">
               <span class="help-block"></span>
             </div>
             <div class="form-group">
               <lable>Remarks</label>
               	<textarea class="form-control" name="remark"></textarea>
               <span class="help-block"></span>
             </div>
             <div class="form-group">
               <label>Transaction Key</label>
               <input type="password" class="form-control" name="transKey" placeholder="Transaction Key">
               <span class="help-block"></span>
             </div>
             <input type="hidden" name="transaction_id">
            
            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-sm bg-olive pull-right" rel="js-update-rejection-clear-btn">Submit</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <script type="text/custom-template" rel="rejection-clear-table-template">
          <table class="table table-hover">
            <thead class="bg-blue-gray">
              <tr>
                <th>Credit Date</th>
                <th>Transaction Id</th>
                <th>Beneficiary Name</th>
                <th>Account Number</th>
                <th>IFSC</th>
                <th>Amount</th>
                <th>Reason</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {{#if this}}
              {{#each this}}
              <tr data-rej="{{json this}}">
                <td>{{credit_date}}</td>
                <td>{{transaction_id}}</td>
                <td>{{benf_name}}</td>
                <td>{{account_number}}</td>
                <td>{{ifsc}}</td>
                <td>{{amount}}</td>
                <th>{{reason}}</th>
                <td><button href="#" class="btn btn-sm bg-olive pull-right"  rel="js-rejection-edit-btn" ><i class="fa fa-fw fa-edit"></i>Edit</button></td>
              </tr>
              {{/each}}
              {{else}}
              <tr>
                <td colspan="5" class="text-center">No data</td>
              </tr>
              {{/if}}
            </tbody>
          </table>
  </script>

</section>
<!-- /.content -->

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Home
      <small>Standing Instruction</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Standing Instruction</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#add_standing_instruction" data-toggle="tab" aria-expanded="false">Add</a></li>
              <li class=""><a href="#view_standing_instruction" data-toggle="tab" aria-expanded="true">View</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="add_standing_instruction">
               <div class="box-body">
                  <div class="col-md-12">
                    <p class="text-red"> Mandatory fields are marked with an asterisk (*)</p>
                    <p class="text-light-blue"> Select the account from which you wish to transfer fund.</p>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <table class="table table-hover">
                      <tbody><tr>
                        <th>#</th>
                        <th>Account Number</th>
                        <th>Account Type</th>
                        <th>Treasury</th>
                        <th class="pull-right">Balance</th>
                      </tr>
                      <tr>
                        <td><input checked type="radio"></td>
                        <td>7000231122009234</td>
                        <td>TSB</td>
                        <td>District. Treasury Trivandrum</td>
                        <td><a class="pull-right badge bg-olive">Show Balance</a></td>
                      </tr>
                      <tr>
                        <td><input type="radio"></td>
                        <td>7000231122009234</td>
                        <td>ETSB</td>
                        <td> Treasury Trivandrum</td>
                        <td><a class="pull-right badge bg-olive">Show Balance</a></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <!--// col-md-12 -->
                <div class="col-md-12">
                <div class="col-md-5">
                 <div class="form-horizontal">
                     <div class="box-body">
                        <div class="form-group">
                          <label for="inputEmail3" class="col-sm-5 control-label">Beneficiary Name <span class="text-red"> *</span></label>

                          <div class="col-sm-7">
                           <select class="form-control">
                              <option value=""> -- Select -- </option>
                              <option value="1">BABY E</option>
                              <option value="2">ANJANA P</option>
                              <option value="3">SIVASANKARAN NAIR  K & VASANTHAKUMARI.N.S</option>
                              <option value="4">VENKATARAJA SARMA  V&SAMBHAVI SARMA</option>
                              <option value="5">CHAIRMAN TVM CHIT FUND PRIVATE LTD</option>
                              <option value="6">STHANU BAI  K</option>
                            </select>
                          </div>
                        </div>
                     </div>
                  </div>
                 </div>
                 <div class="col-md-7">
                 <div class="form-horizontal">
                    <div class="box-body">
                        <div class="form-group">
                          <label for="inputEmail3" class="col-sm-4 control-label">Time Period & Unit <span class="text-red"> *</span></label>

                          <div class="col-sm-5">
                           <select class="form-control">
                              <option value=""> -- Select One -- </option>
                              <option value="monthly">Monthly</option>
                            </select>
                          </div>
                          <div class="col-sm-3">
                              <select class="form-control">
                                <option value=""> -- Select One -- </option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                              </select>
                          </div>
                        </div>
                     </div>
                
                  </div>
                 </div>
                </div>

                <!--// col-md-12 -->
                <div class="col-md-12">
                  <div class="box-default">
                    <div class="box-header ">
                      <h3 class="box-title">Transaction As <span class="text-red"> *</span></h3>
                    </div>
                    <div class="box-body">
                      <div class="row">
                        <div class="col-md-8">
                          <div class="col-xs-3 ">
                            <input type="radio" checked class="" name="periode" >
                            <label>Fixed Amount</label>
                          </div>
                          <div class="col-xs-4 ">
                            <input type="radio" class=""  name="periode">
                            <label>Fixed % of Account Balance</label>
                          </div>
                          <div class="col-xs-5 ">
                            <input type="radio" class=""  name="periode">
                            <label>Fixed % of Current Month Net Balance</label>
                          </div>
                          
                        </div>
                      </div>
                     
                     <div class="row">
                        <div class="col-md-6 ">
                             <div class="form-horizontal">
                                    <div class="box-body">
                                      <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-2 control-label">Amount <span class="text-red"> *</span></label>

                                        <div class="col-sm-10">
                                         <input type="text" class="form-control"  placeholder="Amount">
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Remarks</label>

                                        <div class="col-sm-10">
                                          <textarea class="form-control"  placeholder="Remarks"></textarea>
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-2 control-label">Priority</label>

                                        <div class="col-sm-10">
                                           <select class="form-control">
                                              <option value=""> -- Select One --</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                            </select>
                                        </div>
                                      </div>
                                    </div>
                                    <!-- /.box-body -->
                                  </div>     
                              </div>
                            </div>
                           <div class="form-group  col-md-12">
                        <p class="text-light-blue">Please note, As per RBI Instruction credit will be effected solely on the beneficiary account number information and the beneficiary name perticulars will not be used therefor</p>
                      </div> 
                          <div class="row box-body">
                            <div class="col-md-1">
                              <button class='btn  btn-block btn-success' type="submit">Save</button>
                            </div>
                            <div class="col-md-1">
                              <button class='btn  btn-block btn-default' type="submit">Reset</button>
                            </div>
                      </div>
                    </div>
                  <!-- /.box-body -->
                  </div>
                </div>
              </div>
              <!--// row -->
            </div>
              <!-- /.tab-pane -->
            <div class="tab-pane " id="view_standing_instruction">
              <div class="row">
                <div class="col-md-12">
                     <div class="col-md-8">
                             <div class="form-horizontal">
                                 <div class="box-body">
                                    <div class="form-group">
                                      <label for="inputEmail3" class="col-md-4 control-label">Select Account Number<span class="text-red"> *</span></label>

                                      <div class="col-md-6">
                                       <select class="form-control">
                                          <option value=""> -- Select One -- </option>
                                          <option value="7000231122009234">7000231122009234</option>
                                        </select>
                                      </div>
                                      <div class="col-md-2">
                                        <button class='btn  btn-block btn-success' type="submit">Go</button>
                                      </div>
                                    </div>
                                 </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-body table-responsive no-padding">
                          <table class="table table-hover">
                            <tbody><tr>
                              <th>sl.No</th>
                              <th> Account Type</th>
                              <th> Beneficiary Name</th>
                              <th> Time Period</th>
                              <th> Time Unit</th>
                              <th> Account Minimum</th>
                              <th> Percentage</th>
                              <th> Transaction AmountInt. Due</th>
                              <th> Priority</th>
                              <th> Edit</th>
                              <th> Active/De-Active</th>
                              <th> Confirm/Cancel</th>
                            </tr>
                            <tr>
                              <td>1</td>
                              <td>TREASURY SAVINGS BANK</td>
                              <td>RATHEESH</td>
                              <td>Monthly</td>
                              <td>28</td>
                              <td></td>
                              <td>0</td>
                              <td>1000</td>
                              <td>1</td>
                              <td>edit</td>
                              <td>Active</td>
                              <td>Confirm</td>
                            </tr>
                           <tr>
                               <td>2</td>
                              <td>TREASURY SAVINGS BANK</td>
                              <td>Satheesh</td>
                              <td>Monthly</td>
                              <td>13</td>
                              <td>1000</td>
                              <td>10</td>
                              <td>0</td>
                              <td>3</td>
                              <td>edit</td>
                              <td>InActive</td>
                              <td>Cancel</td>
                            </tr>
                          </tbody></table>
                        </div>
                        <!-- /.box-body -->
                      </div>
                      <!-- /.box -->
                    </div>
              </div>
            </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
      </div>
    </div>
    <div class="row"></div>
  </section>
  <!-- /.content -->

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Home
      <small>Account Statement</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Account Statement</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#account_statements_savings" data-toggle="tab" aria-expanded="false">Savings</a></li>
              <li class=""><a href="#account_statements_fixed_deposite" data-toggle="tab" aria-expanded="true">Fixed Desposit</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="account_statements_savings">
                <div class="row">
                  <form rel="account-statement-savings-form">
                  <div class="col-md-12 table-responsive " rel="savings-account-list-view">
                      <!-- load saving bank template here -->
                  </div>
                <!--// col-md-12 -->
                <div class="col-md-12">
                  <!--
                 <div class="box-header ">
                  <!-- <h4><b>Selected Account Number: </b><span>7000231122009234</span></h4> -->
                  <!--
                 </div>
               -->
                  <div class="box-default">
                    <div class="box-header ">
                      <h3 class="box-title">Select option for statement period</h3>
                    </div>
                    <div class="box-body">
                      <div class="row">
                        <div class="col-md-8">
                          <div class="row">
                            <div class="col-md-3 ">
                              <input  type="radio"  class="" value="byDate" name="periode" rel="select-statement-period" >
                              <label>By Date</label>
                            </div>
                            <div class="col-md-3 ">
                              <input type="radio" class=""  value="byMonth" name="periode" rel="select-statement-period">
                              <label>By Month</label>
                            </div>
                            <div class="col-md-3 ">
                              <input type="radio" class=""  value="lastThreeMonth" name="periode" rel="select-statement-period">
                              <label>Last 3 Months</label>
                            </div>
                            <div class="col-md-3 ">
                              <input type="radio" class="" value="lastSixMonth"  name="periode" rel="select-statement-period">
                              <label>Last 6 Months</label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <span rel="name-periode" class='text-red'></span>
                      <div class="row form-inline box-body" >
                        <div class="col-md-4 hide" rel="period-by-date">
                            <div class="form-group">
                              <label for="accountSatementStartDate">Start Date</label>
                              <div class="input-group">
                                <label for="accountSatementStartDate" class="input-group-addon">
                                  <i class="fa fa-calendar"></i>
                                </label>
                                <input type="text" class="form-control" id="accountSatementStartDate" rel="savings-account-statement-start-date" name="startDate" placeholder="Start Date" >
                              </div>
                            </div>
                            <span rel="name-startDate" style="display: block" class="text-red"></span>
                        </div>
                        <div class="col-md-4 hide" rel="period-by-date">
                              <div class="form-group">
                                <label for="accountSatementEndDate">End Date</label>
                                <div class="input-group">
                                  <label for="accountSatementEndDate" class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                  </label>
                                <input type="email" class="form-control" id="accountSatementEndDate" rel="savings-account-statement-end-date" name="endDate" placeholder="End Date" >
                                </div>
                              </div>
                              <span rel="name-endDate" style="display: block" class="text-red"></span>
                        </div>
                        <div class="col-md-4 hide" rel="period-by-month">
                          <div class="form-group">
                            <label for="accountSatementYear">Year</label>
                            <select name="year" id="accountSatementYear" class="form-control">
                              <option value="">Select Year</option>
                              <?php
                                $current_year = (new DateTime())->format('Y');
                                for($i = $current_year; $i >= ($current_year - 2); $i--){
                                  ?>
                                  <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                  <?php
                                }
                              ?>
                            </select>
                            <span class="help-block"></span>
                          </div>
                        </div>
                        <div class="col-md-4 hide" rel="period-by-month">
                          <div class="form-group">
                            <label for="accountSatementMonth">Month</label>
                            <select name="month" id="accountSatementMonth" class="form-control">
                              <option value="">Select Month</option>
                              <option value="1">January</option>
                              <option value="2">February</option>
                              <option value="3">March</option>
                              <option value="4">April</option>
                              <option value="5">May</option>
                              <option value="6">June</option>
                              <option value="7">July</option>
                              <option value="8">August</option>
                              <option value="9">September</option>
                              <option value="10">October</option>
                              <option value="11">November</option>
                              <option value="12">December</option>
                            </select>
                            <span class="help-block"></span>
                          </div>
                        </div>
                      </div>
                      <div class="row box-body">
                          <button class='btn bg-olive' rel='generate-savings-account-statement' type="submit">Submit</button>
                      </div>
                    </div>
                  <!-- /.box-body -->
                  </div>
                </div>
                </form>
              </div>
              <!--// row -->
              <div class="row">
                <!--
                <div class="col-xs-12">
                  <div class="box">
                    <div class="box-header">
                      <h3 class="box-title">Account Statement</h3>
                    </div>
                    <div class="col-md-8">
                      <div class="box-body table-responsive no-padding">
                        <table class="table border-less">
                           <tbody>
                             <tr>
                              <td><b>Account Number </b></td><td>:</td>
                              <td>7000231122009234</td>
                              <td ><b>Accountant Name </b></td><td>:</td>
                              <td>Aswathy</td>
                            </tr>
                            <tr>
                              <td ><b>Treasury </b></td><td>:</td>
                              <td>District Treasury Trivandrum</td>
                              <td ><b>Account type </b></td><td>:</td>
                              <td>TSB</td>
                            </tr>
                           </tbody>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
              -->
                    <!-- /.box-header -->

                <div class="col-xs-12">
                  <div class="box box-solid">
                    <div class="box-body table-responsive no-padding" rel="savings-account-statement-view">
                    </div>
                    <!-- /.box-body -->
                  </div>
                  <!-- /.box -->
                </div>
              </div>
            </div>
              <!-- /.tab-pane -->
            <div class="tab-pane " id="account_statements_fixed_deposite">
              <div class="row">
                <div class="col-md-12">
                     <div class="col-md-8">
                       <div class="form-horizontal">
                           <div class="box-body">
                             <form rel="account-statement-fd-form">
                              <div class="form-group">
                                <label for="inputEmail3" class="col-md-4 control-label">Select TFD Account Number<span class="text-red"> *</span></label>
                                <div class="col-md-6" rel="fd-account-select-view">
                                  <!-- fd account select view -->
                                </div>
                                <div class="col-md-2">
                                  <button class='btn  btn-block bg-olive' rel="generate-fd-account-statement" type="submit">Submit</button>
                                </div>
                              </div>
                            </form>
                           </div>
                        </div>
                    </div>
                </div>
              </div>
                   <div class="row">
                <!--
                <div class="col-xs-12">
                  <div class="box">
                    <div class="box-header">
                      <h3 class="box-title">Account Details</h3>
                    </div>
                    <div class="col-md-10">
                      <div class="box-body table-responsive no-padding">
                        <table class="table border-less">
                           <tbody>
                             <tr>
                              <td><b>Treasury Name</b></td><td>:</td>
                              <td>District Treasury Trivandrum</td>
                              <td ><b>Account Holder</b></td><td>:</td>
                              <td>Aswathy</td>
                            </tr>
                            <tr>
                              <td ><b>Opening Balance</b></td><td>:</td>
                              <td>100000.00</td>
                              <td ><b>Balance Amount</b></td><td>:</td>
                              <td>100000.00</td>
                            </tr>
                             <tr>
                              <td ><b>Opening Date </b></td><td>:</td>
                              <td>05/10/2015</td>
                              <td ><b>Maturity Date</b></td><td>:</td>
                              <td>04/10/2018</td>
                            </tr>
                             <tr>
                              <td ><b>Interest Percentage </b></td><td>:</td>
                              <td>9.500</td>
                              <td ><b>Withdrawal Status</b></td><td>:</td>
                              <td>  Amount not Drawn</td>
                            </tr>
                             <tr>
                              <td ><b>Interest Crediting Account Type </b></td><td>:</td>
                              <td>1</td>
                              <td><b>Interest Crediting Account Number</b></td><td>:</td>
                              <td></td>
                            </tr>
                           </tbody>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
              -->
                    <!-- /.box-header -->

                <div class="col-xs-12">
                  <div class="box box-solid">
                    <div class="box-body table-responsive no-padding" rel="fd-account-statement-view">
                    <!-- fd addount statement view -->
                    </div>
                    <!-- /.box-body -->
                  </div>
                  <!-- /.box -->
                </div>
              </div>
            </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
      </div>
    </div>
    <div class="row"></div>
    <script type="text/custom-template" rel="fd-account-select-template">
      <select class="form-control" name="accountNumber">
         <option value="">Select Fd Account Number</option>
         {{#each this}}
         <option value="{{accNo}}">{{accNo}}</option>
         {{/each}}
      </select>
      <span class="text-red" rel="name-accountNumber"></span>
    </script>
    <script type="text/custom-template" rel="savings-account-list-template">
        <table class="table table-hover">
          <thead class="bg-blue-gray"><tr>
            <th>#</th>
            <th>Account Number</th>
            <th>Account Type</th>
            <th>Treasury</th>
            <th class="text-right">Balance</th>
          </tr>
          </thead>
          <tbody>
          {{#if this}}
          {{#each this}}
          <tr>
            <td><input name="accountNumber" value="{{accNo}}"  type="radio"></td>
            <td>{{accNo}}</td>
            <td>{{accTypeAbbr}}</td>
            <td>{{accTrcode}}</td>
            <td><a class="pull-right badge bg-olive"  rel="account-balance-btn" data-balance="{{accBal}}">Show Balance</a></td>
          </tr>
          {{/each}}
          {{else}}
          <tr>
            <td colspan="5" class="text-center">No data</td>
          </tr>
          {{/if}}
          </tbody>
        </tbody>
      </table>
      <span class="text-red" rel="name-accountNumber"></span>
    </script>
    <script type="text/custom-template" rel="savings-account-statement-template">
          <table class="table table-hover">
            <thead class="bg-blue-gray">
              <tr>
                <th>Sl.No</th>
                <th>Date</th>
                <th>Particulars</th>
                <th>Transaction ID</th>
                <th class="text-right">Debit</th>
                <th class="text-right">Credit</th>
                <th class="text-right">Account Balance</th>
                <th class="text-left">Remarks</th>
              </tr>
            </thead>
            <tbody>
              {{#if this}}
              {{#each this }}
              <tr>
                <td>{{slNo}}</td>
                <td>{{transDate}}</td>
                <td>{{description}}</td>
                <td>{{transId}}</td>
                <td><p class="pull-right">{{debit}}</p></td>
                <td><p class="pull-right">{{credit}}</p></td>
                <td><p class="pull-right">{{accBal}}</p></td>
                <td><p class="text-left">{{remark}}</p></td>
              </tr>
              {{/each}}
              {{else}}
                <tr>
                  <td colspan="8" class="text-center">No Data Found</td>
                </tr>
              {{/if}}
          </tbody>
        </table>
    </script>
    <script type="text/custom-template" rel="fd-account-statement-template">
      <table class="table table-hover">
        <thead class="bg-blue-gray">
          <tr>
            <th>Sl. No.</th>
            <th>From</th>
            <th>To</th>
            <th>Due Date</th>
            <th class="text-right">Int. Amt</th>
            <th class="text-right">Int.Amt Drawn</th>
            <th class="text-right">Int. Adjusted</th>
            <th class="text-right">Int. Due</th>
            <th class="text-right" >Excess Paid</th>
            <th>Trans. Date</th>
            <th>Trans. No</th>
          </tr>
        </thead>
        <tbody>
          {{#if this}}
          {{#each this}}
          <tr>
            <td>{{slNo}}</td>
            <td>{{fromDate}}</td>
            <td>{{toDate}}</td>
            <td>{{dueDate}}</td>
            <td class="text-right" >{{intAmount}}</td>
            <td class="text-right" >{{intAmountDrawn}}</td>
            <td class="text-right" >{{#if intAdjusted}}{{intAdjusted}}{{else}}no data{{/if}}</td>
            <td class="text-right" >{{intDue}}</td>
            <td class="text-right" >{{excessPaid}}</td>
            <td>{{transDate}}</td>
            <td>{{transNum}}</td>
          </tr>
          {{/each}}
          {{else}}
          <tr>
            <td colspan="12" class="text-center">No data</td>
          </tr>
          {{/if}}
        </tbody>
      </table>
    </script>
  </section>
  <!-- /.content -->

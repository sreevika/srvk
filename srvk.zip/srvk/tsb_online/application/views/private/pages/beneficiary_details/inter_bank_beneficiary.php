  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Bank Beneficiary
      <small>Manage Bank Beneficiaries</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>  Beneficiary Details</a></li>
      <li class="active"> Bank Beneficiary</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Add</a></li>
              <li><a href="#tab_2" data-toggle="tab">View</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-12">
                      <p class="text-red"> Mandatory fields are marked with an asterisk (*)</p>
                      <p class="text-light-blue"> Ensure that you enter the correct account number.</p>
                      <p class="text-light-blue"> TSB Does not accept responsiblity for fund transfered inadvertantly to a wrong account numberinput by the customer</p>
                    </div>
                  </div>
                </div>
                  <form role="form" rel="js-inter-bank-add-new-benf-form">
                    <div class="box-body ">
                      <div class="row">
                        <div class="form-group  col-md-6">
                          <label for="beneficiaryName">Beneficiary Name <span class="text-red"> *</span></label>
                          <input type="text" class="form-control" name="benfName" id="benfName" placeholder="Beneficiary Name">
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group col-md-6">
                          <label for="IfsCode"> IFS Code<span class="text-red"> *</span></label>
                          <input type="text" rel="js-inter-bank-add-new-benf-ifsc-field" class="form-control " name="ifsCode" id="ifsCode" placeholder="IFS Code">
                          <span class="help-block"></span>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group  col-md-6">
                          <label for="benficiaryBankName">Bank Name <span class="text-red"> *</span></label>
                          <input type="text" placeholder="Bank Name" readonly class="form-control col-md-6" rel="js-inter-bank-add-new-benf-bankname-field" name="bankName">
                          <input type="hidden" rel="js-inter-bank-add-new-benf-bankid-field" class="form-control" name="bankId" id="BranchId" >
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group  col-md-6">
                          <label for="BranchName">Branch <span class="text-red"> *</span></label>
                          <input type="text" readonly class="form-control" rel="js-inter-bank-add-new-benf-branchname-field" name="branchName" id="branchName" placeholder="Branch">
                          <span class="help-block"></span>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group  col-md-6">
                          <label for="BeneficiaryAccountNumber">Beneficiary Account No <span class="text-red"> *</span></label>
                          <input type="text" class="form-control" name="benefAccNo" rel="js-inter-bank-add-new-benf-acc-no" id="benefAccNo" placeholder="Beneficiary Account No">
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group  col-md-6">
                          <label for="BeneficiaryConfirmAccountNumber">Confirm Account Number <span class="text-red"> *</span></label>
                          <input type="text" class="form-control" id="CnfbenefAccNo" rel="js-inter-bank-add-new-benf-acc-no-confirm" name="CnfbenefAccNo" placeholder="Confirm Account Number">
                          <span class="help-block"></span>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group  col-md-6">
                          <label for="transactionLimit">Transfer Limit <span class="text-red"> *</span></label>
                          <input type="text" class="form-control" id="benfTransLimit" name="benfTransLimit" placeholder="Transfer Limit">
                          <span class="help-block"></span>
                        </div>
                        <div class="form-group  col-md-6">
                          <label for="transactionKey">Transaction Key <span class="text-red"> *</span></label>
                          <input type="password" class="form-control" id="benfTransKey" name="benfTransKey" placeholder="Transaction Key">
                          <span class="help-block"></span>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group  col-md-12">
                          <p class="text-light-blue"> SMS Alert for the new beneficiary will be sent to your mobile number</p>
                          <h5>Mobile Number : ********<?php echo $mobNoHint; ?></h5>
                          <p>Please note, As per RBI Instruction credit will be effected solely on the beneficiary account number information and the beneficiary name perticulars will not be used therefore</p>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group  col-md-6">
                         <button type="submit" rel="js-inter-bank-add-new-benf-submit-btn" class="btn bg-olive">Add Beneficiary</button>
                        </div>
                      </div>
                    </div>
                    <!-- /.box-body -->
                  </form>

              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                  <div class="row">
                    <div class="col-xs-12">

                        <div class="box-header">


                          <div class="box-tools">
                           <!-- /.Search box place -->
                          </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding" rel="inter-beneficiary-view-list-view">
                        <!--/. InterBank Beneficiary View -->
                        </div>
                        <!-- /.box-body -->

                      <!-- /.box -->
                    </div>
                  </div>
                  <div class="modal fade in" id="beneficiary_edit_modal" rel="js-beneficiary-edit-modal"  >
                   <div class="modal-dialog">
                     <div class="modal-content">
                       <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">×</span></button>
                         <h4 class="modal-title">Update Beneficairy</h4>
                       </div>
                       <div class="modal-body">
                         <form rel="js-beneficiary-edit-form">
                           <div class="form-group">
                             <lable>Beneficiary Account Number</label>
                             <input type="text" readonly class="form-control" name="benfAccNo" placeholder="Beneficiary Account Number">
                             <span class="help-block"></span>
                           </div>
                           <div class="form-group">
                             <lable>Beneficiary Name</label>
                             <input type="text" readonly class="form-control" name="benfName" placeholder="Beneficiary Name">
                             <span class="help-block"></span>
                           </div>
                           <div class="form-group">
                             <lable>Transaction limit</label>
                             <input type="text"  class="form-control" name="transLimit" placeholder="Transaction Limit">
                             <span class="help-block"></span>
                           </div>
                           <div class="form-group">
                             <label>Status</label>
                             <select name='activated' class="form-control">
                               <option value="">Select Status</option>
                               <option value="Y" >Active</option>
                               <option value="N">Deactivate</option>
                             </select>
                             <span class="help-block"></span>
                           </div>
                           <div class="form-group">
                             <label>Transaction Key</label>
                             <input type="password" class="form-control" name="transKey" placeholder="Transaction Key">
                             <span class="help-block"></span>
                           </div>
                           <input type="hidden" name="benfId">
                         </form>
                       </div>
                       <div class="modal-footer">
                         <button type="button" class="btn btn-default pull-left"  data-dismiss="modal">Close</button>
                         <button type="button" class="btn btn-sm bg-olive pull-right" rel="js-beneficiary-edit-form-save-btn">Submit</button>
                       </div>
                     </div>
                     <!-- /.modal-content -->
                   </div>
                   <!-- /.modal-dialog -->
                 </div>

              </div>
              <!-- /.tab-pane -->
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
    </div>
    <script type="text/custom-template" rel="inter-beneficiary-view-list-template">
        <table class="table table-hover">
            <thead class="bg-blue-gray"><tr>
              <th>Sl.No</th>
              <th>Status</th>
              <th>Beneficiary Name</th>
              <th>IFS Code</th>
              <th>Beneficiary Account Number </th>
              <th>Bank Name</th>
              <th>Branch</th>
              <th class="text-right">Transfer Limit</th>
              <th class="text-center">#</th>
            </tr>
            </thead>
            <tbody>
            {{#each this}}
              {{> app.namespace.pages.InterBankBeneficiary.benfTableRow}}
            {{/each}}
          </tbody>
        </table>
    </script>
    <script type="text/custom-template" rel="js-beneficiary-view-list-table-row">
          <tr data-benf="{{json this}}">
            <td>{{slNo}}</td>
            <td><span class=" badge {{#ifCond  activated 'Y'}} bg-olive {{else}} bg-red {{/ifCond }} ">{{#ifCond activated 'Y'}}Active{{else}}Not Active{{/ifCond }} </span></td>
            <td>{{benfName}}</td>
            <td>{{ifsCode}}</td>
            <td>{{benfAccNo}}</td>
            <td>{{bankName}}</td>
            <td>{{branch}}</td>
            <td class="text-right">{{transLimit}}</td>
            <td><button href="#" class="btn btn-sm bg-olive pull-right"  rel="js-beneficiary-edit-btn" ><i class="fa fa-fw fa-edit"></i>Edit</button></td>
          </tr>
    </script>
  </section>
  <!-- /.content -->

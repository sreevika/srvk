  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      TSB Beneficiary
      <small>Manage TSB Beneficiaries</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>  Beneficiary Details</a></li>
      <li class="active"> TSB Beneficiary</li>
    </ol>
  </section>

  <!-- Main content -->
    <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Add</a></li>
              <li><a href="#tab_2" data-toggle="tab">View</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-12">
                    <p class="text-red"> Mandatory fields are marked with an asterisk (*)</p>
                    <p class="text-light-blue"> Ensure that you enter the correct Account Number.</p>
                    <p class="text-light-blue"> TSB Does not accept responsiblity for fund transfered inadvertantly to a wrong account number input by the customer</p>
                  </div>
                </div>
                </div>
                  <form role="form" rel="js-form-save-intra-bank-benf">
                    <div class="box-body ">

                      <div class="row">
                      <div class="form-group  col-md-6">
                        <label for="BeneficiaryAccountNumber" >Beneficiary Account Number <span class="text-red"> *</span></label>
                        <input type="text" class="form-control" rel="js-form-benf-acc-no" name="benefAccNo" id="benefAccNo" placeholder="Beneficiary Account Number">
                        <span class="help-block"></span>
                      </div>

                      <div class="form-group  col-md-6">
                        <label for="CnfbenefAccNo">Confirm Account Number <span class="text-red"> *</span></label>
                        <input type="text" class="form-control" rel="js-form-benf-acc-no-cnf" id="CnfbenefAccNo" name="CnfbenefAccNo" placeholder="Confirm Account Number">
                        <span class="help-block"></span>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group  col-md-6">
                        <label for="benfName">Beneficiary Name <span class="text-red"> *</span></label>
                        <input type="text" class="form-control" readonly rel="js-form-benf-name" id="benfName" name="benfName" placeholder="Beneficiary Name">
                        <span class="help-block"></span>
                      </div>

                      <div class="form-group  col-md-6">
                        <label for="benfTransLimit">Transfer Limit <span class="text-red"> *</span></label>
                        <input type="text" class="form-control" id="benfTransLimit" name="benfTransLimit" placeholder="Transfer Limit">
                        <span class="help-block"></span>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group  col-md-6">
                        <label for="benfTransKey">Transaction Key <span class="text-red"> *</span></label>
                        <input type="password" class="form-control" id="benfTransKey" name="benfTransKey" placeholder="Transfer Limit">
                        <span class="help-block"></span>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group  col-md-12">
                        <p class="text-light-blue"> SMS Alert for the new beneficiary will be sent to your mobile number</p>
                        <h5>Mobile Number : ********<?php echo $mobNoHint; ?></h5>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group  col-md-6">
                        <button type="submit" rel="js-form-bnt-save-intra-bank-benf" class="btn bg-olive">Add Beneficiary</button>
                      </div>
                    </div>
                    </div>
                    <!-- /.box-body -->
                  </form>

              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                  <div class="row">
                    <div class="col-xs-12">

                        <div class="box-header">
                          <div class="box-tools">
                            <!-- /.Search box place -->
                          </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding" rel="beneficiary-view-list-view" >
                          <!-- benificary list view here -->
                        </div>
                        <!-- /.box-body -->

                      <!-- /.box -->
                    </div>
                  </div>
                 <div class="modal fade in" id="beneficiary_edit_modal" rel="js-beneficiary-edit-modal"  >
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Update Beneficairy</h4>
                      </div>
                      <div class="modal-body">
                        <form rel="js-beneficiary-update-form">
                          <div class="form-group">
                            <lable>Beneficiary Account Number</label>
                            <input type="text" readonly class="form-control" name="benfAccNo" placeholder="Beneficiary Account Number">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group">
                            <lable>Beneficiary Name</label>
                            <input type="text" readonly class="form-control" name="benfName" placeholder="Beneficiary Name">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group">
                            <lable>Transaction limit</label>
                            <input type="text"  class="form-control" name="transLimit" placeholder="Transaction Limit">
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group">
                            <label>Status</label>
                            <select name='activated' class="form-control">
                              <option value="">Select Status</option>
                              <option value="Y" >Active</option>
                              <option value="N">Deactivate</option>
                            </select>
                            <span class="help-block"></span>
                          </div>
                          <div class="form-group">
                            <label>Transaction Key</label>
                            <input type="password" class="form-control" name="transKey" placeholder="Transaction Key">
                            <span class="help-block"></span>
                          </div>
                          <input type="hidden" name="benfId">
                        </form>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"  data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-sm bg-olive pull-right" rel="js-beneficiary-edit-form-save-btn">Submit</button>
                      </div>
                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
    </div>
    <script type="text/custom-template" rel="beneficiary-view-list-template">
        <table class="table table-hover">
            <thead class="bg-blue-gray"><tr>
              <th>Sl.No</th>
              <th>Status</th>
              <th>Beneficiary Account Number </th>
              <th>Beneficiary Name</th>
              <th class="text-right">Transfer Limit</th>
              <th class="text-center">#</th>
            </tr>
            </thead>
            <tbody>
            {{#each this}}
            {{> app.namespace.pages.IntraBankBeneficiary.benfTableRow}}
            {{/each}}
            </tbody>
        </table>
    </script>
    <!-- Handlebars partials for row -->
    <script type="text/custom-template" rel="js-beneficiary-view-list-table-row">
            <tr data-benf="{{ json this}}">
            <td>{{slNo}}</td>
            <td><span class=" badge {{#ifCond activated 'Y' }} bg-olive {{else}} bg-red{{/ifCond }}">{{#ifCond activated  'Y' }}Active{{else}}Not active{{/ifCond}}</span></td>
            <td>{{benfAccNo}}</td>
            <td>{{benfName}}</td>
            <td class="text-right">{{transLimit}}</td>
            <td><a href="#" class="btn btn-sm bg-olive pull-right " rel="js-beneficiary-edit-btn"><i class="fa fa-fw fa-edit"></i>Edit</a></td>
            </tr>
    </script>
  </section>
  <!-- /.content -->

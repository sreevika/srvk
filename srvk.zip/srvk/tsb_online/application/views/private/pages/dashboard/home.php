  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Dashboard
      <small>My Accounts & Profile</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-4">
          <!-- Widget: user widget style 1 -->
          <div class="box box-primary" rel="profile-template-view">
            <!--load profile template here -->
          </div>

          <!-- /.widget-user -->
        </div>
        <div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Savings</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding" rel="savings-account-list-view">
            <!-- saving bank template here -->
            </div>
            <!-- /.box-body -->
          </div>
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Fixed Desposit</h3>

            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding" rel="fd-account-list-view">
            </div>
            <!-- /.box-body -->
          </div>
        </div>
    </div>
  </div>
  <div class="row">
      <div class="col-md-12">
      <div class="alert alert-dismissible" style="background: #F48FB1;color: #fff;">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4>Alert!</h4>
       Your last Login Time is - <?php echo $lastLoginTime; ?>
       </div>
      </div>
      <div class="col-md-12">
        <div class=" alert" style="background: #64B5F6; color: #fff;">
           <h4>Tip!</h4>
            <p>Do not share Otp, login password, transaction key with anyone!</p>
        </div>
      </div>
  </div>
  </section>
  <!-- PROFILE TEMPLATE -->
  <script type="text/custom-template" rel="profile-template">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>assets/private/img/user-icon.png" alt="User profile picture">

              <h3 class="profile-username text-center">{{name}}</h3>

              <!-- <p class="text-muted text-center">DOB:{{birthDate}}</p> -->

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Address:</b><p>{{address}} </p>
                </li>
                <li class="list-group-item">
                  <b>Pincode:</b> <p>{{pinCode}}</p>
                </li>
                <li class="list-group-item">
                  <b>Treasury:</b><p>{{treasury}}</p>
                </li>
              </ul>
            </div>
  </script>
  <!--/ PROFILE TEMPLATE END -->
  <script type="text/custom-template" rel="account-list-template">
              <table class="table table-hover">
                <tbody><tr>
                  <th>Sl.No</th>
                  <th>Account Number</th>
                  <th>Account Type</th>
                  <th class="pull-right">Balance</th>
                </tr>
                {{#each this}}
                <tr>
                  <td>{{siNo}}</td>
                  <td>{{accNo}}</td>
                  <td>{{accTypeAbbr}}</td>
                  <td><a data-balance="{{accBal}}" rel="account-balance-btn" class="pull-right badge bg-olive">Show Balance</a></td>
                </tr>
                {{/each}}
              </tbody>
            </table>

  </script>
  <!-- /.content -->

<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Dashboard
    <small>My Accounts & Profile</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class='box'>
        <div class="box-header"><h3 class="box-title">Salary Instruction</h3></div>
        <div class="box-body table-responsive" rel="salary-instruction-view">
          <!-- view for loading the salary instuction template -->
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade in" rel="salary-instruction-edit-modal" id="salary-instruction-edit-modal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Edit Salary Instruction</h4>
        </div>
        <div class="modal-body">
          <form role="form" rel="salary-instuction-update-form">
              <div class="box-body">
                <div class="form-group">
                  <label for="salary_instruction_beneficiary_name">Select Beneficiary Type</label>
                  <select class="form-control" disabled name="beneficiaryTransType" id="salary_instruction_beneficiary_name">
                    <option value="" >Select beneficiary</option>
                    <option value="I">TSB Bank</option>
                    <option value="O">Other Banks</option>
                  </select>
                  <span class="help-block"></span>
                </div>
                <div class="form-group">
                  <label for="salary_instruction_beneficiary_account_number">Select Beneficiary</label>
                  <select class='form-control' disabled name="beneficiaryId">
                    <option value="">Select Beneficiary</option>
                  </select>
                  <span class="help-block"></span>
                </div>
                <div class="form-group">
                  <label for="salary_instruction_percentage">Percentage</label>
                  <input type="text"  class="form-control" name="salaryInstructionPercentage" id="salary_instruction_percentage" value="" placeholder="Percentage">
                  <span class="help-block"></span>
                </div>
                <div class="form-group">
                  <label for="salary_instruction_trans_key">Transaction Key</label>
                  <input type="password"  class="form-control" name="salaryInstructionTransKey" id="salary_instruction_trans_key"  placeholder="Transaction Key">
                  <span class="help-block"></span>
                </div>
              </div>
              <input type="hidden" name="salaryInstructinId" value="">
              <!-- /.box-body -->
            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-sm bg-olive pull-right" rel="update-salary-instuction-btn">Submit</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <script type="text/custom-template" rel="salary-instruction-table-template">
          <table class="table table-hover">
            <thead class="bg-blue-gray">
              <tr>
                <th>Beneficiary Name</th>
                <th>Beneficiary Account Number</th>
                {{#ifCond transType 'O' }}
                <th>IFSC</th>
                {{/ifCond}}
                {{#ifCond transType 'I'}}
                <th>Trcode</th>
                {{/ifCond}}
                <th>Percentage</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {{#if this}}
              <tr>
                <td>{{benfName}}</td>
                <td>{{benfAccno}}</td>
                {{#ifCond transType 'O' }}
                <td>{{ifsc}}</td>
                {{/ifCond}}
                {{#ifCond transType 'I'}}
                <td>{{trCode}}</td>
                {{/ifCond}}
                <td>{{percentage}}</td>
                <td><button data-id="{{id}}" class="btn btn-sm bg-olive " data-toggle="modal" data-target="#salary-instruction-edit-modal">Edit</button></td>
              </tr>
              {{else}}
              <tr>
                <td colspan="5" class="text-center">No data</td>
              </tr>
              {{/if}}
            </tbody>
          </table>
  </script>
  <script type="text/custom-template" rel="salary-instruction-beneficiary-select-list-template">
      <option value="">Select Beneficiary</option>
      {{#each this }}
        <option value="{{id}}" >{{benfName}} : {{benfAccNo}}</option>
      {{/each}}
  </script>
</section>
<!-- /.content -->

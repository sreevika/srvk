  </div>
  <!-- /.data container -->
</div>
<!-- OTP modal -->
<div class="modal fade in" id="otp_modal" data-backdrop="static" data-keyboard="false" rel="js-otp-modal" >
    <div class="modal-dialog">
      <form rel="js-otp-verify-form">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Verify OTP</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="otp_input">Enter OTP</label>
            <input class="form-control" type="text" name="otp" placeholder="Enter OTP" >
            <span class="help-block"></span>
          </div>
          <a href="#" rel="js-otp-resend-otp-btn" >Click Here to resend OTP...</a>
        </div>
        <div class="modal-footer">
          <button type="button" rel="js-send-otp-btn" class="btn btn-primary">Submit</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </form>
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /OTP modal -->
<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0
  </div>
  <strong>All rights reserved  Treasury Department. Copyright &copy; <?php echo date('Y'); ?> Developed & Maintained by NIC Kerala State Centre</strong>.
</footer>

<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<div class="spinner-container " style=""><svg class="spinner" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div>
<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/private/js/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url(); ?>assets/private/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
$.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/private/js/bootstrap.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url(); ?>assets/private/js/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url(); ?>assets/private/js/bootstrap-datepicker.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url(); ?>assets/private/js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>assets/private/js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/private/js/adminlte.min.js"></script>
<!-- loading appliation core js files -->
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/eventemitter2.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/handlebars-v4.0.11.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/sweetalert.min.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/app.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/router.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/ajax.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/lib/alert.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/dashboard.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/accountstatement.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/intraBankBeneficiary.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/interBankBeneficiary.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/intraBankFundTransaction.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/interBankFundTransaction.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/transactionHistory.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/salaryInstruction.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/changeLogInPassword.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/changeTransactionPassword.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/pages/rejectionClear.js"></script>
<script src="<?php echo base_url(); ?>assets/private/js/src/main.js"></script>
</body>
</html>

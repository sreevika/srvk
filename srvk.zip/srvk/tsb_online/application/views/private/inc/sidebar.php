<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo base_url(); ?>assets/private/img/user-icon.png" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo $name; ?></p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <!-- search form -->
    <form action="#" method="get" class="sidebar-form hide">
      <div class="input-group">
        <input type="text" name="q" class="form-control" placeholder="Search...">
        <span class="input-group-btn">
              <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
              </button>
            </span>
      </div>
    </form>
    <!-- /.search form -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MAIN NAVIGATION</li>
      <li class="active">
        <a href="#!/">
          <i class="fa fa-dashboard"></i> <span>Home</span>
          <span class="pull-right-container">
          </span>
        </a>
      </li>
      <li class="">
        <a href="#!/account-statement">
          <i class="fa fa-files-o"></i> <span>Account Statement</span>
          <span class="pull-right-container">
          </span>
        </a>
      </li>
       <li class="treeview">
        <a href="#">
          <i class="fa fa-newspaper-o"></i> <span>Beneficiary Details</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#!/intra-bank-beneficiary"><i class="fa fa-circle-o"></i>TSB Beneficiary</a></li>
          <li><a href="#!/inter-bank-beneficiary"><i class="fa fa-circle-o"></i>Bank Beneficiary</a></li>
        </ul>
      </li>
      <!--
      <li class="">
        <a href="#!/standing-instruction">
          <i class="fa fa-bullseye"></i> <span>Standing Instruction</span>
          <span class="pull-right-container">
          </span>
        </a>
      </li>
      -->
       <li class="">
        <a href="#!/periodic-scheduled-payment/salary-instruction">
          <i class="fa fa-calculator"></i> <span>Salary Instruction</span>
          <span class="pull-right-container">
          </span>
        </a>
      </li>
       <li class="treeview">
        <a href="#">
          <i class="fa fa-newspaper-o"></i> <span>Fund Transfer</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#!/intra-bank-fund-transaction"><i class="fa fa-circle-o"></i>TSB Transaction</a></li>
          <li><a href="#!/inter-bank-fund-transaction"><i class="fa fa-circle-o"></i>Bank Transaction</a></li>
          <li><a href="#!/transaction-history"><i class="fa fa-circle-o"></i>Transaction History</a></li>
        </ul>
      </li>
      <li class="">
        <a href="#!/rejection-clear">
          <i class="fa fa-rotate-left"></i> <span>Rejection Clear</span>
          <span class="pull-right-container">
          </span>
        </a>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-gear"></i> <span>Change Password</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#!/change-login-password"><i class="fa fa-circle-o"></i>Login Password</a></li>
          <li><a href="#!/change-transaction-password"><i class="fa fa-circle-o"></i>Transaction Key</a></li>
        </ul>
      </li>
      <li>
        <a href="<?php echo base_url(); ?>dashboard/logout">
          <i class="fa fa-power-off"></i> <span>Logout</span>
        </a>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- .data-container -->
  <div class="data-container" rel="data-container">

<?php
  if(isset($page_name) && file_exists(APPPATH."views/private/pages/".$page_name.".php")){
    //if file exists
    $this->load->view('private/inc/header');
    $this->load->view('private/inc/sidebar');
    $this->load->view("private/pages/".$page_name);
    $this->load->view('private/inc/footer');
  }else{
    //if not exists
    show_404();
  }
?>

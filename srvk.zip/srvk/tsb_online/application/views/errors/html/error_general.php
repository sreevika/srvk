<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$ci = get_instance();
$ci->load->view('public/inc/header');

switch ($status_code) {

	case 403:
		$ci->load->view('errors/html/pages/error_403');
		break;

	default:
		$ci->load->view('errors/html/pages/error_403');
		break;
}

$ci->load->view('public/inc/footer');

?>

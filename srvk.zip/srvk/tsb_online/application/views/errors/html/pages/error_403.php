<section class="site-main-container">
  <div class="container">
    <div class="image-container text-center col-md-6 col-md-push-3">
      <img alt="403 Access Denied" src="<?php echo base_url(); ?>/assets/img/403-page.png" >
    </div>
  </div>
    <div class="text-center"><a href="<?php echo base_url(); ?>" class=" btn-tsb btn-round ">Go to Home Page</a></div>
</section>

<?php
  if(isset($page_name) && file_exists(APPPATH."views/public/pages/".$page_name.".php")){
    //if file exists

    $this->load->view('public/inc/header');
    $this->load->view("public/pages/".$page_name);
    $this->load->view('public/inc/footer');

  }else{
    //if not exists
    show_404();
  }
?>

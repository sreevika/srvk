<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container"><h2 class="page-type-1-title">Contact Us</h2></div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control" placeholder="Name">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" placeholder="Email">
          </div>
          <div class="form-group">
            <label>Subject</label>
            <input type="text" class="form-control" placeholder="Subject">
          </div>
          <div class="form-group">
            <label>Message</label>
            <textarea  class="form-control" rows="5" placeholder="Message"></textarea>
          </div>
          <input type="submit" class="btn btn-tsb" value="Submit">
        </div>
        <div class="col-md-6">
          <h2><b>Address</b></h2>
          <h3>Directorate of Treasuries</h3>
          <h4>Krishna Buildings</h4>
          <h4>Thycaud. P. O 695014</h4>
          <h4>Thiruvananthapuram</h4>
          <h4>Kerala, India</h4>
          <h4><b>Phone:</b> ++ 91 471 - 2322533 / 2323963 / 2322712</h4>
          <h4><b>Email:</b> dir.tsry@kerala.gov.in / keralatreasury@gmail.com</h4>
        </div>
      </div>
    </div>
  </div>
</section>

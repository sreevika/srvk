<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container">
      <h2 class="page-type-1-title">Forget Password<h2>
    </div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area" id="forget-password_view">
      <form class="forget-password-form">
      <div class="forget-password-1 ">
        <div class="row">
          <div class="form-group col-md-12">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-6">
            <label for="tsb_account_username">Username<span class="text-red"> *</span></label>
            <input type="text" class="form-control" id="tsb_account_username" name="tsb_account_username" placeholder="Username">
            <span class="help-block"></span>
          </div>
          <div class="form-group col-md-6 ">
            <label for="tsb_account_number">Account Number<span class="text-red"> *</span></label>
            <input type="text" class="form-control" id="tsb_account_number" name="tsb_account_number" placeholder="Account Number">
            <span class="help-block"></span>
          </div>
          </div>

          <div class="row">
          <div class="form-group col-md-6">
            <label for="tsb_account_dob">Date Of Birth<span class="text-red"> *</span></label>
            <input type="text" rel="js-forget-password-form-dob" class="form-control" id="tsb_account_date_of_birth" name="tsb_account_date_of_birth" placeholder="Date Of Birth">
            <span class="help-block"></span>
          </div>
          <div class="form-group col-md-6 ">
            <label for="tsb_account_mobile_number">Registered Mobile Number<span class="text-red"> *</span></label>
            <input type="text" class="form-control" id="tsb_account_mobile_number" name="tsb_account_mobile_number" placeholder="Mobile Number">
            <span class="help-block"></span>
          </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-4">
            <input type="button" class="btn btn-tsb btn-xl"  id="reset_password_submit" value="Next">
          </div>
        </div>
      </form>
      </div>
      <!-- /user-registration-level-1 -->
  </div>
  </div>
  <script id="reset_password_level_2_template" type="text/custom-template">
    <div class="reset-password-level-2 " style="overflow: hidden;">
      <div class="user-profile-box">
        <div class="user-left">
          <span class="glyphicon glyphicon-user user-icon"></span>
          <h4 class="user-profile-heading">{{name}}</h4>
        </div>
        <div class="user-right">
          <ul>
            <li><span class="profile-title">Account Number</span><span class="profile-desc">{{accNo}}</span></li>
            <li><span class="profile-title">Mobile Number</span><span class="profile-desc">{{mobNo}}</span></li>
            <li><span class="profile-title">Username</span><span class="profile-desc">{{username}}</span></li>
          </ul>
        </div>
      </div>
      <div class="row" style="margin-top: 50px;" id="reset-password-content-view">
          <form>
          <div class="col-md-12">
            <p class="bg-info info-msg text-info"> OTP has been sent to the registered mobile no. Enter the OTP to continue...</p><p>
          </p></div>
          <div class="form-group col-md-4">
            <label>Enter OTP<span class="text-red"> *</span></label>
            <input type="text" name="otp" placeholder="Enter OTP" class="form-control">
            <span class="help-block"><a href="#">Click here </a>to resend OTP</span>
            <input type="button" class="btn btn-tsb btn-xl verify_otp" value="Verify">
          </div>
          </form>
      </div>
    </div>
    <!-- /user-registration-level-2 -->
  </script>
  <script type="text/custom-template" id="reset_password_level_3_template">
       <form role="form" rel="js-new-password-form">
        <div class="col-md-12">
            <p class="bg-info info-msg text-info"> OTP Verification Succesfully. Enter a New Login Password and confirm the new login Password...</p><p>
          </p></div>
          <div class="col-md-6">
          <div class="form-group">
            <label for="new_login_password">New Login Password</label>
            <input type="password" id="newPassword" class="form-control" name="newPassword" placeholder="New Login Password" >
            <span class="help-block"></span>
          </div>
          <div class="form-group">
            <label for="confirm_new_login_password" >Confirm New Login Password</label>
            <input type="password" data-toggle="tooltip" tile="testing" id="confirmNewPassword" name="confirmNewPassword" class="form-control" placeholder="Confirm New Login Password" >
            <span class="help-block"></span>
          </div>
          <div class="form-group">
            <input type="submit" id="new-login-password-submit-btn" class="btn btn-tsb btn-xl"  value="Submit">
          </div>
        </div>
        </form>
  </script>
</section>

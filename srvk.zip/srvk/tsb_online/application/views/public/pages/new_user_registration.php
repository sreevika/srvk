<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container">
      <h2 class="page-type-1-title">New User Registration<h2>
    </div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area" id="new_user_registration_view">
      <div class="user-registration-level-1 ">
        <form class="user-registration-level-1-form">
        <div class="row">
          <div class="form-group col-md-12">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-6">
            <label for="level_1_tsb_account_number">TSB Account Number<span class="text-danger"> *</span></label>
            <input type="text" class="form-control" id="level_1_tsb_account_number" name="level_1_tsb_account_number" placeholder="Account number">
            <span class="help-block"></span>
          </div>
          <div class="form-group col-md-6 ">
            <label for="level_1_confirm_tsb_account_number">Confirm TSB Account Number<span class="text-danger"> *</span></label>
            <input type="text" class="form-control" name="level_1_confirm_tsb_account_number" id="level_1_confirm_tsb_account_number" placeholder="Confirm Account number">
            <span class="help-block"></span>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-6 ">
            <label for="level_1_aadhar_number">Aadhaar Number<span class="text-danger"> *</span></label>
            <input type="text" class="form-control" name="level_1_aadhar_number" id="level_1_aadhar_number" placeholder="Aadhar number">
            <span class="help-block"></span>
          </div>
          <div class="form-group col-md-6">
            <label for="level_1_mobile_number">Mobile Number<span class="text-danger"> *</span></label>
            <input type="text" class="form-control" name="level_1_mobile_number" id="level_1_mobile_number" placeholder="Mobile no (Given in the Tsb account)">
            <span class="help-block"></span>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-6">
            <label for="level_1_email">Email</label>
            <input type="email" class="form-control" id="level_1_email" name="level_1_email" placeholder="Email">
            <span class="help-block"></span>
          </div>
          <div class="form-group  col-md-6">
            <label label="test" for="level_1_username">Preferred Username<span class="text-danger"> *</span></label>
            <input type="text" class="form-control" id="level_1_username" name="level_1_username" placeholder="Username">
            <span class="help-block"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <input type="button" class="btn btn-tsb btn-xl" id="level_1_submit" value="Next">
          </div>
        </div>
      </form>
      </div>
      <!-- /user-registration-level-1 -->
  </div>
  </div>
  <script id="new_user_level_2_template" type="text/custom-template">
    <div class="user-registration-level-2 " style="overflow: hidden;">
      <div class="user-profile-box">
        <div class="user-left">
          <span class="glyphicon glyphicon-user user-icon"></span>
          <h4 class="user-profile-heading">{{name}}</h4>
        </div>
        <div class="user-right">
          <ul>
            <li><span class="profile-title">Account Number</span><span class="profile-desc">{{accNo}}</span></li>
            <li><span class="profile-title">Aadhaar Number</span><span class="profile-desc">{{aadharNo}}</span></li>
            <li><span class="profile-title">Mobile Number</span><span class="profile-desc">{{mobileNo}}</span></li>
            <li><span class="profile-title">Username</span><span class="profile-desc">{{username}}</span></li>
          </ul>
        </div>
      </div>
      <div class="row" style="margin-top: 50px;">
          <form>
          <div class="col-md-12">
            <p class="bg-info info-msg text-info"> OTP has been sent to the registered mobile no. Enter the OTP to continue...</p><p>
          </p></div>
          <div class="form-group col-md-4">
            <label>Enter OTP<span class="text-red"> *</span></label>
            <input type="text" name="otp" placeholder="Enter OTP" class="form-control">
            <span class="help-block"><a href="#">Click here </a>to resend OTP</span>
            <input type="button" class="btn btn-tsb btn-xl verify_otp" value="Verify">
          </div>
          </form>
      </div>
    </div>
    <!-- /user-registration-level-2 -->
  </script>
  <script type="text/custom-template" id="otp_success" >
      <div class="user-registration-level-3 " style="overflow: hidden; ">
        <h3 class="text-info text-center">Application Submitted Successfully</h3>
        <p class="bg-info info-msg text-info">Your application is under processing. Once your account is activated, a system generated password will be sent to the registered mobile number. It may take 6 working hours. Thanks for your patience..</p>
      </div>
  </script>
</section>

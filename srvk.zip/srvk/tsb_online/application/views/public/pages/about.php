<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container"><h2 class="page-type-1-title">About</h2></div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area" >
      <p>The Treasury savings bank of Kerala is a unique system in India. It provides facilities for Savings Bank (SB) operations and Fixed Deposits. The Savings Bank facility in Kerala Treasuries serves as a means to provide a channel for safe deposits for the public since last fifty years. Any public can open an account in any of the treasuries in the state. There is no hidden charge for any transaction which includes internet banking transaction for fund transfer.</p>
      <p>Online TSB facilitate for fund transfer, account statement, standing instruction for scheduled payments.</p>
    </div>
  </div>
</section>

<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container">
      <h2 class="page-type-1-title">Change Credentials<h2>
    </div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area" rel="page-container">
      <form rel="js-reset-credentials-form">
      <div class="row">
        <div class="col-md-6">
          <h4>Create New Login Password</h4>
          <div class="alert alert-info"><strong>Tsb Online Login password</strong>. Create a secured login password.</div>
        </div>
        <div class="col-md-6">
          <h4>Create New Transacion Key</h4>
          <div class="alert alert-info">The <strong>Transacion Key</strong> provides an additional layer of security to your accounts.
            You have to enter Transacion Key whenever you do fund trasaction, adding new beneficiarys etc..</div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label for="new_login_password">New Login Password</label>
            <input type="password" id="new_login_password" class="form-control" name="loginNewPassword" placeholder="New Login Password" >
            <span class="help-block"></span>
          </div>
          <div class="form-group">
            <label for="confirm_new_login_password" >Confirm New Login Password</label>
            <input type="password" data-toggle="tooltip" tile="testing" id="confirm_new_login_password" name="confirmNewLoginPassword" class="form-control" placeholder="Confirm New Login Password" >
            <span class="help-block"></span>
          </div>
          <div class="form-group">
            <input type="submit" rel="js-submi-reset-credentials" class="btn btn-tsb btn-xl"  value="Submit">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="new_trans_key">New Transaction Key</label>
            <input type="password" id="new_trans_key" name="newTransKey" class="form-control" placeholder="New Transaction Key" >
            <span class="help-block"></span>
          </div>
          <div class="form-group">
            <label for="confirm_new_trans_key">Confirm New Transaction Key</label>
            <input type="password" id="confirm_new_trans_key" name="confirmNewTransKey" class="form-control" placeholder="Confirm New Transaction Key" >
            <span class="help-block"></span>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
  </div>
  <script id="" type="text/custom-template" rel="js-reset-credentials-success">
  <div  style="overflow: hidden; ">
    <h3 class="text-info text-center">Login password and Transaction key reset Successfully</h3>
    <p class="bg-info info-msg text-center text-info">Login password and Transaction key reset Successfully. You can login using new password</p>
    <p class="text-center"><a class="btn-tsb btn  btn-xl"  href="<?php echo base_url().'login'; ?>"> Login</a></p>
  </div>
  </script>
</section>

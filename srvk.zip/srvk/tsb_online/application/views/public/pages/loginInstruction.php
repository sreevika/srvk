<section class="site-main-container">
  <div class="container">
    <div class="login-notice">
      <h3>Important Notices</h3>
      <p>Beware of Phishing attacks
Phishing is a fraudulent attempt, usually made through email, phone calls, SMS etc seeking your personal and confidential information.
State Bank or any of its representative never sends you email/SMS or calls you over phone to get your personal information,password or one time SMS (high security) password. Any such e-mail/SMS or phone call is an attempt to fraudulently withdraw money from your account through Internet Banking. Never respond to such email/SMS or phone call. Please report immediately on report.phishing@sbi.co.in if you receive any such email/SMS or Phone call. Please lock your user access immediately, if you have accidentally revealed your credentials.Click here to lock.</p>
    </div>
    <a href="<?php echo base_url(); ?>login" class=" btn-tsb btn-tsb-lg continue-login-btn">Continue Login</a>
  </div>
</section>

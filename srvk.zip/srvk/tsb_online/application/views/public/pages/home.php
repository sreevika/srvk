<!-- Site main banner section -->
<section class="site-main-banner wow fadeIn" >
  <div class="container">
    <h1>Welcome to Treasury Savings Bank</h1>
    <p>The Treasury savings bank of Kerala is a unique system in India. It provides facilities for Savings Bank (SB) operations and Fixed Deposits. The Savings Bank facility in Kerala Treasuries serves as a means to provide a channel for safe deposits for the public since last fifty years. Any public can open an account in any of the treasuries in the state. There is no hidden charge for any transaction which includes internet banking transaction for fund transfer.</p>
  </div>
</section>
<!--// Site main banner section -->
<!-- Site registration  banner section -->
<section class="site-reg-banner" >
  <div class="container wow fadeInUp" >
    <div class="row">
      <div class="col-sm-6">
        <img src="assets/img/finance.png" >
      </div>
      <div class="col-sm-6 site-reg-right">
        <h2>Banking At Your Fingertips</h2>
        <p>Focused on Bringing the best service to you</p>
        <a href="<?php echo base_url(); ?>new-user-registration" class="btn btn-danger" style="margin-right: 10px;">New User Registration</a>
        <a href="<?php echo base_url(); ?>login" class="btn btn-success">Login</a>
      </div>
    </div>
  </div>
</section>
<!--// Site registration  banner section -->
<section class="site-savings-bank-types ">
  <div class="container wow fadeInUp">
    <div class="row wow fadeInUp">
      <div class="col-md-12">
        <h2 class="text-center">Types of Savings Bank Accounts</h2>
      </div>
    </div>
    <div class="row wow fadeInUp">
      <div class="col-md-6 col-md-push-0 col-sm-8 col-sm-push-2">
        <div class="type-container">
          <div class="left type-icon-blue">
            <h3>TSB</h3>
          </div>
          <div class="right">
            <h3>TSB</h3>
            <p>Treasury Savings Bank Account</p>
            <p>TSB account can be opened by any individual</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-md-push-0 col-sm-8 col-sm-push-2">
        <div class="type-container">
          <div class="left type-icon-pink">
            <h3>PTSB</h3>
          </div>
          <div class="right">
            <h3>PTSB</h3>
            <p>Pensioners Treasury Savings Bank Account</p>
            <p>Exclusively for pensioners</p>
          </div>
        </div>
      </div>
    </div>
    <div class="row wow fadeInUp">
      <div class="col-md-6 col-md-push-0 col-sm-8 col-sm-push-2">
        <div class="type-container">
          <div class="left type-icon-orange">
            <h3>TFD</h3>
          </div>
          <div class="right">
            <h3>TFD</h3>
            <p>Treasury Fixed Deposits</p>
            <p>TFD can be opened by any individual</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-md-push-0 col-sm-8 col-sm-push-2">
        <div class="type-container">
          <div class="left type-icon-green">
            <h3>ETSB</h3>
          </div>
          <div class="right">
            <h3>ETSB</h3>
            <p>Employees Treasury Savings Bank Account</p>
            <p>Exclusively for state Govt. employees</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Site important link -->
<section class="site-important-links wow fadeIn">
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-sm-3">
    			<a target="_blank" title="Digital India Programme" href="http://digitalindia.gov.in/"><img src="<?php echo base_url(); ?>/assets/img/digital_india1.png" alt="Digital India Programme"></a>
    	</div>
    	<div class="col-md-2 col-sm-3">
    			<a target="_blank" title="National Informatics Centre" href="http://www.nic.in/"><img src="<?php echo base_url(); ?>/assets/img/nic1.png" alt="National Informatics Centre"></a>
    	</div>
    	<div class="col-md-2 col-sm-3">
    		<a target="_blank" title="Indian Government" href="https://india.gov.in/"><img src="<?php echo base_url(); ?>/assets/img/india_govt1.png" alt="Indian Government"></a>
    	</div>
    	<div class="col-md-2 col-sm-3">
    		<a target="_blank" title="kerala government" href="https://kerala.gov.in/"><img src="<?php echo base_url(); ?>/assets/img/kerala_govt1.png" alt="kerala government"></a>
    	</div>
    	<div class="col-md-2 col-md-push-0 col-sm-push-3 col-sm-3">
    		<a target="_blank" title="Treasury department" href="https://www.treasury.kerala.gov.in/treasury_site/"><img src="<?php echo base_url(); ?>/assets/img/treasury_logo1.png" alt="Treasury department"></a>
    	</div>
    	<div class="col-md-2 col-md-push-0 col-sm-push-3   col-sm-3">
    		<a target="_blank" title="finance department" href="http://www.finance.kerala.gov.in"><img src="<?php echo base_url(); ?>/assets/img/Finanace-kerla-logo1.png" alt="finance department"></a>
    	</div>
    </div>
  </div>
</section>
<!-- Site important link -->

<section class="site-main-container">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="login-container">
          <form id="tsb_main_form" autocomplete="off">
            <div class="form-group">
              <h4>Sign in</h4>
            </div>
            <div class="form-group">
              <label>Username</label>
              <input type="text" name="username" class=" form-control keyboard-init-focus keyboard  username" placeholder="Username">
              <span class="help-block"></span>
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" name="password" class="form-control keyboard password" placeholder="Password">
              <span class="help-block"></span>
            </div>
            <div class="form-group">
              <input type='submit' class="btn-tsb submit-login" value="Login">
            </div>
            <div class="form-group">
              <input id="keyboard-toggle" class="keyboard-toggle" type="checkbox" > <label for="keyboard-toggle" class="login-link">Enable Virtual Keyboard</label>
            </div>
             <div class="form-group">
              <a href="<?php echo base_url(); ?>forget-password" class="login-link">Forgot Password?</a>
            </div>
            <div class="form-group">
              <a href="<?php echo base_url(); ?>forget-username" class="login-link">Forgot Username?</a>
            </div>

          </form>
        </div>
      </div>
      <div class="col-md-8">
        <div class="login-banner"><img src="<?php echo base_url(); ?>assets/img/login_bg.png"></div>
      </div>
    </div>
    <div class="row login-page-info-section">
      <div class="col-md-12"><p class="alert alert-info"><strong>Warning! </strong>    NEVER respond to any popup,email, SMS or phone call, no matter how appealing or official looking, seeking your personal information such as username, password(s), mobile number, ATM Card details, etc. Such communications are sent or created by fraudsters to trick you into parting with your credentials.</p></div>
    </div>
  </div>
</section>

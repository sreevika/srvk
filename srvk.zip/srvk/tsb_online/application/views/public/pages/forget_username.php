<section class="page-type-1">
  <div class="top-banner page-type-1-bg-tsb">
    <div class="container">
      <h2 class="page-type-1-title">Forget Username<h2>
    </div>
  </div>
  <div class=" container">
    <div class="page-type-1-content-area" id="forget-username_view">
      <form class="forget-username-form">
      <div class="forget-username-1 ">
        <div class="row">
          <div class="form-group col-md-12">
          </div>
        </div>
        <div class="row">
        
          <div class="form-group col-md-6 ">
            <label for="tsb_account_number">Account Number<span class="text-red"> *</span></label>
            <input type="text" class="form-control" id="tsb_acc_no" name="tsb_acc_no" placeholder="Account Number">
            <span class="help-block"></span>
          </div>
          <div class="form-group col-md-6 ">
            <label for="tsb_mobile_number">Registered Mobile Number<span class="text-red"> *</span></label>
            <input type="text" class="form-control" id="tsb_reg_mobile_number" name="tsb_reg_mobile_number" placeholder="Mobile Number">
            <span class="help-block"></span>
          </div>
          </div>

          <div class="row">
          <div class="form-group col-md-6">
            <label for="tsb_account_dob">Date Of Birth<span class="text-red"> *</span></label>
            <input type="text" rel="js-forget-username-form-dob"  class="form-control" id="tsb_account_dob" name="tsb_account_dob" placeholder="Date Of Birth">
            <span class="help-block"></span>
          </div>

          </div>
        </div>

        <div class="row">
          <div class="col-md-4">
            <input type="button" class="btn btn-tsb btn-xl"  id="forget_username_submit" value="Next">
          </div>
        </div>
      </form>
      </div>
      <!-- /user-registration-level-1 -->
  </div>
  </div>
  <script id="forget_username_level_2_template" type="text/custom-template">
    <div class="reset-password-level-2 " style="overflow: hidden;">
      <div class="user-profile-box">
        <div class="user-left">
          <span class="glyphicon glyphicon-user user-icon"></span>
          <h4 class="user-profile-heading">{{name}}</h4>
        </div>
        <div class="user-right">
          <ul>
            <li><span class="profile-title">Account Number</span><span class="profile-desc">{{accNo}}</span></li>
            <li><span class="profile-title">Mobile Number</span><span class="profile-desc">{{mobNo}}</span></li>
            
          </ul>
        </div>
      </div>
      <div class="row" style="margin-top: 50px;" id="reset-password-content-view">
          <form>
          <div class="col-md-12">
            <p class="bg-info info-msg text-info"> Username has been sent to the registered mobile Number..</p><p>
          </p></div>
          <div class="form-group col-md-4">
            
            <span class="help-block"><a href="#">Click here </a>to resend Username</span>
            <span class="help-block"><a href="<?php echo base_url(); ?>dashboard/logout">Click here </a>to Back Login Page</span>
            
          </div>
          </form>
      </div>
    </div>
    <!-- /user-registration-level-2 -->
  </script>

</section>

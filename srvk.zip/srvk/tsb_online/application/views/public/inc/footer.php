<!-- Site footer -->
<section class="site-footer">
  <footer>
    <div class="container" >
      <p class="text-center">Copyright @ Department of Treasuries. Government of Kerala</p>
    </div>
  </footer>
</section>
<!--// Site footer -->
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/smoothscroll.js"></script>
<script src="<?php echo base_url(); ?>assets/js/wow.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.keyboard.js"></script>
<script src="<?php echo base_url(); ?>assets/js/site.js"></script>
<script src="<?php echo base_url(); ?>assets/js/handlebars-v4.0.11.js"></script>
<script src="<?php echo base_url(); ?>assets/js/SHA256Hashing.js"></script>
<script src="<?php echo base_url(); ?>assets/js/login.js"></script>
<script src="<?php echo base_url(); ?>assets/js/user-registration.js"></script>
<script src="<?php echo base_url(); ?>assets/js/reset-credentials.js"></script>
<script src="<?php echo base_url(); ?>assets/js/reset-password.js"></script>
<script src="<?php echo base_url(); ?>assets/js/forget-username.js"></script>
</body>
</html>

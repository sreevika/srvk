<!DOCTYPE hmtl>
 <html lang="en" class="no-js">
	 <head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<title>TSBONLINE</title>
		<meta name="description" content="Tsb online banking" >
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta data-type="csrf" name="<?php echo $this->security->get_csrf_token_name(); ?>" content="<?php echo $this->security->get_csrf_hash(); ?>">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-datepicker.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/keyboard.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/keyboard-basic.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/wow-animate.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	</head>
	<body data-base-url="<?php echo base_url(); ?>" >
		<noscript class="no-js-message">Javascript is not enabled in your browser. Please Enable or update your browser</noscript>
		<div class="spinner-container"><div class="spinner"></div></div>
		<!-- Header section   -->
		<section class="site-header" >
			<span class="glyphicon glyphicon-align-justify site-header-menu-btn"></span>
			<header>
				<div class="container">
					<div class="site-logo"><a  href="<?php echo base_url(); ?>"><img   src="assets/img/logo2.png" alt="Tsbonline"></a></div>
          <div class="right"><img src="assets/img/treasury_logo2.png"></div>
				</div>
			</header>
			<nav>
				<span class="glyphicon glyphicon-remove-circle close-nav-btn"> </span>
				<div class="container">
					<ul>
						<li class="<?php if(isset($active_page) && $active_page == 'home' ){?> active <?php } ?>"><a href="<?php echo base_url(); ?>" >Home</a></li>
						<li class="<?php if(isset($active_page) && $active_page == 'about' ){?> active <?php } ?>" ><a href="<?php echo base_url(); ?>about" >About</a></li>
						<li class="<?php if(isset($active_page) && $active_page == 'contact' ){?> active <?php } ?>"><a href="<?php echo base_url(); ?>contact" >Contact</a></li>
					</ul>
				</div>
			</nav>
		</section>
		<!--// Header section -->

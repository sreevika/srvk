<?php

  /**
   * seconds to seconds_to_humanize
   * @param string $seconds
   * @return string humanized seconds
   */
  if(!function_exists("seconds_to_humanize")){
    function seconds_to_humanize($seconds){
      $output = "";
      switch($seconds){
          // seconds less than or equls to 60
          case ($seconds <= 60 && $seconds > 0):
          $output = $seconds." seconds";
          break;

          // seconds less than or equals to 3600
          case($seconds <= 3600):
          $output =  ceil($seconds / 60)." minutes";
          break;

          // seconds less than or equals to 86400
          case($seconds <= 86400):
          $output = ceil($seconds/3600)." hours";
          break;

          // seconds less than or equals to
          case($seconds > 86400):
          $output = ceil($seconds/86400)." days";
          break;

          default:
          $output = $seconds." seconds";
      }
      return $output;
    }
  }

  if(!function_exists('switch_date_format')){
    function switch_date_format($date, $from, $to){
      $date = DateTime::createFromFormat($from, $date);
      if($date){
        return $date->format($to);
      }
      return false;
    }
  }


  if(!function_exists('db2TimestampToDataTime')){
    function db2TimestampToDataTime($db2Timestamp){
      $dateTime = DateTime::createFromFormat('Y-m-d H:i:s.u', $db2Timestamp);
      if(!$dateTime ){
        return false;
      }
      return $dateTime ;
    }
  }

  if(!function_exists('getDb2TimeStamp')){
    function getDb2CurrentTimeStamp(){
      $dateTime = new DateTime('now');
      return $dateTime->format('Y-m-d H:i:s.u');
    }
  }

  /**
   * Send Otp
   * @param mixed $mobile_number,
   * @param string $message
   * @return boolean true on success and false on failure
   * @todo integrate Otp service
   */
  if(!function_exists('sendOtp')){
    function sendOtp($mobile_number, $message){
      return true;
    }
  }


  /**
   * is Valid Date
   * Check date is valid or invalid as per the format
   * @param string $date
   * @param string $format
   * @return boolean true if valid and false if invalid
   */
   if(!function_exists('isValidDate')){
     function isValidDate($date, $format){
       $date = DateTime::createFromFormat($format, $date);
       $date_time_last_warning = DateTime::getLastErrors();
       if($date === false || !empty($date_time_last_warning['warnings'])){
        return false;
       }
       return true;
     }
   }



  /**
   * Send Otp
   * @param string $mobile_number
   * @param string $message
   * @return boolean true on success and false on failure
   */
   if(!function_exists('send_otp')){
     function send_otp($mobile_number, $message){
       $service_url = "http://api.esms.kerala.gov.in/webservice/falertservicerevised.php?wsdl";
       $params = array();
       $params[] = "treasury";
       $params[] = "TRSKER";
       $params[] = "esmsalerts";
       $params[] = $message;
       $params[] = $mobile_number;
       $soap_client = new SoapClient($service_url);
       $result = $soap_client->__soapCall("SendSMSwithDR", $params);
       if(!$result){
         return false;
       }
       $response_parsed_array = explode(',', $result);
       if(is_array($response_parsed_array) && count($response_parsed_array) > 0){
         if($response_parsed_array[0] == 402){
           return true;
         }
       }
       return false;
     }
   }
?>

<?php
namespace TsbApp\Domain\OnlineUser;
class OnlineUserException extends \Exception{
    public function __construct($msg, $code, $previous = null){
      parent::__construct($msg, $code, $previous);
    }
}
?>

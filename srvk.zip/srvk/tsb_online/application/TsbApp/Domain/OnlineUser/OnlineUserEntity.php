<?php
namespace TsbApp\Domain\OnlineUser;
class OnlineUserEntity{
  private $id;
  private $customerId;
  private $username;
  private $password;
  private $passwordChanged;
  private $mobile;
  private $email;
  private $confirm;
  private $activated;
  private $transactionKey;
  private $transactionKeyChanged;
  private $loginAttempt;
  private $locked;


  public function getId(){
    if($id){
      return $this->id;
    }
  }

  public function setId($id){
      return $this->id;
  }


  public function getCustomerId(){
    if($id){
      return $this->customerId;
    }
  }

  public function setCustomerId(){
    $this->customerId = $customerId;
  }

  public function getUsername(){
    if($id){
      return $this->username;
    }
  }

  public function setUsername($username){
      return $this->username = $username;
  }

  public function getPassword(){
    if($id){
      return $this->password;
    }
  }

  public function setPassword($password){
      $this->password = $password;
  }

  public function getPasswordChanged(){
    if($id){
      return $this->passwordChanged;
    }
  }

  public function setPasswordChanged($passwordChanged){
      $this->passwordChanged = $passwordChanged;
  }

  public function getMobile(){
    if($id){
      return $this->mobile;
    }
  }

  public function setMobile($mobile){
    $this->mobile = $mobile;
  }

  public function getEmail(){
    if($id){
      return $this->email;
    }
  }

  public function setEmail($email){
    $this->email = $email;
  }

  public function getConfirm(){
    if($id){
      return $this->confirm;
    }
  }


  public function setConfirm($confirm){
    $this->confirm = $confirm;
  }

  public function getActivated(){
    if($id){
      return $this->mobile;
    }
  }

  public function setActivated($activated){
    $this->activated = $activated;
  }


  public function getTransactionKey(){
    if($id){
      return $this->activated;
    }
  }

  public function setTransactionKey($transactionKey){
    $this->activated = $transactionKey;
  }

  public function getTransactionKeyChanged(){
    if($id){
      return $this->activated;
    }
  }

  public function setTransactionKeyChanged($transactionKeyChanged){
    $this->transactionKeyChanged = $transactionKeyChanged;
  }

  public function getLoginAttempt(){
    if($id){
      return $this->activated;
    }
  }

  public function setLoginAttempt($loginAttempt){
    $this->loginAttempt = $loginAttempt;
  }

  public function getLocked(){
    if($id){
      return $this->activated;
    }
  }

  public function setLocked($locked){
      return $this->locked = $locked;
  }

}
?>

<?php
  /*
  |------------------------------------------------------------------------
  | ERROR_CODE
  |
  | ERR_ONLINE_USER_REPO_0000 =
  |
  |------------------------------------------------------------------------
 */
namespace TsbApp\Domain\OnlineUser;
class OnlineUserRepository extends \TsbApp\Util\Repo\Repository{


  private $_entity;

  public function __construct(OnlineUserEntity $entity, $conn){
      parent::__construct($conn);
      $this->_entity = $entity;
  }

  private function _createUser($user){
    $userObj = clone $this->_entity;
    $userObj->setUsername($user["USERNAME"]);
    $userObj->setPassword($user["PASSWORD"]);
    return $user;
  }

  private function _createUserSet($resultSet){
    $user_collection = [];
    foreach($resultSet as $result){
        $user = $this->_createUser($result);
        $user_collection[] = $user;
    }
    return $user_collection;
  }

  public function getById($id){
    $sql = " SELECT * FROM TSBONLINE_PORTAL_USERS WHERE ID = ? ";
    $params = array();
    $params[] = $id;
    $resultStmt = $this->execute_query($sql, $params);
    $resultSet = $resultStmt->fetchAll();
    var_dump($resultSet);
    return (is_array($resultSet))? array_pop($this->_createUserSet($resultSet)) : array();
  }

  public function update($entity){
    
  }
}
?>

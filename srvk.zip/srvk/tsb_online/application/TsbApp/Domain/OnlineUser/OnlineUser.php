<?php
namespace TsbApp\Domain\OnlineUser;
class OnlineUser{

  private $_repo;

  public function __construct(OnlineUserRepository $online_user_repo){
      $this->_repo = $online_user_repo;
  }

  public function getByUsername($username){
    $this->_repo->getByUserName();
  }

  public function getById($id){
    return $this->_repo->getById($id);
  }

  public function lockUser($user){
    $user->setLocked('Y');
    $repo = new OnlineUserRepository($user);
    $repo->update();
    $
  }


}
?>

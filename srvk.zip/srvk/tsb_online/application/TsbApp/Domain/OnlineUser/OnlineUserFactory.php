<?php

namespace TsbApp\Domain\OnlineUser;

class OnlineUserFactory{

    public static function getOnlineUser($conn){
      $entity = new OnlineUserEntity();
      $repo = new OnlineUserRepository($entity, $conn);
      return new OnlineUser($repo);
    }

}

?>

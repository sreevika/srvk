<?php
TsbApp\Domain\OnlineUser;

class OnlineUserService{
    public function getUserByUsername(){
        $userEntity = new User();
        
    }
}

?>

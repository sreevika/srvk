<?php
namespace TsbApp\Domain\FundTransfer;

class FundTransferManager{

    private $_data;
    private $_ci;
    /**
     *
     *
     */
    public function __construct($data){
        $this->_data = $data;
        $this->_ci = get_instance();
    }


    public function processFundTransfer(){
      $this->_ci->load->model('fund_transaction_model');
      $this->_ci->load->model('account_model');
      $this->_ci->load->model('beneficiary_model');
      $account_details = $this->_ci->account_model->getAccountDetails($this->_data['accNo']);
      $ledger_balance = $account_details[0]['LEDGER_BAL'];
      $account_type = $account_details[0]['ACCTYPE'];
      $today = (new \DateTime())->format('Y-m-d');
      $seq_no = $this->_ci->fund_transaction_model->generateSequenceNo($today);
      if($seq_no == false){
        return false;
      }
      $schedule_id = $this->_ci->fund_transaction_model->getMaximumScheduleId();
      if($schedule_id == false){
        return false;
      }
      $transaction_id = $this->_ci->fund_transaction_model->transactionId($seq_no);
      $this->_data['accType'] = $account_type;
      $this->_data['todayDate'] = $today;
      $this->_data['scheduleId'] = $schedule_id;
      $this->_data['tsbTransactionId'] = $transaction_id;
      $status = $this->_ci->fund_transaction_model->scheduleFundTransfer($this->_data);
      if($status == false){
        return false;
      }
      if($this->_data['paymentOption'] == 'PN'){
        return $this->payNowProcess();
      }else{
        return true;
      }
      return false;
    }

    /**
     * Pay Now process
     * @todo if time greater than 7 pm then show message
     * add rollbak on failure conditions
     * @todo add transaction for coretis database
     */
    public function payNowProcess(){
      $schedule_id = $this->_data['scheduleId'];
      $schedule_details = $this->_ci->fund_transaction_model->getScheduleDetails($schedule_id);
      if(!is_array($schedule_details)){
        return false;
      }
      $current_timestamp = (new \DateTime())->format('Y-m-d H:i:s.u');
      $current_date = (new \DateTime())->format('Y-m-d');
      //
      if((new \DateTime())->format('H') >= 18){
        return;
      }
      $this->_ci->fund_transaction_model->conn->beginTransaction();
      $acc_no =  $this->_data['accNo'];
      $benf_id =  $this->_data['benfId'];
      $amount =  $this->_data['amount'];
      $remark =  $this->_data['remark'];
      $account_type = $this->_data['accType'];
      $trans_type = $this->_data['transType'];
      $username = $this->_data['username'];
      // recall the get account details inside the transaction for getting correct data
      $account_details = $this->_ci->account_model->getAccountDetails($acc_no);
      if(!is_array($account_details)){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return;
      }
      $ledger_balance = $account_details[0]['LEDGER_BAL'];
      $category_code = $account_details[0]['ACCTYPE_CATEGORY_CODE'];
      $scrt_bal = $account_details[0]['SCRT_BAL'];
      $head_id = $this->_ci->account_model->getAccountHeadId($account_type, $category_code);
      $beneficiary_details = $this->_ci->beneficiary_model->getBeneficiaryDetails($benf_id);
      $beneficiary_name = $beneficiary_details['BENEFICIARY_NAME'];
      $beneficiary_acctype = $beneficiary_details['ACCTYPE'];
      $beneficiary_mobile =  $beneficiary_details['MOBILE'];
      $beneficiary_accno =  $beneficiary_details['BENEFICIARY_ACCNO'];
      $beneficiary_ifsc =  $beneficiary_details['IFS_CODE'];

      // GET BANK DETAILS FORM THE IFS CODE
      $beneficiary_bank_id = null;
      if($trans_type == 'O'){
        $bank_details = $this->_ci->beneficiary_model->getBankDetailsFromIfsc($beneficiary_ifsc);
        if(!is_array($bank_details)){
          $this->_ci->fund_transaction_model->conn->rollBack();
          return;
        }
        $beneficiary_bank_id = $bank_details['BANK_CODE'];
      }

      // CALCULATE NEW SCRT BALANCE AND NEW LEDGER BAL
      $new_ledger_balance = $ledger_balance - $amount;
      if($new_ledger_balance <  0){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }

      $new_scrt_balance = $scrt_bal - $amount;
      if($new_scrt_balance <  0){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }

      // generate new sequence no
      $seq_no = $this->_ci->fund_transaction_model->generateSequenceNo($current_date);
      if($seq_no === false){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }
      $sb_transaction_id = $this->_ci->fund_transaction_model->transactionId($seq_no);
      $central_trcode = APP_CENTRAL_TRCODE;
      $current_time = (new \DateTime())->format('H:i:s');
      $financial_year = $this->_ci->fund_transaction_model->getFinYearCode();
      if(!is_array($financial_year)){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }
      $financial_year = $financial_year['FINYR_CD'];
      $sb_transaction_type_details = $this->_ci->fund_transaction_model->getSbTransType(259);
      if(!is_array($sb_transaction_type_details)){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }
      $sb_transaction_type = $sb_transaction_type_details['SB_TRANSTYPE'];
      $sb_transaction_desc = $sb_transaction_type_details['DESC_ABBR'];
      $payment_transaction_type = 66;
      // insert data to sb_payment_online table
      $sb_payment_data = array();
      $sb_payment_data['trCode'] = $central_trcode;
      $sb_payment_data['transDate'] = $current_date;
      $sb_payment_data['transTime'] = $current_time;
      $sb_payment_data['paymentSeqNo'] = $seq_no;
      $sb_payment_data['headId'] = $head_id;
      $sb_payment_data['finYearCode'] = $financial_year;
      $sb_payment_data['netPay'] = $amount;
      $sb_payment_data['accType'] = $account_type;
      $sb_payment_data['accNo'] = $acc_no;
      $sb_payment_data['tsbTransactionId'] = $sb_transaction_id;
      $sb_payment_data['benfName'] = $beneficiary_name;
      $sb_payment_data['accHolderName'] = $account_details[0]['NAME'];
      $sb_payment_data['remark'] = $remark;
      $sb_payment_data['sbTransType'] = $sb_transaction_type;
      $sb_payment_data['currentTimestamp'] = $current_timestamp;
      $sb_payment_data['seqDate'] = $current_date;
      $sb_payment_data['scrtBal'] = $new_scrt_balance;
      $sb_payment_data['ledgerBalance'] = $new_ledger_balance;
      $sb_payment_status = $this->_ci->fund_transaction_model->insertSbPaymentOnline($sb_payment_data);
      if($sb_payment_status == false){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }

      // update account master
      $update_accmast_status = $this->_ci->fund_transaction_model->updateBalance($acc_no,$new_ledger_balance,$new_scrt_balance);

      if($update_accmast_status == false){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }

      // generate new sequence no
      $online_amount_trans_seq_no = $this->_ci->fund_transaction_model->generateSequenceNo($current_date);
      // generate new transaction id for online amount transfer details
      $details_transaction_id = $this->_ci->fund_transaction_model->transactionId($online_amount_trans_seq_no);
      $online_amt_trans_details_data  = $sb_payment_data;
      $online_amt_trans_details_data['sequenceNo'] = $online_amount_trans_seq_no;
      $online_amt_trans_details_data['currentDate'] = $current_date;
      $online_amt_trans_details_data['transType'] = $trans_type;
      $online_amt_trans_details_data['benfAccType'] =$beneficiary_acctype;
      $online_amt_trans_details_data['benfAccNo'] =$beneficiary_accno;
      $online_amt_trans_details_data['benfIfsc'] =$beneficiary_ifsc;
      $online_amt_trans_details_data['benfBankId'] = $beneficiary_bank_id;
      $online_amt_trans_details_data['mobile'] = $beneficiary_mobile;
      $online_amt_trans_details_data['username'] = $username;
      $online_amt_trans_details_data['detailTransId'] = $details_transaction_id;
      $online_amt_trans_details_data['benfId'] = $benf_id;

      $insert_online_amt_details_insert_status = $this->_ci->fund_transaction_model->insertOnlineAmountTransferDetails($online_amt_trans_details_data);
      if($insert_online_amt_details_insert_status === false){
        $this->_ci->fund_transaction_model->conn->rollBack();
        return false;
      }

      // insert into tsbonline trans mast
      $online_trans_mast_data = $online_amt_trans_details_data;
      $online_trans_mast_data['descAbbr'] = $sb_transaction_desc;
      $online_trans_mast_data['paymentTransType'] = $payment_transaction_type;


       $tsb_online_trans_master_insert_status = $this->_ci->fund_transaction_model->insertTsbOnlineTransMaster($online_trans_mast_data);

       if($tsb_online_trans_master_insert_status === false){
         $this->_ci->fund_transaction_model->conn->rollBack();
         return false;
       }

       // for tranaction inside the tsb bank
       if($trans_type == 'I'){

         $sb_transaction_type_details_for_recpt = $this->_ci->fund_transaction_model->getSbTransType(162);
         if(!is_array($sb_transaction_type_details_for_recpt)){
           $this->_ci->fund_transaction_model->conn->rollback();
           return false;
         }
         $sb_trans_type_rcpt = $sb_transaction_type_details_for_recpt['SB_TRANSTYPE'];

         $intra_benf_acc_details = $this->_ci->account_model->getAccountDetails($beneficiary_accno);
         if(!is_array($intra_benf_acc_details) && count($intra_benf_acc_details) > 0){
           $this->_ci->fund_transaction_model->conn->rollback();
           return false;
         }
         $benf_ledger_bal = $intra_benf_acc_details[0]['LEDGER_BAL'];
         $benf_scrt_bal = $intra_benf_acc_details[0]['SCRT_BAL'];
         $new_benf_ledger_bal = $benf_ledger_bal + $amount;
         $new_benf_scrt_bal = $benf_scrt_bal + $amount;

         // insert into recept online
         $sb_recpt_online_data = $online_trans_mast_data;
         $sb_recpt_online_data['recptSbTransType'] =  $sb_trans_type_rcpt;
         $sb_recpt_online_data['newBenfScrtBal'] =  $new_benf_scrt_bal ;
         $sb_recpt_online_data['newBenfLedgerBal'] =  $new_benf_ledger_bal;
         $insert_recpt_online_status = $this->_ci->fund_transaction_model->insertSbRecptOnline($sb_recpt_online_data);

         if($insert_recpt_online_status === false){
           $this->_ci->fund_transaction_model->conn->rollback();
           return false;
         }

         $tsbonline_trans_mast_2_data = $sb_recpt_online_data;
         $tsbonline_trans_mast_2_data['descAbbr'] = 'ONLINESBTRANSREC';
         $tsbonline_trans_mast_2_data['paymentTransType'] = 67;
         $tsbonline_trans_mast_2_data['paymentSeqNo'] = $online_amount_trans_seq_no;
         $tsbonline_trans_mast_2_status = $this->_ci->fund_transaction_model->insertTsbOnlineTransMaster($tsbonline_trans_mast_2_data);
         if($tsbonline_trans_mast_2_status === false){
           $this->_ci->fund_transaction_model->conn->rollback();
           return false;
         }

         // update new balance to the beneficiary account
         $update_new_benf_status = $this->_ci->fund_transaction_model->updateBalance($beneficiary_accno,$new_benf_ledger_bal,$new_benf_scrt_bal);
         if($update_new_benf_status === false){
           $this->_ci->fund_transaction_model->conn->rollback();
           return false;
         }
         try{
           $commit_status = $this->_ci->fund_transaction_model->conn->commit();
         }catch(Exception $e){
           return false;
         }


         return true;
         //-------------  END  TRANS TYPE I-------- //
       }

       // Other bank tranaction start here
       if($trans_type == 'O'){

         $core_tsb_row_id = $this->_ci->fund_transaction_model->coreTsbRows($details_transaction_id);

         if($core_tsb_row_id === false){
           $this->_ci->fund_transaction_model->conn->rollBack();
           return false;
         }

         $core_tsb_row_count = $this->_ci->fund_transaction_model->coreTsbRowsCount($core_tsb_row_id);

         if($core_tsb_row_count === false){
           $this->_ci->fund_transaction_model->conn->rollBack();
           return false;
         }

         if($core_tsb_row_count == 0){
           // inset data to ekuber tabel
           $ekuber_data = $online_trans_mast_data;
           $ekuber_data['rowId'] = $core_tsb_row_id;
           $core_tsb_row_count = $this->_ci->fund_transaction_model->insertTsbOnlineFundTransferEkuber($ekuber_data);
           if($core_tsb_row_count === false){
             $this->_ci->fund_transaction_model->conn->rollBack();
             return false;
           }

           // insert data to tsbonline trans mast
           $tsb_ekuber_transmaster_data = $ekuber_data;
           $tsb_ekuber_transmaster_data['descAbbr'] = 'ONLINESBTRANSREC';
           $tsb_ekuber_transmaster_data['paymentTransType'] = 67;
           $tsb_ekuber_transmaster_data['paymentSeqNo'] = $online_amount_trans_seq_no;

           $ekuber_trans_master_status = $this->_ci->fund_transaction_model->insertTsbOnlineTransMaster($tsb_ekuber_transmaster_data);

           if($ekuber_trans_master_status === false){
             $this->_ci->fund_transaction_model->conn->rollBack();
             return false;
           }

         }else{
           // if count > 0 then update
           $update_ekuber_trans_master_status = $this->_ci->fund_transaction_model->updateTsbOnlineFundTransferEkuber($details_transaction_id,$core_tsb_row_id);
           if($update_ekuber_trans_master_status === false){
             $this->_ci->fund_transaction_model->conn->rollBack();
             return false;
           }

         }

         // Connect Coretis database
         // Insert datas in TSB_TO_BANK Table
         $coretis_row_count = $this->_ci->fund_transaction_model->coretisRows($core_tsb_row_id);
         // if error then show error
         if($coretis_row_count === false){
           $this->_ci->fund_transaction_model->conn->rollBack();
           return false;
         }
         // if row count  == 0
         if($coretis_row_count == 0){
            $tsb_to_bank_transfer_data = $tsb_ekuber_transmaster_data;
            $insert_tsb_to_bank_status = $this->_ci->fund_transaction_model->insertTsbToBank($tsb_to_bank_transfer_data);
            $this->_ci->fund_transaction_model->conn->commit();
            return true;
         }else{
            $this->_ci->fund_transaction_model->conn->rollback();
         }

       }
       return false;
    }

    public function scheduleLaterProcess(){

    }
}

?>

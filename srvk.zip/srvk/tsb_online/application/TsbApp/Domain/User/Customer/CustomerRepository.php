<?php
namespace TsbApp\Domain\User\Customer;
class CustomerRepository extends \TsbApp\Util\Database\Database{


  /**
   * Create customer form the data array
   * @param array $data
   * @return CustomerEntity
   */
  public function createCustomer($data){
    $customer = new CustomerEntity();
    $customer->setCustomerId($data['CUSTOMER_ID']);
    $customer->setBrTrCode($data['BR_TRCODE']);
    $customer->setName($data['NAME']);
    $customer->setPresAdd1($data['PRES_ADD1']);
    $customer->setPresAdd2($data['PRES_ADD2']);
    $customer->setPresAdd3($data['PRES_ADD3']);
    $customer->setPresStateCode($data['PRES_STATECODE']);
    $customer->setPresDistCode($data['PRES_DISTCODE']);
    $customer->setPresPinCode($data['PRES_PINCODE']);
    $customer->setPermAdd1($data['PERM_ADD1']);
    $customer->setPermAdd2($data['PERM_ADD2']);
    $customer->setPermAdd3($data['PERM_ADD3']);
    $customer->setPermStateCode($data['PERM_STATECODE']);
    $customer->setPermDistCode($data['PERM_DISTCODE']);
    $customer->setPermPinCode($data['PERM_PINCODE']);
    $customer->setPermPhone($data['PERM_PHONE']);
    $customer->setPresPhone($data['PRES_PHONE']);
    $customer->setBirthDate($data['BIRTH_DATE']);
    $customer->setGender($data['GENDER']);
    $customer->setOccupation($data['OCCUPATION']);
    $customer->setIdType($data['ID_TYPE']);
    $customer->setIdNo($data['ID_NO']);
    $customer->setAadhar($data['AADHAR']);
    $customer->setPan($data['PAN']);
    $customer->setEmail($data['EMAIL']);
    $customer->setMobileNo($data['MOBILE_NO']);
    $customer->setUpdatedBy($data['UPDATED_BY']);
    $customer->setUpdatedTime($data['UPDATED_TIME']);
    $customer->setConfirm($data['CONFIRM']);
    $customer->setConfirmedBy($data['CONFIRMED_BY']);
    $customer->setConfirmedTime($data['CONFIRMED_TIME']);
    $customer->setPresStdCode($data['PRES_STD_CODE']);
    $customer->setPermStdCode($data['PERM_STD_CODE']);
    $customer->setFirstName($data['FIRST_NAME']);
    $customer->setMiddleName($data['MIDDLE_NAME']);
    $customer->setLastName($data['LAST_NAME']);
    $customer->setGovStateEmp($data['GOV_STATE_EMP']);
    $customer->setPenNo($data['PEN_NO']);
    $customer->setOccType($data['OCCTYPE']);
    $customer->setNationality($data['NATIONALITY']);
    $customer->setFatherSpouseName($data['FATHERSPOUSENAME']);
    $customer->setMaritalStatus($data['MARITA_STATUS']);
    $customer->setReligion($data['RELLIGION']);
    $customer->setReligionCategory($data['RELLIGION_CATEGORY']);
    $customer->setQualification($data['QUALIFICATION']);
    $customer->setOccupationId($data['OCCPATION_ID']);
    $customer->setPresPostOffice($data['PRESS_POST_OFFICE']);
    $customer->setPermPostOffice($data['PERM_POST_OFFICE']);
    $customer->setPpoNo($data['PPO_NO']);
    $customer->setOnlineBenfCounter($data['ONLINE_BENF_COUNTER']);
    return $customer;
  }



  /**
   * Fetch by id
   * @param string $id
   * @return CustomerEntity
   */
  public function fetchById($id){
    $sql = " SELECT * FROM TSB_CUSTOMER_MAST WHERE CUSTOMER_ID = ? ";
    $params = array();
    $params[] = $id;

    try{
      $result = $this->execute_query($sql, $params)->fetchAll();
      if(!is_array($result) || count($result) == 0){
        throw new CustomerException('User not found');
      }
    }catch(\PDOException $e){
      throw new CustomerException('somthing went wrong!!', 0, $e);
    }

    return $this->createCustomer(array_pop($result));

  }
}
?>

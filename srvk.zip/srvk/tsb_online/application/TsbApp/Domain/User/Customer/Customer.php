<?php
namespace TsbApp\Domain\User\Customer;
class Customer {
  // customer repository
  private $_repo;

  /**
   * Php magic constructor
   *
   */
  public function __construct(){
    $this->_repo = new CustomerRepository();
  }

  /**
   * get By id
   *
   */
  public function getById($id){
    $customer_repo = $this->_repo->fetchById($id);
    return $customer_repo;
  }

}
?>

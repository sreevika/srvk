<?php
namespace TsbApp\Domain\User\Customer\Exceptions;
class CustomerExceptions extends Exception{

  private $_debugCode;

  /**
   * Php Magic constructor
   *
   */
  public function __construct($message, $code = 0, $prev = null, $debug_code){
    parent::__construct($message, $code);
    $this->_debugCode = $debug_code;
  }


  public function getDebugCode(){
    return $this->_debugCode;
  }

}
?>

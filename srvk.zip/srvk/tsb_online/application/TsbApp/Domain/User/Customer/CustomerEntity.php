<?php
namespace TsbApp\Domain\User\Customer;
class CustomerEntity{
	private $_customerId;
	private $_brTrcode;
	private $_name;
	private $_presAdd1;
	private $_presAdd2;
	private $_presAdd3;
	private $_presStateCode;
	private $_presDistCode;
	private $_presPinCode;
	private $_permAdd1;
	private $_permAdd2;
	private $_permAdd3;
	private $_permStateCode;
	private $_permDistCode;
	private $_permPinCode;
	private $_permPhone;
	private $_presPhone;
	private $_birthDate;
	private $_gender;
	private $_occupation;
	private $_idType;
	private $_idNo;
	private $_aadhar;
	private $_pan;
	private $_email;
	private $_mobileNo;
	private $_updatedBy;
	private $_updatedTime;
	private $_confirm;
	private $_confirmBy;
	private $_confirmTime;
	private $_presStdCode;
	private $_permStdCode;
	private $_firstName;
	private $_middleName;
	private $_lastName;
	private $_govStateEmp;
	private $_penNo;
	private $_occType;
	private $_nationality;
	private $_fatherSpouseName;
	private $_maritalStatus;
	private $_religion;
	private $_religionCatogery;
	private $_qualification;
	private $_occupationId;
	private $_presPostOffice;
	private $_permPostOffice;
	private $_ppoNo;
	private $_onlineBeneficiaryCounter;

  public function getCustomerId(){
      return $this->_customerId;
  }

  public function setCustomerId($customer_id){
    $this->_customerId = $customer_id;
  }

   public function getBrTrcode(){
      return $this->_brTrcode;
  }

  public function setBrTrcode($br_trcode){
    $this->_brTrcode = $br_trcode;
  }

  public function getName(){
      return $this->_name;
  }

  public function setName($name){
    $this->_name = $name;
  }

  public function getPresAdd1(){
      return $this->_presAdd1;
  }

  public function setPresAdd1($pres_add1){
    $this->_presAdd1 = $pres_add1;
  }


  public function getPresAdd2(){
      return $this->_presAdd2;
  }

  public function setPresAdd2($pres_add2){
    $this->_presAdd2 = $pres_add2;
  }


  public function getPresAdd3(){
      return $this->_presAdd3;
  }

  public function setPresAdd3($pres_add3){
    $this->_presAdd3 = $pres_add3;
  }

  public function getPresStateCode(){
      return $this->_presStateCode;
  }

  public function setPresStateCode($pres_state_code){
    $this->_presStateCode = $pres_state_code;
  }

  public function getPresDistCode(){
      return $this->_presDistCode;
  }

  public function setPresDistCode($pres_dist_code){
    $this->_presDistCode = $pres_dist_code;
  }


  public function getPresPinCode(){
      return $this->_presPinCode;
  }

  public function setPresPinCode($pres_pin_code){
    $this->_presPinCode = $pres_pin_code;
  }

 public function getPermAdd1(){
      return $this->_permAdd1;
  }

  public function setPermAdd1($perm_add1){
    $this->_permAdd1 = $perm_add1;
  }


  public function getPermAdd2(){
      return $this->_permAdd2;
  }

  public function setPermAdd2($perm_add2){
    $this->_permAdd2 = $perm_add2;
  }


  public function getPermAdd3(){
      return $this->_permAdd3;
  }

  public function setPermAdd3($perm_add3){
    $this->_permAdd3 = $perm_add3;
  }

  public function getPermStateCode(){
      return $this->_permStateCode;
  }

  public function setPermStateCode($perm_state_code){
    $this->_permStateCode = $perm_state_code;
  }

  public function getPermDistCode(){
      return $this->_permDistCode;
  }

  public function setPermDistCode($perm_dist_code){
    $this->_permDistCode = $perm_dist_code;
  }


  public function getPermPinCode(){
      return $this->_permPinCode;
  }

  public function setPermPinCode($perm_pin_code){
    $this->_permPinCode = $perm_pin_code;
  }

  public function getPermPhone(){
      return $this->_permPhone;
  }

  public function setPermPhone($perm_phone){
    $this->_permPhone = $perm_phone;
  }

    public function getPresPhone(){
      return $this->_presPhone;
  }

  public function setPresPhone($pres_phone){
    $this->_presPhone = $pres_phone;
  }

    public function getBirthDate(){
      return $this->_birthDate;
  }

  public function setBirthDate($birth_date){
    $this->_birthDate = $birth_date;
  }

   public function getGender(){
      return $this->_gender;
  }

  public function setGender($gender){
    $this->_gender = $gender;
  }

  public function getOccupation(){
      return $this->_occupation;
  }

  public function setOccupation($occupation){
    $this->_occupation = $occupation;
  }

  public function getIdType(){
      return $this->_idType;
  }

  public function setIdType($id_type){
    $this->_idType = $id_type;
  }

  public function getIdNo(){
      return $this->_idNo;
  }

  public function setIdNo($id_no){
    $this->_idNo = $id_no;
  }

    public function getAadhar(){
      return $this->_aadhar;
  }

  public function setAadhar($aadhar){
    $this->_aadhar = $aadhar;
  }

    public function getPan(){
      return $this->_pan;
  }

  public function setPan($pan){
    $this->_pan = $pan;
  }

    public function getEmail(){
      return $this->_email;
  }

  public function setEmail($email){
    $this->_email = $email;
  }

    public function getMobileNo(){
      return $this->_mobileNo;
  }

  public function setMobileNo($mobile_no){
    $this->_mobileNo = $mobile_no;
  }

  public function getUpdatedBy(){
      return $this->_updatedBy;
  }

  public function setUpdatedBy($updated_by){
    $this->_updatedBy = $updated_by;
  }

  public function getUpdatedTime(){
      return $this->_updatedTime;
  }

  public function setUpdatedTime($updated_time){
    $this->_updatedTime = $updated_time;
  }

  public function getConfirm(){
      return $this->_confirm;
  }

  public function setConfirm($confirm){
    $this->_confirm = $confirm;
  }

  public function getConfirmedBy(){
      return $this->_confirmBy;
  }

  public function setConfirmedBy($confirm_by){
    $this->_confirmBy = $confirm_by;
  }

    public function getConfirmedTime(){
      return $this->_confirmTime;
  }

  public function setConfirmedTime($confirm_time){
    $this->_confirmTime = $confirm_time;
  }

   public function getPresStdCode(){
      return $this->_presStdCode;
  }

  public function setPresStdCode($pres_std_code){
    $this->_presStdCode = $pres_std_code;
  }

  public function getPermStdCode(){
      return $this->_permStdCode;
  }

  public function setPermStdCode($perm_std_code){
    $this->_permStdCode = $perm_std_code;
  }

 public function getFirstName(){
      return $this->_firstName;
  }

  public function setFirstName($first_name){
    $this->_firstName = $first_name;
  }

   public function getMiddleName(){
      return $this->_middleName;
  }

  public function setMiddleName($middle_name){
    $this->_middleName = $middle_name;
  }

    public function getLastName(){
      return $this->_lastName;
  }

  public function setLastName($last_name){
    $this->_lastName = $last_name;
  }

  public function getGovStateEmp(){
      return $this->_govStateEmp;
  }

  public function setGovStateEmp($gov_state_emp){
    $this->_govStateEmp = $gov_state_emp;
  }

    public function getId(){
      return $this->_penNo;
  }

  public function setPenNo($pen_no){
    $this->_penNo = $pen_no;
  }

    public function getOccType(){
      return $this->_occType;
  }

  public function setOccType($occ_type){
    $this->_occType = $occ_type;
  }

    public function getNationality(){
      return $this->_nationality;
  }

  public function setNationality($nationality){
    $this->_nationality = $nationality;
  }

  public function getFatherSpouseName(){
      return $this->_fatherSpouseName;
  }

  public function setFatherSpouseName($father_spouse_name){
    $this->_fatherSpouseName = $father_spouse_name;
  }

  public function getMaritalStatus(){
      return $this->_maritalStatus;
  }

  public function setMaritalStatus($marital_status){
    $this->_maritalStatus = $marital_status;
  }


  public function getReligion(){
      return $this->_religion;
  }

  public function setReligion($religion){
    $this->_religion = $religion;
  }

  public function getReligionCategory(){
      return $this->_religionCatogery;
  }

  public function setReligionCategory($relegion_catogery){
    $this->_religionCatogery = $relegion_catogery;
  }

    public function getQualification(){
      return $this->_qualification;
  }

  public function setQualification($qualification){
    $this->_qualification = $qualification;
  }

    public function getOccupationId(){
      return $this->_occupationId;
  }

  public function setOccupationId($occupation_id){
    $this->_occupationId = $occupation_id;
  }

    public function getPresPostOffice(){
      return $this->_presPostOffice;
  }

  public function setPresPostOffice($pres_post_office){
    $this->_presPostOffice = $pres_post_office;
  }

  public function getPermPostOffice(){
      return $this->_permPostOffice;
  }

  public function setPermPostOffice($perm_post_office){
    $this->_permPostOffice = $perm_post_office;
  }
  public function getPpoNo(){
      return $this->_ppoNo;
  }

  public function setPpoNo($ppo_no){
    $this->_ppoNo = $ppo_no;
  }

  public function getOnlineBenfCounter(){
      return $this->_onlineBeneficiaryCounter;
  }

  public function setOnlineBenfCounter($online_beneficiary_counter){
    $this->_onlineBeneficiaryCounter = $online_beneficiary_counter;
  }
}

?>

<?php
namespace TsbApp\Domain\User;
class UserEntity{
  private $_id;
  private $_customerId;
  private $_username;
  private $_password;
  private $_changePassword;
  private $_mobile;
  private $_email;
  private $_confirm;
  private $_activated;
  private $_transactionKey;
  private $_transactionKeyChanged;
  private $_loginAttempt;
  private $_locked;
  private $_attemptedAt;
  private $_updatedBy;
  private $_updatedTime;


  public function getId(){
      return $this->_id;
  }

  public function setId($id){
    $this->_id = $id;
  }

  public function getCustomerId(){
    return $this->_customerId;
  }

  public function setCustomerId($customer_id){
    $this->_customerId = $customer_id;
  }

  public function getUsername(){
      return $this->_username;
  }

  public function setUsername($username){
      return $this->_username = $username;
  }

  public function getPassword(){
      return $this->_password;
  }

  public function setPassword($password){
      $this->_password = $password;
  }

  public function getChangePassword(){
      return $this->_changePassword;
  }

  public function setChangepassword($change_password){
      $this->_changePassword = $change_password;
  }

  public function getMobile(){
      return $this->_mobile;
  }

  public function setMobile($mobile){
    $this->_mobile = $mobile;
  }

  public function getEmail(){
      return $this->_email;
  }

  public function setEmail($email){
    $this->_email = $email;
  }

  public function getConfirm(){
      return $this->_confirm;
  }

  public function setConfirm($confirm){
    $this->_confirm = $confirm;
  }

  public function getActivated(){
    return $this->_activated;
  }

  public function setActivated($activated){
    $this->_activated = $activated;
  }

  public function getTransactionKey(){
      return $this->_transactionKey;
  }

  public function setTransactionKey($transactionKey){
    $this->_transactionKey = $transactionKey;
  }

  public function getTransactionKeyChanged(){
      return $this->_transactionKeyChanged;
  }

  public function setTransactionKeyChanged($transactionKeyChanged){
    $this->_transactionKeyChanged = $transactionKeyChanged;
  }

  public function getLoginAttempt(){
      return $this->_loginAttempt;
  }

  public function setLoginAttempt($loginAttempt){
    $this->_loginAttempt = $loginAttempt;
  }

  public function getLocked(){
      return $this->_locked;
  }

  public function setLocked($locked){
      return $this->_locked = $locked;
  }

  public function getAttemptedAt(){
    return $this->_attemptedAt;
  }

  public function setAttemptedAt($attempted_at){
    $this->_attemptedAt = $attempted_at;
  }

  public function getUpdatedBy(){
      return $this->_updatedBy;
  }

  public function setUpdatedBy($updated_by){
      $this->_updatedBy = $updated_by;
  }

  public function getUpdatedTime(){
    return $this->_updatedTime;
  }

  public function setUpdatedTime($updated_time){
    $this->_updatedTime = $updated_time;
  }

  public function getCustomer(){
      if($this->_customerId){
        $customer = (new Customer\Customer())->getById($this->_customerId);
        return $customer;
      }
  }

}
?>

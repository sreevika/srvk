<?php
namespace TsbApp\Domain\User\Exceptions;
class UserException extends \Exception{
  // debug code
  private $_debugCode;

  /**
   * Php magic constructor
   * @param string message
   * @param ini $code optional
   * @param Exception $e optional
   * @param string $debug_code debug code
   */
  public function __construct($message, $code = 0, $prev = null, $debug_code = null){
    parent::__construct($message, $code, $prev);
  }

  /**
   * Get debug code
   * @return string $debug_code
   */
  public function getDebugCode(){
    return $this->_debugCode;
  }

}
?>

<?php
/*
 |------------------------------------------------------------------------
 | ERROR CODES
 |------------------------------------------------------------------------
 | ERR_USER_REPO_000 = 'Invalid argument in createUser method'
 |
 */
namespace TsbApp\Domain\User;

class UserRepository extends \TsbApp\Util\Database\Database{


  /**
   * Create Use
   * @param array $data
   * @return UserEntity
   * @throws UserException
   */
  public function createUser($data){
      if(!$data || !is_array($data)){
        return new UserException('Sorry something went wrong', null, null, 'ERR_USER_REPO_000' );
      }
      $user = new UserEntity();
      $user->setId($data['ID']);
      $user->setCustomerId($data['CUSTOMERID']);
      $user->setUsername($data['USERNAME']);
      $user->setPassword($data['PASSWORD']);
      $user->setMobile($data['MOBILE']);
      $user->setEmail($data['EMAIL']);
      $user->setUpdatedBy($data['UPDATED_BY']);
      $user->setUpdatedTime($data['UPDATED_TIME']);
      $user->setConfirm($data['CONFIRM']);
      $user->setActivated($data['ACTIVATED']);
      $user->setTransactionKey($data['TRANSACTION_KEY']);
      $user->setChangepassword($data['CHANGE_PASSWORD']);
      $user->setLoginAttempt($data['LOGIN_ATTEMPT']);
      $user->setLocked($data['LOCKED']);
      $user->setAttemptedAt($data['ATTEMPTED_AT']);
      $user->setTransactionKeyChanged($data['TRANS_KEY_CHANGED']);
      return $user;
  }

  public function fetchAll(){

  }


  /**
   * Fetch by Id
   * @param integer
   * @throws UserException
   * @return UserEntity on success and boolean false on failure
   */
  public function fetchById($id){
    $sql = " SELECT * FROM TSBONLINE_PORTAL_USERS WHERE  ID = ? ";
    $params = array();
    $params[] = $id;
    try{
      $result = $this->execute_query($sql, $params)->fetchAll();
    }catch( \PDOException $e){
      throw new Exceptions\UserException('Database error',null, $e, $e->getMessage());
    }
    if(count($result) == 0){
        return false;
    }
    return $this->createUser(array_pop($result));
  }

  /**
   * Fetch by usernmae
   * @param string $username
   * @throws UserException
   * @return UserEntity and boolean false on failure
   */
  public function fetchByUsername($username){
      $sql = " SELECT * FROM TSBONLINE_PORTAL_USERS WHERE  USERNAME = ? ";
      $params = array();
      $params[] = $username;
      try{
        $result = $this->execute_query($sql, $params)->fetchAll();
        if(count($result) == 0){
          return false;
        }
        return $this->createUser(array_pop($result));
      }catch( \PDOException $e){
        throw new Exceptions\UserException('Database error',null, $e, $e->getcode());
      }
  }

  public function save($entity){

  }


  /**
   * Update
   * @param UserEntity
   * @return boolean true on success
   * @throws UserException
   */
  public function update($entity){
    $sql = " UPDATE TSBONLINE_PORTAL_USERS SET ";
    $sql .= " CUSTOMERID = ?, USERNAME = ?, PASSWORD = ?, MOBILE = ?, ";
    $sql .= " EMAIL = ?, UPDATED_BY = ?, UPDATED_TIME = ?, CONFIRM = ?, ";
    $sql .= " ACTIVATED = ?, TRANSACTION_KEY = ?, CHANGE_PASSWORD = ?, ";
    $sql .= " LOGIN_ATTEMPT = ?, LOCKED = ?, ATTEMPTED_AT = ?,  ";
    $sql .= " TRANS_KEY_CHANGED = ? ";
    $sql .= " WHERE ID = ?";
    $params = array();
    $params[] = $entity->getCustomerId();
    $params[] = $entity->getUsername();
    $params[] = $entity->getPassword();
    $params[] = $entity->getMobile();
    $params[] = $entity->getEmail();
    $params[] = $entity->getUpdatedBy();
    $params[] = $entity->getUpdatedTime();
    $params[] = $entity->getConfirm();
    $params[] = $entity->getActivated();
    $params[] = $entity->getTransactionKey();
    $params[] = $entity->getChangePassword();
    $params[] = $entity->getLoginAttempt();
    $params[] = $entity->getLocked();
    $params[] = $entity->getAttemptedAt();
    $params[] = $entity->getTransactionKeyChanged();
    $params[] = $entity->getId();
    try{
      $result = $this->execute_query($sql, $params);
    }catch(\PDOException $e){
      //var_dump($e->getMessage());
      throw new Exceptions\UserException('Database error',null, $e);
    }
    if($result){
      return true;
    }
  }
}
?>

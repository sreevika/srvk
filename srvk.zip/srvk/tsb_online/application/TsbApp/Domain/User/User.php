<?php
namespace TsbApp\Domain\User;
class User {

  // User Repository
  private $_repo;

  /**
   * Php magic constructor
   *
   */
  public function __construct(){
    $this->_repo = new UserRepository();
  }

  /**
   * Get by username
   * @param string $username
   * @return UserEntity
   * @throws UserException
   */
  public function getUserByusername($username){
    return $this->_repo->fetchByUsername($username);
  }

  /**
   * Get by User Id
   * @param integer
   * @return UserEntity
   * @throws UserException
   */
  public function getUserById($id){
    return $this->_repo->fetchById($id);
  }


  /**
   * Update User
   * @param UserEntity
   * @return boolean
   * @throws UserException
   */
  public function updateUser($user_entity){
    return $this->_repo->update($user_entity);
  }


  /**
   * Change User password
   * @param string $username
   * @param string $password
   * @param string $new_password
   * @return boolean
   * @throws Exception
   */
   public function changeUserPassword($username, $password, $new_password){
     // get the user from the username
     $user = $this->_repo->fetchByUsername($username);
     if(!$user){
        return false;
     }

   }


}
?>

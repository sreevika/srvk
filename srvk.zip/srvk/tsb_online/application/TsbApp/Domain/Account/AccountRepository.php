<?php
namespace TsbApp\Domain\Account;

class AccountRepository{

}
?>

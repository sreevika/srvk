<?php
namespace TsbApp\Domain\Account;

class AccountEntity{

  private $_branchTrCode;
  private $_accType;
  private $_accNo;
  private $_noOperator;
  private $_accHoldStat;
  private $_sbAccStat;
  private $_facility;
  private $_scrtBal;
  private $_clearBal;
  private $_ledgerBal;
  private $_dailyPayCeiling;
  private $_dailyPayCeiling;
  private $_paymentCondSi;
  private $_paymentCondSi;

  public function getBranchTrCode(){
    return $this->$_branchTrCode;
  }

  public function setBranchTrCode($branch_trcode){
    $this->$_branchTrCode = $branch_trcode;
  }

  public function getAccType(){
      return $this->_accType;
  }

  public function setAccType($acc_type){
      $this->_accType = $acc_type;
  }

  public function getAccNo(){
      return $this->_accNo;
  }

  public function setAccNo($acc_no){
      $this->_accNo = $acc_no;
  }
}
?>

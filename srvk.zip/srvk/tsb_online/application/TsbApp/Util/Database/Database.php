<?php
namespace TsbApp\Util\Database;

class Database {

  // Database connection
  protected $_conn;
  protected static $_transactionCounter = 0;

  /**
   * Php magic constructor
   * @param PDO $conn
   */
  public function __construct(\PDO $conn = null){
    if($conn == null){
      $conn = get_instance()->db->conn_id;
      $conn->setAttribute(\PDO::ATTR_ERRMODE,\PDO::ERRMODE_EXCEPTION);
    }
    $this->_conn = $conn;
  }

  public function getConnection(){
    return $this->_conn;
  }

  /**
   * execute query
   * Prepare statement query execute
   * @param $sql String, @param $param array
   * @return $tmt PDOStatement on success and false on failure
   */
   public function execute_query($sql, $param = array()){

     // Prepare sql query
     $stmt = $this->_conn->prepare($sql);
     if(!$stmt){
       log_message('error', "PREPARE QUERY FAILED SQL : ".$sql." PARAMS ".implode(', ', $param));
       return false;
     }

     // Bind params
     if(!empty($param)){
       $index = 1;
       foreach($param as &$p){
         $status = $this->bind($stmt, $index, $p);
         if(!$status){
           return false;
         }
         $index++;
       }
     }

     // execute prepare statement
     $result = $stmt->execute();
     if(!$result){
       log_message('error', "EXECUTE PREPARE STATEMENT : ".$sql." PARAMS : ".implode(', ', $param));
       return false;
     }
     return $stmt;

   }


   /**
    * bind value to a prepare statement
    * @param PDOStatement $stmt, $param mixed, $value mixed, $data_type [pdo constant]
    * @return boolean true on success and false on failure
    */
   public function bind($stmt, $params, $value, $data_type = null){
        $data_type = (!is_null($data_type))? $data_type : $this->getPDODateType($value);
        $status = $stmt->bindParam($params, $value, $data_type);
        if($status){
          return true;
        }
        log_message('error', "PREPARE PARAM FAILED PARAM : ".$value);
        return false;
   }

   /**
    * get pdo date type
    * @param $value Mixed
    * @return  PDO database constant
    */
   public function getPDODateType($value){
     switch (true) {
        case is_bool($value):
        $var_type = \PDO::PARAM_BOOL;
        break;
     case is_int($value):
         $var_type = \PDO::PARAM_INT;
         break;
     default:
         $var_type = \PDO::PARAM_STR;
     }
     return $var_type;
   }

   /**
    * BeginTransaction
    *
    */
    public function beginTransaction(){
      // if transaction count == 0 then only begin trasaction
      if(static::$_transactionCounter == 0){
        $this->_conn->beginTransaction();
      }
      static::$_transactionCounter++;
      return true;
    }

    /**
     * Commit
     *
     */
    public function commit(){
      ( static::$_transactionCounter > 0 )? --static::$_transactionCounter :  null;
      if(static::$_transactionCounter == 0){
        return $this->_conn->commit();
      }
      return true;
    }


    /**
     * Rollback
     *
     */
    public function rollback(){
      if(static::$_transactionCounter > 0){
        static::$_transactionCounter = 0;
        return $this->_conn->rollback();
      }
      return false;
    }

}

?>

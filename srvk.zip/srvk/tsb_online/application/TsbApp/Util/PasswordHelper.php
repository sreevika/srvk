<?php
namespace TsbApp\Util;
  class PasswordHelper{

    /**
     * PasswordHelper
     * password encryption and decryption util
     */

     /**
      * Password Hash
      * @param string $password
      * @return string encrypted sting on success and boolean false on failure
      */
    public funnction passwordHash($password){
        return password_hash($password,PASSWORD_DEFAULT)
    }


    /**
     * Password vefiry
     * @param string $password , string $old_password
     * $password that is going to check
     * $old_password  password that is going to compare
     * @return boolean
     */
    public function passwordVerify($password, $old_password){
        return password_verify($password, $old_password)
    }

  }
?>

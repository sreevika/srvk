<?php
namespace TsbApp\Util\Repo;
class Repository{

    protected $_conn;

    public function __construct(\PDO $conn){
      $this->_conn = $conn;
    }
    /**
     * execute query
     * Prepare statement query execute
     * @param $sql String, @param $param array
     * @return $tmt PDOStatement on success and false on failure
     */
     public function execute_query($sql, $param = array()){

       // Prepare sql query
       $stmt = $this->_conn->prepare($sql);
       if(!$stmt){
         log_message('error', "PREPARE QUERY FAILED SQL : ".$sql." PARAMS ".implode(', ', $param));
         return false;
       }

       // Bind params
       if(!empty($param)){
         $index = 1;
         foreach($param as &$p){
           $status = $this->bind($stmt, $index, $p);
           if(!$status){
             return false;
           }
           $index++;
         }
       }

       // execute prepare statement
       $result = $stmt->execute();
       if(!$result){
         log_message('error', "EXECUTE PREPARE STATEMENT : ".$sql." PARAMS : ".implode(', ', $param));
         return false;
       }
       return $stmt;

     }


     /**
      * bind value to a prepare statement
      * @param PDOStatement $stmt, $param mixed, $value mixed, $data_type [pdo constant]
      * @return boolean true on success and false on failure
      */
     public function bind($stmt, $params, $value, $data_type = null){
          $data_type = (!is_null($data_type))? $data_type : $this->getPDODateType($value);
          $status = $stmt->bindParam($params, $value, $data_type);
          if($status){
            return true;
          }
          log_message('error', "PREPARE PARAM FAILED PARAM : ".$value);
          return false;
     }

     /**
      * get pdo date type
      * @param $value Mixed
      * @return  PDO database constant
      */
     public function getPDODateType($value){
       switch (true) {
          case is_bool($value):
          $var_type = \PDO::PARAM_BOOL;
          break;
       case is_int($value):
           $var_type = \PDO::PARAM_INT;
           break;
       case is_null($value):
           $var_type = \PDO::PARAM_NULL;
           break;
       default:
           $var_type = \PDO::PARAM_STR;
       }
       return $var_type;
     }

}
?>

<?php
namespace Acme\Util;
 /**
  * Errorbag
  * Error collector
  */
 trait ErrorBag{

   protected $_error_bag = [];

   public addError($error_code, $error_message){
    $error_bag[] = ["errorCode" => $error_code, 'errorMessage' => $error_message];
   }

   public function getErrors(){
     return $this->$_error_bag;
   }

   public function hasError(){
     return !empty($this->$_error_bag);
   }


 }
?>

<<?php
namespace TsbApp\Authenticaion;
/** Transaction key authentication
  * authenticates transaction key
  */
class TransactionKeyAuthentication{
  // user domain class
  private $_user;
  // password to check
  private $_password;
  // transaction key encryptor
  private $_password_encryptor;
  // user entity
  private $_user_entity;
  // lock expiration period
  private $_lock_expiration_period;
  // login attempt limit
  private $_login_attempt_limit;

  /**
   * Php magic constructor
   * @param \TsbApp\Domain\User\User $user
   * @param \TsbApp\Util\PasswordEncrypter\PasswordEncrypter $password_encrypter
   */
  public function __construct($user, $transaction_key_encryptor){
      $this->_user = $user;
      $this->_password_encryptor = $transaction_key_encryptor;
  }
  /****************************************************************************
    SETTER PUBLIC METHODS
  ****************************************************************************/

  /**
   * Set lock expireation
   * @param mixed $expiration lock expiration in seconds seconds
   * @return void
   */
  public function setLockExpirationPeriod($expiration){
    $this->_lock_expiration_period = $expiration;
  }

  /**
   * set Login attempt limit
   * @param integer
   * @return void
   */
   public function setLoginAttemptLimit($limit){
     $this->_login_attempt_limit = $limit;
   }


  /**
   * Authenticate
   * @param string $username
   * @param string $transaction_key;
   * @throws Exceptions\InvalidCredentialsexception,
   * @throws Exceptions\UserBlockedException,
   */
  public function authenticate($username, $tranaction_key){
    $this->_password = $transaction_key;
    $user_entity = $this->_user->getUserByusername($username);

    if(!$user_entity){
      throw new Exceptions\InvalidCredentialsException('Invalid username');
    }
    $this->_uner_entity = $user_entity;

    // if user is locked and lock is not expired
    if($this->isLocked() && !$this->isLockExpired()){
      $this->updateAttemptTime();
      // update changes to database
      $this->_user->updateUser($this->_user_entity);
      throw new Exceptions\UserBlockedException('User blocked');
      return false;
    }

    // if lock is expired
    if($this->isLockExpired()){
      $this->unlockUser();
    }

    // check user credentials
    if(!$this->isValidCredentials()){
      $this->incrementLoginAttempt()
      // update changes to database
      $this->_user->updateUser($this->_user_entity);
      // check user is locked after inrementing the login attempt
      if($this->isLocked()){
        throw new Exceptions\UserBlockedException('User blocked');
        return;
      }
      throw new Exceptions\InvalidCredentialsException('Invalid credentials');
      return;
    }

    // check if user have't change temporary password
    if($this->isUsingTemporaryPassword()){
      throw new Exceptions\TransactionKeyChangeException('Transaction Key not changed');
      return;
    }
    // if no isses then return true
    return true;

  }

  /**
   * Check user user is locked or not
   * @return boolean true on locked and boolean false on not blocked
   */
  public function  isLocked(){
    $locked = $this->_user_entity->getLocked();
    return ($locked === 'Y');
  }

  /**
   * Check lock expired
   * @return boolean true if lock is expired and boolean
   * false if still locked
   */
  public function isLockExpired(){
    $current_date_time = new \DateTime();
    $last_login_attempt = $this->_user_entity->getAttemptedAt();
    $date_time_last_attempt = db2TimestampToDataTime($last_login_attempt);
    if(!$date_time_last_attempt){
      throw new \Exception("error");
    }
    $expiration_date_interval = new \DateInterval('p'.$this->_lock_expiration_period.'s');
    $expiration_data_time = $date_time_last_attempt.add($expiration_date_interval);
    return ($current_timestamp >= $expiration_data_time);
  }

  /**
   * Unlock user
   * Unlock user
   * set login_attempt to 0 and locked status to 'N'
   * @return void
   */
  public function unlockUser(){
      $this->_user_entity->setLocked('N');
      $this->_user_entity->setLoginAttempt(0);
  }


  /**
   * Lock user
   * Lock user by setting the locked status to 'Y' and
   * login attempt to the maximum login attempt
   * @return void
   */
  public function lockUser(){
      $this->_user_entity->setLocked('Y');
      $this->_user_entity->setLoginAttempt($this->_login_attempt_limit);
  }

  public function updateAttemptTime(){
      $this->_user_entity->setAttemptedAt(getDb2CurrentTimeStamp());
  }

  /**
   * Increment Login attempt
   * @return void
   */
  public function incrementLoginAttempt(){
      $current_login_attempt = $this->_user_entity->getLoginAttempt();
      $this->_user_entity->setLoginAttempt($current_login_attempt);
      if($this->isLoginAttemptExceeded()){
        $this->lockUser();
      }
  }
  /**
   * is login attempt exceeded
   * @return boolean true if login attempt exceede false if not exceeded
   */
  public function isLoginAttemptExceeded(){
    return ($this->_user_entity->getLoginAttempt() >= $this->_login_attempt_limit);
  }

  /**
   * is valid credentials
   * @return boolean true on success and false on failure
   */
  public function isValidCredentials(){
    return $this->_password_encryptor->passwordVerify($this->_password, $this->user_entity->getTransactionKey());
  }

  /**
   * Is using temporary password
   * Check user is using temporary password
   * @return boolean true if using temporary transaction password
   * false on if not using temporary tranaction key
   */
   public function isUsingTemporaryPassword(){
     return ($this->_user_entity->getTransactionKeyChanged() === 'Y');
   }

}
?>

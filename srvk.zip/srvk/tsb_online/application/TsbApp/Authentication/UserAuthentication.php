<?php
namespace TsbApp\Authentication;

class UserAuthentication {

    // user class
    private $_user;

    // password encrypter
    private $_password_ecnrypter;

    // CodeIgniter Instance
    private $_ci;

    // CodeIgniter configuraion
    private $_config;

    // user entity class
    private $_user_entity;

    /**
     * Php magin constructor
     * @param \TsbApp\Domain\User\User $user
     * @param \TsbApp\Util\PasswordEncrypter\PasswordEncrypter $password_encrypter
     * @param CodeIgniter Instance $ci_instance
     * @param CodeIgniter configuration  $config
     */
    public function __construct($user, $password_encrypter , $ci_instatnce, $config){
        $this->_user = $user;
        $this->_password_encrypter = $password_encrypter;
        $this->_ci = $ci_instatnce;
        $this->_config = $config;
    }


    /**
     * Authenticaion
     * @param string $username
     * @param string $pasword
     * @return boolean true on success and false on failure
     * @throws Exceptions\InvalidCredentialsException
     * @throws Exceptions\PasswordChangeException
     * @throws Exceptions\TransactionKeyException
     */
    public function authenticate($username, $password){

        // check user exists
        try{
          $this->_user_entity = $this->_user->getUserByusername($username);
        }catch(\Exception $e){
          throw new UserAuthenticationException('Invalid credentials', ERR_USER_AUTH_000, $e);
        }
        if(!$this->_user_entity){
          throw new Exceptions\InvalidCredentialsException('Invalid credentials');
        }

        // process user lock status
        $this->processLockStatus();

        if($this->_user_entity->getLocked() == 'Y'){
          try{
            $this->_user->updateUser($this->_user_entity);
          }catch(\Exception $e){
            throw new UserAuthenticationException($e->getMessge(), $e->getCode(), $e);
          }
          throw new UserAuthenticationException('You account is locked try after '.seconds_to_humanize($this->_config['login_limit']['lock_expiration']), 0);
          return;
        }
        // check password
        if($this->checkPassword($password)){
          try{
            $this->_user->updateUser($this->_user_entity);
          }catch(\Exception $e){
              throw new UserAuthenticationException($e->getMessage(), $e->getCode(), $e);
          }
          // check user password change is y
          if($this->_user_entity->getChangePassword() == 'Y'){
            throw new Exceptions\PasswordChangeException('Change user password');
          }
          if($this->_user_entity->getTransactionKeyChanged() == 'Y'){
            throw new Exceptions\TransactionKeyChangeException('Change user transaction key');
          }

          return true;
        }
        // authetication failure process
        $this->processAuthenticationFailed();
        try{
          $this->_user->updateUser($this->_user_entity);
        }catch(\Exception $e){
            throw new UserAuthenticationException($e->getMessage(), $e->getCode(), $e);
        }
        throw new UserAuthenticationException('Invalid credentials', 0 , null);
        return false;
    }

    /**
     * Check user is logged in or not
     *
     */
    public function isLoggedIn(){
      $user_data = $this->getLoggedInUserData();
      if($user_data && $user_data['status'] === true){
        // update temp data expiration time
        $this->_ci->session->set_tempdata($this->_config['login_session_name'], $user_data,$this->_config['login_expiration']);
        return true;
      }
      return false;
    }

    public function getLoggedInUserData(){
      return $this->_ci->session->tempdata($this->_config['login_session_name']);
    }

    public function getCurrentLoggedinUser(){
      $user_session_data = $this->getLoggedInUserData();
      $user = $this->_user->getUserById($user_session_data['user_id']);
      return $user;
    }

    public function logOut(){
      $this->_ci->session->sess_destroy();
    }

    /**
     * Process Lock Status
     * check lock, if locked then unlock if the user lock time expiration is exceeded
     * @return void
     */
    public function  processLockStatus(){
      $locked_status = $this->_user_entity->getLocked();
      if($locked_status === 'Y'){
        $user_entity = $this->processLockExperation();
      }
    }


    /**
     * Process Lock Expration
     * Helper method
     * Check lock expiration if expired then unlock
     * @return void
     */
    public function processLockExperation(){
      $last_attempt = $this->_user_entity->getAttemptedAt();
      if(empty($last_attempt)){
        $last_attempt = getDb2CurrentTimeStamp();
      }
      $dateTime = db2TimestampToDataTime($last_attempt);
      if(!$dateTime){
        throw new UserAuthenticationException('Error occurred ', ERR_USER_AUTH_001);
        return false;
      }
      $last_attempt_timestamp  = $dateTime->getTimestamp();
      $currentTimestamp = (new \DateTime('now'))->getTimestamp();
      $timestampDifference = $currentTimestamp - $last_attempt_timestamp;
      $lock_experation = $this->_config['login_limit']['lock_expiration'];
      if($timestampDifference > $lock_experation){
        // unlock user
        $this->unlockUser();
      }else{
        $this->lockUser();
      }
      // update login attempt
      $this->_user_entity->setAttemptedAt(getDb2CurrentTimeStamp());
    }

    /**
     * Process authentication failed user
     * if authentication failed then increment user login attempt
     * also check if login attempt limit exceeded then the user
     * will be lock for the time mentioned in the config file
     * @return void
     */
    public function processAuthenticationFailed(){
      $this->incrementLoginAttempt();
      if($this->_user_entity->getLoginAttempt() > $this->_config['login_limit']['limit']){
        $this->lockUser();
      }
    }

    /**
     * Incremnet Login attempt
     * Helper method to increment login attempt
     * @return void
     */
    public function incrementLoginAttempt(){
      $login_attempt = $this->_user_entity->getLoginAttempt();
      $this->_user_entity->setLoginAttempt($login_attempt + 1);
    }

    /**
     * Unlock user
     * helper method to unlock user
     * @return void;
     */
    public function unlockUser(){
      $this->_user_entity->setLocked('N');
      $this->_user_entity->setLoginAttempt(0);
    }


    /**
     * Lock user
     * Helper method to lock user
     * @return void
     */
    public function lockUser(){
      $this->_user_entity->setLocked('Y');
    }

    /**
     * Check Password
     * check password heler method
     * @return boolean true on success and false on failure
     */
     private function checkPassword($password){
       return $this->_password_encrypter->passwordVerify($password, $this->_user_entity->getPassword());
     }


     /**
      * Is valid Transaction Passwaord
      * Warning : This method only return boolean true or false
      * If any exceptin this method return boolean false
      * @param integer $user_id user id
      * @param string $trans_password transaction password
      * @return boolean true on success and false on failure
      */
     public function isValidTransActionPassword($user_id, $trans_password){
       try{
         $user = $this->_user->getUserById($user_id);
       }catch(Exception $e){
         return false;
       }
       $trans_password_db = $user->getTransactionKey();
       return $this->_password_encrypter->passwordVerify($trans_password, $trans_password_db);
     }

     public function isValidLoginPassword($user_id, $login_password){
       try{
         $user = $this->_user->getUserById($user_id);
       }catch(Exception $e){
         return false;
       }
       $login_password_db = $user->getPassword();
       return $this->_password_encrypter->passwordVerify($login_password, $login_password_db);
     }

     /**
      * Get current user user entity
      *
      */
     public function getUserEntity(){
       return $this->_user_entity;
     }


}

?>

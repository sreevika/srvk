<?php
/*
namespace TsbApp\Authentication;
    /*
    |------------------------------------------------------------------------
    | Error codes
    |------------------------------------------------------------------------
    | AUTH_0000 : Invalid username
    | AUTH_0001 : Login limit exeeded
    | AUTH_0002 : Invalid password
    |
    |
    */





    /**
     * User Authintication
     * user authentication checker
     *
     */
    class UserAuthentication_old {

      public $user_model;
      public $username;
      public $password;
      private $_user;
      private $_ci_instance;
      private $_auth_config;
      private $_auth_errors = [];
      private $_login_attempts;
      private $_login_time;


      /**
       * Php magic constructor
       * @param object $user_model , object $password_util
       */
      public function __construct(){
        $this->Online_user = $online_user;
        $this->password_util = $password_util;
        $this->_ci_instance = get_instance();
        $this->_ci_instance->config->load("app_config", TRUE);
        $this->$_auth_config = $this->_ci_instance->config->item('authentication');
      }


      /**
       * Login
       * @param string $username, string $password
       * @return boolean true on success and false on failure
       */
      public function login($suername, $password){
        $this->username = $username;
        $this->password = $password;
        if($this->_authenticateUser()){
            $this->_login_time = time();
            $user_data = [
              'status' => true,
              'username' => $username,
              'login_time' => $this->_login_time,
              'customer_id' => $this->user->getCustomerId()
            ];
            $login_session_name = $this->_ci_instance->config->item('authentication')['login_session_name'];
            $this->_ci_instance->session->set_tempdata($login_session_name, $user_data, $this->_auth_config['login_expiration']);
            $this->onAuthenticationSuccess();
            return true;
        }else{
            $this->onAuthenticationFailure();
        }
        return false;
      }

      /**
       * Authentication
       * this method checks usercredentials and other stuff
       * @return boolean true on success and false on faiure
       */
      private function _authenticateUser(){

        $user = $this->Online_user->getByUsername($username);
        if(!$user){
          throw new UserAuthenticationException("Invalid Username or password", "AUTH_0000");
          $this->onAuthenticationFailure();
          return false;
        }

        // user instance
        $this->_user = $user;

        $this->_login_attempts = $this->_user->getLoginAttempts();
        // check login limit if enabled then check limit
        if($this->_auth_config["login_limit"]["check"]){
            if($this->_checkLoginLimitExceeded()){
              $attempts = $this->_login_attempts;
              $limit = $this->_auth_config["login_limit"]['limit'];
              $account_lock_expiration = $this->_auth_config["login_limit"]["lock_expiration"];
              throw new UserAuthenticationExceptionr("Your login limt exceeded. You can try again after ".seconds_to_humanize($account_lock_expiration), "AUTH_0001");
              $this->online_user->lockUser($this->_user);
              return false;
            }
        }

        // verify password
        if(!$this->password_util->passwordVerify($this->password, $user->getPassword())){
          // If login limit check is enabled
          if($this->_auth_config["login_limit"]["check"]){
            $attempts = $this->_login_attempts;
            $limit = $this->_auth_config["login_limit"]['limit'];
            $attempts_lefts = $limit - $attempts;
            $this->_user->incrementLoginLimit();
            throw new UserAuthenticationException("Invalid credentials.".$attempts_lefts." attempts remaining", "AUTH_0002");
          }
          throw new UserAuthenticationException("Invalid credentials.".$attempts_lefts." attempts remaining", "AUTH_0002");
          return false;
        }
        return true;
      }




      /**
       * Check login limit exeeded
       * @return boolean true on success and false on failure
       */
      private function _checkLoginLimitExceeded(){
          $attempts = $this->_login_attempts;
          $limit = $this->_auth_config["login_limit"]['limit'];
          $account_lock_expiration = $this->_auth_config["login_limit"]["lock_expiration"];
          if($attempts > $limit){
            return true;
          }
          return false;
      }


      public static function isLoggedIn(){
          $ci &= get_instance();
          $ci->config->load("app_config", TRUE);
          $user_data = $ci->tempdata($ci->config->item('authentication')['login_session_name']);
          if($user_data && $user_data['status'] === true){
              return truen
          }
          return false;
      }


      public function onAuthenticationSuccess(){
        // write to database
      }

      public function onAuthenticationFailure(){
        // write to database
      }




    }
*/
?>

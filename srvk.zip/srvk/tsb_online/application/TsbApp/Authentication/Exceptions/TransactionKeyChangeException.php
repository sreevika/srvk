<?php
namespace TsbApp\Authentication\Exceptions;
/**
 * Transaction key exception throws when transaction key havin't
 * changed.
 */
class TransactionKeyChangeException extends \Exception{
    /**
     * Php magic constructor function
     *
     */
     public function __construct($msg, $code = null, $previous = null){
       parent::__construct($msg, $code, $previous);
     }

}


?>

<?php
namespace TsbApp\Authentication\Exceptions;
/**
  * Password change exception triggers when user havin't change the password
  */
class PasswordChangeException extends \Exception{
  /**
   * Php magic constructor function
   *
   */
   public function __construct($msg, $code = null, $previous = null){
     parent::__construct($msg, $code, $previous);
   }

}
?>

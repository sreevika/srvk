<?php
namespace TsbApp\Authentication\Exceptions;
/**
  * Invalid credential exception throws when username or password was wrong
  * in a login or authentication request
  */
class InvalidCredentialsException extends \Exception{
  /**
   * Php magic constructor function
   *
   */
   public function __construct($msg, $code = null, $previous = null){
     parent::__construct($msg, $code, $previous);
   }

}
?>

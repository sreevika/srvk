<?php
namespace TsbApp\Authentication\Exceptions;
/**
  * User Blocked exception triggers when the user is
  * Blocked
  */
class UserBlockedException extends \Exception{
  /**
   * Php magic constructor function
   *
   */
   public function __construct($msg, $code = null, $previous = null){
     parent::__construct($msg, $code, $previous);
   }

}
?>

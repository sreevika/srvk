<?php
namespace TsbApp\Authentication;
class UserAuthenticationException extends \Exception{
    public function __construct($msg, $code, $previous = null){
      parent::__construct($msg, $code, $previous);
    }
}
?>

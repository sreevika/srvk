<?php
namespace TsbApp\Authentication;
/**
 * Authentication service
 */
class AuthenticationService {

  /**
   * UserAuthenticationFactory
   * Creates User authentication instance
   * @return UserAuthentication
   */
  private static function  UserAuthenticationFactory(){
    $user = new \TsbApp\Domain\User\User();
    $password_encrypter = new \TsbApp\Util\PasswordEncrypter\PasswordEncrypter();
    $codeigeniter_instance =& get_instance();
    $codeigeniter_instance->config->load("app_config", TRUE);
    $config = $codeigeniter_instance->config->item('authentication', 'app_config');
    $user_authentication = new UserAuthentication($user, $password_encrypter, $codeigeniter_instance, $config);
    return $user_authentication;
  }

  /**
   * Check login for the given credentials
   * @param string $username
   * @param string $password
   * @throws UserAuthenticationException
   */
  public static function checkLogin($username, $password){
    $user_authentication_instance = self::UserAuthenticationFactory();
    $authentication_status = $user_authentication_instance->authenticate($username, $password);
    if($authentication_status === true){
      $user_data = [
        'status' => true,
        'user_id' => $user_authentication_instance->getUserEntity()->getId(),
      ];
      $codeigeniter_instance =& get_instance();
      $codeigeniter_instance->config->load("app_config", TRUE);
      $config = $codeigeniter_instance->config->item('authentication', 'app_config');
      $login_session_name = $config['login_session_name'];
      $login_session_expiration = $config['login_expiration'];
      $codeigeniter_instance->session->sess_regenerate(true);
      $codeigeniter_instance->session->set_tempdata($login_session_name, $user_data, $login_session_expiration);
      return true;
    }
    return false;
  }

  /**
   * Is logged in
   * Check user is logged in
   * @return boolean true on success and false on faiure
   */
  public static function isLoggedIn(){
    return self::UserAuthenticationFactory()->isLoggedIn();
  }

  /**
   * Logout
   * This function clears user session
   * @return boolean true on succes and false on failure
   */
  public static function logOut(){
    return self::UserAuthenticationFactory()->logOut();
  }

  /**
   * Get current logged in user
   * @return UserEntity
   */
  public static function getCurrentLoggedinUser(){
      if(static::isLoggedIn()){
        return static::UserAuthenticationFactory()->getCurrentLoggedinUser();
      }
  }

  public static function verifyTransactionPassword($user_id, $trans_password){
    return self::UserAuthenticationFactory()->isValidTransActionPassword($user_id, $trans_password);
  }

  public static function verifyLoginPassword($user_id, $login_password){
    return self::UserAuthenticationFactory()->isValidLoginPassword($user_id, $login_password);
  }

  public static function changePassword($username, $new_password){
    $user = new \TsbApp\Domain\User\User();
    $password_encrypter = new \TsbApp\Util\PasswordEncrypter\PasswordEncrypter();
    $user_entity = $user->getUserByusername($username);
    $encrypted_password = $password_encrypter->passwordHash($new_password);
    if(!$user_entity){
      throw new \Exception('Invalid username');
    }
    $user_entity->setPassword($encrypted_password);
    $user_entity->setChangepassword('N');
    return $user->updateUser($user_entity);
  }

  public static function newTransactionKey($username, $new_transaction_key){
    $user = new \TsbApp\Domain\User\User();
    $password_encrypter = new \TsbApp\Util\PasswordEncrypter\PasswordEncrypter();
    $user_entity = $user->getUserByusername($username);
    $encrypted_password = $password_encrypter->passwordHash($new_transaction_key);
    if(!$user_entity){
      throw new \Exception('Invalid username');
    }
    $user_entity->setTransactionKey($encrypted_password);
    $user_entity->setTransactionKeyChanged('N');
    return $user->updateUser($user_entity);
  }


}

?>

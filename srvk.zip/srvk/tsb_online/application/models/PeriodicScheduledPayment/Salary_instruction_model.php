<?php
class Salary_instruction_model extends MY_Model{

  /**
   * Get Salary instruction for the customer
   * @param mixed $customer_id customer id
   * @param boolean true of only get verfied result if set to false then all
   * results and default value is true
   * @return array on success if data return null if no data
   * return boolean false if error
   */
  public function getSalaryInstructionByCustomerId($customer_id, $vefified_only = true){
    $sql = " SELECT * FROM TSB_SPI_STANDING_INSTRUCTION AS STANDING_INSTRUCTION  ";
    $sql .= " JOIN TSB_CUSTOMER_ACCOUNT AS TSB_CUST_ACC ";
    $sql .= " ON ( STANDING_INSTRUCTION.ACC_NO = TSB_CUST_ACC.ACCNO ) ";
    $sql .= " JOIN TSBONLINE_BENEFICIARYMASTER TSB_BENF_MASTER ";
    $sql .= " ON STANDING_INSTRUCTION.BENEF_ID =  TSB_BENF_MASTER.BENEFICIARY_ID ";
    $sql .= " JOIN TSB_ACCMAST ON (TSB_CUST_ACC.ACCNO = TSB_ACCMAST.ACCNO ) ";
    $sql .= " WHERE TSB_CUST_ACC.CUSTOMER_ID = ? AND TSB_BENF_MASTER.ACTIVATED = 'Y' ";
    $sql .= " AND TSB_CUST_ACC.ACCTYPE = '26' ";
    if($vefified_only){
      $sql .= " AND STANDING_INSTRUCTION.ACTIVE = 'Y' ";
    }
    $params = array();
    $params[] = $customer_id;
    try{
      $result = $this->execute_query($sql, $params)->fetchAll();
    }catch(Exception $e){
      var_dump($e->getMessage());
      return false;
    }
    if(count($result) > 0 ){
      return array_pop($result);
    }
    return null;
  }

  /**
   * Update Salary instruction
   * @param array $data parameters
   */
  public function updateSalaryInstructin($data){
    $sql = " UPDATE TSB_SPI_STANDING_INSTRUCTION ";
    //$sql .= " SET BENEF_ID = ?, PERCENTAGE = ?, UPDATED_BY = ?, UPDATED_TIME =  CURRENT_TIMESTAMP ";
    $sql .= "SET PERCENTAGE = ?, UPDATED_BY = ?, UPDATED_TIME =  CURRENT_TIMESTAMP ";
    $sql .= " WHERE SI_ID = ? ";
    $params = array();
    //$params[] = $data['beneficiaryId'];
    $params[] = $data['percentage'];
    $params[] = $data['username'];
    $params[] = $data['siId'];
    try{
      $update_status = $this->execute_query($sql, $params);
    }catch(Exception $e){
      return false;
    }
    return true;
  }

}
?>

<?php
/*
 |------------------------------------------------------------------------------
 | ERROR CODES
 |------------------------------------------------------------------------------
 |
 |
 |
 |------------------------------------------------------------------------------
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Beneficiary_model extends MY_Model{

  /**
   * Get Customer beneficiary_details
   * @param integer $customer_id
   * @param boolean $activated if boolean true then get all the activated beneficiary
   * @return array on success return false on failure
   * if boolean false then diactivated beneficiary
   */
  private function getCustomerBeneficiarys($customer_id , $activated = true){
    $sql = " SELECT A.PARENT_CUSTOMER_ID,A.BENEFICIARY_ID,A.BENEFICIARY_NAME,";
    $sql .="A.BENEFICIARY_ACCNO,A.ACCTYPE,A.IFS_CODE,A.TRANSACTION_LIMIT,A.ACTIVATED,";
    $sql .="A.TRANS_TYPE,A.BANK_ID,A.BRANCH_CODE,B.BANK_NAME,B.BANK_CODE,C.BRANCH_NAME,C.BANK_CODE";
    $sql .=" FROM TSBONLINE_BENEFICIARYMASTER AS A ";
    $sql .= " FULL OUTER JOIN IFSC_MASTER AS C ON C.IFS_CODE = A.IFS_CODE ";
    $sql .= "FULL OUTER JOIN BANK_MASTER AS B ON B.BANK_CODE = C.BANK_CODE ";
    $sql .= " WHERE A.PARENT_CUSTOMER_ID = ? ";
    $sql .= ($activated === true)? " AND A.ACTIVATED = 'Y' " : "";
    $params = array();
    $params[] = $customer_id;
    try{
      $resultArray = $this->execute_query($sql, $params)->fetchAll();
    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }

    return $resultArray;

  }


  /**
   * Get all the activated customer id
   * @param integer $customer_id
   * @return array on success and boolean false on failure
   */
  public function getActivatedCustomerBeneficiarys($customer_id){
    return $this -> getCustomerBeneficiarys($customer_id, true);
  }

  /**
   * Get all the  beneficiary it contain deactivated beneficiary
   * @param integer $customer_id
   * @return array on success and boolean false on failure
   */
  public function getAllCustomerBeneficiarys($customer_id){
    return $this ->getCustomerBeneficiarys($customer_id, false);
  }


  /**
   * Get customer Inter bank benefiary
   *
   */
  public function getCustomerInterBankBeneficiarys($customer_id){
    $all_beneficiary = $this->getAllCustomerBeneficiarys($customer_id);

    if(!is_array($all_beneficiary)){
      return false;
    }
    $filtered_inter_bank_benf = array_filter($all_beneficiary, function($v){
        return ( isset($v['TRANS_TYPE']) && $v['TRANS_TYPE'] == 'O');
    });
    return $filtered_inter_bank_benf;
  }

  /**
   * Get all Intra bank beneficiary
   * @param integer $customer_id
   * @return array on success and boolean false on failure
   */
   public function getActivatedCustomerIntraBankBeneficiarys($customer_id){
      $all_beneficiary = $this->getActivatedCustomerBeneficiarys($customer_id);

      if(!is_array($all_beneficiary)){
        return false;
      }
      $filtered_intra_bank_benf = array_filter($all_beneficiary, function($v){
          return ( isset($v['TRANS_TYPE']) && $v['TRANS_TYPE'] == 'I');
      });
      return $filtered_intra_bank_benf;
   }



   /**
    * Get all Intra bank beneficiary
    * @param integer $customer_id
    * @return array on success and boolean false on failure
    */
    public function getCustomerIntraBankBeneficiarys($customer_id){
       $all_beneficiary = $this->getAllCustomerBeneficiarys($customer_id);

       if(!is_array($all_beneficiary)){
         return false;
       }
       $filtered_intra_bank_benf = array_filter($all_beneficiary, function($v){
           return ( isset($v['TRANS_TYPE']) && $v['TRANS_TYPE'] == 'I');
       });
       return $filtered_intra_bank_benf;
    }



   /**
   * Get all Inter bank beneficiary
   * @param integer $customer_id
   * @return array on success and boolean false on failure
   */
   public function getActivatedCustomerInterBankBeneficiarys($customer_id){
     $all_beneficiary = $this->getActivatedCustomerBeneficiarys($customer_id);
      if(!is_array($all_beneficiary)){
        return false;
      }
      $filtered_inter_bank_benf = array_filter($all_beneficiary, function($v){
          return ( isset($v['TRANS_TYPE']) && $v['TRANS_TYPE'] == 'O');
      });
      return $filtered_inter_bank_benf;
   }

   /**
    * Is already added as beneficiary
    * If already added as beneficiary then return true else false
    * @param integer $customer_id
    * @param string account number $accNO
    * @throws Exception on query failure
    */
   public function isAlreadyAddedAsBenf($parent_customer_id, $acc_no){
     $sql = " SELECT count(*) FROM TSBONLINE_BENEFICIARYMASTER WHERE PARENT_CUSTOMER_ID = ? AND BENEFICIARY_ACCNO = ? ";
     $params = array();
     $params[] = $parent_customer_id;
     $params[] = $acc_no;
     try{
       $count = $this->execute_query($sql, $params)->fetchColumn();
     }catch(Exception $e){
       $this->setError('somthing went wrong', $e->getCode());
       throw new Exception('somthing went wrong');
     }
     if($count >  0){
      return true;
     }
     return false;
   }
      /**
    * Get Beneficiary Id using Parent customer id and account number used
    * @param integer $customer_id
    * @param string account number $accNO
    * @throws Exception on query failure
    */
   public function getbeneficiaryid($parent_customer_id, $acc_no){
     $sql = " SELECT * FROM TSBONLINE_BENEFICIARYMASTER WHERE PARENT_CUSTOMER_ID = ? AND BENEFICIARY_ACCNO = ? ";
     $params = array();
     $params[] = $parent_customer_id;
     $params[] = $acc_no;
      try{
    $schedule_data = $this->execute_query($sql, $params)->fetchAll();
    return array_pop($schedule_data);
    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }
   }

   /**
    *
    * To Create Beneficiary ID
    * Insert Beneficiaries
    * Update Beneficiary Count on Customer Master
    *
    */

   public function addNewBeneficiary($data){
      $cutomer_id=(isset($data['customerId']))? $data['customerId']: NULL;
      $sql = " SELECT ONLINE_BENF_COUNTER as BENEFICIARY_ID FROM tsb_customer_mast ";
      $sql .= " WHERE CUSTOMER_ID = ? ";
      $params = array();
      $params[] = $cutomer_id;
        try{
          $this ->conn->beginTransaction();
           $count = $this->execute_query($sql, $params)->fetchColumn();
           //To get the count of beneficiaries
            if ($count == '' || is_null($count))
            {
              $currentbeniffiCiaryID = 1;
            }
            else{
              $currentbeniffiCiaryID = $count + 1;
            }
            //set Beneficiary Id
            $beniffiCiaryID = $cutomer_id . '-' . $currentbeniffiCiaryID;
            $query = 'INSERT INTO TSBONLINE_BENEFICIARYMASTER ';
            $query .='(PARENT_CUSTOMER_ID,BENEFICIARY_ID,BENEFICIARY_NAME,BENEFICIARY_ACCNO,';
            $query .='BENEFICIARY_ACCNO_CANONICAL,IFS_CODE,MOBILE,TRANSACTION_LIMIT,TRANS_TYPE,CONFIRM,';
            $query .='ACTIVATED,UPDATED_TIME,UPDATED_BY,BANK_ID,CONFIRMED_BY,CONFIRMED_TIME,branch_code, ACCTYPE)';
            $query .=' VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ';
            $param = array();
            $param[] = $cutomer_id;
            $param[] = $beniffiCiaryID;
            $param[] = (isset($data['benfName']))? $data['benfName']: NULL;
            $param[] = (isset($data['benefAccNo']))? $data['benefAccNo']: NULL;
            $param[] = (isset($data['benefAccNo']))? $data['benefAccNo']: NULL;
            $param[] = (isset($data['ifsCode']))? $data['ifsCode']: NULL;
            $param[] = (isset($data['mobileNo']))? $data['mobileNo']: NULL;
            $param[] = (isset($data['benfTransLimit']))? $data['benfTransLimit']: NULL;
            $param[] = (isset($data['transType']))? $data['transType']: NULL;
            $param[] = 'Y';
            $param[] = 'Y';
            $param[] = getDb2CurrentTimeStamp();
            $param[] = (isset($data['userName']))? $data['userName']: NULL;
            $param[] = (isset($data['bankId']))? $data['bankId']: NULL;
            $param[] = (isset($data['userName']))? $data['userName']: NULL;
            $param[] = getDb2CurrentTimeStamp();
            $param[] = (isset($data['BranchId']))? $data['BranchId']: NULL;
            $param[] = (isset($data['benfAccType']))? $data['benfAccType']: NULL;

            $this -> execute_query($query, $param);

            //Update customer beneficiary counter

            $update = "UPDATE tsb_customer_mast SET ONLINE_BENF_COUNTER=?  where CUSTOMER_ID=?";
            $para = array();
            $para[] = $currentbeniffiCiaryID;
            $para[] = $cutomer_id;

            $this -> execute_query($update, $para);

            $this ->conn->commit();
           }catch(Exception $e){
             $this->setError('somthing went wrong', $e->getCode());
             $this ->conn->rollBack();
             return false;
           }
           return true;

   }
   /**
    * Update Inter bank beneficiarysfor rejection time
    * @param array
    * @return boolean true on success and boolean false on failure
    */
   public function rejectionClearUpdateBeneficiary($data){

      $sql = " UPDATE  TSBONLINE_BENEFICIARYMASTER ";
      $sql .= " SET BENEFICIARY_ACCNO = ?, BENEFICIARY_ACCNO_CANONICAL = ?, BENEFICIARY_NAME = ?, IFS_CODE = ? ";
      $sql .= " WHERE PARENT_CUSTOMER_ID = ? AND BENEFICIARY_ACCNO = ?";
      $params = array();
      $params[] = $data['accNo'];
      $params[] = $data['accNo'];
      $params[] = $data['benfName'];
      $params[] = $data['ifsc'];
      $params[] = $data['customerId'];
      $params[] = $data['currentAccNo'];
      try{
        $status = $this->execute_query($sql, $params);
      }catch(Exception $e){
        return false;
      }
      if(!$status){
        return false;
      }
      return true;
   }


   /**
    * Update Intra bank beneficiarys
    * @param array
    * @return boolean true on success and boolean false on failure
    */
   public function updateBeneficiary($data){
      $sql = " UPDATE  TSBONLINE_BENEFICIARYMASTER ";
      $sql .= " SET TRANSACTION_LIMIT = ?, ACTIVATED = ? ";
      $sql .= " WHERE BENEFICIARY_ID = ? ";
      $params = array();
      $params[] = $data['transLimit'];
      $params[] = $data['activated'];
      $params[] = $data['benfId'];

      try{
        $status = $this->execute_query($sql, $params);
      }catch(Exception $e){
        var_dump($e->getMessage());
        return false;
      }
      if(!$status){
        return false;
      }
      return true;
   }


   /**
    * Get Bank details from Ifs code
    * @param string
    * @return array on succes if no data then return null and boolean  false on failure
    */
   public function getBankDetailsFromIfsc($ifsc){
     $sql = " SELECT * FROM IFSC_MASTER ";
     $sql .= " INNER JOIN BANK_MASTER ON IFSC_MASTER.BANK_CODE = BANK_MASTER.BANK_CODE ";
     $sql .= " WHERE IFSC_MASTER.IFS_CODE = ? ";
     $params = array();
     $params[] = $ifsc;
     try{
       $result = $this->execute_query($sql, $params)->fetchAll();
     }catch(Exception $e){
       $this->setError('Somthing went wrong', $e->getCode());
       return false;
     }
     if(count($result) > 0){
       return array_pop($result);
     }
     return null;
   }
   /**
    * Get Bank details from Beneficiary Id
    * @param string
    * @return array on succes if no data then return null and boolean  false on failure
    */
   public function getBeneficiaryDetails($benfId) {
      $sql = " SELECT * FROM TSBONLINE_BENEFICIARYMASTER AS BENF  ";
      $sql .= " FULL OUTER JOIN IFSC_MASTER AS IFSC ON IFSC.IFS_CODE = BENF.IFS_CODE ";
      $sql .= " FULL OUTER JOIN BANK_MASTER AS BANK ON BANK.BANK_CODE = IFSC.BANK_CODE  ";
      $sql .= " WHERE BENF.BENEFICIARY_ID = ? ";
      $params = array();
      $params[] = $benfId;
      try{
        $result = $this->execute_query($sql, $params)->fetchAll();
      }catch(Exception $e){
       $this->setError('Somthing went wrong', $e->getCode());
       return false;
      }
      if(count($result) == 0){
        return null;
      }
      return array_pop($result);
   }


}

?>

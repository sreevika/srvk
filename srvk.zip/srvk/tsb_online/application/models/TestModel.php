<?php
class TestModel extends MY_Model{

  public function __construct(){
    $table_name = "UMAS_USER";
    $primary_key = 'ID';
    $table_columns = [
      'ID' => 'INTEGER',
      'NAME' => 'STRING',
      'MOBILE_NUM' => 'STRING',
      'EMAIL' => 'STRING',
      'DOB' => 'DATE',
      'USER_ID' => 'STRING',
      'PASSWD' => 'STRING',
      'DOMAIN_ID' => 'INTEGER',
      'DEPT_CODE' => 'VARCHAR',
      'OFFICE_CODE' => 'VARCHAR',
      'DESIG_CODE' => 'VARCHAR',
      'PEN' => 'VARCHAR',
      'TRCODE' => 'INTEGER',
      'LOGIN_TYPE' => 'VARCHAR',
      'IS_ACTIVE' => 'VARCHAR',
      'CREATED_BY' => 'VARCHAR',
      'CREATED_ON' => 'DATA',
      'UPDATED_BY' => 'VARCHAR',
      'UPDATED_ON' => 'DATA'
     ];
    parent::__construct($table_name, $table_columns, $primary_key);
  }



}
?>

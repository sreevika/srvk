<?php
/*
 |------------------------------------------------------------------------------
 | ERROR CODES
 |------------------------------------------------------------------------------
 |
 |
 |
 |------------------------------------------------------------------------------
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Fund_transaction_model extends MY_Model{

	public function fundTransferManager($data){

		$fundTransferManager = new TsbApp\Domain\FundTransfer\FundTransferManager($data);
		return $fundTransferManager->processFundTransfer();

	}
  public function getCoretisConnection() {
    try{

      $db2_coretis = $this->load->database('coretis', TRUE);
      $db2_coretis_conn = $db2_coretis->conn_id;
      $db2_coretis_conn->setAttribute(\PDO::ATTR_ERRMODE,\PDO::ERRMODE_EXCEPTION);

    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }

    return $db2_coretis_conn;
  }

  /**
   * Actions Of Fund Transaction
   * Generate Sequence Number
   * @param Date $date
   * Generate Transaction Id
   * @param Sequence Number $seqno
   * Generate Maximum Schedule Id
   */

  public function generateSequenceNo($date) {

  	$query = 'SELECT SEQNO FROM SEQNO_TSBONLINE WHERE TRANSACTION_DATE= ? ';
  	$params = array();
    $params[] = $date;
    try{
    	$resultSeq = $this->execute_query($query, $params)->fetchColumn();
    	if($resultSeq>0){
    		$seqno = $resultSeq + 1;
    		$updateQuery = 'UPDATE SEQNO_TSBONLINE SET SEQNO=? WHERE  TRANSACTION_DATE=?';
    		$param = array();
    		$param[] = $seqno;
    		$param[] = $date;
    		$update = $this->execute_query($updateQuery, $param);
    		return $seqno;
    	}
    	else {
	    	 $seqno = 5000000;
	    	 $insertQuery = 'INSERT INTO SEQNO_TSBONLINE (SEQNO,TRANSACTION_DATE) VALUES(?,?) ';
	    	 $insert_param = array();
				 $insert_param[] = $seqno;
				 $insert_param[] = $date;
				 $insert = $this->execute_query($insertQuery, $insert_param);
				 return $seqno;

        }
    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }

  }


	/**
	 * Get minimum Facitlity account balance for the account
	 * number
	 * @param mixed $accno
	 * @return integer on success null if no data and boolean false if error
	 */
	public function getMinimumAccBalForAccType($acc_type, $facility){
			$sql = " SELECT MINBAL FROM SB_FACILITY ";
			$sql .= " WHERE ACCTYPE = ? AND FACILITY = ? AND  CURRENT_DATE BETWEEN MINBAL_EFF_FROM AND ";
			$sql .= " CASE WHEN MINBAL_EFF_TO IS NULL THEN CURRENT_DATE ELSE MINBAL_EFF_TO END ";
			$params = array();
			$params[] = $acc_type;
			$params[] = $facility;
			try{
				$minbal = $this->execute_query($sql, $params)->fetchColumn();
			}catch(Exception $e){
				var_dump($e->getMessage());
				return false;
			}
			return $minbal;
	}

  public function transactionId($seqno, $trCode = '9901') {
        $noSeq = str_pad($seqno, 7, '0', STR_PAD_LEFT);
        $time = new \DateTime("now");
        $time = $time->format('YmdHisu');
        $ekuber_transaction_id_spacestrip = str_pad($time, 20, 0, STR_PAD_RIGHT);
				// for safty if length greater than 0 then substr
				if(strlen($ekuber_transaction_id_spacestrip) > 20){
					$ekuber_transaction_id_spacestrip = substr($ekuber_transaction_id_spacestrip, 0, 20);
				}
				$trcode = str_pad($trCode, 4, 0, STR_PAD_LEFT);
        $ekuber_transaction_id = 'TSB'.$ekuber_transaction_id_spacestrip.$trCode.$noSeq;
        return $ekuber_transaction_id;
   }

  public function getMaximumScheduleId() {
  	$scheduleId=0;
  	$selectSchedule = 'SELECT SCHEDULE_ID FROM TSBONLINE_SCHEDULE_CURRENTID';
  	try{
  		$resultScheduleId = $this->execute_query($selectSchedule)->fetchAll();
  		$resltCount = count($resultScheduleId);
  		if($resltCount>0){
  			 $scheduleId = $resultScheduleId[0]['SCHEDULE_ID'] ;
         $scheduleId = $scheduleId+1;
         $updateQuery = 'UPDATE TSBONLINE_SCHEDULE_CURRENTID SET SCHEDULE_ID=? ';
         $param = array();
    		 $param[] = $scheduleId;
    		 $update = $this->execute_query($updateQuery, $param);
    		 return $scheduleId;
  		}else{
  			 $scheduleId = 1;
  			 $insertQuery = 'INSERT INTO TSBONLINE_SCHEDULE_CURRENTID (SCHEDULE_ID) VALUES(?) ';
  			 $params = array();
    		 $params[] = $scheduleId;
    		 $update = $this->execute_query($insertQuery, $params);
    		 return $scheduleId;

  		}
  	}catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }


  }

  /**
   * Insert Data In TSB ONLINE SCHEDULE (TSBONLINE_SCHEDULE)
   * @param Data $data values (accNo,accType,benfId,transDate,amount,userName,todayDate,option,scheduleId,remark,tsbTransactionId)
   */

  public function scheduleFundTransfer($data) {
  	$insertQuery = 'INSERT INTO TSBONLINE_SCHEDULE ';
  	$insertQuery .='(ACC_NO,ACC_TYPE,BENEF_ID,DATE,AMOUNT,ENTERED_BY,ENTERED_TIME,';
  	$insertQuery .='PROCESS,SCHEDULE_ID,REMARKS,TRANSACTION_ID,INITIATE_STATUS,PROCESS_STATUS) ';
  	$insertQuery .="VALUES (?,?,?,?,?,?,?,?,?,?,?,'I','I')";
  	$params = array();
  	$params[] = $data['accNo'];
  	$params[] = $data['accType'];
  	$params[] = $data['benfId'];
  	$params[] = $data['scheduleDate'];
  	$params[] = $data['amount'];
  	$params[] = $data['username'];
  	$params[] = $data['scheduleDate'];
  	$params[] = $data['paymentOption'];
  	$params[] = $data['scheduleId'];
  	$params[] = $data['remark'];
  	$params[] = $data['tsbTransactionId'];
  	try{
  		$insert = $this->execute_query($insertQuery, $params);
  		return true;
    	}catch(Exception $e){
				var_dump($e->getMessage());
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
  }

  public function checkScheduledBenId($benf_id){
    $sql = " SELECT count(*) FROM TSBONLINE_SCHEDULE WHERE BENEF_ID = ? ";
     $params = array();
     $params[] = $benf_id;
     try{
       $count = $this->execute_query($sql, $params)->fetchColumn();
     }catch(Exception $e){
       $this->setError('somthing went wrong', $e->getCode());
       throw new Exception('somthing went wrong');
     }
     if($count >  0){
      return true;
     }
     return false;
  }

  public function getScheduleDetails($scheduleId) {
    $query = 'SELECT * FROM TSBONLINE_SCHEDULE WHERE SCHEDULE_ID =?';
    $params = array();
    $params[] = $scheduleId;
    try{
    $schedule_data = $this->execute_query($query, $params)->fetchAll();
    return array_pop($schedule_data);
    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }

  }
  /**
   * Insert Data In SB PAYMENT ONLINE (SB_PAYMT_ONLINE)
   * @param Data $data values (accNo,accType,benfId,transDate,amount,userName,todayDate,option,scheduleId,remark,tsbTransactionId)
   */

  public function insertSbPaymentOnline($data) {
  	$insertQuery = 'INSERT INTO SB_PAYMT_ONLINE ';
  	$insertQuery .='(TRCODE,TRANSACTION_DATE,TRANSACTION_TIME,DAILY_SEQNO,HEAD_ID,';
  	$insertQuery .='FINYR_CD,PAYMT_AMT,AMT_CASH,NET_CLAIM,SB_ACCTYPE,SB_ACCNO,TRANSACTION_ID,PARTY_NAME,';
  	$insertQuery .='REMARKS,SB_TRANSTYPE,SCRT_OK,SCRT_DATE,DT_ACC_DATE,SCRT_BALANCE,ACC_BALANCE)';
  	$insertQuery .='VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $params = array();
    $params[] = $data['trCode'];
    $params[] = $data['transDate'];
    $params[] = $data['transTime'];
    $params[] = (string) $data['paymentSeqNo'];
    $params[] = $data['headId'];
    $params[] = $data['finYearCode'];
    $params[] = $data['netPay'];
    $params[] = $data['netPay'];
    $params[] = $data['netPay'];
    $params[] = $data['accType'];
    $params[] = $data['accNo'];
    $params[] = $data['tsbTransactionId'];
    $params[] = $data['accHolderName'];
    $params[] = $data['remark'];
    $params[] = $data['sbTransType'];
    $params[] = 'Y';
    $params[] = $data['currentTimestamp'];
    $params[] = $data['seqDate'];
    $params[] = $data['scrtBal'];
    $params[] = $data['ledgerBalance'];
    try{
    	$insert = $this->execute_query($insertQuery, $params);
    	}catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;
  }

  /**
   * Update tsb account mast
   * @param Data $ledger_balance,$scrt_balance
   */

  public function updateBalance($acc_no,$ledger_balance,$scrt_balance) {
    $updateAccmast = "UPDATE  TSB_ACCMAST SET LEDGER_BAL=?,SCRT_BAL=? WHERE ACCNO=?";
    $params = array();
    $params[] = $ledger_balance;
    $params[] = $scrt_balance;
    $params[] = $acc_no;
    try{
    $update = $this->execute_query($updateAccmast, $params);

    }catch(Exception $e){
      $this->setError('Something went wrong', $e->getCode());
      return false;
    }
    return true;
  }

    /**
   * Insert Data In Online Amount Transfer Details (ONLINE_AMT_TRANSFER_DETAIL)
   * @param Data $data
   */

  public function insertOnlineAmountTransferDetails($data) {
    $insertQuery = 'INSERT INTO ONLINE_AMT_TRANSFER_DETAIL ';
    $insertQuery .='(TRCODE,COUNTER_DATE,DAILY_SEQNO,SENDER_ACCTYPE,SENDER_ACCNO,REF_TRCODE,';
    $insertQuery .='REF_COUNTER_DATE,REF_DAILY_SEQNO,BENF_TYPE,BENF_ACCTYPE,BENEF_ACCNO,IFSC,';
    $insertQuery .='NET_PAY,BANK_ID,NAME,REMARKS,MOBILE,UPDATED_BY,UPDATED_TIME,TRANS_ID,BENF_ID)';
    $insertQuery .='VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $params = array();
    $params[] = $data['trCode'];
    $params[] = $data['transDate'];        //currentdate
    $params[] = $data['sequenceNo'];         //generate new sequence number
    $params[] = $data['accType'];
    $params[] = $data['accNo'];
    $params[] = $data['trCode'];
    $params[] = $data['transDate'];
    $params[] = $data['paymentSeqNo'];  //generate new sequence number
    $params[] = $data['transType'];            //benf Trans Type
    $params[] = $data['benfAccType'];         //benfaccType
    $params[] = $data['benfAccNo'];           // benf accNo
    $params[] = $data['benfIfsc'];             // Benf Ifsc
    $params[] = $data['netPay'];              //AMount
    $params[] = $data['benfBankId'];
    $params[] = $data['benfName'];
    $params[] = $data['remark'];
    $params[] = $data['mobile'];
    $params[] = $data['username'];
    $params[] = $data['currentTimestamp'];
    $params[] = $data['detailTransId'];
    $params[] = $data['benfId'];
    try{
      $insert = $this->execute_query($insertQuery, $params);
      return true;
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
  }


    /**
   * Insert Data In Tsb Online Transaction Master (TSBONLINE_TRANS_MAST)
   * @param Data $data
   */

  public function insertTsbOnlineTransMaster($data) {
    $insertQuery = 'INSERT INTO TSBONLINE_TRANS_MAST ';
    $insertQuery .='(TRCODE,COUNTER_DATE,DAILY_SEQNO,TRANS_ABBR,BILL_AMT,TRANS_ID,TRANS_TYPE) ';
    $insertQuery .='VALUES (?,?,?,?,?,?,?)';
    $params = array();
    $params[] = $data['trCode'];
    $params[] = $data['currentDate'];        //currentdate
    $params[] = $data['paymentSeqNo'];  // sequence number
    $params[] = $data['descAbbr'];          //DESC ABBR taken by SB_TRANSTYPE
    $params[] = $data['netPay'];
    $params[] = $data['detailTransId'];
    $params[] = $data['paymentTransType']; // value 66/67
    try{
      $insert = $this->execute_query($insertQuery, $params);
      return true;
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
  }

    /**
   * Transfer Type IntraBank
   * Insert Data In Sb Reciept Online(SB_RECPT_ONLINE)
   * @param Data $data
   */

  public function insertSbRecptOnline($data) {
    $insertQuery = 'INSERT INTO SB_RECPT_ONLINE ';
    $insertQuery .='(TRCODE,TRANSACTION_DATE,TRANSACTION_TIME,DAILY_SEQNO,HEAD_ID,FINYR_CD,RECPT_AMT,';
    $insertQuery .='ACCNO,TRANS_ID,ACCTYPE,SB_TRANSTYPE,RECEIPT_DATE,PARTY_NAME,AMTBY_CASH,';
    $insertQuery .='ACCTYPE_CATEGORY_CODE,REMARKS,DT_ACC_DATE,RECPT_OK,SCRT_BALANCE,ACC_BALANCE, ';
    $insertQuery .=' REF_COUNTER_DATE , REF_DAILY_SEQNO ) ';
    $insertQuery .='VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $params = array();
    $params[] = $data['trCode'];
    $params[] = $data['currentDate'];        //currentdate
    $params[] = $data['transTime'];        //currentTime
    $params[] = $data['sequenceNo'];         //sequence number
    $params[] = $data['headId'];
    $params[] = $data['finYearCode'];
    $params[] = $data['netPay'];
    $params[] = $data['benfAccNo'];
    $params[] = $data['detailTransId'];
    $params[] = $data['benfAccType'];
    $params[] = $data['recptSbTransType'];         //SB_TRANSTYPE  From SB_TRANSTYPE
    $params[] = $data['currentTimestamp'];
    $params[] = $data['benfName'];
    $params[] = 'Y';
    $params[] = 1;
    $params[] = $data['remark'];
    $params[] = $data['currentDate'];
    $params[] = 'Y';
    $params[] = $data['newBenfScrtBal'];
    $params[] = $data['newBenfLedgerBal'];
    $params[] = $data['seqDate'];
    $params[] = $data['paymentSeqNo'];
    try{
      $insert = $this->execute_query($insertQuery, $params);
      return true;
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
  }
    /**
   * Transfer Type Other Bank
   * Get Row Id from ONLINE_AMT_TRANSFER_DETAIL
   * Get Count of row  in TSBONLINE_FUND_TRANSFER_EKUBER using rowId
   * Get Count of row   in TSB_TO_BANK using row id
   * @param Data $data
   */

  public function coreTsbRows($transactionId) {
    $query = 'SELECT ROWID FROM ONLINE_AMT_TRANSFER_DETAIL WHERE TRANS_ID=? ';
    $params = array();
    $params[] = $transactionId;
    try{
      $rowid = $this->execute_query($query, $params)->fetchColumn();

    }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
    }
    return ($rowid)? $rowid : null;
  }

  public function getFinYearCode() {
    $query = 'SELECT FINYR_CD FROM FINYR WHERE CURRENT_DATE BETWEEN DATE_FROM AND DATE_TO';
    try{
      $fin_year_code = $this->execute_query($query)->fetchAll();
    }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
    if(count($fin_year_code)==0){
      return null;
    }else{
      return array_pop($fin_year_code);
    }
  }

  public function getSbTransType($data) {
    $query = 'SELECT SB_TRANSTYPE,DESC_ABBR FROM SB_TRANSTYPE WHERE SB_TRANSTYPE=?';
    $params = array();
    $params[] = $data;
    try{
      $sb_transtype = $this->execute_query($query, $params)->fetchAll();
    }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
    if(count($sb_transtype)==0){
      return null;
    }else{
     return array_pop($sb_transtype);
    }

  }

  public function coreTsbRowsCount($rowId) {
    $query = 'SELECT count(ROWID) AS ROWIDCNT FROM TSBONLINE_FUND_TRANSFER_EKUBER WHERE ROWID = ?  ';
    $params = array();
    $params[] = $rowId;
    try{
      $rowcount = $this->execute_query($query, $params)->fetchColumn();

    }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return $rowcount;

  }


/*
    $query = 'SELECT count(ROWID) AS ROWIDCNT FROM TSB_TO_BANK WHERE ROWID=? ';
    try{
      $pdoStmt = $coretis_connection->prepare($query);
      $pdoStmt->bindParam(1, $rowId);
      $pdoStmt->execute();
      $data = $pdoStmt->fetchColumn();
    }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
    }
    if(count($rowcount)==0){
      return null;
    }else{
     return array_pop($rowcount);
    }
  }
*/
    /**
   * Transfer Type Other Bank
   * Insert Data In Tsb Online Fund Transfer Ekuber(TSBONLINE_FUND_TRANSFER_EKUBER)
   * @param Data $data
   */

  public function insertTsbOnlineFundTransferEkuber($data) {
    $insertQuery = 'INSERT INTO TSBONLINE_FUND_TRANSFER_EKUBER ';
    $insertQuery .='(REF_TRANSACTION_ID,TRANSACTION_ID,TRANS_DATE,CREDIT_DATE,TSB_ACCNO,';
    $insertQuery .='BENEFICIARY_NAME,IFSCODE,BENIFFICIARY_ACCNO,NET_PAY,';
    $insertQuery .='MOBILE_NO,EPOC_CONFIRM,REMARKS,ROWID, REF_DAILY_SEQNO, REF_COUNTER_DATE)';
    $insertQuery .='VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $params = array();
    $params[] = $data['tsbTransactionId'];
    $params[] = $data['detailTransId'];
    $params[] = $data['currentDate'];
    $params[] = $data['currentDate'];
    $params[] = $data['accNo'];
    $params[] = $data['benfName'];
    $params[] = strtoupper($data['benfIfsc']);
    $params[] = $data['benfAccNo'];
    $params[] = $data['netPay'];
    $params[] = $data['mobile'];
    $params[] = 'Y';
    $params[] = $data['remark'];
    $params[] = $data['rowId'];
    $params[] = $data['paymentSeqNo'];
    $params[] = $data['seqDate'];

    try{
      $insert = $this->execute_query($insertQuery, $params);
      return true;
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
  }

    /**
   *
   * Update TSBONLINE_FUND_TRANSFER_EKUBER
   * @param Data $data
   */

  public function updateTsbOnlineFundTransferEkuber($transaction_id, $rowid) {
    $updateQuery = 'UPDATE TSBONLINE_FUND_TRANSFER_EKUBER SET TRANSACTION_ID=? WHERE ROWID=?  ';

    $params = array();
    $params[] = $transaction_id;
    $params[] = $rowid;
    try{
      $update = $this->execute_query($updateQuery, $params);

      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;
  }

    /**
   * Insert data in TSB_TO_BANK table (Coretis database)
   * @param Data $data
   */

  public function insertTsbToBank($data) {
    $coretis_connection = $this->getCoretisConnection();
    if(!$coretis_connection){
      return false;
    }
    $insertQuery = 'INSERT INTO TSB_TO_BANK ';
    $insertQuery .='( TRANSACTION_ID, TRANS_DATE, CREDIT_DATE, TSB_ACCNO, BENEFICIARY_NAME, IFSC, ';
    $insertQuery .='ACCOUNT_NO,NET_PAY, MOBILE_NO, EPOC_CONFIRM, EPOC_CONFIRM_DATE, ';
    $insertQuery .='REMARKS, ROWID, TRCODE, FROM_ONLINE, PROCESS_CNT ) ';
    $insertQuery .='VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $statement1 = $coretis_connection->prepare($insertQuery);
    $statement1->bindValue(1, $data['detailTransId'], \PDO::PARAM_INT);
    $statement1->bindValue(2, $data['currentDate']);
    $statement1->bindValue(3, $data['currentDate']);
    $statement1->bindValue(4, $data['accNo'], \PDO::PARAM_INT);
    $statement1->bindValue(5, $data['benfName']);
    $statement1->bindValue(6, $data['benfIfsc']);
    $statement1->bindValue(7, $data['benfAccNo']);
    $statement1->bindValue(8, $data['netPay'], \PDO::PARAM_INT);
    $statement1->bindValue(9, $data['mobile']);
    $statement1->bindValue(10, 'Y');
    $statement1->bindValue(11, $data['currentDate']);
    $statement1->bindValue(12, $data['remark']);
    $statement1->bindValue(13, $data['rowId']);
    $statement1->bindValue(14, $data['trCode']);
    $statement1->bindValue(15, 'Y');
    $statement1->bindValue(16, '1');


    	try{
      	$statement1->execute();
      }catch(Exception $e){
        var_dump($e->getMessage());
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;

  }



  public function getTransactionDetailsFromTsbToBank($transactionId) {

    $coretis_connection = $this->getCoretisConnection();

    if(!$coretis_connection){
      return false;
    }
    else{
      $query = 'SELECT * FROM TSB_TO_BANK WHERE TRANSACTION_ID=? ';
      $statement1 = $coretis_connection->prepare($query);
      $statement1->bindValue(1, $transactionId, \PDO::PARAM_INT);

      try{
        $statement1->execute();
        $result1 = $statement1->fetchAll(\PDO::FETCH_ASSOC);
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      if(count($result1)==0){
        return null;
      }else{
        return array_pop($result1);
      }
    }
}


    /**
   * Update data in TSB_TO_BANK table for rejection clear time(Coretis database)
   * @param Data $data
   */

  public function rejectionCleartsbToBank($data) {
    $coretis_connection = $this->getCoretisConnection();

    if(!$coretis_connection){
      return false;
    }
    else{
      $query = "UPDATE TSB_TO_BANK SET ACK_STATUS = null, DN_STATUS = null, RN_STATUS = null, CN_STATUS = null, ";
      $query .= " RECORD_PROCESSED = null, PROCESS_CNT = ?, BENEFICIARY_NAME = ?, ACCOUNT_NO = ?, IFSC = ?, ";
      $query .= "REMARKS = ?  WHERE TRANSACTION_ID = ?  ";
      $statement1 = $coretis_connection->prepare($query);
      $statement1->bindValue(1, $data['newProcessCount']);
      $statement1->bindValue(2, $data['benfName']);
      $statement1->bindValue(3, $data['accNo']);
      $statement1->bindValue(4, $data['ifsc']);
      $statement1->bindValue(5, $data['remark']);
      $statement1->bindValue(6, $data['transId']);
      try{
        $update =  $statement1->execute();

      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;

    }

  }

  /**
   * Update Data in TSBONLINE EKUBER Table
   * @param data as $data
   */

  public function rejectionClearTsbOnlineEkuber($data) {
    $updateQuery = 'UPDATE TSBONLINE_FUND_TRANSFER_EKUBER SET BENEFICIARY_NAME = ?,IFSCODE = ?, ';
    $updateQuery .= 'BENIFFICIARY_ACCNO = ?,REMARKS = ? WHERE TRANSACTION_ID=?  ';

    $params = array();
    $params[] = $data['benfName'];
    $params[] = $data['ifsc'];
    $params[]= $data['accNo'];
    $params[] = $data['remark'];
    $params[] = $data['transId'];
    try{
      $update = $this->execute_query($updateQuery, $params);

      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;
  }

  /**
   * Update Data in TSB ONLINE AMOUNT TRANSFER DETAILS Table
   * @param data as $data
   */

  public function rejectionClearOnlineAmountTransferDetails($data) {
    $updateQuery = 'UPDATE ONLINE_AMT_TRANSFER_DETAIL SET NAME = ?,IFSC = ?, ';
    $updateQuery .= 'BENEF_ACCNO = ?,REMARKS = ? WHERE TRANS_ID=?  ';

    $params = array();
    $params[] = $data['benfName'];
    $params[] = $data['ifsc'];
    $params[]= $data['accNo'];
    $params[] = $data['remark'];
    $params[] = $data['transId'];
    try{
      $update = $this->execute_query($updateQuery, $params);

      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return true;
  }


	/**
	 * Get fund transaction history form the customer id
	 * @param mixed $customer_id Customer id
	 * @return array on success and boolean false on failure
	 */
	public function getFundTransactionHistrory($customer_id){

		// select
		$sql = " SELECT PAYMT.PAYMT_AMT AS AMOUNT, PAYMT.TRANSACTION_DATE AS TRANS_DATE , PAYMT.SB_ACCNO AS SOURCE_ACCNO, ";
		$sql .= " PAYMT.TRANSACTION_ID AS TRANSACTION_ID , RECPT.ACCNO AS RECPT_DEST_ACCNO, ";
		$sql .= " EKUBER.BENIFFICIARY_ACCNO AS EKUBER_DEST_ACCNO, EKUBER.TRANSACTION_ID AS EKUBER_TRANS_ID, ";
		$sql .= " RECPT.TRANSACTION_DATE AS RECPT_RECEIVED_DATE, EKUBER.TRANS_DATE AS EKUBER_RECEIVED_DATE, 'NORMAL_DATA' AS TRANS_OPTION ";
		// from
		$sql .= " FROM SB_PAYMT_ONLINE  AS  PAYMT  LEFT JOIN TSB_CUSTOMER_ACCOUNT CUST_ACC  ON ( PAYMT.SB_ACCNO = CUST_ACC.ACCNO ) ";
		$sql .= " FULL OUTER  JOIN SB_RECPT_ONLINE AS RECPT ";
		$sql .= " ON ( PAYMT.DAILY_SEQNO = RECPT.REF_DAILY_SEQNO AND  PAYMT.TRANSACTION_DATE = RECPT.REF_COUNTER_DATE ) ";
		$sql .= " LEFT  JOIN TSBONLINE_FUND_TRANSFER_EKUBER AS EKUBER ON ( PAYMT.TRANSACTION_ID = EKUBER.REF_TRANSACTION_ID )  ";
		// where
		$sql .= " WHERE  CUST_ACC.CUSTOMER_ID  = ? AND PAYMT.TRANSACTION_DATE > CURRENT_DATE - 3 MONTHS  ";
		$sql .= " UNION SELECT SCHEDULE.AMOUNT AS AMOUNT, DATE(SCHEDULE.DATE) AS TRANS_DATE , SCHEDULE.ACC_NO AS SOURCE_ACCNO,  ";
		$sql .= " TRANSACTION_ID AS TRANSACTION_ID , BENF.BENEFICIARY_ACCNO AS RECPT_DEST_ACCNO, NULL, NULL, NULL, NULL, 'SL_DATA' AS TRANS_OPTION  ";
		$sql .= " FROM TSBONLINE_SCHEDULE AS SCHEDULE JOIN TSB_CUSTOMER_ACCOUNT CUST_ACC ON ( SCHEDULE.ACC_NO = CUST_ACC.ACCNO ) ";
		$sql .= " LEFT JOIN TSBONLINE_BENEFICIARYMASTER AS BENF ON ( BENF.BENEFICIARY_ID = SCHEDULE.BENEF_ID ) ";
		$sql .= " WHERE CUST_ACC.CUSTOMER_ID = ? AND SCHEDULE.PROCESS_STATUS = 'I' AND SCHEDULE.INITIATE_STATUS = 'I' AND SCHEDULE.PROCESS = 'SL' ORDER BY TRANS_DATE DESC ";

		// parameters
		$params = array($customer_id, $customer_id);

		try{
			$result = $this->execute_query($sql, $params)->fetchAll();
		}catch(Exception $e){
				var_dump($e->getMessage());
				return false;
		}
		return $result;
	}

	/**
	 * Get coretis Tsb to Bank Account numbers Transaction details from
	 * source account numbers
	 * @param array $account_numbers
	 * @return array on success and boolean false on failure
	 */
	public function getCoretisTsbToBankLast3MonthsTransFromSourceAccnos($account_numbers){

			$sql = " SELECT * FROM TSB_TO_BANK WHERE  TSB_ACCNO IN ( ";
			$sql .= implode(", ", array_fill(0, count($account_numbers), "?"));
			$sql .= " ) ";

			$coretis_connection = $this->getCoretisConnection();
			if(!$coretis_connection){
				return false;
			}

			try{
				$stmt = $coretis_connection->prepare($sql);
				$counter = 1;
				foreach($account_numbers as &$accno){
					$stmt->bindValue($counter, $accno);
					$counter++;
				}
				$stmt->execute();
				$result = $stmt->fetchAll();
			}catch(Exception $e){
				return false;
			}
			return $result;

	}

	public function coretisRows($rowId) {

	$coretis_connection = $this->getCoretisConnection();

	if(!$coretis_connection){
		return false;
	}
	else{
		$query = 'SELECT count(ROWID) AS ROWIDCNT FROM TSB_TO_BANK WHERE ROWID=? ';
		$statement1 = $coretis_connection->prepare($query);
		$statement1->bindValue(1, $rowId, \PDO::PARAM_INT);
		$statement1->execute();
		$result1 = $statement1->fetchAll(\PDO::FETCH_ASSOC);
		if ($result1) {
					$rowidCnt = $result1[0]['ROWIDCNT'];

					return $rowidCnt;
			}
			return $rowidCnt;
	}
}

}

?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends MY_Model{

    /**
     * User Name Exists
     * @param string $username
     * @throws PDOException
     */
    public function usernameExists($username){
        $sql = " SELECT COUNT(*) FROM TSBONLINE_PORTAL_USERS WHERE LOWER(USERNAME) = LOWER(?) ";
        $parama = array();
        $params[] = $username;
        $count = $this->execute_query($sql, $params)->fetchColumn();
        if($count > 0){
          return true;
        }
        return false;
    }

    /**
     * Get tsb user by CUSTOMER_ID
     * @param integer $customer_id
     * @return array if customer exists null if no customer boolean false if error
     */
     public function getUserByCustomerId($customer_id){
        $sql  = " SELECT * from TSBONLINE_PORTAL_USERS ";
        $sql .= " WHERE CUSTOMERID = ? ";
        $params = array();
        $params[] = $customer_id;
        try{
          $result = $this->execute_query($sql, $params)->fetchAll();
        }catch(Exception $e){
          $this->setError('Somthing went wrong' ,$e->getcode());
          return false;
        }
        return (!empty($result))? $result : null ;
     }

       

     /**
      *Save user
      * @param array $data
      * @return boolean true on succes and false on failure
      */
      public function saveUser($data){
        $sql = " INSERT INTO TSBONLINE_PORTAL_USERS ";
        $sql .= " ( CUSTOMERID, USERNAME, MOBILE, MOBILE_CANONICAL, ";
        $sql .= " EMAIL, EMAIL_CANONICAL, CHANGE_PASSWORD, TRANS_KEY_CHANGED, CONFIRM, ACTIVATED, REG_VIA_ONLINE ) VALUES ( ";
        $sql .= " ?, ?, ?, ?, ?, ?, 'Y', 'Y', 'N', 'N', 'Y' ) ";
        $params = array();
        $params[] = $data['customerId'];
        $params[] = $data['username'];
        $params[] = $data['mobileNo'];
        $params[] = $data['mobileNo'];
        $params[] = $data['email'];
        $params[] = $data['email'];
        try{
          $pdoStmt = $this->execute_query($sql, $params);
        }catch(Exception $e){
            return false;
        }
        if($pdoStmt){
          return true;
        }
      }

}

?>

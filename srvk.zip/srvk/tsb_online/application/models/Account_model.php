<?php
/*
 |------------------------------------------------------------------------------
 | ERROR CODES
 |------------------------------------------------------------------------------
 |
 |
 |
 |------------------------------------------------------------------------------
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Account_model extends MY_Model{

  /**
   * Account statement
   * @parma Array $data
   * @return array $output_data and boolean false on failure
   */
  public function getSbAccountSatement($data){
      $accountNumber = $data['accountNumber'];
      $periodeType = $data['periodeType'];
      $fromDate = $data['fromDate'];
      $toDate = $data['toDate'];
      $year = $data['year'];
      $month = $data['month'];

      // where condition in bydate
      if($periodeType=='byDate'){
        $startDate = $fromDate;
        $endDate = $toDate;
      }

      // where condition in by month
      if($periodeType=='byMonth'){
        $calculateDate = $year . "-" . $month . "-01";
        $lastDayofThemonth = date('Y-m-t', strtotime($calculateDate));
        $startDate = $calculateDate;
        $endDate = $lastDayofThemonth;
      }

      // where condition in last 3months
      if($periodeType=='lastThreeMonth'){
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime('-3 month'));
      }

      // where condition in last 6months
      if($periodeType=='lastSixMonth'){
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime('-6 month'));
      }

      $sql = 'SELECT A.REF_TRANSACTIONID AS REF_TRANSACTIONID , A.ACCNO, A.DT_ACC_DATE, A.PAYMT_AMT, A.RECPT_AMT, A.ACC_BALANCE, A.REMARKS,';
      $sql .= ' B.DESCRIPTION FROM V_SBPASSBOOK_ONLINE_PAID A LEFT JOIN SB_TRANSTYPE B ';
      $sql .= ' ON A.SB_TRANSTYPE=B.SB_TRANSTYPE WHERE ACCNO=? AND DT_ACC_DATE BETWEEN ? AND  ? ';
      $sql .= ' ORDER BY COUNTER_DATE DESC,BPO_INIT_SYSDATE DESC , BPO_INIT_DATE DESC , DAILY_SEQNO DESC ';
      $param_data = array();
      $param_data[] = $accountNumber;
      $param_data[] = $startDate;
      $param_data[] = $endDate;
      try{
        $result = $this->execute_query($sql, $param_data)->fetchAll();
      }catch(Exception $e){
          return false;
      }
      return $result;
  }


  /**
   * Get Fd account statement
   * @param mixed $account_number
   * @return array on success and boolean false on failure
   */
  public function getFdAccountSatement($account_number){
    $param_data = array();
    $sql = "SELECT * FROM FDAUTOINT_DET WHERE FD_ACCNO=? ORDER BY INT_FROM ";
    $param_data[] = $account_number;
    try{
      $result = $this->execute_query($sql, $param_data)->fetchAll();
    }catch(Exception $e){
        return false;
    }
    return $result;
  }


  /**
   * In customer account
   * Check given account number is in customer account list
   * @param mixed $acc_no,
   * @param mixed $customer_id
   * @return true if in customer account if not then return false
   * @throws Exception on query failure
   */
  public function inCustomerAccount($acc_no, $customer_id){
    $sql = " SELECT  COUNT(*) FROM TSB_CUSTOMER_ACCOUNT  ";
    $sql .= " WHERE CUSTOMER_ID = ? AND ACCNO = ? ";
    $params = array();
    $params[] = $customer_id;
    $params[] = $acc_no;
    try{
      $count = $this->execute_query($sql, $params)->fetchColumn();
    }catch(Exception $e){
      throw new Exception('somthing went wrong', $e->getCode());
    }
    if($count > 0){
      return true;
    }
    return false;
  }





  /**
   * Get account details
   * @param mixed account number
   * @return array on success return null on no data, return false on failure
   */
  public function getAccountDetails($acc_no){
    $sql = " SELECT * FROM TSB_ACCMAST FULL OUTER ";
    $sql .= " JOIN SB_ACCTYPE ON TSB_ACCMAST.ACCTYPE = SB_ACCTYPE.ACCTYPE ";
    $sql .= " FULL OUTER JOIN TSB_CUSTOMER_ACCOUNT ON TSB_CUSTOMER_ACCOUNT.ACCNO = TSB_ACCMAST.ACCNO ";
    $sql .= " FULL OUTER JOIN TSB_CUSTOMER_MAST ON TSB_CUSTOMER_MAST.CUSTOMER_ID = TSB_CUSTOMER_ACCOUNT.CUSTOMER_ID";
    $sql .= " FULL  OUTER JOIN TRMAST ON TSB_ACCMAST.BRANCH_TRCODE = TRMAST.TRCODE ";
    $sql .= " WHERE TSB_ACCMAST.ACCNO = ? ";
    $params = array();
    $params[] = $acc_no;
    try{
      $result = $this->execute_query($sql, $params)->fetchAll();
    }catch(Exception $e){
        $this->setError('Somthing went wrong', $e->getCode());
        return false;
    }
    if(count($result) > 0){
      return $result;
    }
    return null;
  }

  /**
   * Get customer accounts
   * @param initeger $customer_id
   * @return array  on success and boolean false on failure
   */
  
  public function getCustomerAccounts($customer_id){
      $sql = "SELECT * FROM TSB_CUSTOMER_ACCOUNT JOIN ";
      $sql .= " SB_ACCTYPE ON TSB_CUSTOMER_ACCOUNT.ACCTYPE = SB_ACCTYPE.ACCTYPE ";
      $sql .= " JOIN TSB_ACCMAST ON TSB_CUSTOMER_ACCOUNT.ACCNO = TSB_ACCMAST.ACCNO";
      $sql .= " JOIN TRMAST ON  TSB_ACCMAST.BRANCH_TRCODE = TRMAST.TRCODE ";
      $sql .= " WHERE TSB_CUSTOMER_ACCOUNT.CUSTOMER_ID = ? ";
      $params = array();
      $params[] = $customer_id;
      try{
        $resultSet = $this->execute_query($sql, $params)->fetchAll();
      }catch(Exception $e){
        $this->setError('Something went wrong', $e->getCode());
        return false;
      }
      return $resultSet;
  }

  /**
   * Get customer savings Accounts
   * @param integer $customer_id
   * @return array acconts on success and boolean false on failure
   */
  public function getCustomerSavingsAccounts($customer_id){
      $customerAccounts = $this->getCustomerAccounts($customer_id);
      if(is_array($customerAccounts)){
        $savingsAccount = [];
        $savingsAccount = array_filter($customerAccounts, function($k){
          return !in_array($k['ACCTYPE'], [5, 16]);
        });
        return $savingsAccount;
      }
      return false;
  }

  /**
   * Get customer Fixed Accounts
   * @param integer $customer_id
   * @return array acconts on success and boolean false on failure
   */
  public function getCustomerFdAccounts($customer_id){
      $customerAccounts = $this->getCustomerAccounts($customer_id);
      if(is_array($customerAccounts)){
        $FdAccount = array_filter($customerAccounts, function($k){
          return in_array($k['ACCTYPE'], [5]);
        });
        return $FdAccount;
      }
      return false;
  }


  public function test($data){
      echo "success";
      var_dump($data);
  }

  /**
   * Get account number head id
   * @param mixed $acc_type
   * @param mixed $category_code
   */
  public function getAccountHeadId($acc_type, $category_code){
    $sql = " SELECT HEAD_ID FROM SB_ACCTYPE_CATEGORY_HEAD ";
    $sql .= " WHERE CATEGORY_CODE = ? AND ACCTYPE = ? ";
    $params = array();
    $params[] = $acc_type;
    $params[] = $category_code;
    try{
      $acc_head = $this->execute_query($sql, $params)->fetchAll();
    }catch(Exception $e){
      $this->setError('Somthing went wrong', $e->getCode());
      return false;
    }
    if(count($acc_head) == 0){
        return null;
    }
    return isset($acc_head[0]['HEAD_ID']) ? $acc_head[0]['HEAD_ID'] : null;
  }

  /**
   * Get treasury information
   * @param mixed $tr_code treasury code
   * @return array on success null if no data boolean false on failure
   */
  public function getTreasuryInfo($tr_code){
      $sql = " SELECT * FROM TRMAST WHERE TRCODE = ? ";
      $params = array();
      $params[] = $tr_code;
      try{
        $result = $this->execute_query($sql, $params)->fetchAll();
      }catch(Exception $e){
        return false;
      }
      return array_pop($result);
  }





  /***************************************************************************
   Rejection clear Model
  ****************************************************************************/

public function getRejectedTransactionsByCustomerId($customer_id){

    $customer_accounts = $this->getCustomerAccounts($customer_id);
    if(!is_array($customer_accounts)){
      return false;
    }

    // Filter account number from the account deatils array
    $account_numbers = array_map( function($v){
      if(isset($v['ACCNO'])){
        return $v['ACCNO'];
      }
    }, $customer_accounts);
    // to call fund_transaction_model for coretis connection
    $this->load->model('fund_transaction_model');
    $coretis_connection = $this->fund_transaction_model->getCoretisConnection();
    if(!$coretis_connection){
      return false;
    }

    $sql = " SELECT * FROM TSB_TO_BANK WHERE TSB_ACCNO IN ( ";
    $sql .= implode(',' , array_map(function($v){ return '?'; }, $account_numbers));
    $sql .= " ) AND RECORD_PROCESSED = 'Y' AND FROM_ONLINE = 'Y' AND (ACK_STATUS='RJCT' OR RN_STATUS !='' OR CN_STATUS !='' OR DN_STATUS='RETURN' OR DN_STATUS='BANKAPIFAILED')";
    $statement = $coretis_connection->prepare($sql);
    $i=1;
    
    foreach($account_numbers as $acc_no){
      $statement->bindValue($i, $acc_no);
      $i++;
    }
    $statement->execute();
    $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
    if(!is_array($result)){
      return false;
    }
    return $result;
}



}
?>

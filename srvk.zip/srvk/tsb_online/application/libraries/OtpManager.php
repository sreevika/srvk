<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class OtpManager {
  // database connection instance
  private $_db;
  // error will be saved here
  private $_error;
  // cogeigineter instance
  private $_ci;
  // current otp
  private $_current_otp;
  // mobile number
  private $_mobile_number;
  // username
  private $_username;
  // otp id
  private $_otp_id;
  // otp attempt
  private $_attempt = 0;
  // success message
  private $_success_msg;

  // otp configuration values
  private $_config = [
    'otp_timeout' => 300,
    'otp_debug' => FALSE,
    'otp_debug_value' => '',
    'otp_purpose_code' => 'UNKNOWN'
  ];
  // data
  private $_data;
  /**
   * Php magic construct
   *
   */
  public function __construct(){
      $this->_ci =& get_instance();
      $this->_ci->load->library('session');
      //$this->_ci->load->config('app_config', true);
      $this->_db = new TsbApp\Util\Database\Database();
      $otp_config = $this->_ci->config->item('otp', 'app_config');
      $this->_max_otp_per_day = $otp_config['max_otp_per_day'];
  }

  /**
   * Generate Otp
   * @return integer
   */
  public function generateOtp(){
    $otp =  mt_rand(10000, 99999);
    $otp_usage = $this->getOptUsage();
    if($otp_usage === false){
      return false;
    }
    $this->_attempt = $otp_usage;
    if($this->_config['otp_debug']){
      $this->_current_otp = $this->_config['otp_debug_value'];
      return $this->_config['otp_debug_value'];
    }
    if($this->_attempt > $this->_max_otp_per_day ){
        $this->setError('Your Otp limit exceeded');
        return false;
    }

    $this->_current_otp = $otp;
    return $otp;
  }


  /**
   * Set mobile number
   * @param mixed
   */
  public function setMobileNumber($number){
    $this->_mobile_number = $number;
  }

  /**
   * Set username
   *
   */
   public function setUsername($username){
      $this->_username = $username;
   }


   /**
    * Set data
    * @param array
    */
   public function setData($data){
     $this->_data = $data;
   }

   public function getData(){
     return $this->_data;
   }




  /**
   * Set config
   * @param array $config
   * set configuration
   */
  public function setConfig($config){
    if(is_array($config)){
      $this->_config['otp_timeout'] = (isset($config['otp_timeout']))? $config['otp_timeout'] : (60 * 5);
      $this->_config['otp_debug'] = (isset($config['otp_debug']))? $config['otp_debug'] : FALSE;
      $this->_config['otp_debug_value'] = (isset($config['otp_debug_value']))? $config['otp_debug_value'] : '';
      $this->_config['otp_purpose_code'] = (isset($config['otp_purpose_code']))? $config['otp_purpose_code'] : 'UNKNOWN' ;
    }
  }




  /**
   * Create Message
   * @return string
   */
  public function createMessage(){
    $otp = $this->generateOtp();
    if($otp){
      $msg = "Your OTP is ";
      $msg .= $otp;
      $msg .= ". Do not share it with anyone by any means. ";
      $msg .= "This is confidential and to be used by you only.";
      return $msg;
    }
    return false;
  }

  /**
   * Set session
   * set data to session
   */
  public function setSession(){
    $session = array();
    $session['data'] = $this->_data;
    $session['config'] = $this->_config;
    $session['otp'] = $this->_current_otp;
    $session['otp_id'] = $this->_otp_id;
    $session['username'] = $this->_username;
    $session['mobile_no'] = $this->_mobile_number;
    $this->_ci->session->set_tempdata('otp_settings', $session, $this->_config['otp_timeout']);
  }

  /**
   * Save Otp to Database
   * @return boolean true on success and false on failure
   */
  public function saveOtpToDb(){

    $otp = $this->_current_otp;
    $purpose_code = $this->_config['otp_purpose_code'];
    $username = $this->_username;

    $db = new TsbApp\Util\Database\Database();
    $sql = " INSERT INTO TSBONLINE_OTP  ";
    $sql .= " ( OTP ,PURPOSE_CODE,CREATED_TIME,CREATED_BY ) ";
    $sql .= " VALUES ( ?, ?, ?, ?) ";

    $params = array();
    $params[] = $otp;
    $params[] = $purpose_code;
    $params[] = getDb2CurrentTimeStamp();
    $params[] = $username;
    try{
      $stmt = $this->_db->execute_query($sql, $params);
      $this->_otp_id = $this->_db->getConnection()->lastInsertId();
    }catch(Exception $e){
      $this->setError('something went wrong');
      return false;
    }
    return true;
  }


  public function getOptUsage(){
      $sql = " SELECT COUNT(*) FROM TSBONLINE_OTP WHERE CREATED_BY = ? ";
      $sql .= " AND DATE(CREATED_TIME) = CURRENT_DATE ";
      $params = array();
      $params[] = $this->_username;
      try{
        $count = $this->_db->execute_query($sql, $params)->fetchColumn();
      }catch(Exception $e){
        $this->setError('Somthing went wrong');
        return false;
      }
      return $count;
  }

  /**
   * SendOtp
   * @todo otp sending curl service
   */
   public function sendOtp($message){
     send_otp($this->_mobile_number, $message);
     return true;
   }


  /**
   * Process Otp
   */
  public function processOtp(){

    $message = $this->createMessage();
    if(!$message){
      return false;
    }
    $otp = $this->_current_otp;
    $mobile_number = $this->_mobile_number;
    $username = $this->_username;

    // insert to database
    $save_status = $this->saveOtpToDb();
    if(!$save_status){
      return false;
    }
    // send otp
    $status = $this->sendOtp($message);
    if(!$status){
      return false;
    }
    // add to session
    $this->setSession();
    return true;
  }

  /**
   * Load from session
   *
   */
  public function loadFromSession(){
    $otp_setting = $this->_ci->session->tempdata('otp_settings');
    /**
    echo "<pre>";
    var_dump($otp_setting);
    echo "</pre>";
    */
    if(!$otp_setting){
      $this->setError('Otp session timeout');
      return false;
    }
    // load session data to property
    $this->setConfig($otp_setting['config']);
    $this->_data = $otp_setting['data'];
    $this->_current_otp = $otp_setting['otp'];
    $this->_otp_id = $otp_setting['otp_id'];
    $this->_username = $otp_setting['username'];
    $this->_mobile_number = $otp_setting['mobile_no'];
    return true;
  }

  /**
   * Check Otp
   * @param mixed $otp
   * @return boolean true on success and false on failure
   */
  public function checkOtp($otp){
    if($this->_current_otp == $otp){
      return true;
    }
    $this->setError("Invalid Otp");
    return false;
  }

  /**
   * Vefiy Otp
   *
   */
  public function verifyOtp($otp){
    $load_from_sesson_status = $this->loadFromSession();
    // if no sesion data in session return false
    if(!$load_from_sesson_status){
      return false;
    }
    if(!$this->checkOtp($otp)){
        return false;
    }
    return true;
  }

  public function resendOtp(){
    $load_from_sesson_status = $this->loadFromSession();
    // if no sesion data in session return false
    if(!$load_from_sesson_status){
      $this->setError('Otp Session timeout');
      return false;
    }
    $message = $this->createMessage();
    if(!$message){
      return false;
    }
    // insert to database
    $save_status = $this->saveOtpToDb();
    if(!$save_status){
      return false;
    }
    // send otp
    $status = $this->sendOtp($message);
    if(!$status){
      return false;
    }
    // add to session
    $this->setSession();
    return true;

  }

  public function setError($error){
    $this->_error = $error;
  }

  public function getError(){
    return $this->_error;
  }

}

?>

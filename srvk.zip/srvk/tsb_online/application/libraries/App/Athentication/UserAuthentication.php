<?php
    /*
    |------------------------------------------------------------------------
    | Error codes
    |------------------------------------------------------------------------
    | AUTH_0000 : Invalid username ;
    |
    */
    /**
     * User Authintication
     * user authentication checker
     *
     */
    class UserAuthentication {
      public $user_model;
      public $username;
      public $password;
      private $_ci_instance;
      private $_auth_config;
      private $_auth_errors = [];


      /**
       * Php magic constructor
       * @param object $user_model , object $password_util
       */
      public function __construct($user_model, $password_util){
        $this->user_model = $user_model;
        $this->password_util = $password_util;
        $this->_ci_instance = get_instance();
        $this->_ci_instance->config->load("app_config", TRUE);
        $this->$_auth_config = $this->_ci_instance->item('authentication');
      }

      public function login($suername, $password){
        $this->username = $username;
        $this->password = $password;
        $this->_authenticateUser();
      }

      private function _authenticateUser(){

        $user = $this->user_model->getUserByUsername($username)
        if(!$user){
          $this->onAuthenticationFailure();
          $this->_auth_errors["errorcode"] =
          return false;
        }

        // check login limit if enabled
        if($this->_auth_config["login_limit"]["check"]){
            $this->_checkLoginLimit();
        }

        // verify password
        if($this->password_util->passwordVerify($this->password, $user->getPassword())){
          $this->onAuthenticationSuccess();
          return true;
        }
      }

      private function _checkLoginLimit(){
          $attempts = $this->user_model->getLoginAttempts();
          $limit = $this->_auth_config["login_limit"]['limit'];
          if($attempts > $limit){

          }
      }


      public function onAuthenticationSuccess(){

      }

      public function onAuthenticationFailure(){

      }


    }
?>
